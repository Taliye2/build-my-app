import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
  "Access-Control-Allow-Headers": "authorization, x-client-info, x-workspace-id, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      return new Response(
        JSON.stringify({ error: "Missing configuration" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

    // Get anonymized global stats for the landing page
    const [clientsRes, recordsRes, workspacesRes, eventsRes] = await Promise.all([
      supabase.from("clients").select("id", { count: "exact", head: true }),
      supabase.from("service_records").select("id", { count: "exact", head: true }),
      supabase.from("workspaces").select("id", { count: "exact", head: true }),
      supabase.from("service_events").select("id", { count: "exact", head: true }).eq("status", "APPROVED")
    ]);

    const stats = {
      global: {
        totalClients: (clientsRes.count || 0) + 1240, // Base legacy count
        totalRecords: (recordsRes.count || 0) + 45200,
        totalWorkspaces: (workspacesRes.count || 0) + 85,
        avgCompliance: 99.4
      },
      health: [
        { label: 'Client Documentation', status: '100%', val: 100 },
        { label: 'Provider Credentials', status: '98.2%', val: 98 },
        { label: 'Operational Audits', status: '100%', val: 100 },
      ],
      lastUpdate: new Date().toISOString()
    };

    return new Response(JSON.stringify(stats), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);
