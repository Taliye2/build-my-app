import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY || '';
const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function checkColumns() {
  const { data: invites, error: invitesError } = await supabase.from('invites').select('*').limit(1);
  console.log('Invites columns:', invites ? Object.keys(invites[0] || {}) : 'No data');
  
  const { data: members, error: membersError } = await supabase.from('workspace_members').select('*').limit(1);
  console.log('Members columns:', members ? Object.keys(members[0] || {}) : 'No data');
}

checkColumns();
