import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

async function processImage(src, dest, options = {}) {
  if (!fs.existsSync(src)) {
    console.error(`File not found: ${src}`);
    return;
  }

  const image = sharp(src);
  
  // Trim transparent space
  let pipeline = image.trim({ threshold: 10 });
  
  // Add a small margin
  pipeline = pipeline.extend({
    top: 5,
    bottom: 5,
    left: 5,
    right: 5,
    background: { r: 0, g: 0, b: 0, alpha: 0 }
  });

  if (options.resize) {
    pipeline = pipeline.resize(options.resize.width, options.resize.height, {
      fit: 'contain',
      background: { r: 0, g: 0, b: 0, alpha: 0 }
    });
  }

  await pipeline.toFile(dest);
  console.log(`Saved: ${dest}`);
}

async function main() {
  const brandDir = 'public/brand';
  if (!fs.existsSync(brandDir)) {
    fs.mkdirSync(brandDir, { recursive: true });
  }

  // Trim Logo
  await processImage(
    'public/brand/kafiskey-logo-20260120.png',
    'public/brand/kafiskey-logo-tight.png'
  );

  // Trim Favicon
  await processImage(
    'public/brand/kafiskey-favicon-source-20260120.png',
    'public/brand/kafiskey-favicon-tight.png'
  );

  // Generate Favicon sizes
  const faviconSource = 'public/brand/kafiskey-favicon-tight.png';
  
  // 16x16
  await sharp(faviconSource).resize(16, 16).toFile('public/favicon-16x16-20260120.png');
  // 32x32
  await sharp(faviconSource).resize(32, 32).toFile('public/favicon-32x32-20260120.png');
  // Apple Touch
  await sharp(faviconSource).resize(180, 180).toFile('public/apple-touch-icon-20260120.png');
  
  // .ico (requires specialized generation for multiple sizes, but sharp can do a single one or we use a buffer)
  // For simplicity, we'll just save the 32x32 as .ico or use a dedicated tool. 
  // Actually, sharp can't directly output .ico with multiple layers easily without more code.
  // We will just copy the 32x32 to .ico for now or just save it.
  await sharp(faviconSource).resize(32, 32).toFile('public/favicon-20260120.ico');

  console.log('All images processed successfully.');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
