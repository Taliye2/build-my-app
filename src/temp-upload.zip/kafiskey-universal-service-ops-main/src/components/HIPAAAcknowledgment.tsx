import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { ShieldCheck, X } from 'lucide-react';
import { toast } from 'sonner';

export const HIPAAAcknowledgment: React.FC = () => {
  const { user } = useAuth();
  const { activeWorkspace, activeMember } = useWorkspace();
  const [show, setShow] = useState(false);
  const [acknowledged, setAcknowledged] = useState(true);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAcknowledgment = async () => {
      if (!user || !activeWorkspace || !activeMember) {
        setLoading(false);
        return;
      }

      // Only Owners and Admins need to acknowledge
      if (activeMember.role !== 'OWNER' && activeMember.role !== 'ADMIN') {
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('hipaa_acknowledgments')
          .select('*')
          .eq('workspace_id', activeWorkspace.id)
          .eq('user_id', user.id)
          .maybeSingle();

        if (error) throw error;

        if (!data) {
          setAcknowledged(false);
          setShow(true);
        } else {
          setAcknowledged(true);
        }
      } catch (err) {
        console.error('Error checking HIPAA acknowledgment:', err);
      } finally {
        setLoading(false);
      }
    };

    checkAcknowledgment();
  }, [user, activeWorkspace, activeMember]);

  const handleAcknowledge = async () => {
    if (!user || !activeWorkspace) return;

    try {
      const { error } = await supabase
        .from('hipaa_acknowledgments')
        .upsert({
          workspace_id: activeWorkspace.id,
          user_id: user.id,
          acknowledged_at: new Date().toISOString()
        }, {
          onConflict: 'workspace_id, user_id'
        });

      if (error) throw error;

      setAcknowledged(true);
      setShow(false);
      toast.success('HIPAA responsibility acknowledged.');
    } catch (err: any) {
      console.error('Error acknowledging HIPAA responsibility:', err);
      toast.error('Failed to save acknowledgment: ' + err.message);
    }
  };

  if (loading || acknowledged || !show) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md animate-in fade-in slide-in-from-bottom-4 duration-500">
      <Alert className="border-primary/20 bg-card shadow-2xl">
        <ShieldCheck className="h-5 w-5 text-primary" />
        <AlertTitle className="text-primary font-bold">HIPAA Responsibility Acknowledgment</AlertTitle>
        <AlertDescription className="mt-2 space-y-4">
          <p className="text-sm text-muted-foreground leading-relaxed">
            I understand that this workspace may be configured to contain Protected Health Information (PHI) 
            and that I am responsible for using Kafiskey in compliance with organizational policies and HIPAA. 
            Kafiskey provides technical controls, while my organization remains the Covered Entity responsible 
            for configuration and compliance oversight.
          </p>
          <div className="flex items-center gap-2 pt-2">
            <Button size="sm" onClick={handleAcknowledge} className="w-full">
              I Acknowledge
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setShow(false)} title="Remind me later">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </AlertDescription>
      </Alert>
    </div>
  );
};
