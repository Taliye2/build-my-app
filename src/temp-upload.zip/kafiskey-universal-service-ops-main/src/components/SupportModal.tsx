import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { sendEmail } from '@/lib/emails';
import { toast } from 'sonner';
import { ShieldCheck, ExternalLink, Info } from 'lucide-react';
import { Link } from 'react-router-dom';

interface SupportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const SUPPORT_EMAIL = 'absame@lazimkey.com';

export const SupportModal: React.FC<SupportModalProps> = ({ open, onOpenChange }) => {
  const { user } = useAuth();
  const { activeWorkspace } = useWorkspace();
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    category: '',
    subject: '',
    message: '',
    email: user?.email || '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subject || !formData.message) {
      toast.error('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      const emailHtml = `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; rounded: 8px;">
          <h2 style="color: #0f172a; margin-bottom: 16px;">New Support Request</h2>
          <p><strong>Category:</strong> ${formData.category || 'Not specified'}</p>
          <p><strong>Subject:</strong> ${formData.subject}</p>
          <p><strong>From:</strong> ${formData.email}</p>
          <p><strong>Workspace:</strong> ${activeWorkspace?.name || 'N/A'} (${activeWorkspace?.id || 'N/A'})</p>
          <hr style="margin: 24px 0; border: none; border-top: 1px solid #e2e8f0;" />
          <div style="white-space: pre-wrap; color: #334155; line-height: 1.6;">
            ${formData.message}
          </div>
          <hr style="margin: 24px 0; border: none; border-top: 1px solid #e2e8f0;" />
          <p style="font-size: 12px; color: #64748b;">
            Sent at: ${new Date().toLocaleString()}<br />
            URL: ${window.location.href}
          </p>
        </div>
      `;

      if (activeWorkspace?.id) {
        await sendEmail({
          to: SUPPORT_EMAIL,
          subject: `[Support] ${formData.category ? formData.category + ' - ' : ''}${formData.subject}`,
          html: emailHtml,
          workspaceId: activeWorkspace.id,
          senderIdentity: 'transactional',
        });
        
        toast.success('Message sent. We’ll get back to you soon.');
        onOpenChange(false);
        setFormData({
          category: '',
          subject: '',
          message: '',
          email: user?.email || '',
        });
      } else {
        throw new Error('No active workspace found');
      }
    } catch (error) {
      console.error('Failed to send email via API, falling back to mailto:', error);
      
      // Fallback to mailto
      const mailtoSubject = encodeURIComponent(`[Support] ${formData.category ? formData.category + ' - ' : ''}${formData.subject}`);
      const mailtoBody = encodeURIComponent(
        `From: ${formData.email}\n` +
        `Category: ${formData.category || 'N/A'}\n` +
        `Workspace: ${activeWorkspace?.name || 'N/A'}\n` +
        `URL: ${window.location.href}\n` +
        `Timestamp: ${new Date().toLocaleString()}\n\n` +
        `Message:\n${formData.message}`
      );
      
      window.location.href = `mailto:${SUPPORT_EMAIL}?subject=${mailtoSubject}&body=${mailtoBody}`;
      
      toast.success('Opening your email client to send the message...');
      onOpenChange(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <div className="flex flex-col gap-6">
          <div className="space-y-4">
            <h4 className="text-sm font-medium uppercase tracking-wider text-muted-foreground">Compliance Resources</h4>
            <div className="grid gap-2">
              <Link 
                to="/compliance?tab=readiness" 
                onClick={() => onOpenChange(false)}
                className="flex items-center justify-between p-3 rounded-lg border bg-primary/5 dark:bg-primary/10 hover:bg-primary/10 dark:hover:bg-primary/20 transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <ShieldCheck className="h-5 w-5 text-primary" />
                  <div className="text-left">
                    <p className="text-sm font-bold leading-none">HIPAA Readiness</p>
                    <p className="text-[10px] text-muted-foreground mt-1">Platform safeguards and readiness checklists.</p>
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </Link>
              <Link 
                to="/compliance?tab=guidelines" 
                onClick={() => onOpenChange(false)}
                className="flex items-center justify-between p-3 rounded-lg border bg-muted/20 hover:bg-muted/30 transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <Info className="h-5 w-5 text-muted-foreground" />
                  <div className="text-left">
                    <p className="text-sm font-bold leading-none">Privacy Guidelines</p>
                    <p className="text-[10px] text-muted-foreground mt-1">General operational safeguards and PHI policies.</p>
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </Link>
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            <DialogHeader>
              <DialogTitle>Contact Support</DialogTitle>
              <DialogDescription>
                Need help? Fill out the form below and our team will get back to you as soon as possible.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="email">Your Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="your@email.com"
                  readOnly={!!user?.email}
                  className={user?.email ? 'bg-muted' : ''}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="category">Category (Optional)</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Bug">Bug</SelectItem>
                    <SelectItem value="Billing">Billing</SelectItem>
                    <SelectItem value="Feature Request">Feature Request</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="subject">Subject <span className="text-destructive">*</span></Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="How can we help?"
                  required
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="message">Message <span className="text-destructive">*</span></Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Please provide as much detail as possible..."
                  rows={5}
                  required
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? 'Sending...' : 'Send Message'}
              </Button>
            </DialogFooter>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};
