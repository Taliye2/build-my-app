import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, LayoutDashboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

export const AccessDenied: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="flex h-[calc(100vh-10rem)] items-center justify-center p-4">
      <Card className="max-w-md w-full border-destructive/20 shadow-lg">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-destructive/10">
            <ShieldAlert className="h-10 w-10 text-destructive" />
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight">Access Denied</CardTitle>
          <CardDescription className="text-base mt-2">
            You don't have permission to view this page.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center text-muted-foreground pb-6">
          <p>This resource is restricted to workspace administrators or managers. Please contact your administrator if you believe this is an error.</p>
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
          <Button 
            variant="outline" 
            className="w-full gap-2" 
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4" />
            Go Back
          </Button>
          <Button 
            className="w-full gap-2" 
            onClick={() => navigate('/')}
          >
            <LayoutDashboard className="h-4 w-4" />
            Go to Dashboard
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};
