import React, { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';

const TIMEOUT_DURATION = 20 * 60 * 1000; // 20 minutes
const WARNING_DURATION = 60 * 1000; // 60 seconds warning

export const InactivityTimer: React.FC = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [showWarning, setShowWarning] = useState(false);
  const [lastActivity, setLastActivity] = useState(Date.now());

  const handleLogout = useCallback(async () => {
    try {
      await signOut();
      setShowWarning(false);
      toast.info('Session expired due to inactivity');
      navigate('/auth');
    } catch (error) {
      console.error('Error during inactivity logout:', error);
    }
  }, [signOut, navigate]);

  const resetTimer = useCallback(() => {
    setLastActivity(Date.now());
    if (showWarning) {
      setShowWarning(false);
    }
  }, [showWarning]);

  useEffect(() => {
    if (!user) return;

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    
    const handler = () => resetTimer();
    
    events.forEach(event => {
      window.addEventListener(event, handler);
    });

    const interval = setInterval(() => {
      const now = Date.now();
      const timeSinceLastActivity = now - lastActivity;

      if (timeSinceLastActivity >= TIMEOUT_DURATION) {
        handleLogout();
      } else if (timeSinceLastActivity >= TIMEOUT_DURATION - WARNING_DURATION) {
        if (!showWarning) {
          setShowWarning(true);
        }
      }
    }, 5000); // Check every 5 seconds

    return () => {
      events.forEach(event => {
        window.removeEventListener(event, handler);
      });
      clearInterval(interval);
    };
  }, [user, lastActivity, handleLogout, resetTimer, showWarning]);

  return (
    <AlertDialog open={showWarning} onOpenChange={setShowWarning}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Session Expiring</AlertDialogTitle>
          <AlertDialogDescription>
            Your session is about to expire due to inactivity. Would you like to stay signed in?
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogAction onClick={resetTimer}>Stay Signed In</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
