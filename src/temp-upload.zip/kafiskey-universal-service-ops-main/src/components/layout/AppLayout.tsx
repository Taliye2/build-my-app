import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { clsx } from 'clsx';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import {
  LayoutDashboard,
  Users,
  Clock,
  Briefcase,
  FileText,
  Calendar,
  CreditCard,
  Settings,
  Menu,
  ChevronDown,
  LogOut,
  User as UserIcon,
  ShieldCheck,
  Plus,
  UserSquare2,
  Contact2,
  Wallet,
  BarChart3,
  Users2,
  MessageSquare,
  HelpCircle,
  Mail,
  AlertTriangle,
  Lock,
  Layers
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  useSidebar
} from '@/components/ui/sidebar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SupportModal } from '@/components/SupportModal';
import { BrandLogo } from '@/components/BrandLogo';
import { InactivityTimer } from './InactivityTimer';
import { HIPAAAcknowledgment } from '@/components/HIPAAAcknowledgment';

const SidebarLogo: React.FC = () => {
  const { state } = useSidebar();
  const isCollapsed = state === 'collapsed';

  return (
    <Link to="/" className="flex items-center hover:opacity-80 transition-smooth w-full">
      <BrandLogo variant="sidebar" isCollapsed={isCollapsed} />
    </Link>
  );
};

export const AppLayout: React.FC = () => {
  const { user, signOut, impersonatedWorkspaceId, setImpersonatedWorkspaceId } = useAuth();
  const { workspaces, activeWorkspace, setActiveWorkspaceId, activeMember, isLocked, isTrialActive, trialDaysRemaining, hasBillingAccess, hasAdvancedReporting } = useWorkspace();
  const [supportOpen, setSupportOpen] = React.useState(false);
  const location = useLocation();

  const isPaid = activeWorkspace?.plan_status === 'active' || activeWorkspace?.access_state === 'ACTIVE_PAID';
  // Use trial state from context
  const isPendingPayment = !isPaid && !isTrialActive;

  const showBanner = (activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN') && 
    !isPaid &&
    isTrialActive &&
    trialDaysRemaining !== null && trialDaysRemaining <= 7 && trialDaysRemaining >= 0;

  const showImpersonationBanner = !!impersonatedWorkspaceId;

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/', disabled: isPendingPayment },
    { 
      icon: Clock, 
      label: 'Queue', 
      path: '/queue', 
      disabled: isPendingPayment,
      roles: ['OWNER', 'ADMIN', 'MANAGER']
    },
    { icon: Users, label: 'Clients', path: '/clients', disabled: isPendingPayment },
    { 
      icon: UserSquare2, 
      label: 'Providers', 
      path: '/providers', 
      disabled: isPendingPayment,
      roles: ['OWNER', 'ADMIN', 'MANAGER']
    },
    { icon: Contact2, label: 'Contacts', path: '/contacts', disabled: isPendingPayment },
    { 
      icon: ShieldCheck, 
      label: 'Compliance', 
      path: '/compliance', 
      disabled: isPendingPayment,
      roles: ['OWNER', 'ADMIN', 'MANAGER', 'READ_ONLY']
    },
    { icon: Briefcase, label: 'Services', path: '/services', disabled: isPendingPayment },
    { 
      icon: Layers, 
      label: 'Programs', 
      path: '/programs', 
      disabled: isPendingPayment || !hasAdvancedReporting,
      roles: ['OWNER', 'ADMIN', 'MANAGER'],
      plan: 'Scale'
    },
    { 
      icon: Wallet, 
      label: 'Payroll', 
      path: '/payroll', 
      disabled: isPendingPayment || !hasAdvancedReporting,
      roles: ['OWNER', 'ADMIN', 'MANAGER'],
      plan: 'Scale'
    },
    { icon: CreditCard, label: 'Billing', path: '/billing', disabled: false },
    { 
      icon: BarChart3, 
      label: 'Analytics', 
      path: '/analytics', 
      disabled: isPendingPayment || !hasAdvancedReporting,
      roles: ['OWNER', 'ADMIN', 'MANAGER'],
      plan: 'Scale'
    },
    { 
      icon: Users2, 
      label: 'Team', 
      path: '/team', 
      disabled: isPendingPayment,
      roles: ['OWNER', 'ADMIN', 'MANAGER']
    },
    { icon: MessageSquare, label: 'Messaging', path: '/messaging', disabled: isPendingPayment },
    { 
      icon: Mail, 
      label: 'Email Templates', 
      path: '/email-templates', 
      disabled: isPendingPayment,
      roles: ['OWNER', 'ADMIN', 'MANAGER']
    },
    { 
      icon: Settings, 
      label: 'Settings', 
      path: '/settings', 
      disabled: isPendingPayment,
      roles: ['OWNER', 'ADMIN', 'MANAGER']
    },
  ];

  // Helper to check if user has role access
  const hasRoleAccess = (itemRoles?: string[]) => {
    if (!itemRoles || !activeMember) return true;
    return itemRoles.includes(activeMember.role);
  };

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U';
  };

  return (
    <SidebarProvider>
      <InactivityTimer />
      <HIPAAAcknowledgment />
      <div className="flex h-screen w-full overflow-hidden bg-background flex-col">
        {showImpersonationBanner && (
          <div className="bg-[#0f172a] text-white px-6 py-2 flex items-center justify-between text-sm font-medium z-50">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-[#2563eb]" />
              <span>
                Viewing workspace: <span className="text-[#2563eb] font-bold">{activeWorkspace?.name}</span> (Impersonation Mode)
              </span>
            </div>
            <Button 
              size="sm" 
              className="h-7 bg-[#2563eb] hover:bg-blue-600 text-white border-0"
              onClick={() => {
                setImpersonatedWorkspaceId(null);
                window.location.href = '/admin/organizations';
              }}
            >
              Stop Impersonating
            </Button>
          </div>
        )}
        <div className="flex flex-1 overflow-hidden">
          <Sidebar className="border-r">
            <SidebarHeader className="min-h-[104px] border-b flex items-center px-4 py-3 overflow-visible shrink-0">
              <SidebarLogo />
            </SidebarHeader>
            <SidebarContent>
              <SidebarGroup>
                <SidebarGroupLabel>Workspace</SidebarGroupLabel>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <SidebarMenuButton size="lg" className="w-full justify-between">
                          <div className="flex items-center gap-2 truncate">
                            <div className="flex h-6 w-6 items-center justify-center rounded bg-brand-gradient text-white text-xs font-bold">
                              {activeWorkspace?.name[0]}
                            </div>
                            <span className="truncate font-medium">{activeWorkspace?.name}</span>
                          </div>
                          <ChevronDown className="h-4 w-4 opacity-50" />
                        </SidebarMenuButton>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent className="w-56" align="start">
                        <DropdownMenuLabel>Switch Workspace</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        {workspaces.map((ws) => (
                          <DropdownMenuItem
                             key={ws.id}
                             onClick={() => setActiveWorkspaceId(ws.id)}
                             className="flex items-center justify-between group"
                          >
                            {ws.name}
                            {ws.id === activeWorkspace?.id && <ShieldCheck className="h-4 w-4 text-brand-blue" />}
                          </DropdownMenuItem>
                        ))}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link to="/onboarding" className="flex items-center gap-2">
                            <Plus className="h-4 w-4" />
                            Create New Workspace
                          </Link>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroup>

              <SidebarGroup>
                <SidebarGroupLabel>Main Menu</SidebarGroupLabel>
                <SidebarMenu>
                  {menuItems.map((item: any) => {
                    const roleAccess = hasRoleAccess(item.roles);
                    const isScaleFeature = item.plan === 'Scale';
                    const isGrowthFeature = item.plan === 'Growth';
                    
                    // In trial, Scale features are "Trial Preview" instead of restricted
                    const isTrialPreview = isTrialActive && (isScaleFeature || isGrowthFeature);
                    
                    const planRestricted = !isTrialPreview && item.plan && (
                      (isScaleFeature && !hasAdvancedReporting) || 
                      (isGrowthFeature && !hasBillingAccess)
                    );
                    
                    const isDisabled = item.disabled || planRestricted || !roleAccess;
                    const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
                    
                    return (
                      <SidebarMenuItem key={item.path}>
                        <SidebarMenuButton
                          asChild
                          isActive={isActive}
                          tooltip={
                            isDisabled && !roleAccess 
                              ? 'Admin access required' 
                              : isTrialPreview 
                                ? `Trial Preview: ${item.label}`
                                : (planRestricted ? `${item.plan} Tier Required` : item.label)
                          }
                          disabled={isDisabled}
                          className={clsx(
                            isDisabled ? 'opacity-50 cursor-not-allowed grayscale' : '',
                            isActive ? 'bg-brand-blue/5 dark:bg-brand-blue/10 text-brand-blue dark:text-brand-teal font-bold border-l-2 border-brand-blue rounded-none' : ''
                          )}
                        >
                          {isDisabled ? (
                            <div className="flex items-center justify-between w-full">
                              <div className="flex items-center gap-2 text-muted-foreground">
                                <item.icon className="h-4 w-4" />
                                <span>{item.label}</span>
                              </div>
                              {planRestricted && <Lock className="h-3 w-3 text-muted-foreground" />}
                            </div>
                          ) : (
                            <Link to={item.path} className="flex items-center justify-between w-full">
                              <div className="flex items-center gap-2">
                                <item.icon className={clsx("h-4 w-4", isActive ? "text-brand-blue" : "")} />
                                <span>{item.label}</span>
                              </div>
                              {isTrialPreview && (
                                <Badge variant="secondary" className="h-4 px-1 text-[10px] font-bold bg-brand-blue/10 text-brand-blue border-brand-blue/20">
                                  TRIAL
                                </Badge>
                              )}
                            </Link>
                          )}
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroup>
            </SidebarContent>
            <SidebarFooter className="border-t p-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start gap-2 px-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback>{getInitials(user?.user_metadata?.full_name || user?.email || '')}</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col items-start truncate text-xs">
                      <span className="font-medium truncate">{user?.user_metadata?.full_name || 'User'}</span>
                      <span className="text-muted-foreground truncate">{activeMember?.role || 'Staff'}</span>
                    </div>
                    <ChevronDown className="ml-auto h-4 w-4 opacity-50" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <UserIcon className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/logout" className="flex items-center w-full">
                      <LogOut className="mr-2 h-4 w-4" />
                      Sign Out
                    </Link>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
            <header className="h-16 border-b flex items-center justify-between px-6 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-30">
              <div className="flex items-center gap-4">
                <SidebarTrigger className="lg:hidden" />
                <div className="flex items-center gap-3">
                  <div className="w-1 h-6 bg-brand-gradient rounded-full" />
                  <h1 className="text-lg font-bold tracking-tight bg-brand-gradient bg-clip-text text-transparent">
                    {menuItems.find(item => (item.path !== '/' && location.pathname.startsWith(item.path)) || location.pathname === item.path)?.label || 'Dashboard'}
                  </h1>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setSupportOpen(true)}
                >
                  <HelpCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">Help</span>
                </Button>
              </div>
            </header>

            {showBanner && (
              <div className="bg-amber-50 dark:bg-amber-900/20 border-b border-amber-200 dark:border-amber-800/50 px-6 py-2 flex items-center justify-between text-amber-800 dark:text-amber-200 text-sm font-medium animate-in fade-in slide-in-from-top duration-500">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                  <span>
                    {trialDaysRemaining === 0 
                      ? "Your free trial ends today. Add payment to avoid interruption."
                      : `Your free trial ends in ${trialDaysRemaining} ${trialDaysRemaining === 1 ? 'day' : 'days'}. Add payment to avoid interruption.`}
                  </span>
                </div>
                <Button variant="outline" size="sm" className="h-7 text-xs border-amber-300 dark:border-amber-700 hover:bg-amber-100 dark:hover:bg-amber-900/40 hover:text-amber-900 dark:hover:text-amber-100" asChild>
                  <Link to="/billing/plan">Choose a plan</Link>
                </Button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto p-6">
              <div className="max-w-7xl mx-auto space-y-6">
                {isLocked && !location.pathname.startsWith('/billing') && !location.pathname.startsWith('/logout') ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center space-y-6 animate-in zoom-in duration-500">
                    <div className="h-20 w-20 rounded-full bg-muted flex items-center justify-center">
                      <Lock className="h-10 w-10 text-muted-foreground" />
                    </div>
                    <div className="space-y-2">
                      <h2 className="text-2xl font-bold tracking-tight">Your trial has ended</h2>
                      <p className="text-muted-foreground max-w-md mx-auto">
                        Your trial has ended. Choose a plan to continue using Kafiskey.
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4">
                      <Button size="lg" asChild>
                        <Link to="/billing/plan">Choose Monthly</Link>
                      </Button>
                      <Button size="lg" variant="secondary" asChild>
                        <Link to="/billing/plan">Choose Yearly</Link>
                      </Button>
                    </div>
                    <div className="pt-4">
                      <Button variant="ghost" size="sm" onClick={() => setSupportOpen(true)}>
                        Contact Support
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Outlet />
                )}
              </div>
            </div>
            <SupportModal open={supportOpen} onOpenChange={setSupportOpen} />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};
