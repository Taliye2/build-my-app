import React from 'react';
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

interface AddressFieldsProps {
  form: any;
  prefix?: string;
}

export const AddressFields: React.FC<AddressFieldsProps> = ({ form, prefix = '' }) => {
  const mailingSameAsPhysical = form.watch(`${prefix}mailing_same_as_physical`);

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <h4 className="text-sm font-medium">Physical Address</h4>
        <FormField
          control={form.control}
          name={`${prefix}street_address`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Street Address</FormLabel>
              <FormControl>
                <Input {...field} placeholder="123 Main St" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name={`${prefix}city`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>City</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="City" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name={`${prefix}state`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>State</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="State" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name={`${prefix}zip_code`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>Zip Code</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="Zip" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
      </div>

      <div className="flex items-center space-x-2 py-2 border-y border-border/50">
        <FormField
          control={form.control}
          name={`${prefix}mailing_same_as_physical`}
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm w-full">
              <div className="space-y-0.5">
                <FormLabel>Mailing Address</FormLabel>
                <div className="text-xs text-muted-foreground">
                  Is the mailing address the same as the physical address?
                </div>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />
      </div>

      {!mailingSameAsPhysical && (
        <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
          <h4 className="text-sm font-medium">Mailing Address</h4>
          <FormField
            control={form.control}
            name={`${prefix}mailing_street_address`}
            render={({ field }) => (
              <FormItem>
                <FormLabel>Mailing Street Address</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="PO Box or alternate street" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <div className="grid grid-cols-3 gap-4">
            <FormField
              control={form.control}
              name={`${prefix}mailing_city`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mailing City</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="City" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name={`${prefix}mailing_state`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mailing State</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="State" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name={`${prefix}mailing_zip_code`}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mailing Zip Code</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Zip" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
      )}
    </div>
  );
};
