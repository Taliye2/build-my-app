import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from 'sonner';
import { sendEmail } from '@/lib/emails';
import { useAuth } from '@/contexts/AuthContext';
import { Mail, Sparkles, Send } from 'lucide-react';

interface ComposeEmailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultRecipient?: string;
  clientName?: string;
  clientId?: string;
}

export const ComposeEmailDialog: React.FC<ComposeEmailDialogProps> = ({ 
  open, 
  onOpenChange, 
  defaultRecipient = '',
  clientName = '',
  clientId
}) => {
  const { activeWorkspace } = useWorkspace();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [templates, setTemplates] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    to: defaultRecipient,
    subject: '',
    body: ''
  });

  useEffect(() => {
    if (open && activeWorkspace) {
      fetchTemplates();
      setFormData(prev => ({ ...prev, to: defaultRecipient }));
    }
  }, [open, activeWorkspace, defaultRecipient]);

  const fetchTemplates = async () => {
    const { data } = await supabase
      .from('email_templates')
      .select('*')
      .eq('workspace_id', activeWorkspace?.id)
      .order('name');
    setTemplates(data || []);
  };

  const handleTemplateSelect = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      let body = template.body;
      let subject = template.subject;

      // Replace variables
      const vars: Record<string, string> = {
        workspace_name: activeWorkspace?.name || '',
        user_name: user?.user_metadata?.full_name || user?.email || '',
        client_name: clientName || 'there',
        action_link: `${window.location.origin}/dashboard`
      };

      Object.entries(vars).forEach(([key, val]) => {
        const regex = new RegExp(`{{${key}}}`, 'g');
        body = body.replace(regex, val);
        subject = subject.replace(regex, val);
      });

      setFormData({
        ...formData,
        subject,
        body
      });
    }
  };

  const handleSend = async () => {
    if (!activeWorkspace) return;
    if (!formData.to || !formData.subject || !formData.body) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      const result = await sendEmail({
        to: formData.to,
        subject: formData.subject,
        html: formData.body.replace(/\n/g, '<br>'), // Simple conversion for rich text
        workspaceId: activeWorkspace.id,
        userId: user?.id
      });

      if (result.success) {
        toast.success('Email sent successfully');
        onOpenChange(false);
      } else {
        throw new Error(result.error || 'Failed to send email');
      }
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Compose Email
          </DialogTitle>
          <DialogDescription>
            Send a direct email to a client or contact.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex-1 max-w-[200px]">
              <Label htmlFor="template" className="text-xs mb-1 block">Use Template</Label>
              <Select onValueChange={handleTemplateSelect}>
                <SelectTrigger id="template" className="h-8">
                  <SelectValue placeholder="Select a template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map(t => (
                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-muted-foreground">Sending as:</p>
              <p className="text-xs font-medium">
                {activeWorkspace?.email_sender_name || activeWorkspace?.name} 
                {` <${activeWorkspace?.email_sender_address || 'hello@kafiskey.com'}>`}
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="to">To</Label>
            <Input
              id="to"
              value={formData.to}
              onChange={(e) => setFormData({ ...formData, to: e.target.value })}
              placeholder="recipient@example.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              placeholder="Enter subject"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="body">Message</Label>
            <Textarea
              id="body"
              value={formData.body}
              onChange={(e) => setFormData({ ...formData, body: e.target.value })}
              placeholder="Write your message..."
              className="min-h-[250px]"
            />
          </div>
        </div>

        <DialogFooter className="flex items-center justify-between sm:justify-between">
          <p className="text-[10px] text-muted-foreground italic">
            Reply-to set to: {activeWorkspace?.email_reply_to || activeWorkspace?.email_sender_address || 'not set'}
          </p>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSend} disabled={loading}>
              <Send className="h-4 w-4 mr-2" />
              {loading ? 'Sending...' : 'Send Email'}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
