import React from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface BrandLogoProps {
  variant?: 'sidebar' | 'navbar' | 'auth' | 'icon';
  className?: string;
  isCollapsed?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ 
  variant = 'navbar', 
  className,
  isCollapsed = false
}) => {
  const logoUrl = "/brand/kafiskey-logo-tight.png";
  const iconUrl = "/brand/kafiskey-favicon-tight.png";

  const styles = {
    sidebar: {
      height: '72px',
      width: 'auto',
      maxWidth: '100%',
      objectFit: 'contain' as const,
      display: 'block'
    },
    navbar: {
      desktop: {
        height: '64px',
        width: 'auto',
        maxWidth: '360px',
        objectFit: 'contain' as const
      },
      mobile: {
        height: '48px',
        width: 'auto',
        objectFit: 'contain' as const
      }
    },
    auth: {
      height: '80px',
      width: 'auto',
      maxWidth: '400px',
      objectFit: 'contain' as const
    },
    icon: {
      height: '40px',
      width: '40px',
      objectFit: 'contain' as const,
      display: 'block'
    }
  };

  if (variant === 'icon' || (variant === 'sidebar' && isCollapsed)) {
    return (
      <img 
        src={iconUrl} 
        alt="Kafiskey Icon" 
        className={cn("shrink-0", className)}
        style={styles.icon}
      />
    );
  }

  if (variant === 'sidebar') {
    return (
      <img 
        src={logoUrl} 
        alt="Kafiskey Logo" 
        className={cn("shrink-0", className)}
        style={styles.sidebar}
      />
    );
  }

  if (variant === 'auth') {
    return (
      <img 
        src={logoUrl} 
        alt="Kafiskey Logo" 
        className={cn("mx-auto", className)}
        style={styles.auth}
      />
    );
  }

  // Navbar variant with responsive styles
  return (
    <div className={cn("flex-shrink-0 min-w-[240px]", className)}>
      {/* Desktop Logo */}
      <img 
        src={logoUrl} 
        alt="Kafiskey Logo" 
        className="hidden md:block"
        style={styles.navbar.desktop}
      />
      {/* Mobile Logo */}
      <img 
        src={logoUrl} 
        alt="Kafiskey Logo" 
        className="block md:hidden"
        style={styles.navbar.mobile}
      />
    </div>
  );
};
