import React from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';

interface TrialPreviewBannerProps {
  featureName?: string;
}

export const TrialPreviewBanner: React.FC<TrialPreviewBannerProps> = ({ featureName }) => {
  const { isTrialActive } = useWorkspace();

  if (!isTrialActive) return null;

  return (
    <Alert className="bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800/50 text-amber-900 dark:text-amber-200 mb-6">
      <AlertCircle className="h-4 w-4 text-amber-600 dark:text-amber-400" />
      <div className="flex flex-col sm:flex-row sm:items-center justify-between w-full gap-2">
        <div>
          <AlertTitle className="flex items-center gap-2">
            Trial Preview Mode
            <Badge variant="outline" className="bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-800/50 font-bold">SCALE FEATURE</Badge>
          </AlertTitle>
          <AlertDescription className="text-amber-800/80 dark:text-amber-300/80">
            {featureName ? `The ${featureName} feature is` : 'This feature is'} currently available for your evaluation during your free trial. 
            Once your trial ends, this feature will be restricted based on your chosen plan.
          </AlertDescription>
        </div>
      </div>
    </Alert>
  );
};
