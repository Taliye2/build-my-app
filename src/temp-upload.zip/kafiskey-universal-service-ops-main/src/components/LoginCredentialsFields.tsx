import React, { useState } from 'react';
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface LoginCredentialsFieldsProps {
  form: any;
  prefix?: string;
  isEdit?: boolean;
}

export const LoginCredentialsFields: React.FC<LoginCredentialsFieldsProps> = ({ form, prefix = '', isEdit = false }) => {
  const { activeMember } = useWorkspace();
  const [showPassword, setShowPassword] = useState(false);
  const isAdmin = activeMember && ['OWNER', 'ADMIN'].includes(activeMember.role);

  if (!isAdmin && isEdit) {
    return null;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Separator className="flex-1" />
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Portal Login (Optional)</span>
        <Separator className="flex-1" />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <FormField
          control={form.control}
          name={`${prefix}saved_username`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Saved Username</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Username for reference" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name={`${prefix}saved_password`}
          render={({ field }) => (
            <FormItem>
              <FormLabel>Saved Password</FormLabel>
              <FormControl>
                <div className="relative">
                  <Input 
                    type={showPassword ? "text" : "password"} 
                    {...field} 
                    placeholder="Password for reference" 
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      {isEdit && (
        <p className="text-[10px] text-muted-foreground italic">
          Credentials can only be managed by administrators.
        </p>
      )}
    </div>
  );
};
