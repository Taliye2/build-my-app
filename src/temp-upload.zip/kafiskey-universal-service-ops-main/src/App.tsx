import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { WorkspaceProvider, useWorkspace } from './contexts/WorkspaceContext';
import { AuthPage } from './pages/AuthPage';
import { ResetPasswordPage } from './pages/ResetPasswordPage';
import { OnboardingPage } from './pages/OnboardingPage';
import { AppLayout } from './components/layout/AppLayout';
import { RequireRole } from './components/layout/RequireRole';
import { ClientListPage } from './pages/clients/ClientListPage';
import { ClientProfilePage } from './pages/clients/ClientProfilePage';
import { ProvidersPage } from './pages/providers/ProvidersPage';
import { ProviderProfilePage } from './pages/providers/ProviderProfilePage';
import { ContactsPage } from './pages/contacts/ContactsPage';
import { ContactProfilePage } from './pages/contacts/ContactProfilePage';
import { ServicesPage } from './pages/services/ServicesPage';
import { ServiceRecordEditor } from './pages/documentation/ServiceRecordEditor';
import { PayrollPage } from './pages/payroll/PayrollPage';
import { BillingPage } from './pages/billing/BillingPage';
import { StripePlanPage } from './pages/billing/StripePlanPage';
import { LaunchpadPage } from './pages/billing/LaunchpadPage';
import { AnalyticsPage } from './pages/analytics/AnalyticsPage';
import { TeamPage } from './pages/team/TeamPage';
import { MessagingPage } from './pages/messaging/MessagingPage';
import { EmailTemplatesPage } from './pages/email-templates/EmailTemplatesPage';
import { SettingsPage } from './pages/settings/SettingsPage';
import { DashboardPage } from './pages/dashboard/DashboardPage';
import { CompliancePage } from './pages/compliance/CompliancePage';
import { ProgramsPage } from './pages/programs/ProgramsPage';
import { LandingPage } from './pages/LandingPage';
import { Toaster } from './components/ui/sonner';
import { ThemeProvider } from 'next-themes';
import { PrivacyPage } from './pages/legal/PrivacyPage';
import { LogoutPage } from './pages/LogoutPage';
import { QuickBooksCallbackPage } from './pages/QuickBooksCallbackPage';
import { CheckInPage } from './pages/CheckInPage';
import { QueuePage } from './pages/queue/QueuePage';

// Admin Imports
import { AdminLayout } from './pages/admin/AdminLayout';
import { AdminDashboardPage } from './pages/admin/AdminDashboardPage';
import { AdminOrganizationsPage } from './pages/admin/AdminOrganizationsPage';
import { AdminLeadsPage } from './pages/admin/AdminLeadsPage';
import { AdminSubscriptionsPage } from './pages/admin/AdminSubscriptionsPage';
import { AdminCampaignsPage } from './pages/admin/AdminCampaignsPage';
import { AdminSettingsPage } from './pages/admin/AdminSettingsPage';

const LoadingScreen: React.FC<{ message?: string }> = ({ message = "Loading..." }) => (
  <div className="flex min-h-screen items-center justify-center bg-background">
    <div className="flex flex-col items-center gap-4">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      <p className="text-sm text-muted-foreground">{message}</p>
    </div>
  </div>
);

const BootstrapGate: React.FC<{ children: React.ReactNode; requireAuth?: boolean }> = ({ children, requireAuth = true }) => {
  const { loading: authLoading, session } = useAuth();
  const { loading: workspaceLoading } = useWorkspace();

  if (authLoading || workspaceLoading) {
    return <LoadingScreen />;
  }

  if (requireAuth && !session) return <Navigate to="/auth" replace />;

  return <>{children}</>;
};

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { session } = useAuth();

  if (!session) return <Navigate to="/auth" replace />;

  return <>{children}</>;
};

const AdminProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { session, isSuperAdmin, loading } = useAuth();

  if (loading) return <LoadingScreen message="Verifying administrative access..." />;
  if (!session) return <Navigate to="/auth" replace />;
  if (!isSuperAdmin) return <Navigate to="/access-denied" replace />;

  return <>{children}</>;
};

const WorkspaceRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { activeWorkspace } = useWorkspace();
  const { isSuperAdmin } = useAuth();
  const location = useLocation();

  if (!activeWorkspace) return <Navigate to="/onboarding" replace />;

  // If workspace is not active or trialing, only allow the billing/plan page
  // Super admins bypass this check
  const isPaid = isSuperAdmin || ['active', 'trialing', 'trial'].includes(activeWorkspace.plan_status || '');
  const isBillingPlanPage = location.pathname === '/billing/plan';

  if (!isPaid && !isBillingPlanPage) {
    return <Navigate to="/billing/plan" replace />;
  }

  return <>{children}</>;
};

const OnboardingRoute: React.FC = () => {
  const { activeWorkspace } = useWorkspace();

  if (activeWorkspace) {
    return <Navigate to="/" replace />;
  }

  return <OnboardingPage />;
};

const HomeRoute: React.FC = () => {
  const { session } = useAuth();

  if (!session) return <LandingPage />;

  return (
    <WorkspaceRoute>
      <AppLayout />
    </WorkspaceRoute>
  );
};

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <AuthProvider>
        <WorkspaceProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/reset-password" element={<ResetPasswordPage />} />
              <Route path="/legal/privacy" element={<PrivacyPage />} />
              <Route path="/logout" element={<LogoutPage />} />
              <Route path="/check-in/:workspaceSlug" element={<CheckInPage />} />
              <Route path="/api/quickbooks/callback" element={<QuickBooksCallbackPage />} />
              
              {/* Super Admin Portal */}
              <Route path="/admin" element={
                <AdminProtectedRoute>
                  <AdminLayout />
                </AdminProtectedRoute>
              }>
                <Route index element={<AdminDashboardPage />} />
                <Route path="organizations" element={<AdminOrganizationsPage />} />
                <Route path="leads" element={<AdminLeadsPage />} />
                <Route path="subscriptions" element={<AdminSubscriptionsPage />} />
                <Route path="campaigns" element={<AdminCampaignsPage />} />
                <Route path="settings" element={<AdminSettingsPage />} />
              </Route>

              <Route path="/onboarding" element={
                <BootstrapGate>
                  <OnboardingRoute />
                </BootstrapGate>
              } />

              <Route path="/" element={
                <BootstrapGate requireAuth={false}>
                  <HomeRoute />
                </BootstrapGate>
              }>
                <Route index element={<DashboardPage />} />
                <Route path="clients" element={<ClientListPage />} />
                <Route path="clients/:clientId" element={<ClientProfilePage />} />
                <Route path="queue" element={<QueuePage />} />
                <Route path="providers" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <ProvidersPage />
                  </RequireRole>
                } />
                <Route path="providers/:providerId" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <ProviderProfilePage />
                  </RequireRole>
                } />
                <Route path="contacts" element={<ContactsPage />} />
                <Route path="contacts/:contactId" element={<ContactProfilePage />} />
                <Route path="compliance" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER', 'READ_ONLY']}>
                    <CompliancePage />
                  </RequireRole>
                } />
                <Route path="services" element={<ServicesPage />} />
                <Route path="programs" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <ProgramsPage />
                  </RequireRole>
                } />
                <Route path="documentation/edit/:eventId" element={<ServiceRecordEditor />} />
                <Route path="payroll" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <PayrollPage />
                  </RequireRole>
                } />
                <Route path="billing" element={<BillingPage />} />
                <Route path="billing/plan" element={<StripePlanPage />} />
                <Route path="billing/launchpad" element={<LaunchpadPage />} />
                <Route path="analytics" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <AnalyticsPage />
                  </RequireRole>
                } />
                <Route path="team" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <TeamPage />
                  </RequireRole>
                } />
                <Route path="messaging" element={<MessagingPage />} />
                <Route path="email-templates" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <EmailTemplatesPage />
                  </RequireRole>
                } />
                <Route path="settings" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <SettingsPage />
                  </RequireRole>
                } />
                <Route path="settings/integrations" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN', 'MANAGER']}>
                    <SettingsPage defaultTab="integrations" />
                  </RequireRole>
                } />
                <Route path="settings/compliance" element={
                  <RequireRole allowedRoles={['OWNER', 'ADMIN']}>
                    <SettingsPage defaultTab="compliance" />
                  </RequireRole>
                } />
              </Route>

              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </BrowserRouter>
          <Toaster position="top-right" richColors />
        </WorkspaceProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;