import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { 
  Clock, 
  MoreHorizontal, 
  Play, 
  CheckCircle2, 
  UserMinus, 
  Trash2, 
  RefreshCw,
  Search,
  Users,
  QrCode
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

type QueueStatus = 'waiting' | 'in_service' | 'done' | 'no_show';

interface QueueEntry {
  id: string;
  workspace_id: string;
  created_at: string;
  status: QueueStatus;
  first_name: string;
  last_name: string;
  phone: string;
  location_tag: string | null;
  source: string;
}

export const QueuePage: React.FC = () => {
  const { activeWorkspace, activeMember } = useWorkspace();
  const navigate = useNavigate();
  const [entries, setEntries] = useState<QueueEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>('waiting');
  const [searchQuery, setSearchQuery] = useState('');

  const canSeeFullPhone = activeMember && ['OWNER', 'ADMIN', 'MANAGER'].includes(activeMember.role);

  const fetchQueue = async () => {
    if (!activeWorkspace) return;
    
    setLoading(true);
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const { data, error } = await supabase
        .from('queue_entries')
        .select('*')
        .eq('workspace_id', activeWorkspace.id)
        .gte('created_at', today.toISOString())
        .order('created_at', { ascending: true });
        
      if (error) throw error;
      setEntries(data || []);
    } catch (err) {
      console.error('Error fetching queue:', err);
      toast.error('Failed to load queue');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchQueue();
    
    // Subscribe to changes
    const subscription = supabase
      .channel('queue_changes')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'queue_entries',
        filter: `workspace_id=eq.${activeWorkspace?.id}`
      }, () => {
        fetchQueue();
      })
      .subscribe();
      
    return () => {
      subscription.unsubscribe();
    };
  }, [activeWorkspace?.id]);

  const updateStatus = async (id: string, newStatus: QueueStatus) => {
    try {
      const { error } = await supabase
        .from('queue_entries')
        .update({ status: newStatus })
        .eq('id', id);
        
      if (error) throw error;
      toast.success(`Status updated to ${newStatus.replace('_', ' ')}`);
      fetchQueue();
    } catch (err) {
      console.error('Error updating status:', err);
      toast.error('Failed to update status');
    }
  };

  const deleteEntry = async (id: string) => {
    if (!window.confirm('Are you sure you want to remove this entry?')) return;
    
    try {
      const { error } = await supabase
        .from('queue_entries')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
      toast.success('Entry removed');
      fetchQueue();
    } catch (err) {
      console.error('Error deleting entry:', err);
      toast.error('Failed to remove entry');
    }
  };

  const maskPhone = (phone: string) => {
    if (canSeeFullPhone) return phone;
    const digits = phone.replace(/[^0-9]/g, '');
    if (digits.length < 4) return '***-***-****';
    const last4 = digits.slice(-4);
    return `***-***-${last4}`;
  };

  const filteredEntries = entries.filter(entry => {
    const matchesTab = entry.status === activeTab;
    const fullName = `${entry.first_name} ${entry.last_name}`.toLowerCase();
    const matchesSearch = fullName.includes(searchQuery.toLowerCase()) || 
                          entry.phone.includes(searchQuery);
    return matchesTab && matchesSearch;
  });

  const getStatusBadge = (status: QueueStatus) => {
    switch (status) {
      case 'waiting': return <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">Waiting</Badge>;
      case 'in_service': return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">In Service</Badge>;
      case 'done': return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Done</Badge>;
      case 'no_show': return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">No Show</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Check-In Queue</h1>
          <p className="text-muted-foreground">Manage today's walk-in visitors and check-ins.</p>
        </div>
        <div className="flex items-center gap-2">
          {activeMember && ['OWNER', 'ADMIN', 'MANAGER'].includes(activeMember.role) && (
            <Button variant="outline" size="sm" onClick={() => navigate('/settings?tab=check-in')}>
              <QrCode className="h-4 w-4 mr-2" />
              Get QR Code
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={fetchQueue} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full md:w-auto">
              <TabsList className="grid grid-cols-4 w-full md:w-auto">
                <TabsTrigger value="waiting" className="relative">
                  Waiting
                  {entries.filter(e => e.status === 'waiting').length > 0 && (
                    <Badge className="ml-2 h-5 w-5 p-0 flex items-center justify-center rounded-full bg-brand-blue">
                      {entries.filter(e => e.status === 'waiting').length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="in_service">In Service</TabsTrigger>
                <TabsTrigger value="done">Done</TabsTrigger>
                <TabsTrigger value="no_show">No Show</TabsTrigger>
              </TabsList>
            </Tabs>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search visitor..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-[100px]">Time</TableHead>
                  <TableHead>First Name</TableHead>
                  <TableHead>Last Name</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Loading queue...
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredEntries.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-40 text-center">
                      <div className="flex flex-col items-center justify-center text-muted-foreground">
                        <Users className="h-10 w-10 mb-2 opacity-20" />
                        <p>No visitors in this status.</p>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredEntries.map((entry) => (
                    <TableRow key={entry.id} className="group hover:bg-muted/30 transition-colors">
                      <TableCell className="font-medium text-xs">
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {format(new Date(entry.created_at), 'h:mm a')}
                        </div>
                      </TableCell>
                      <TableCell className="font-semibold">{entry.first_name}</TableCell>
                      <TableCell className="font-semibold">{entry.last_name}</TableCell>
                      <TableCell className="font-mono text-xs">{maskPhone(entry.phone)}</TableCell>
                      <TableCell>
                        {entry.location_tag ? (
                          <Badge variant="secondary" className="text-[10px] font-mono px-1.5 py-0 uppercase">
                            {entry.location_tag}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground italic text-xs">None</span>
                        )}
                      </TableCell>
                      <TableCell>{getStatusBadge(entry.status)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            
                            {entry.status === 'waiting' && (
                              <DropdownMenuItem onClick={() => updateStatus(entry.id, 'in_service')}>
                                <Play className="mr-2 h-4 w-4 text-blue-600" />
                                Start Service
                              </DropdownMenuItem>
                            )}
                            
                            {(entry.status === 'waiting' || entry.status === 'in_service') && (
                              <DropdownMenuItem onClick={() => updateStatus(entry.id, 'done')}>
                                <CheckCircle2 className="mr-2 h-4 w-4 text-green-600" />
                                Mark Done
                              </DropdownMenuItem>
                            )}
                            
                            {(entry.status === 'waiting' || entry.status === 'in_service') && (
                              <DropdownMenuItem onClick={() => updateStatus(entry.id, 'no_show')}>
                                <UserMinus className="mr-2 h-4 w-4 text-amber-600" />
                                Mark No Show
                              </DropdownMenuItem>
                            )}

                            {entry.status !== 'waiting' && (
                              <DropdownMenuItem onClick={() => updateStatus(entry.id, 'waiting')}>
                                <Clock className="mr-2 h-4 w-4 text-slate-600" />
                                Move to Waiting
                              </DropdownMenuItem>
                            )}
                            
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              onClick={() => deleteEntry(entry.id)}
                              className="text-red-600 focus:text-red-600 focus:bg-red-50"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const Loader2 = ({ className }: { className?: string }) => (
  <RefreshCw className={`animate-spin ${className}`} />
);
