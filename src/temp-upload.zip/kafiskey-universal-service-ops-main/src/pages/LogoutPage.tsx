import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { logAudit } from '@/lib/audit';

export const LogoutPage: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const handleLogout = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        const activeWorkspaceId = localStorage.getItem('activeWorkspaceId');
        
        if (user && activeWorkspaceId) {
          // Log logout before signing out
          await logAudit(activeWorkspaceId, user.id, 'LOGOUT', 'auth', user.id);
        }
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
        toast.success('Successfully logged out');
        navigate('/auth', { replace: true });
      } catch (error: any) {
        console.error('Logout error:', error);
        toast.error('Failed to log out');
        navigate('/', { replace: true });
      }
    };

    handleLogout();
  }, [navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        <p className="text-sm text-muted-foreground">Logging out...</p>
      </div>
    </div>
  );
};
