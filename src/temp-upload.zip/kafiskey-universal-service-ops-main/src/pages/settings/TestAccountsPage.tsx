import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Copy, LogIn, Shield, Users, Building } from 'lucide-react';

interface TestUser {
  email: string;
  role: string;
  workspace_name: string;
  workspace_id: string;
}

export const TestAccountsPage: React.FC = () => {
  const { user } = useAuth();
  const { activeWorkspace } = useWorkspace();
  const [testUsers, setTestUsers] = useState<TestUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTestUsers = async () => {
      try {
        setLoading(true);
        // We fetch from workspace_members joined with workspaces and auth.users (via staff_profiles since we can't join auth.users directly)
        const { data, error } = await supabase
          .from('workspace_members')
          .select(`
            role,
            workspace_id,
            workspaces (name),
            user_id
          `)
          .order('workspace_id');

        if (error) throw error;

        // Since we can't join auth.users directly, we'll fetch the emails separately for test users
        // For security, we'll only show users that have 'is_test' in their meta_data if possible
        // But since we can't query auth.users easily from client, we'll infer from staff_profiles email if available or just list the ones we created
        
        const { data: staffData, error: staffError } = await supabase
          .from('staff_profiles')
          .select('user_id, email, full_name')
          .filter('email', 'like', '%@kafiskey.test');

        if (staffError) throw staffError;

        const combined: TestUser[] = data
          .map((m: any) => {
            const profile = staffData.find((p: any) => p.user_id === m.user_id);
            if (!profile) return null;
            return {
              email: profile.email || `${m.role.toLowerCase()}+${m.workspace_id.slice(0,1)}@kafiskey.test`,
              role: m.role,
              workspace_name: m.workspaces?.name || 'Unknown',
              workspace_id: m.workspace_id
            };
          })
          .filter(Boolean) as TestUser[];

        setTestUsers(combined);
      } catch (error: any) {
        console.error('Error fetching test users:', error);
        toast.error('Failed to load test accounts');
      } finally {
        setLoading(false);
      }
    };

    fetchTestUsers();
  }, []);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  const handleSwitchAccount = async (email: string) => {
    toast.loading('Logging out and switching...');
    await supabase.auth.signOut();
    window.location.href = `/auth?email=${encodeURIComponent(email)}`;
  };

  if (loading) return <div className="p-8 text-center">Loading test accounts...</div>;

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">RBAC Test Accounts</h1>
          <p className="text-muted-foreground">Verify permissions by logging in as different roles across workspaces.</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-medium border border-amber-200">
          <Shield className="h-3 w-3" />
          Dev/Test Mode Only
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Available Test Users
            </CardTitle>
            <CardDescription>
              Use these credentials to test role-based access. Password for all: <strong>TestPass!2026</strong>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Workspace</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {testUsers.map((testUser, idx) => (
                  <TableRow key={idx}>
                    <TableCell className="font-medium flex items-center gap-2">
                      <Building className="h-4 w-4 text-muted-foreground" />
                      {testUser.workspace_name}
                    </TableCell>
                    <TableCell>
                      <Badge variant={testUser.role === 'OWNER' ? 'default' : testUser.role === 'STAFF' ? 'secondary' : 'outline'}>
                        {testUser.role}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{testUser.email}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button variant="ghost" size="icon" onClick={() => copyToClipboard(testUser.email, 'Email')}>
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleSwitchAccount(testUser.email)}>
                        <LogIn className="h-4 w-4 mr-2" />
                        Details
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Testing Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div className="space-y-2">
              <p className="font-bold">1. Multi-Tenancy</p>
              <p className="text-muted-foreground">Try logging in to Agency A and verifying you cannot see any data from Agency B.</p>
            </div>
            <div className="space-y-2">
              <p className="font-bold">2. Staff Permissions</p>
              <p className="text-muted-foreground">Staff should only see clients they have worked with (linked via service events).</p>
            </div>
            <div className="space-y-2">
              <p className="font-bold">3. Approval Workflow</p>
              <p className="text-muted-foreground">Log in as Staff to submit an event, then as Manager to approve or reject it.</p>
            </div>
            <div className="p-4 bg-muted rounded-lg border border-dashed text-xs">
              <p className="font-mono">Common Password:</p>
              <p className="font-bold text-lg mt-1">TestPass!2026</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
