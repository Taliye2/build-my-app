import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Trash2, Mail, Users, Settings2, Sparkles, Send } from 'lucide-react';
import { toast } from 'sonner';
import { Campaign } from './CampaignsTab';
import { sendEmail } from '@/lib/emails';
import { useAuth } from '@/contexts/AuthContext';

interface Sequence {
  id?: string;
  sequence_order: number;
  delay_days: number;
  subject: string;
  body_html: string;
  enabled: boolean;
}

interface CampaignDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  campaign?: Campaign;
  onSuccess: () => void;
}

export const CampaignDialog: React.FC<CampaignDialogProps> = ({ open, onOpenChange, campaign, onSuccess }) => {
  const { activeWorkspace } = useWorkspace();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState('');
  const [type, setType] = useState<Campaign['campaign_type']>('onboarding');
  const [senderIdentity, setSenderIdentity] = useState<Campaign['sender_identity']>('transactional');
  const [audienceRules, setAudienceRules] = useState({
    workspace_role: [] as string[],
    workspace_state: [] as string[],
    account_age_days: 0,
    feature_flags: {
      billing_enabled: false,
      services_configured: false,
      docs_approved: false
    }
  });
  const [sequences, setSequences] = useState<Sequence[]>([]);

  useEffect(() => {
    if (campaign) {
      setName(campaign.name);
      setType(campaign.campaign_type);
      setSenderIdentity(campaign.sender_identity);
      setAudienceRules(campaign.audience_rules || {
        workspace_role: [],
        workspace_state: [],
        account_age_days: 0,
        feature_flags: { billing_enabled: false, services_configured: false, docs_approved: false }
      });
      fetchSequences(campaign.id);
    } else {
      resetForm();
    }
  }, [campaign, open]);

  const resetForm = () => {
    setName('');
    setType('onboarding');
    setSenderIdentity('transactional');
    setAudienceRules({
      workspace_role: [],
      workspace_state: [],
      account_age_days: 0,
      feature_flags: { billing_enabled: false, services_configured: false, docs_approved: false }
    });
    setSequences([]);
  };

  const fetchSequences = async (campaignId: string) => {
    const { data, error } = await supabase
      .from('campaign_sequences')
      .select('*')
      .eq('campaign_id', campaignId)
      .order('sequence_order', { ascending: true });

    if (error) {
      toast.error('Failed to fetch sequences');
    } else {
      setSequences(data || []);
    }
  };

  const handleSave = async () => {
    if (!activeWorkspace) return;
    if (!name) {
      toast.error('Campaign name is required');
      return;
    }

    setLoading(true);
    try {
      let campaignId = campaign?.id;

      if (campaignId) {
        const { error } = await supabase
          .from('campaigns')
          .update({
            name,
            campaign_type: type,
            sender_identity: senderIdentity,
            audience_rules: audienceRules,
            updated_at: new Date().toISOString()
          })
          .eq('id', campaignId);
        
        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('campaigns')
          .insert({
            workspace_id: activeWorkspace.id,
            name,
            campaign_type: type,
            sender_identity: senderIdentity,
            audience_rules: audienceRules,
            status: 'draft'
          })
          .select()
          .single();
        
        if (error) throw error;
        campaignId = data.id;
      }

      // Save sequences
      // First delete removed sequences or just upsert?
      // For MVP, we'll delete and re-insert or use upsert if they have IDs
      const { error: seqError } = await supabase
        .from('campaign_sequences')
        .upsert(
          sequences.map(s => ({
            ...s,
            campaign_id: campaignId
          }))
        );
      
      if (seqError) throw seqError;

      toast.success(campaign ? 'Campaign updated' : 'Campaign created');
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const addSequence = () => {
    const nextOrder = sequences.length > 0 ? Math.max(...sequences.map(s => s.sequence_order)) + 1 : 1;
    setSequences([
      ...sequences,
      {
        sequence_order: nextOrder,
        delay_days: 0,
        subject: '',
        body_html: '',
        enabled: true
      }
    ]);
  };

  const updateSequence = (index: number, updates: Partial<Sequence>) => {
    const newSequences = [...sequences];
    newSequences[index] = { ...newSequences[index], ...updates };
    setSequences(newSequences);
  };

  const removeSequence = (index: number) => {
    setSequences(sequences.filter((_, i) => i !== index));
  };

  const handleTestEmail = async (sequence: Sequence) => {
    if (!activeWorkspace || !user?.email) return;
    try {
      await sendEmail({
        to: user.email,
        subject: `[TEST] ${sequence.subject}`,
        html: sequence.body_html,
        workspaceId: activeWorkspace.id,
        senderIdentity: senderIdentity,
        userId: user.id
      });
      toast.success('Test email sent to your address');
    } catch (error: any) {
      toast.error('Failed to send test email');
    }
  };

  const preloadStarter = (campaignKey: string) => {
    if (campaignKey === 'onboarding') {
      setName('Workspace Onboarding');
      setType('onboarding');
      setSenderIdentity('campaign');
      setAudienceRules({
        workspace_role: ['OWNER', 'ADMIN'],
        workspace_state: ['active', 'trial'],
        account_age_days: 0,
        feature_flags: { billing_enabled: false, services_configured: false, docs_approved: false }
      });
      setSequences([
        { 
          sequence_order: 1, 
          delay_days: 0, 
          subject: 'Welcome to Kafiskey: Your Journey Starts Here', 
          body_html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
              <h1 style="color: #0d9488;">Welcome to Kafiskey</h1>
              <p>Hello! We're thrilled to have you as part of the Kafiskey community.</p>
              <p>Kafiskey provides configurable tools and technical safeguards to help you manage service operations with compliance and clarity. To get started, we recommend setting up your workspace identity and branding.</p>
              <a href="https://kafiskey.live.blink.new/settings" style="background: #0d9488; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 10px;">Go to Settings</a>
              <p style="margin-top: 20px; font-size: 12px; color: #666;">If you have any questions, just reply to this email.</p>
            </div>
          `, 
          enabled: true 
        },
        { 
          sequence_order: 2, 
          delay_days: 2, 
          subject: 'Activate Your Core Setup', 
          body_html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
              <h1 style="color: #0d9488;">Scale Your Operations</h1>
              <p>Now that you've settled in, it's time to build your service catalog.</p>
              <p>Defining your <strong>Service Types</strong> (Hourly, Session, or Program) is the key to accurate documentation and billing.</p>
              <a href="https://kafiskey.live.blink.new/services" style="background: #0d9488; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 10px;">Configure Services</a>
            </div>
          `, 
          enabled: true 
        },
        { 
          sequence_order: 3, 
          delay_days: 7, 
          subject: 'Trust, Structure & Vision', 
          body_html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
              <h1 style="color: #0d9488;">Audit-Ready Workflows</h1>
              <p>Kafiskey provides tools and controls designed to support your compliance readiness efforts.</p>
              <p>Ensure your team is following the approved workflows for service records. You can now monitor approvals from your dashboard.</p>
              <a href="https://kafiskey.live.blink.new/dashboard" style="background: #0d9488; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 10px;">View Dashboard</a>
            </div>
          `, 
          enabled: true 
        }
      ]);
    } else if (campaignKey === 'compliance') {
      setName('Compliance Nudges');
      setType('compliance');
      setSenderIdentity('campaign');
      setAudienceRules({
        workspace_role: ['OWNER', 'ADMIN', 'MANAGER'],
        workspace_state: ['active'],
        account_age_days: 14,
        feature_flags: { billing_enabled: true, services_configured: true, docs_approved: false }
      });
      setSequences([
        { 
          sequence_order: 1, 
          delay_days: 0, 
          subject: 'Compliance Action Required: Pending Documentation', 
          body_html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #d97706;">Attention: Compliance Gap Detected</h2>
              <p>Our system has noticed that your workspace has not yet approved any service records.</p>
              <p>Documentation is a critical part of a compliance framework. Administrators can use Kafiskey to review records and ensure the organization remains audit-ready.</p>
              <a href="https://kafiskey.live.blink.new/services?tab=records" style="background: #d97706; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-top: 10px;">Review Records</a>
            </div>
          `, 
          enabled: true 
        }
      ]);
    }
    toast.success('Starter template loaded');
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl h-[80vh] flex flex-col p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle>{campaign ? 'Edit Campaign' : 'Create New Campaign'}</DialogTitle>
          <DialogDescription>
            Define your campaign audience and email sequence.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-hidden px-6">
          <Tabs defaultValue="general" className="h-full flex flex-col mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="general" className="flex items-center gap-2">
                <Settings2 className="h-4 w-4" /> General
              </TabsTrigger>
              <TabsTrigger value="audience" className="flex items-center gap-2">
                <Users className="h-4 w-4" /> Audience
              </TabsTrigger>
              <TabsTrigger value="sequence" className="flex items-center gap-2">
                <Mail className="h-4 w-4" /> Sequence
              </TabsTrigger>
            </TabsList>

            <ScrollArea className="flex-1 mt-4">
              <TabsContent value="general" className="space-y-4 pb-4">
                <div className="space-y-2">
                  <Label>Campaign Name</Label>
                  <Input 
                    value={name} 
                    onChange={e => setName(e.target.value)} 
                    placeholder="e.g., Onboarding Series"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Campaign Type</Label>
                    <Select value={type} onValueChange={(v: any) => setType(v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="onboarding">Onboarding</SelectItem>
                        <SelectItem value="activation">Activation</SelectItem>
                        <SelectItem value="feature_update">Feature Update</SelectItem>
                        <SelectItem value="compliance">Compliance</SelectItem>
                        <SelectItem value="retention">Retention</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Sender Identity</Label>
                    <Select value={senderIdentity} onValueChange={(v: any) => setSenderIdentity(v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="transactional">Notifications (notifications@kafiskey.com)</SelectItem>
                        <SelectItem value="campaign">Marketing (hello@kafiskey.com)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {!campaign && (
                  <div className="pt-4 border-t">
                    <Label className="text-xs text-muted-foreground uppercase mb-3 block">Quick Starter Templates</Label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline" size="sm" onClick={() => preloadStarter('onboarding')} className="justify-start">
                        <Sparkles className="h-3 w-3 mr-2 text-amber-500" />
                        New Workspace Onboarding
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => preloadStarter('compliance')} className="justify-start">
                        <Sparkles className="h-3 w-3 mr-2 text-teal-500" />
                        Compliance Nudges
                      </Button>
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="audience" className="space-y-6 pb-4">
                <div className="space-y-4">
                  <Label>Workspace Roles</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {['OWNER', 'ADMIN', 'MANAGER', 'SUPERVISOR', 'STAFF', 'READ_ONLY'].map(role => (
                      <div key={role} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`role-${role}`} 
                          checked={audienceRules.workspace_role.includes(role)}
                          onCheckedChange={(checked) => {
                            const roles = checked 
                              ? [...audienceRules.workspace_role, role]
                              : audienceRules.workspace_role.filter(r => r !== role);
                            setAudienceRules({ ...audienceRules, workspace_role: roles });
                          }}
                        />
                        <Label htmlFor={`role-${role}`} className="text-xs">{role}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <Label>Workspace State</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {['active', 'trial', 'suspended'].map(state => (
                      <div key={state} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`state-${state}`} 
                          checked={audienceRules.workspace_state.includes(state)}
                          onCheckedChange={(checked) => {
                            const states = checked 
                              ? [...audienceRules.workspace_state, state]
                              : audienceRules.workspace_state.filter(s => s !== state);
                            setAudienceRules({ ...audienceRules, workspace_state: states });
                          }}
                        />
                        <Label htmlFor={`state-${state}`} className="text-xs capitalize">{state}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Account Age (Min Days)</Label>
                  <Input 
                    type="number" 
                    value={audienceRules.account_age_days}
                    onChange={e => setAudienceRules({ ...audienceRules, account_age_days: parseInt(e.target.value) || 0 })}
                  />
                </div>

                <div className="space-y-4">
                  <Label>System Readiness (Feature Flags)</Label>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <p className="text-xs font-medium">Billing Enabled</p>
                        <p className="text-[10px] text-muted-foreground">Workspace has an active subscription</p>
                      </div>
                      <Checkbox 
                        checked={audienceRules.feature_flags.billing_enabled}
                        onCheckedChange={checked => setAudienceRules({ 
                          ...audienceRules, 
                          feature_flags: { ...audienceRules.feature_flags, billing_enabled: !!checked } 
                        })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <p className="text-xs font-medium">Services Configured</p>
                        <p className="text-[10px] text-muted-foreground">Workspace has created service types</p>
                      </div>
                      <Checkbox 
                        checked={audienceRules.feature_flags.services_configured}
                        onCheckedChange={checked => setAudienceRules({ 
                          ...audienceRules, 
                          feature_flags: { ...audienceRules.feature_flags, services_configured: !!checked } 
                        })}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <p className="text-xs font-medium">Docs Approved</p>
                        <p className="text-[10px] text-muted-foreground">Workspace has at least one approved record</p>
                      </div>
                      <Checkbox 
                        checked={audienceRules.feature_flags.docs_approved}
                        onCheckedChange={checked => setAudienceRules({ 
                          ...audienceRules, 
                          feature_flags: { ...audienceRules.feature_flags, docs_approved: !!checked } 
                        })}
                      />
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="sequence" className="space-y-6 pb-4">
                <div className="flex items-center justify-between">
                  <Label>Email Sequence</Label>
                  <Button variant="outline" size="sm" onClick={addSequence}>
                    <Plus className="h-3 w-3 mr-2" /> Add Email
                  </Button>
                </div>

                {sequences.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed rounded-lg">
                    <p className="text-xs text-muted-foreground">No emails in this sequence yet.</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {sequences.map((seq, index) => (
                      <div key={index} className="p-4 border rounded-lg space-y-4 relative bg-muted/30">
                        <div className="absolute top-4 right-4 flex items-center gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleTestEmail(seq)} title="Send Test">
                            <Send className="h-3 w-3" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive" onClick={() => removeSequence(index)}>
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                        
                        <div className="flex items-center gap-4">
                          <div className="h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-[10px] font-bold">
                            {index + 1}
                          </div>
                          <div className="flex-1 grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <Label className="text-[10px]">Delay (Days)</Label>
                              <Input 
                                type="number" 
                                size={1}
                                className="h-8 text-xs"
                                value={seq.delay_days}
                                onChange={e => updateSequence(index, { delay_days: parseInt(e.target.value) || 0 })}
                              />
                            </div>
                            <div className="flex items-center gap-2 pt-5">
                              <Checkbox 
                                id={`enabled-${index}`}
                                checked={seq.enabled}
                                onCheckedChange={checked => updateSequence(index, { enabled: !!checked })}
                              />
                              <Label htmlFor={`enabled-${index}`} className="text-[10px]">Enabled</Label>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label className="text-[10px]">Subject Line</Label>
                          <Input 
                            className="h-8 text-xs"
                            value={seq.subject}
                            onChange={e => updateSequence(index, { subject: e.target.value })}
                            placeholder="Email subject..."
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="text-[10px]">Email Body (HTML)</Label>
                          <textarea 
                            className="w-full min-h-[120px] p-2 text-xs font-mono border rounded-md"
                            value={seq.body_html}
                            onChange={e => updateSequence(index, { body_html: e.target.value })}
                            placeholder="<h1>Hello</h1><p>Your message here...</p>"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </ScrollArea>
          </Tabs>
        </div>

        <DialogFooter className="p-6 border-t">
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={loading}>Cancel</Button>
          <Button onClick={handleSave} disabled={loading}>
            {loading ? 'Saving...' : campaign ? 'Update Campaign' : 'Create Campaign'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
