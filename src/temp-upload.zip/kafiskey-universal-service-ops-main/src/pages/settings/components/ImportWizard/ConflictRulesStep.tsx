import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ArrowLeft, RefreshCw, Trash2, Upload } from 'lucide-react';

interface ConflictRulesStepProps {
  importing: boolean;
  progress: number;
  validCount: number;
  totalCount: number;
  conflictStrategy: 'update' | 'skip';
  onStrategyChange: (strategy: 'update' | 'skip') => void;
  onExecute: () => void;
  onPrev: () => void;
}

export const ConflictRulesStep: React.FC<ConflictRulesStepProps> = ({
  importing,
  progress,
  validCount,
  totalCount,
  conflictStrategy,
  onStrategyChange,
  onExecute,
  onPrev
}) => {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center space-y-2">
        <h3 className="text-xl font-bold">Finalize Conflict Rules</h3>
        <p className="text-muted-foreground">How should we handle records that already exist?</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card 
          className={`p-6 cursor-pointer border-2 transition-all hover:bg-primary/5 dark:hover:bg-primary/10 ${
            conflictStrategy === 'update' ? 'border-primary bg-primary/5 dark:bg-primary/10' : 'border-transparent'
          }`}
          onClick={() => onStrategyChange('update')}
        >
          <div className="flex items-start gap-4">
            <div className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 ${
              conflictStrategy === 'update' ? 'bg-primary/20' : 'bg-muted'
            }`}>
              <RefreshCw className={`h-5 w-5 ${conflictStrategy === 'update' ? 'text-primary' : 'text-muted-foreground'}`} />
            </div>
            <div className="space-y-1">
              <p className="font-semibold">Update Existing Records</p>
              <p className="text-xs text-muted-foreground">Match by External ID or Email and overwrite with new data. Recommended for syncing.</p>
            </div>
          </div>
        </Card>
        <Card 
          className={`p-6 cursor-pointer border-2 transition-all hover:border-primary/20 hover:bg-muted/50 dark:hover:bg-muted/20 ${
            conflictStrategy === 'skip' ? 'border-primary bg-primary/5 dark:bg-primary/10' : 'border-transparent'
          }`}
          onClick={() => onStrategyChange('skip')}
        >
          <div className="flex items-start gap-4">
            <div className={`h-10 w-10 rounded-full flex items-center justify-center shrink-0 ${
              conflictStrategy === 'skip' ? 'bg-primary/20' : 'bg-muted'
            }`}>
              <Trash2 className={`h-5 w-5 ${conflictStrategy === 'skip' ? 'text-primary' : 'text-muted-foreground'}`} />
            </div>
            <div className="space-y-1">
              <p className="font-semibold">Skip Conflicts</p>
              <p className="text-xs text-muted-foreground">If a record matches, leave it untouched and move to the next row.</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800">
        <p className="text-xs text-blue-700 dark:text-blue-300">
          You are about to import <strong>{validCount}</strong> valid rows out of <strong>{totalCount}</strong> total. 
          Rows with errors will be skipped.
        </p>
      </div>

      {importing && (
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-medium">
            <span>Importing records...</span>
            <span>{progress}%</span>
          </div>
          <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onPrev} disabled={importing}>Back</Button>
        <Button onClick={onExecute} disabled={importing || validCount === 0}>
          {importing ? 'Processing Import...' : `Import ${validCount} Valid Rows`}
          <Upload className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};
