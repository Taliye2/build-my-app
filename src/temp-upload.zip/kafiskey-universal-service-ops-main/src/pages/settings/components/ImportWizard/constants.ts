import { Users, User, Settings, Calendar, ClipboardList, FileText, MessageSquare } from 'lucide-react';

export const MIGRATION_ENTITIES = [
  { id: 'clients', label: 'Clients', icon: Users, description: 'Client demographic and status data' },
  { id: 'providers', label: 'Providers', icon: User, description: 'Staff profiles and contact info' },
  { id: 'contacts', label: 'Contacts', icon: Users, description: 'Client family or emergency contacts' },
  { id: 'service_catalog', label: 'Service Catalog', icon: Settings, description: 'Service types and templates' },
  { id: 'scheduling', label: 'Scheduling', icon: Calendar, description: 'Planned and historical schedules' },
  { id: 'service_records', label: 'Service Records', icon: ClipboardList, description: 'Clinical documentation and records' },
  { id: 'documents', label: 'Documents', icon: FileText, description: 'Client uploaded files (metadata)' },
  { id: 'notes', label: 'Notes & Activity', icon: MessageSquare, description: 'Timeline notes and attachments' },
];

export interface FieldDefinition {
  label: string;
  required: boolean;
  description?: string;
  aliases?: string[];
}

export const ENTITY_FIELDS: Record<string, FieldDefinition[]> = {
  clients: [
    { label: 'external_id', required: false, description: 'Stable ID from source CRM', aliases: ['record id', 'contact id', 'id', 'record_id'] },
    { label: 'first_name', required: true, aliases: ['first name', 'given name', 'fname'] },
    { label: 'last_name', required: true, aliases: ['last name', 'surname', 'lname', 'family name'] },
    { label: 'email', required: false, aliases: ['email address', 'primary email'] },
    { label: 'phone', required: false, aliases: ['mobile', 'phone number', 'cell phone', 'primary phone', 'home phone', 'other phone'] },
    { label: 'dob', required: false, description: 'Format: YYYY-MM-DD', aliases: ['date of birth', 'birthday', 'dob', 'birth date'] },
    { label: 'case_number', required: false, aliases: ['case number', 'reference number', 'ssn last 4', 'id number'] },
    { label: 'status', required: false, description: 'ACTIVE, PENDING, ON_HOLD, CLOSED', aliases: ['client status', 'status'] },
    { label: 'address', required: false, aliases: ['mailing street', 'street address', 'address line 1'] },
  ],
  providers: [
    { label: 'external_id', required: false, aliases: ['staff id', 'provider id', 'id', 'record id'] },
    { label: 'full_name', required: true, aliases: ['full name', 'name', 'staff name', 'provider name'] },
    { label: 'email', required: false, aliases: ['email address'] },
    { label: 'phone', required: false, aliases: ['phone number', 'mobile'] },
    { label: 'title', required: false, aliases: ['job title', 'position', 'role'] },
    { label: 'status', required: false, description: 'ACTIVE, INACTIVE', aliases: ['staff status', 'status'] },
  ],
  contacts: [
    { label: 'external_id', required: false, aliases: ['id', 'contact id', 'record id'] },
    { label: 'client_external_id', required: true, description: 'External ID of the associated client', aliases: ['client id', 'associated client', 'external_id', 'parent id', 'contact id'] },
    { label: 'first_name', required: true, aliases: ['first name', 'given name'] },
    { label: 'last_name', required: true, aliases: ['last name', 'surname'] },
    { label: 'relationship', required: false, aliases: ['relation'] },
    { label: 'phone', required: false, aliases: ['phone number', 'mobile'] },
    { label: 'email', required: false, aliases: ['email address'] },
  ],
  service_catalog: [
    { label: 'external_id', required: false, aliases: ['id', 'catalog id', 'record id'] },
    { label: 'name', required: true, aliases: ['service name', 'title', 'label'] },
    { label: 'description', required: false, aliases: ['summary', 'details', 'about'] },
    { label: 'unit_cost', required: false, description: 'Decimal number', aliases: ['rate', 'price', 'cost', 'unit price'] },
    { label: 'is_active', required: false, description: 'true or false', aliases: ['active', 'status', 'enabled'] },
  ],
  scheduling: [
    { label: 'external_id', required: false, aliases: ['id', 'schedule id', 'appointment id'] },
    { label: 'client_external_id', required: true, aliases: ['client id', 'client_id', 'contact id', 'external_client_id', 'external_id', 'parent id'] },
    { label: 'provider_external_id', required: true, aliases: ['provider id', 'provider_id', 'staff id', 'staff_id', 'staff name'] },
    { label: 'start_time', required: true, description: 'ISO 8601 format', aliases: ['start', 'from', 'date time start', 'appointment date', 'created time', 'start time'] },
    { label: 'end_time', required: true, description: 'ISO 8601 format', aliases: ['end', 'to', 'date time end', 'end time'] },
    { label: 'service_code', required: false, aliases: ['service', 'code', 'service type'] },
    { label: 'notes', required: false, aliases: ['comment', 'description', 'remarks'] },
    { label: 'status', required: false, description: 'SCHEDULED, COMPLETED, CANCELLED', aliases: ['appointment status', 'state'] },
  ],
  service_records: [
    { label: 'external_id', required: false, aliases: ['id', 'record id', 'note id'] },
    { label: 'client_external_id', required: true, aliases: ['client id', 'client_id', 'contact id', 'external_client_id', 'external_id', 'parent id'] },
    { label: 'provider_external_id', required: true, aliases: ['provider id', 'provider_id', 'staff id', 'staff_id', 'staff name'] },
    { label: 'service_date', required: true, description: 'YYYY-MM-DD', aliases: ['date', 'service date', 'visit date', 'work date'] },
    { label: 'service_code', required: true, aliases: ['service', 'code', 'service type', 'activity code'] },
    { label: 'units', required: false, description: 'Decimal number', aliases: ['quantity', 'qty', 'duration', 'hours'] },
    { label: 'notes', required: false, aliases: ['comment', 'description', 'remarks', 'body', 'content'] },
    { label: 'status', required: false, description: 'DRAFT, FINAL, REVISED', aliases: ['record status', 'state'] },
  ],
  documents: [
    { label: 'external_id', required: false, aliases: ['id', 'document id', 'file id'] },
    { label: 'client_external_id', required: true, aliases: ['client id', 'client_id', 'contact id', 'external_client_id', 'external_id', 'parent id'] },
    { label: 'file_name', required: true, aliases: ['filename', 'name', 'title'] },
    { label: 'file_type', required: false, aliases: ['type', 'extension', 'mime'] },
    { label: 'upload_date', required: false, description: 'YYYY-MM-DD', aliases: ['date', 'created at', 'upload time', 'created time'] },
    { label: 'description', required: false, aliases: ['notes', 'summary'] },
  ],
  notes: [
    { label: 'external_id', required: false, aliases: ['id', 'note id', 'record id'] },
    { label: 'client_external_id', required: true, aliases: ['client id', 'client_id', 'contact id', 'external_client_id', 'external_id', 'parent id', 'client', 'contact'] },
    { label: 'author_external_id', required: false, aliases: ['author id', 'author_id', 'staff id', 'staff_id', 'provider id', 'author', 'staff', 'provider'] },
    { label: 'timestamp', required: true, description: 'ISO 8601 format', aliases: ['date', 'created at', 'time', 'datetime', 'note date', 'created_at', 'created time', 'modified time', 'timestamp'] },
    { label: 'title', required: false, aliases: ['subject', 'headline', 'name'] },
    { label: 'note_type', required: false, aliases: ['type', 'category', 'class'] },
    { label: 'content', required: true, aliases: ['note', 'notes', 'body', 'message', 'text', 'description', 'note content', 'comment', 'remarks'] },
    { label: 'attachment_file_name', required: false, aliases: ['attachment', 'file', 'filename'] },
  ],
};
