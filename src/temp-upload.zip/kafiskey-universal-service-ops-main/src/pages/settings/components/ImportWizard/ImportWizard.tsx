import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { toast } from 'sonner';
import { CheckCircle2 } from 'lucide-react';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import { ENTITY_FIELDS } from './constants';
import { EntitySelectionStep } from './EntitySelectionStep';
import { FileUploadStep } from './FileUploadStep';
import { ColumnMappingStep } from './ColumnMappingStep';
import { ValidationStep } from './ValidationStep';
import { ConflictRulesStep } from './ConflictRulesStep';
import { ImportSummaryStep } from './ImportSummaryStep';

interface ImportWizardProps {
  onComplete: () => void;
}

export interface SkippedRow {
  rowNumber: number;
  data: any;
  reason: string;
  resolved?: boolean;
}

export interface ImportSummary {
  imported: number;
  updated: number;
  failed: number;
  skipped: number;
  total: number;
}

export const ImportWizard: React.FC<ImportWizardProps> = ({ onComplete }) => {
  const { activeWorkspace, isTrialActive } = useWorkspace();
  const [step, setStep] = useState(1);
  const [selectedEntity, setSelectedEntity] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<Record<string, string>>({});
  const [validationResults, setValidationResults] = useState<{ row: number; errors: Record<string, string[]> }[]>([]);
  const [conflictStrategy, setConflictStrategy] = useState<'update' | 'skip'>('update');
  const [importing, setImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [skippedRows, setSkippedRows] = useState<SkippedRow[]>([]);

  // Reassurance warning on leave
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (parsedData.length > 0 && step < 6) {
        e.preventDefault();
        e.returnValue = 'If you leave this page, your validation progress will be lost.';
        return e.returnValue;
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [parsedData.length, step]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    setFile(selectedFile);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result;
      if (selectedFile.name.endsWith('.csv')) {
        Papa.parse(content as string, {
          header: true,
          skipEmptyLines: 'greedy',
          transformHeader: (h) => h.trim(),
          complete: (results) => {
            setParsedData(results.data);
            setHeaders(results.meta.fields || []);
            autoMap(results.meta.fields || []);
          }
        });
      } else if (selectedFile.name.endsWith('.xlsx')) {
        const workbook = XLSX.read(content, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const data = XLSX.utils.sheet_to_json(worksheet);
        setParsedData(data);
        if (data.length > 0) {
          const firstRow = data[0] as any;
          const h = Object.keys(firstRow);
          setHeaders(h);
          autoMap(h);
        }
      }
    };

    if (selectedFile.name.endsWith('.csv')) {
      reader.readAsText(selectedFile);
    } else {
      reader.readAsBinaryString(selectedFile);
    }
  };

  const autoMap = useCallback((sourceHeaders: string[]) => {
    if (!selectedEntity) return;
    const targetFields = ENTITY_FIELDS[selectedEntity] || [];
    const newMapping: Record<string, string> = {};

    targetFields.forEach(field => {
      const match = sourceHeaders.find(h => {
        const headerLower = h.toLowerCase();
        const labelLower = field.label.toLowerCase();
        if (headerLower === labelLower) return true;
        if (headerLower.replace(/ /g, '_') === labelLower) return true;
        if (field.aliases?.some(alias => headerLower === alias.toLowerCase())) return true;
        return false;
      });
      if (match) newMapping[field.label] = match;
    });

    setMapping(newMapping);
  }, [selectedEntity]);

  const validateData = useCallback(() => {
    if (!selectedEntity) return;
    const errors: { row: number; errors: Record<string, string[]> }[] = [];
    const targetFields = ENTITY_FIELDS[selectedEntity] || [];

    parsedData.forEach((row, index) => {
      const isEmpty = Object.values(row).every(v => !v || String(v).trim() === '' || String(v).trim() === '-');
      if (isEmpty) return;

      const rowErrors: Record<string, string[]> = {};
      targetFields.forEach(field => {
        const val = row[mapping[field.label]];
        const fieldErrors: string[] = [];
        
        if (field.required && !val) {
          fieldErrors.push(`Required`);
        }
        
        if (field.label === 'dob' && val) {
          const date = new Date(val);
          if (isNaN(date.getTime())) fieldErrors.push(`Invalid date`);
        }
        
        if (field.label === 'email' && val) {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(String(val).trim())) fieldErrors.push(`Invalid email`);
        }

        if (fieldErrors.length > 0) {
          rowErrors[field.label] = fieldErrors;
        }
      });

      if (Object.keys(rowErrors).length > 0) {
        errors.push({ row: index + 1, errors: rowErrors });
      }
    });

    setValidationResults(errors);
  }, [selectedEntity, parsedData, mapping]);

  // Re-validate when data or mapping changes
  useEffect(() => {
    if (parsedData.length > 0 && selectedEntity) {
      validateData();
    }
  }, [parsedData, mapping, selectedEntity, validateData]);

  const handleUpdateRow = (index: number, newData: any) => {
    const nextData = [...parsedData];
    nextData[index] = newData;
    setParsedData(nextData);
  };

  const startImport = async () => {
    if (!activeWorkspace || !selectedEntity) return;
    setImporting(true);
    setImportProgress(0);
    setSummary(null);
    setSkippedRows([]);

    // Hard timeout for the entire import job (5 minutes)
    const IMPORT_TIMEOUT_MS = 5 * 60 * 1000;
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('IMPORT_TIMEOUT')), IMPORT_TIMEOUT_MS);
    });

    const runImport = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const tableMap: Record<string, string> = {
        clients: 'clients',
        providers: 'staff_profiles',
        contacts: 'contacts',
        service_catalog: 'service_templates',
        scheduling: 'service_events',
        service_records: 'service_records',
        documents: 'documents',
        notes: 'client_notes',
      };
      
      const tableName = tableMap[selectedEntity] || selectedEntity;
      const rowsWithErrors = new Set(validationResults.map(v => v.row));
      
      // Capture skipped rows (validation errors)
      const initialSkippedRows: SkippedRow[] = validationResults.map(v => ({
        rowNumber: v.row,
        data: parsedData[v.row - 1],
        reason: Object.values(v.errors).flat().join(', '),
      }));

      // Filter valid rows only
      const validRows = parsedData.map((row, i) => ({ row, originalIndex: i + 1 }))
        .filter(({ row, originalIndex }) => {
          const isEmpty = Object.values(row).every(v => !v || String(v).trim() === '' || String(v).trim() === '-');
          if (isEmpty) return false;
          return !rowsWithErrors.has(originalIndex);
        });

      if (validRows.length === 0 && initialSkippedRows.length === 0) {
        toast.error('No rows to import');
        setImporting(false);
        return;
      }

      // 1. Create Job
      const { data: job, error: jobError } = await supabase
        .from('import_jobs')
        .insert({
          workspace_id: activeWorkspace.id,
          entity_type: selectedEntity,
          status: 'processing',
          created_by: user.id,
          total_rows: parsedData.length,
          started_at: new Date().toISOString(),
          rollback_available: true
        })
        .select()
        .single();

      if (jobError) throw jobError;

      // 2. Pre-load entity mappings for efficiency (Dictionary lookup)
      const clientMap = new Map<string, string>();
      const providerMap = new Map<string, string>();
      const serviceMap = new Map<string, string>();

      // Only load if the current entity needs these references
      const needsClient = ['contacts', 'scheduling', 'service_records', 'documents', 'notes'].includes(selectedEntity);
      const needsProvider = ['scheduling', 'service_records', 'notes'].includes(selectedEntity);
      const needsService = ['scheduling', 'service_records'].includes(selectedEntity);

      if (needsClient) {
        const { data } = await supabase.from('clients').select('id, external_id').eq('workspace_id', activeWorkspace.id).not('external_id', 'is', null);
        data?.forEach(r => clientMap.set(r.external_id, r.id));
      }

      if (needsProvider) {
        const { data } = await supabase.from('staff_profiles').select('id, external_id, user_id').eq('workspace_id', activeWorkspace.id).not('external_id', 'is', null);
        data?.forEach(r => providerMap.set(r.external_id, r.id));
      }

      if (needsService) {
        const { data } = await supabase.from('service_templates').select('id, external_id').eq('workspace_id', activeWorkspace.id).not('external_id', 'is', null);
        data?.forEach(r => serviceMap.set(r.external_id, r.id));
      }

      let imported = 0, failed = 0, updated = 0, skipped = 0;
      const processLimit = isTrialActive ? Math.min(5, validRows.length) : validRows.length;
      
      const BATCH_SIZE = 50;
      const UPDATE_EVERY = 10; // Update DB progress every 10 rows

      for (let i = 0; i < processLimit; i += BATCH_SIZE) {
        const batch = validRows.slice(i, Math.min(i + BATCH_SIZE, processLimit));
        const jobRowBatch: any[] = [];
        
        // Process batch rows sequentially for now to maintain rollback/audit logs precisely,
        // but we'll optimize the row-by-row lookups with our preloaded maps.
        for (const { row, originalIndex } of batch) {
          try {
            const dataToInsert: any = { workspace_id: activeWorkspace.id };
            
            Object.keys(mapping).forEach(field => {
              if (mapping[field]) {
                let value = row[mapping[field]];
                if (typeof value === 'string') {
                  value = value.trim();
                  if (value === '' || value === '-') value = null;
                }
                dataToInsert[field] = value;
              }
            });

            // Resolve references using pre-loaded maps
            if (dataToInsert.client_external_id && !dataToInsert.client_id) {
              dataToInsert.client_id = clientMap.get(dataToInsert.client_external_id);
              if (!dataToInsert.client_id) {
                throw new Error(`Client with external ID ${dataToInsert.client_external_id} not found`);
              }
            }

            if ((dataToInsert.provider_external_id || dataToInsert.author_external_id) && !dataToInsert.staff_user_id && !dataToInsert.author_user_id) {
              const extId = dataToInsert.provider_external_id || dataToInsert.author_external_id;
              dataToInsert.staff_user_id = providerMap.get(extId);
              dataToInsert.author_user_id = providerMap.get(extId);
              if (!dataToInsert.staff_user_id && !dataToInsert.author_user_id) {
                throw new Error(`Staff with external ID ${extId} not found`);
              }
            }

            const hasExternalId = !!dataToInsert.external_id;
            let previousData = null;

            if (hasExternalId && conflictStrategy === 'update') {
              const { data: existing } = await supabase
                .from(tableName)
                .select('*')
                .eq('workspace_id', activeWorkspace.id)
                .eq('external_id', dataToInsert.external_id)
                .maybeSingle();
              previousData = existing;
            }

            const query = hasExternalId && conflictStrategy === 'update'
              ? supabase.from(tableName).upsert(dataToInsert, { onConflict: 'workspace_id,external_id' })
              : supabase.from(tableName).insert(dataToInsert);

            const { data: result, error: insertError } = await query.select().single();

            if (insertError) {
              throw insertError;
            } else {
              if (hasExternalId && previousData) updated++;
              else imported++;
              
              jobRowBatch.push({
                job_id: job.id,
                row_number: originalIndex,
                status: 'success',
                record_id_created_or_updated: result.id,
                previous_data_snapshot: previousData ? JSON.stringify(previousData) : null
              });
            }
          } catch (err: any) {
            failed++;
            jobRowBatch.push({
              job_id: job.id,
              row_number: originalIndex,
              status: 'error',
              errors_json: JSON.stringify([err.message || 'Unknown error'])
            });
          }

          // Periodic progress update in UI
          const currentProcessed = i + batch.indexOf(batch.find(b => b.originalIndex === originalIndex)! ) + 1;
          setImportProgress(Math.round((currentProcessed / processLimit) * 100));
        }

        // Insert job rows in batch after processing the whole batch
        if (jobRowBatch.length > 0) {
          await supabase.from('import_job_rows').insert(jobRowBatch);
        }

        // Periodic progress update in DB
        const currentBatchEnd = Math.min(i + BATCH_SIZE, processLimit);
        await supabase.from('import_jobs').update({
          imported_count: imported,
          updated_count: updated,
          failed_count: failed,
          status: 'processing'
        }).eq('id', job.id);
      }

      // Finalize job
      const finalSkippedCount = parsedData.length - (imported + updated + failed);
      
      await supabase.from('import_jobs').update({
        status: failed > 0 ? 'completed_with_errors' : 'completed',
        finished_at: new Date().toISOString(),
        imported_count: imported,
        updated_count: updated,
        failed_count: failed,
        skipped_count: finalSkippedCount
      }).eq('id', job.id);

      setSummary({
        imported,
        updated,
        failed,
        skipped: finalSkippedCount,
        total: parsedData.length
      });
      setSkippedRows(initialSkippedRows);

      toast.success(`Import complete: ${imported} imported, ${updated} updated.`);
      setStep(6);
    };

    try {
      await Promise.race([runImport(), timeoutPromise]);
    } catch (error: any) {
      console.error('Import process error:', error);
      
      // Handle timeout or other fatal errors
      const isTimeout = error.message === 'IMPORT_TIMEOUT';
      const errorMessage = isTimeout 
        ? 'Import timed out. The process was taking too long. Some records may have been imported.' 
        : error.message;

      toast.error(errorMessage);

      // Attempt to mark job as failed in DB if we have a job ID
      // We'd need to track the job ID outside the runImport scope or find it
      const { data: latestJob } = await supabase
        .from('import_jobs')
        .select('id')
        .eq('workspace_id', activeWorkspace.id)
        .eq('status', 'processing')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (latestJob) {
        await supabase.from('import_jobs').update({
          status: 'failed',
          finished_at: new Date().toISOString(),
          failure_reason: isTimeout ? 'Timed out after 5 minutes' : error.message
        }).eq('id', latestJob.id);
      }
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4 mb-8">
        {[1, 2, 3, 4, 5, 6].map((s) => (
          <React.Fragment key={s}>
            <div className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition-colors ${
              step === s ? 'bg-primary text-primary-foreground' : 
              step > s ? 'bg-emerald-500 text-white' : 'bg-muted text-muted-foreground'
            }`}>
              {step > s ? <CheckCircle2 className="h-4 w-4" /> : s}
            </div>
            {s < 6 && <div className={`h-0.5 flex-1 ${step > s ? 'bg-emerald-500' : 'bg-muted'}`} />}
          </React.Fragment>
        ))}
      </div>

      {step === 1 && <EntitySelectionStep selectedEntity={selectedEntity} onSelect={setSelectedEntity} onNext={() => setStep(2)} />}
      {step === 2 && <FileUploadStep selectedEntity={selectedEntity!} file={file} parsedCount={parsedData.length} onFileSelect={handleFileSelect} onClearFile={() => { setFile(null); setParsedData([]); }} onPrev={() => setStep(1)} onNext={() => setStep(3)} />}
      {step === 3 && <ColumnMappingStep selectedEntity={selectedEntity!} headers={headers} mapping={mapping} sampleRow={parsedData[0]} onMappingChange={(f, s) => setMapping({ ...mapping, [f]: s })} onPrev={() => setStep(2)} onNext={() => setStep(4)} />}
      {step === 4 && <ValidationStep selectedEntity={selectedEntity!} parsedData={parsedData} mapping={mapping} validationResults={validationResults} onUpdateRow={handleUpdateRow} onPrev={() => setStep(3)} onNext={() => setStep(5)} />}
      {step === 5 && <ConflictRulesStep importing={importing} progress={importProgress} validCount={parsedData.length - validationResults.length} totalCount={parsedData.length} conflictStrategy={conflictStrategy} onStrategyChange={setConflictStrategy} onExecute={startImport} onPrev={() => setStep(4)} />}
      {step === 6 && summary && (
        <ImportSummaryStep 
          summary={summary} 
          skippedRows={skippedRows}
          selectedEntity={selectedEntity!}
          mapping={mapping}
          onResolveRow={(rowNumber) => {
            setSkippedRows(prev => prev.map(r => r.rowNumber === rowNumber ? { ...r, resolved: true } : r));
          }}
          onComplete={onComplete} 
        />
      )}
    </div>
  );
};
