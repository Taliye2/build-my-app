import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CheckCircle2, AlertCircle, FileDown, Eye, ArrowRight } from 'lucide-react';
import { ImportSummary, SkippedRow } from './ImportWizard';
import { SkippedRowsReview } from './SkippedRowsReview';
import Papa from 'papaparse';

interface ImportSummaryStepProps {
  summary: ImportSummary;
  skippedRows: SkippedRow[];
  selectedEntity: string;
  mapping: Record<string, string>;
  onResolveRow: (rowNumber: number) => void;
  onComplete: () => void;
}

export const ImportSummaryStep: React.FC<ImportSummaryStepProps> = ({
  summary,
  skippedRows,
  selectedEntity,
  mapping,
  onResolveRow,
  onComplete
}) => {
  const [showReview, setShowReview] = useState(false);

  const downloadSkippedCsv = () => {
    if (skippedRows.length === 0) return;
    
    const csvData = skippedRows.map(s => ({
      'Row Number': s.rowNumber,
      'Skip Reason': s.reason,
      ...s.data
    }));
    
    const csv = Papa.unparse(csvData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `skipped_${selectedEntity}_rows.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (showReview) {
    return (
      <SkippedRowsReview 
        skippedRows={skippedRows}
        selectedEntity={selectedEntity}
        mapping={mapping}
        onResolve={onResolveRow}
        onBack={() => setShowReview(false)}
      />
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="h-16 w-16 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center">
            <CheckCircle2 className="h-10 w-10 text-emerald-600 dark:text-emerald-400" />
          </div>
        </div>
        <h3 className="text-2xl font-bold">Import Completed</h3>
        <p className="text-muted-foreground">Your data migration has been processed.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 text-center space-y-1">
          <p className="text-2xl font-bold text-emerald-600">{summary.imported}</p>
          <p className="text-xs text-muted-foreground uppercase tracking-wider">New</p>
        </Card>
        <Card className="p-4 text-center space-y-1">
          <p className="text-2xl font-bold text-blue-600">{summary.updated}</p>
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Updated</p>
        </Card>
        <Card className="p-4 text-center space-y-1">
          <p className="text-2xl font-bold text-destructive">{summary.failed}</p>
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Failed</p>
        </Card>
        <Card className="p-4 text-center space-y-1">
          <p className="text-2xl font-bold text-amber-600">{summary.skipped}</p>
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Skipped</p>
        </Card>
      </div>

      {summary.skipped > 0 && (
        <div className="p-4 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0" />
            <div className="space-y-1">
              <p className="text-sm font-semibold text-amber-800 dark:text-amber-200">
                {summary.skipped} rows were skipped
              </p>
              <p className="text-xs text-amber-700 dark:text-amber-300">
                Some rows had validation issues. You can review and fix them manually.
              </p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={downloadSkippedCsv}>
              <FileDown className="h-4 w-4 mr-2" />
              Download CSV
            </Button>
            <Button variant="brand" size="sm" onClick={() => setShowReview(true)}>
              <Eye className="h-4 w-4 mr-2" />
              Review Rows
            </Button>
          </div>
        </div>
      )}

      <div className="flex justify-center pt-6">
        <Button onClick={onComplete} className="w-full md:w-auto px-8">
          Done
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>

      <p className="text-center text-[10px] text-muted-foreground italic">
        Skipped rows are only available for this session.
      </p>
    </div>
  );
};
