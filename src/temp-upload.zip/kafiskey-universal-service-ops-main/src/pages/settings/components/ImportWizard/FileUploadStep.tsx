import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft, ArrowRight, FileSpreadsheet, FileText, X } from 'lucide-react';

interface FileUploadStepProps {
  selectedEntity: string;
  file: File | null;
  parsedCount: number;
  onFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onClearFile: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export const FileUploadStep: React.FC<FileUploadStepProps> = ({
  selectedEntity,
  file,
  parsedCount,
  onFileSelect,
  onClearFile,
  onPrev,
  onNext
}) => {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center space-y-2">
        <h3 className="text-xl font-bold">Upload your data file</h3>
        <p className="text-muted-foreground">Upload a CSV or XLSX file containing your {selectedEntity} data.</p>
        <p className="text-sm text-emerald-600 dark:text-emerald-400 font-medium">
          Your file will be reviewed in a safe preview mode. Nothing is added until you approve.
        </p>
      </div>
      
      <div className="flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-12 bg-muted/20 hover:bg-muted/30 transition-colors">
        <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
          <FileSpreadsheet className="h-8 w-8 text-primary" />
        </div>
        <p className="text-sm font-medium mb-1">Drag and drop or click to upload</p>
        <p className="text-xs text-muted-foreground mb-4">CSV or Excel (max 10MB)</p>
        <Input 
          type="file" 
          className="max-w-[200px] cursor-pointer" 
          accept=".csv,.xlsx" 
          onChange={onFileSelect}
        />
      </div>

      {file && (
        <div className="flex items-center justify-between p-4 rounded-lg bg-card border">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded bg-emerald-500/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-sm font-medium">{file.name}</p>
              <p className="text-xs text-muted-foreground">{parsedCount} records found</p>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClearFile}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onPrev}>Back</Button>
        <Button disabled={!file} onClick={onNext}>
          Next Step
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};
