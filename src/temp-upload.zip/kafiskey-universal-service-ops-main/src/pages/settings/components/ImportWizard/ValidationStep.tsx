import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, ArrowRight, CheckCircle2, Search, Filter } from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { ENTITY_FIELDS } from './constants';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';

interface ValidationStepProps {
  selectedEntity: string;
  parsedData: any[];
  mapping: Record<string, string>;
  validationResults: { row: number; errors: Record<string, string[]> }[];
  onUpdateRow: (index: number, newData: any) => void;
  onPrev: () => void;
  onNext: () => void;
}

export const ValidationStep: React.FC<ValidationStepProps> = ({
  selectedEntity,
  parsedData,
  mapping,
  validationResults,
  onUpdateRow,
  onPrev,
  onNext
}) => {
  const [showOnlyIssues, setShowOnlyIssues] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const targetFields = useMemo(() => ENTITY_FIELDS[selectedEntity] || [], [selectedEntity]);
  
  const filteredData = useMemo(() => {
    return parsedData.map((row, index) => ({ row, index })).filter(({ row, index }) => {
      const hasIssue = validationResults.some(v => v.row === index + 1);
      if (showOnlyIssues && !hasIssue) return false;
      
      if (searchQuery) {
        const rowString = JSON.stringify(row).toLowerCase();
        if (!rowString.includes(searchQuery.toLowerCase())) return false;
      }
      
      return true;
    });
  }, [parsedData, validationResults, showOnlyIssues, searchQuery]);

  const getRowError = (rowIndex: number) => {
    return validationResults.find(v => v.row === rowIndex + 1);
  };

  const handleCellChange = (index: number, field: string, value: string) => {
    const sourceColumn = mapping[field];
    if (!sourceColumn) return;
    
    const newRow = { ...parsedData[index], [sourceColumn]: value };
    onUpdateRow(index, newRow);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center space-y-2">
        <h3 className="text-xl font-bold">Validate & Clean Data</h3>
        <p className="text-muted-foreground">Fix any issues directly in the grid below. Changes are saved in memory.</p>
      </div>

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center space-x-2">
            <Switch 
              id="show-issues" 
              checked={showOnlyIssues} 
              onCheckedChange={setShowOnlyIssues} 
            />
            <Label htmlFor="show-issues" className="text-sm cursor-pointer">Show only rows with issues</Label>
          </div>
          <Badge variant="outline" className="text-[10px] h-6 px-2">
            {validationResults.length} issues found
          </Badge>
        </div>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search preview..." 
            className="pl-8 h-9" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {validationResults.length > 0 ? (
        <div className="p-4 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 flex gap-3">
          <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0" />
          <div className="space-y-1">
            <p className="text-sm font-semibold text-amber-800 dark:text-amber-200">Validation Issues Found</p>
            <p className="text-xs text-amber-700 dark:text-amber-300">
              Please fix the highlighted cells. You can import valid rows now or fix the remaining ones.
            </p>
          </div>
        </div>
      ) : (
        <div className="p-4 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex gap-3">
          <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <div className="space-y-1">
            <p className="text-sm font-semibold text-emerald-800 dark:text-emerald-200">Data looks clean!</p>
            <p className="text-xs text-emerald-700 dark:text-emerald-300">
              All {parsedData.length} rows are valid and ready to import.
            </p>
          </div>
        </div>
      )}

      <div className="rounded-md border overflow-hidden bg-background">
        <ScrollArea className="h-[400px] w-full">
          <Table>
            <TableHeader className="sticky top-0 bg-background z-10 shadow-sm">
              <TableRow>
                <TableHead className="w-12 bg-background">Row</TableHead>
                {targetFields.map(f => (
                  <TableHead key={f.label} className="min-w-[150px] bg-background">
                    {f.label} {f.required && <span className="text-destructive">*</span>}
                  </TableHead>
                ))}
                <TableHead className="w-24 bg-background">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={targetFields.length + 2} className="h-24 text-center text-muted-foreground">
                    No rows match your criteria.
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map(({ row, index }) => {
                  const rowError = getRowError(index);
                  return (
                    <TableRow key={index} className={rowError ? 'bg-destructive/[0.02]' : ''}>
                      <TableCell className="text-[10px] text-muted-foreground text-center">{index + 1}</TableCell>
                      {targetFields.map(f => {
                        const cellError = rowError?.errors[f.label];
                        return (
                          <TableCell key={f.label} className="p-1">
                            <div className="relative group">
                              <Input 
                                className={`h-8 text-xs border-transparent hover:border-input focus:border-primary transition-colors ${
                                  cellError ? 'bg-destructive/10 border-destructive hover:border-destructive text-destructive' : ''
                                }`}
                                value={mapping[f.label] ? String(row[mapping[f.label]] || '') : ''}
                                onChange={(e) => handleCellChange(index, f.label, e.target.value)}
                                disabled={!mapping[f.label]}
                                placeholder={!mapping[f.label] ? 'Not mapped' : ''}
                              />
                              {cellError && (
                                <div className="absolute left-0 bottom-full mb-1 hidden group-hover:block z-50 w-48 p-2 rounded bg-destructive text-white text-[10px] shadow-lg">
                                  {cellError.join(', ')}
                                </div>
                              )}
                            </div>
                          </TableCell>
                        );
                      })}
                      <TableCell className="text-center">
                        {rowError ? (
                          <Badge variant="destructive" className="text-[9px] px-1 h-4">Issue</Badge>
                        ) : (
                          <Badge variant="success" className="text-[9px] px-1 h-4">Valid</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </ScrollArea>
      </div>

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onPrev}>Back to Mapping</Button>
        <div className="flex gap-2">
          <Button onClick={onNext}>
            Next Step
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};
