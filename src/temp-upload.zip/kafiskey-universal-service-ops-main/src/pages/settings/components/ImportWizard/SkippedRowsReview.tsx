import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, PlusCircle, CheckCircle2 } from 'lucide-react';
import { SkippedRow } from './ImportWizard';
import { ENTITY_FIELDS } from './constants';
import { ManualAddDialog } from './ManualAddDialog';

interface SkippedRowsReviewProps {
  skippedRows: SkippedRow[];
  selectedEntity: string;
  mapping: Record<string, string>;
  onResolve: (rowNumber: number) => void;
  onBack: () => void;
}

export const SkippedRowsReview: React.FC<SkippedRowsReviewProps> = ({
  skippedRows,
  selectedEntity,
  mapping,
  onResolve,
  onBack
}) => {
  const [selectedRow, setSelectedRow] = useState<SkippedRow | null>(null);
  const targetFields = ENTITY_FIELDS[selectedEntity] || [];
  
  // Show only identified fields to keep table readable
  const identifiedFields = targetFields.filter(f => 
    ['first_name', 'last_name', 'email', 'name', 'title'].includes(f.label)
  );

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-left-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h3 className="text-xl font-bold">Review Skipped Rows</h3>
            <p className="text-sm text-muted-foreground">Resolve validation issues by adding records manually.</p>
          </div>
        </div>
        <Badge variant="outline">
          {skippedRows.filter(r => !r.resolved).length} pending
        </Badge>
      </div>

      <div className="rounded-md border overflow-hidden bg-background">
        <ScrollArea className="h-[400px] w-full">
          <Table>
            <TableHeader className="sticky top-0 bg-background z-10">
              <TableRow>
                <TableHead className="w-12">Row</TableHead>
                <TableHead>Reason</TableHead>
                {identifiedFields.map(f => (
                  <TableHead key={f.label}>{f.label}</TableHead>
                ))}
                <TableHead className="w-24 text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {skippedRows.map((row) => (
                <TableRow key={row.rowNumber} className={row.resolved ? 'opacity-50' : ''}>
                  <TableCell className="text-xs font-mono">{row.rowNumber}</TableCell>
                  <TableCell className="max-w-[200px] truncate text-xs text-destructive">
                    {row.reason}
                  </TableCell>
                  {identifiedFields.map(f => (
                    <TableCell key={f.label} className="text-xs">
                      {row.data[mapping[f.label]] || '-'}
                    </TableCell>
                  ))}
                  <TableCell className="text-right">
                    {row.resolved ? (
                      <Badge variant="success" className="h-6">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Added
                      </Badge>
                    ) : (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="h-7 text-[10px]"
                        onClick={() => setSelectedRow(row)}
                      >
                        <PlusCircle className="h-3 w-3 mr-1" />
                        Add Manually
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      </div>

      {selectedRow && (
        <ManualAddDialog
          isOpen={!!selectedRow}
          onOpenChange={(open) => !open && setSelectedRow(null)}
          entityType={selectedEntity}
          initialData={selectedRow.data}
          mapping={mapping}
          onSuccess={() => {
            onResolve(selectedRow.rowNumber);
            setSelectedRow(null);
          }}
        />
      )}
    </div>
  );
};
