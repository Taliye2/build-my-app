import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { ENTITY_FIELDS } from './constants';

interface ManualAddDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  entityType: string;
  initialData: any;
  mapping: Record<string, string>;
  onSuccess: () => void;
}

export const ManualAddDialog: React.FC<ManualAddDialogProps> = ({
  isOpen,
  onOpenChange,
  entityType,
  initialData,
  mapping,
  onSuccess,
}) => {
  const { activeWorkspace } = useWorkspace();
  const [loading, setLoading] = useState(false);
  const targetFields = ENTITY_FIELDS[entityType] || [];

  // Create a dynamic schema
  const schemaShape: Record<string, any> = {};
  targetFields.forEach(field => {
    if (field.required) {
      schemaShape[field.label] = z.string().min(1, `${field.label} is required`);
    } else {
      schemaShape[field.label] = z.string().optional();
    }
  });
  const schema = z.object(schemaShape);

  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: {} as any,
  });

  useEffect(() => {
    if (isOpen && initialData) {
      const defaultValues: Record<string, string> = {};
      targetFields.forEach(field => {
        const sourceColumn = mapping[field.label];
        defaultValues[field.label] = initialData[sourceColumn] || '';
      });
      form.reset(defaultValues);
    }
  }, [isOpen, initialData, targetFields, mapping, form]);

  const onSubmit = async (values: any) => {
    if (!activeWorkspace) return;
    setLoading(true);

    try {
      const tableMap: Record<string, string> = {
        clients: 'clients',
        providers: 'staff_profiles',
        contacts: 'contacts',
        service_catalog: 'service_templates',
        scheduling: 'service_events',
        service_records: 'service_records',
        documents: 'documents',
        notes: 'client_notes',
      };
      
      const tableName = tableMap[entityType] || entityType;

      const { error } = await supabase
        .from(tableName)
        .insert({
          ...values,
          workspace_id: activeWorkspace.id,
          // Handle specific fields if needed
          status: values.status || (entityType === 'clients' ? 'PENDING' : 'ACTIVE'),
        });

      if (error) throw error;

      toast.success('Record added successfully');
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || 'Error adding record');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add {entityType.replace('_', ' ')} Manually</DialogTitle>
          <DialogDescription>
            Fix missing or invalid data to add this record to your workspace.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {targetFields.map(field => (
                <FormField
                  key={field.label}
                  control={form.control}
                  name={field.label}
                  render={({ field: formField }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-1">
                        {field.label.replace('_', ' ')}
                        {field.required && <span className="text-destructive">*</span>}
                      </FormLabel>
                      <FormControl>
                        {field.label === 'content' || field.label === 'notes' || field.label === 'description' ? (
                          <Textarea 
                            {...formField} 
                            className="min-h-[100px]" 
                            spellCheck={true}
                            autoCorrect="on"
                            autoCapitalize="sentences"
                          />
                        ) : (
                          <Input {...formField} />
                        )}
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              ))}
            </div>

            <DialogFooter className="pt-6">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading} variant="brand">
                {loading ? 'Adding...' : 'Add Record'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};
