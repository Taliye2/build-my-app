import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import { MIGRATION_ENTITIES } from './constants';

interface EntitySelectionStepProps {
  selectedEntity: string | null;
  onSelect: (entityId: string) => void;
  onNext: () => void;
}

export const EntitySelectionStep: React.FC<EntitySelectionStepProps> = ({ 
  selectedEntity, 
  onSelect, 
  onNext 
}) => {
  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center space-y-2">
        <h3 className="text-xl font-bold">What would you like to import?</h3>
        <p className="text-muted-foreground">Choose the primary data entity for this migration job.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        {MIGRATION_ENTITIES.map(entity => (
          <Button
            key={entity.id}
            variant={selectedEntity === entity.id ? 'default' : 'outline'}
            className={`h-auto py-6 flex flex-col gap-3 transition-all ${
              selectedEntity === entity.id ? 'ring-2 ring-primary ring-offset-2' : ''
            }`}
            onClick={() => onSelect(entity.id)}
          >
            <entity.icon className={`h-8 w-8 ${selectedEntity === entity.id ? 'text-primary-foreground' : 'text-primary'}`} />
            <div className="space-y-1">
              <p className="font-semibold">{entity.label}</p>
              <p className={`text-[10px] uppercase font-bold ${selectedEntity === entity.id ? 'opacity-80' : 'text-muted-foreground'}`}>
                Template Ready
              </p>
            </div>
          </Button>
        ))}
      </div>
      <div className="flex justify-end pt-6">
        <Button disabled={!selectedEntity} onClick={onNext}>
          Next Step
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};
