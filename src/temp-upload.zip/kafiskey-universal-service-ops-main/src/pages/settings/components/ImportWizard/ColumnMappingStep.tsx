import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { ENTITY_FIELDS } from './constants';

interface ColumnMappingStepProps {
  selectedEntity: string;
  headers: string[];
  mapping: Record<string, string>;
  sampleRow: any;
  onMappingChange: (field: string, sourceColumn: string) => void;
  onPrev: () => void;
  onNext: () => void;
}

export const ColumnMappingStep: React.FC<ColumnMappingStepProps> = ({
  selectedEntity,
  headers,
  mapping,
  sampleRow,
  onMappingChange,
  onPrev,
  onNext
}) => {
  const targetFields = ENTITY_FIELDS[selectedEntity] || [];
  const unmappedRequired = targetFields.filter(f => f.required && !mapping[f.label]);

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
      <div className="text-center space-y-2">
        <h3 className="text-xl font-bold">Map your columns</h3>
        <p className="text-muted-foreground">Match your source columns to Kafiskey's data fields.</p>
      </div>

      {unmappedRequired.length > 0 ? (
        <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-800 dark:text-amber-200">Required fields need mapping</p>
            <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">
              Please map a source column to: <strong>{unmappedRequired.map(f => f.label).join(', ')}</strong>
            </p>
          </div>
        </div>
      ) : (
        <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 flex items-center gap-3">
          <CheckCircle2 className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
          <p className="text-sm text-emerald-700 dark:text-emerald-300">All required fields are mapped!</p>
        </div>
      )}

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Kafiskey Field</TableHead>
              <TableHead>Source Column</TableHead>
              <TableHead>Sample Data</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {targetFields.map(field => {
              const isMapped = !!mapping[field.label];
              const isRequiredUnmapped = field.required && !isMapped;
              return (
                <TableRow key={field.label} className={isRequiredUnmapped ? 'bg-amber-50 dark:bg-amber-950/20' : ''}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{field.label}</span>
                      {field.required && (
                        <Badge 
                          variant={isRequiredUnmapped ? 'warning' : 'outline'} 
                          className={`text-[9px] px-1.5 h-4 ${isRequiredUnmapped ? 'bg-amber-100 text-amber-700 border-amber-300 dark:bg-amber-900 dark:text-amber-300 dark:border-amber-700' : 'bg-muted text-muted-foreground'}`}
                        >
                          {isRequiredUnmapped ? '⚠ Required' : 'Required'}
                        </Badge>
                      )}
                    </div>
                    {field.description && <p className="text-[10px] text-muted-foreground mt-0.5">{field.description}</p>}
                  </TableCell>
                  <TableCell>
                    <select 
                      className={`flex h-9 w-full rounded-md border px-3 py-1 text-sm shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 ${
                        isRequiredUnmapped 
                          ? 'border-amber-400 bg-amber-50 dark:bg-amber-950/30 dark:border-amber-600' 
                          : 'border-input bg-transparent'
                      }`}
                      value={mapping[field.label] || ''}
                      onChange={(e) => onMappingChange(field.label, e.target.value)}
                    >
                      <option value="">-- Skip Field --</option>
                      {headers.map(h => (
                        <option key={h} value={h}>{h}</option>
                      ))}
                    </select>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground italic">
                    {mapping[field.label] && sampleRow?.[mapping[field.label]] ? 
                      String(sampleRow[mapping[field.label]]).substring(0, 30) : '-'}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>

      <div className="flex justify-between pt-6">
        <Button variant="outline" onClick={onPrev}>Back</Button>
        <Button onClick={onNext}>
          Preview & Validate
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};
