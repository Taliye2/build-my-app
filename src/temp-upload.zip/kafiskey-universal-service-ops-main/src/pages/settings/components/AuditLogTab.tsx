import React from 'react';
import { AuditLogViewer } from '@/pages/compliance/components/AuditLogViewer';

export const AuditLogTab: React.FC = () => {
  return <AuditLogViewer />;
};
