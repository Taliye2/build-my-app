import React, { useState, useEffect } from 'react';
import { blink } from '@/lib/blink';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Megaphone, Play, Pause, Edit2, BarChart3, Mail, Trash2, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { CampaignDialog } from './CampaignDialog';
import { CampaignAnalytics } from './CampaignAnalytics';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export interface Campaign {
  id: string;
  workspace_id: string;
  name: string;
  campaign_type: 'onboarding' | 'activation' | 'feature_update' | 'compliance' | 'retention' | 'education';
  status: 'draft' | 'active' | 'paused';
  sender_identity: 'transactional' | 'campaign';
  audience_rules: any;
  created_at: string;
}

export const CampaignsTab: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | undefined>();
  const [isAnalyticsOpen, setIsAnalyticsOpen] = useState(false);

  const fetchCampaigns = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('campaigns')
      .select('*')
      .eq('workspace_id', activeWorkspace.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Failed to fetch campaigns');
    } else {
      setCampaigns(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchCampaigns();
  }, [activeWorkspace]);

  const handleToggleStatus = async (campaign: Campaign) => {
    const newStatus = campaign.status === 'active' ? 'paused' : 'active';
    const { error } = await supabase
      .from('campaigns')
      .update({ status: newStatus })
      .eq('id', campaign.id);

    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success(`Campaign ${newStatus === 'active' ? 'activated' : 'paused'}`);
      fetchCampaigns();
    }
  };

  const handleProcessCampaigns = async () => {
    if (!activeWorkspace) return;
    setProcessing(true);
    try {
      // In a real app, this would be a background job.
      // We'll call an edge function to process campaigns for this workspace.
      const { data, error } = await blink.functions.invoke('campaign-processor', {
        body: { workspaceId: activeWorkspace.id }
      });
      
      if (error) throw error;
      
      toast.success('Campaign processing started');
    } catch (error) {
      toast.error('Campaign processor offline. This normally runs as a background cron.');
    } finally {
      setProcessing(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this campaign?')) return;
    const { error } = await supabase
      .from('campaigns')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error('Failed to delete campaign');
    } else {
      toast.success('Campaign deleted');
      fetchCampaigns();
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Email Campaigns</h2>
          <p className="text-sm text-muted-foreground">
            Manage your onboarding, compliance, and education email sequences.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleProcessCampaigns} 
            disabled={processing}
            className="text-xs"
          >
            <RefreshCw className={`h-3 w-3 mr-2 ${processing ? 'animate-spin' : ''}`} />
            Run Processor
          </Button>
          <Button onClick={() => { setSelectedCampaign(undefined); setIsDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            New Campaign
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Campaigns</CardTitle>
          <CardDescription>
            Campaigns are delivered based on audience rules and sequence delays.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Campaign</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Sender</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">Loading campaigns...</TableCell>
                </TableRow>
              ) : campaigns.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8">
                    <div className="flex flex-col items-center gap-2 text-muted-foreground">
                      <Megaphone className="h-8 w-8 opacity-20" />
                      <p>No campaigns yet</p>
                      <Button variant="link" onClick={() => setIsDialogOpen(true)}>Create your first campaign</Button>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                campaigns.map((campaign) => (
                  <TableRow key={campaign.id}>
                    <TableCell className="font-medium">
                      <div className="flex flex-col">
                        <span>{campaign.name}</span>
                        <span className="text-xs text-muted-foreground">{campaign.id.slice(0, 8)}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">
                        {campaign.campaign_type.replace('_', ' ')}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="capitalize">
                        {campaign.sender_identity}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={campaign.status === 'active' ? 'default' : campaign.status === 'paused' ? 'secondary' : 'outline'}
                        className="capitalize"
                      >
                        {campaign.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(campaign.created_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => handleToggleStatus(campaign)}
                          title={campaign.status === 'active' ? 'Pause' : 'Activate'}
                        >
                          {campaign.status === 'active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => { setSelectedCampaign(campaign); setIsAnalyticsOpen(true); }}
                          title="Analytics"
                        >
                          <BarChart3 className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => { setSelectedCampaign(campaign); setIsDialogOpen(true); }}
                          title="Edit"
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleDelete(campaign.id)}
                          title="Delete"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <CampaignDialog 
        open={isDialogOpen} 
        onOpenChange={setIsDialogOpen} 
        campaign={selectedCampaign}
        onSuccess={fetchCampaigns}
      />

      <CampaignAnalytics
        open={isAnalyticsOpen}
        onOpenChange={setIsAnalyticsOpen}
        campaign={selectedCampaign}
      />
    </div>
  );
};
