import React, { useState, useEffect } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import { logAudit } from '@/lib/audit';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from 'sonner';
import { ShieldCheck, Lock, AlertCircle, Save } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const PHI_SCOPES = [
  { id: 'clients', label: 'Clients' },
  { id: 'notes', label: 'Notes' },
  { id: 'documents', label: 'Documents' },
  { id: 'services', label: 'Services' },
  { id: 'programs', label: 'Programs' },
  { id: 'custom_fields', label: 'Custom Fields' },
];

const ROLES = [
  { id: 'OWNER', label: 'Owner' },
  { id: 'ADMIN', label: 'Admin' },
  { id: 'MANAGER', label: 'Manager' },
  { id: 'STAFF', label: 'Staff' },
  { id: 'READ_ONLY', label: 'ReadOnly/Auditor' },
];

const RESTRICTIONS = [
  { id: 'exports', label: 'Restrict PHI in exports' },
  { id: 'api', label: 'Restrict PHI via API' },
  { id: 'integrations', label: 'Restrict PHI in integrations' },
];

export const HIPAAConfigurationTab: React.FC = () => {
  const { activeWorkspace, refreshWorkspaces, activeMember } = useWorkspace();
  const [loading, setLoading] = useState(false);
  
  const [config, setConfig] = useState({
    enabled: activeWorkspace?.hipaa_config?.enabled ?? false,
    phi_scope: activeWorkspace?.hipaa_config?.phi_scope ?? [],
    role_permissions: activeWorkspace?.hipaa_config?.role_permissions ?? {
      OWNER: { view: true, edit: true },
      ADMIN: { view: true, edit: true },
      MANAGER: { view: false, edit: false },
      STAFF: { view: false, edit: false },
      READ_ONLY: { view: false, edit: false },
    },
    restrictions: activeWorkspace?.hipaa_config?.restrictions ?? [],
  });

  const isPrivileged = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN';

  const handleSave = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    try {
      const { error } = await supabase
        .from('workspaces')
        .update({ hipaa_config: config })
        .eq('id', activeWorkspace.id);

      if (error) throw error;

      await logAudit(
        activeWorkspace.id,
        null,
        'HIPAA_CONFIG_UPDATED',
        'workspace',
        activeWorkspace.id,
        { status: config.enabled ? 'enabled' : 'disabled' }
      );

      toast.success('HIPAA configuration saved and logged to audit trail');
      await refreshWorkspaces();
    } catch (error: any) {
      console.error('Error saving HIPAA config:', error);
      toast.error('Failed to save configuration: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleScope = (scopeId: string) => {
    setConfig(prev => ({
      ...prev,
      phi_scope: prev.phi_scope.includes(scopeId)
        ? prev.phi_scope.filter(id => id !== scopeId)
        : [...prev.phi_scope, scopeId]
    }));
  };

  const togglePermission = (roleId: string, type: 'view' | 'edit') => {
    // Owners and Admins always have full access
    if (roleId === 'OWNER' || roleId === 'ADMIN') return;

    setConfig(prev => ({
      ...prev,
      role_permissions: {
        ...prev.role_permissions,
        [roleId]: {
          ...prev.role_permissions[roleId],
          [type]: !prev.role_permissions[roleId][type]
        }
      }
    }));
  };

  const toggleRestriction = (restrictionId: string) => {
    setConfig(prev => ({
      ...prev,
      restrictions: prev.restrictions.includes(restrictionId)
        ? prev.restrictions.filter(id => id !== restrictionId)
        : [...prev.restrictions, restrictionId]
    }));
  };

  if (!isPrivileged) {
    return (
      <Card>
        <CardContent className="py-12 flex flex-col items-center justify-center text-center space-y-4">
          <Lock className="h-12 w-12 text-muted-foreground opacity-20" />
          <div className="space-y-1">
            <h3 className="text-lg font-bold">Access Denied</h3>
            <p className="text-sm text-muted-foreground">Only Workspace Owners and Admins can configure HIPAA settings.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-primary" />
                HIPAA Compliance Mode
              </CardTitle>
              <CardDescription>
                Toggle the enforcement of HIPAA-specific data controls across the workspace.
              </CardDescription>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked) => setConfig(prev => ({ ...prev, enabled: checked }))}
            />
          </div>
        </CardHeader>
        <CardContent>
          <Alert variant={config.enabled ? 'default' : 'secondary'} className={config.enabled ? 'border-primary/20 bg-primary/5' : ''}>
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{config.enabled ? 'HIPAA Mode Active' : 'HIPAA Mode Inactive'}</AlertTitle>
            <AlertDescription className="text-xs">
              {config.enabled 
                ? 'Advanced PHI controls and strict audit logging are now active. Your organization remains the primary Covered Entity responsible for compliance.'
                : 'Enable this if your organization handles Protected Health Information (PHI). Your organization remains responsible as the Covered Entity.'
              }
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <div className={!config.enabled ? 'opacity-50 pointer-events-none grayscale' : ''}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-bold uppercase tracking-wider">PHI Scope Selection</CardTitle>
              <CardDescription className="text-xs">Select where PHI may exist in your workspace.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {PHI_SCOPES.map((scope) => (
                <div key={scope.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`scope-${scope.id}`}
                    checked={config.phi_scope.includes(scope.id)}
                    onCheckedChange={() => toggleScope(scope.id)}
                  />
                  <Label htmlFor={`scope-${scope.id}`} className="text-sm leading-none cursor-pointer">
                    {scope.label}
                  </Label>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-bold uppercase tracking-wider">PHI Restrictions</CardTitle>
              <CardDescription className="text-xs">Apply additional safeguards for PHI data.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {RESTRICTIONS.map((restriction) => (
                <div key={restriction.id} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`restriction-${restriction.id}`}
                    checked={config.restrictions.includes(restriction.id)}
                    onCheckedChange={() => toggleRestriction(restriction.id)}
                  />
                  <Label htmlFor={`restriction-${restriction.id}`} className="text-sm leading-none cursor-pointer">
                    {restriction.label}
                  </Label>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-wider">PHI Access By Role</CardTitle>
            <CardDescription className="text-xs">Control which roles can view or edit PHI-designated data.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Role</TableHead>
                  <TableHead className="text-center w-32">View PHI</TableHead>
                  <TableHead className="text-center w-32">Edit PHI</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {ROLES.map((role) => (
                  <TableRow key={role.id}>
                    <TableCell className="font-medium text-sm">{role.label}</TableCell>
                    <TableCell className="text-center">
                      <Checkbox 
                        checked={config.role_permissions[role.id]?.view}
                        onCheckedChange={() => togglePermission(role.id, 'view')}
                        disabled={role.id === 'OWNER' || role.id === 'ADMIN'}
                      />
                    </TableCell>
                    <TableCell className="text-center">
                      <Checkbox 
                        checked={config.role_permissions[role.id]?.edit}
                        onCheckedChange={() => togglePermission(role.id, 'edit')}
                        disabled={role.id === 'OWNER' || role.id === 'ADMIN'}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end gap-4">
        <Button variant="outline" onClick={() => refreshWorkspaces()} disabled={loading}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={loading} className="gap-2">
          {loading ? 'Saving...' : <><Save className="h-4 w-4" /> Save HIPAA Configuration</>}
        </Button>
      </div>
    </div>
  );
};
