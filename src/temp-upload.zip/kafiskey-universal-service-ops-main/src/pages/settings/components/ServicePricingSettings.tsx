import React, { useState, useEffect } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Edit2, Plus, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

interface ServiceTemplate {
  id: string;
  name: string;
}

interface ServicePricing {
  id: string;
  service_template_id: string;
  pricing_model: 'hourly' | 'flat' | 'unit';
  rate_amount: number;
  currency: string;
  is_active: boolean;
  notes?: string;
  service_templates?: ServiceTemplate;
}

export const ServicePricingSettings: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [pricing, setPricing] = useState<ServicePricing[]>([]);
  const [templates, setTemplates] = useState<ServiceTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingPrice, setEditingPrice] = useState<Partial<ServicePricing> | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  useEffect(() => {
    if (activeWorkspace) {
      fetchData();
    }
  }, [activeWorkspace]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [pricingRes, templatesRes] = await Promise.all([
        supabase
          .from('service_pricing')
          .select('*, service_templates(id, name)')
          .eq('workspace_id', activeWorkspace?.id),
        supabase
          .from('service_templates')
          .select('id, name')
          .eq('workspace_id', activeWorkspace?.id)
          .eq('active', true)
      ]);

      if (pricingRes.error) throw pricingRes.error;
      if (templatesRes.error) throw templatesRes.error;

      setPricing(pricingRes.data || []);
      setTemplates(templatesRes.data || []);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!editingPrice || !editingPrice.service_template_id || !editingPrice.pricing_model) return;
    
    setLoading(true);
    try {
      const payload = {
        ...editingPrice,
        workspace_id: activeWorkspace?.id,
        rate_amount: Number(editingPrice.rate_amount) || 0
      };

      let error;
      if (editingPrice.id) {
        const { error: err } = await supabase
          .from('service_pricing')
          .update(payload)
          .eq('id', editingPrice.id);
        error = err;
      } else {
        const { error: err } = await supabase
          .from('service_pricing')
          .insert(payload);
        error = err;
      }

      if (error) throw error;
      
      toast.success('Pricing saved');
      setIsDialogOpen(false);
      fetchData();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Service Pricing</CardTitle>
            <CardDescription>Configure rates and pricing models for your services.</CardDescription>
          </div>
          <Button size="sm" onClick={() => { setEditingPrice({ pricing_model: 'hourly', rate_amount: 0, is_active: true, currency: 'USD' }); setIsDialogOpen(true); }}>
            <Plus className="h-4 w-4 mr-2" />
            Add Pricing
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Service</TableHead>
                <TableHead>Model</TableHead>
                <TableHead>Rate</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pricing.map((price) => (
                <TableRow key={price.id}>
                  <TableCell className="font-medium">
                    {price.service_templates?.name || 'Unknown Service'}
                  </TableCell>
                  <TableCell className="capitalize">{price.pricing_model}</TableCell>
                  <TableCell>
                    {price.rate_amount.toLocaleString('en-US', { style: 'currency', currency: price.currency })}
                    {price.pricing_model === 'hourly' && ' / hr'}
                    {price.pricing_model === 'unit' && ' / unit'}
                    {price.pricing_model === 'flat' && ' / session'}
                  </TableCell>
                  <TableCell>
                    <Badge variant={price.is_active ? 'default' : 'secondary'}>
                      {price.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => { setEditingPrice(price); setIsDialogOpen(true); }}>
                      <Edit2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {templates.filter(t => !pricing.some(p => p.service_template_id === t.id)).map(t => (
                <TableRow key={t.id} className="bg-destructive/5 dark:bg-destructive/10">
                  <TableCell className="font-medium text-destructive flex items-center gap-2">
                    <AlertCircle className="h-4 w-4" />
                    {t.name}
                  </TableCell>
                  <TableCell colSpan={3} className="text-muted-foreground italic">No rate set</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" onClick={() => { setEditingPrice({ service_template_id: t.id, pricing_model: 'hourly', rate_amount: 0, is_active: true, currency: 'USD' }); setIsDialogOpen(true); }}>
                      Configure
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {pricing.length === 0 && templates.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    No services found. Create some in Service Catalog first.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingPrice?.id ? 'Edit Pricing' : 'Add Pricing'}</DialogTitle>
            <DialogDescription>Configure how this service is billed to clients.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Service Template</Label>
              <Select 
                value={editingPrice?.service_template_id} 
                onValueChange={(val) => setEditingPrice(prev => ({ ...prev!, service_template_id: val }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select service" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map(t => (
                    <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Pricing Model</Label>
                <Select 
                  value={editingPrice?.pricing_model} 
                  onValueChange={(val: any) => setEditingPrice(prev => ({ ...prev!, pricing_model: val }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select model" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly Rate</SelectItem>
                    <SelectItem value="flat">Flat Session Fee</SelectItem>
                    <SelectItem value="unit">Unit-based Rate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Rate Amount ({editingPrice?.currency || 'USD'})</Label>
                <Input 
                  type="number" 
                  step="0.01" 
                  min="0"
                  value={editingPrice?.rate_amount} 
                  onChange={(e) => setEditingPrice(prev => ({ ...prev!, rate_amount: parseFloat(e.target.value) || 0 }))}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Input 
                value={editingPrice?.notes || ''} 
                onChange={(e) => setEditingPrice(prev => ({ ...prev!, notes: e.target.value }))}
                placeholder="Optional billing notes..."
                spellCheck={true}
                autoCorrect="on"
                autoCapitalize="sentences"
              />
            </div>
            <div className="flex items-center gap-2">
              <input 
                type="checkbox" 
                id="is_active" 
                checked={editingPrice?.is_active} 
                onChange={(e) => setEditingPrice(prev => ({ ...prev!, is_active: e.target.checked }))}
                className="rounded border-gray-300 text-primary focus:ring-primary"
              />
              <Label htmlFor="is_active">Pricing is active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={loading}>Save Pricing</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
