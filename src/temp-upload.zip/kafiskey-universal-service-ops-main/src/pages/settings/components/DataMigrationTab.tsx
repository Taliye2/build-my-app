import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { 
  Download, 
  Upload, 
  History, 
  FileText, 
  FileJson, 
  Archive, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Search,
  Settings,
  Database,
  Users,
  User,
  ShieldAlert,
  Calendar,
  ClipboardList,
  MessageSquare,
  FileSpreadsheet,
  X,
  RefreshCw,
  Trash2,
  Undo2
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { ImportWizard } from './ImportWizard/ImportWizard';
import { MIGRATION_ENTITIES, ENTITY_FIELDS } from './ImportWizard/constants';

// Entity definitions for import/export removed (now in constants.ts)

export const DataMigrationTab: React.FC = () => {
  const { activeWorkspace, activeMember, isTrialActive } = useWorkspace();
  const [activeView, setActiveView] = useState<'overview' | 'import' | 'history'>('overview');
  const [jobs, setJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedJob, setSelectedJob] = useState<any | null>(null);
  const [jobLogs, setJobLogs] = useState<any[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);

  useEffect(() => {
    if (activeWorkspace) {
      fetchJobs();
    }
  }, [activeWorkspace]);

  // Polling for processing jobs
  useEffect(() => {
    if (!activeWorkspace || jobs.length === 0) return;

    const processingJobs = jobs.filter(j => j.status === 'processing');
    if (processingJobs.length === 0) return;

    const interval = setInterval(async () => {
      const { data, error } = await supabase
        .from('import_jobs')
        .select('*')
        .eq('workspace_id', activeWorkspace.id)
        .in('id', processingJobs.map(j => j.id));

      if (!error && data) {
        setJobs(prev => {
          const next = [...prev];
          data.forEach(updatedJob => {
            const index = next.findIndex(j => j.id === updatedJob.id);
            if (index !== -1) {
              // Check for local timeout (if job has been processing for > 10 mins without update)
              const startTime = new Date(updatedJob.started_at || updatedJob.created_at).getTime();
              const now = new Date().getTime();
              
              if (updatedJob.status === 'processing' && (now - startTime > 10 * 60 * 1000)) {
                // Mark as failed locally if it's been too long
                updatedJob.status = 'failed';
                updatedJob.failure_reason = 'Internal timeout (job stalled)';
              }
              
              next[index] = updatedJob;
            }
          });
          return next;
        });
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [activeWorkspace, jobs]);

  const fetchJobs = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('import_jobs')
      .select('*')
      .eq('workspace_id', activeWorkspace.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Failed to fetch import history');
    } else {
      setJobs(data || []);
    }
    setLoading(false);
  };

  const fetchJobLogs = async (job: any) => {
    setSelectedJob(job);
    setLoadingLogs(true);
    setJobLogs([]);
    
    const { data, error } = await supabase
      .from('import_job_rows')
      .select('*')
      .eq('job_id', job.id)
      .order('row_number', { ascending: true });
    
    if (error) {
      toast.error('Failed to fetch job logs');
    } else {
      setJobLogs(data || []);
    }
    setLoadingLogs(false);
  };

  const downloadTemplate = (entityId: string) => {
    const fields = ENTITY_FIELDS[entityId] || [];
    const headers = fields.map(f => f.label).join(',');
    const example = fields.map(f => f.required ? 'Example' : '').join(',');
    const csvContent = `${headers}\n${example}`;
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `kafiskey_${entityId}_template.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportEntity = async (entityId: string, format: 'csv' | 'json') => {
    if (!activeWorkspace) return;
    setLoading(true);
    try {
      const tableMap: Record<string, string> = {
        clients: 'clients',
        providers: 'staff_profiles',
        contacts: 'contacts',
        service_catalog: 'service_templates',
        scheduling: 'service_events',
        service_records: 'service_records',
        documents: 'documents',
        notes: 'client_notes',
      };

      const { data, error } = await supabase
        .from(tableMap[entityId] || entityId)
        .select('*')
        .eq('workspace_id', activeWorkspace.id)
        .limit(isTrialActive ? 10 : 5000);

      if (error) throw error;

      if (isTrialActive && data && data.length >= 10) {
        toast.info('Export limited to 10 sample records during trial evaluation.');
      }

      if (format === 'json') {
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        saveAs(blob, `kafiskey_export_${entityId}_${new Date().toISOString()}.json`);
      } else {
        const csv = Papa.unparse(data);
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        saveAs(blob, `kafiskey_export_${entityId}_${new Date().toISOString()}.csv`);
      }
      
      // Log to audit
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('audit_logs').insert({
          workspace_id: activeWorkspace.id,
          actor_user_id: user.id,
          action: 'DATA_EXPORT',
          entity_type: entityId,
          metadata: { format }
        });
      }

      toast.success(`${entityId} exported successfully`);
    } catch (error: any) {
      toast.error(`Export failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const exportFullBundle = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    try {
      const zip = new JSZip();
      const manifest: any = {
        workspace_id: activeWorkspace.id,
        export_date: new Date().toISOString(),
        entities: []
      };

      const tableMap: Record<string, string> = {
        clients: 'clients',
        providers: 'staff_profiles',
        contacts: 'contacts',
        service_catalog: 'service_templates',
        scheduling: 'service_events',
        service_records: 'service_records',
        documents: 'documents',
        notes: 'client_notes',
      };

      for (const entity of MIGRATION_ENTITIES) {
        const { data, error } = await supabase
          .from(tableMap[entity.id] || entity.id)
          .select('*')
          .eq('workspace_id', activeWorkspace.id)
          .limit(isTrialActive ? 5 : 5000);

        if (!error && data) {
          const csv = Papa.unparse(data);
          zip.file(`${entity.id}.csv`, csv);
          manifest.entities.push({
            id: entity.id,
            count: data.length,
            file: `${entity.id}.csv`
          });
        }
      }

      if (isTrialActive) {
        manifest.trial_mode = true;
        manifest.limit_applied = 5;
        zip.file('TRIAL_NOTICE.txt', 'This export bundle was generated in Trial Evaluation mode and contains a maximum of 5 records per entity.');
      }

      zip.file('manifest.json', JSON.stringify(manifest, null, 2));
      zip.file('README.txt', `Kafiskey Workspace Export\nWorkspace: ${activeWorkspace.name}\nDate: ${new Date().toLocaleString()}`);

      const content = await zip.generateAsync({ type: 'blob' });
      saveAs(content, `kafiskey_full_export_${new Date().toISOString()}.zip`);

      // Log to audit
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('audit_logs').insert({
          workspace_id: activeWorkspace.id,
          actor_user_id: user.id,
          action: 'DATA_EXPORT_FULL',
          metadata: { entities: manifest.entities.map((e: any) => e.id) }
        });
      }

      toast.success('Full export bundle generated');
    } catch (error: any) {
      toast.error(`Bundle export failed: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const isAdmin = activeMember?.role === 'ADMIN' || activeMember?.role === 'OWNER';

  if (!isAdmin) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <ShieldAlert className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Access Restricted</h3>
          <p className="text-muted-foreground">Only Workspace Owners and Admins can perform data migrations.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Data Migration</h2>
          <p className="text-muted-foreground">
            Export your data or migrate records from other CRMs.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant={activeView === 'overview' ? 'secondary' : 'ghost'} 
            onClick={() => setActiveView('overview')}
            size="sm"
          >
            Overview
          </Button>
          <Button 
            variant={activeView === 'history' ? 'secondary' : 'ghost'} 
            onClick={() => setActiveView('history')}
            size="sm"
          >
            History
          </Button>
        </div>
      </div>

      {activeView === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5 text-primary" />
                Export Data
              </CardTitle>
              <CardDescription>
                Download your workspace data in standard formats for backup or migration.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-3">
                <Button 
                  variant="outline" 
                  className="justify-start h-auto py-3 px-4"
                  onClick={exportFullBundle}
                  disabled={loading}
                >
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded bg-primary/10 flex items-center justify-center">
                      <Archive className="h-4 w-4 text-primary" />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-medium">Full Export Bundle</p>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">ZIP (All entities + attachments)</p>
                    </div>
                  </div>
                </Button>
                <Separator className="my-1" />
                {MIGRATION_ENTITIES.map(entity => (
                  <div key={entity.id} className="flex items-center justify-between p-2 rounded-md hover:bg-muted/50 transition-colors">
                    <div className="flex items-center gap-3">
                      <entity.icon className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <span className="text-sm font-medium">{entity.label}</span>
                        <div className="flex gap-2">
                          <button 
                            className="text-[9px] uppercase font-bold text-primary hover:underline"
                            onClick={() => downloadTemplate(entity.id)}
                          >
                            Template
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        title="Export CSV"
                        onClick={() => exportEntity(entity.id, 'csv')}
                        disabled={loading}
                      >
                        <FileText className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8" 
                        title="Export JSON"
                        onClick={() => exportEntity(entity.id, 'json')}
                        disabled={loading}
                      >
                        <FileJson className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-primary/20 dark:border-primary/30 bg-primary/5 dark:bg-primary/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-primary" />
                Import Data
              </CardTitle>
              <CardDescription>
                Migrate clients, providers, and historical records into Kafiskey.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-background border border-primary/10 space-y-3">
                <h4 className="text-sm font-semibold">Ready to migrate?</h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Your file will be reviewed in a safe preview mode. Nothing is added to your workspace until you approve the import.
                </p>
                <ul className="space-y-2 py-2">
                  {[
                    'Automatic column mapping',
                    'In-browser data validation',
                    'Safe de-duplication rules',
                    'Support for XLSX and CSV'
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-2 text-[11px]">
                      <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={() => setActiveView('import')}>
                Upload & Validate Data
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}

      {activeView === 'import' && (
        <div className="space-y-6">
          <Button variant="ghost" size="sm" onClick={() => setActiveView('overview')} className="mb-2">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Migration Overview
          </Button>
          <ImportWizard onComplete={() => {
            setActiveView('history');
            fetchJobs();
          }} />
        </div>
      )}

      {activeView === 'history' && (
        <Card>
          <CardHeader>
            <CardTitle>Migration History</CardTitle>
            <CardDescription>View status and logs of past import and export jobs.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job ID</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Rows</TableHead>
                  <TableHead>Imported/Updated</TableHead>
                  <TableHead>Skipped</TableHead>
                  <TableHead>Failed</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading && jobs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="h-24 text-center">Loading history...</TableCell>
                  </TableRow>
                ) : jobs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="h-24 text-center text-muted-foreground">
                      No migration jobs found.
                    </TableCell>
                  </TableRow>
                ) : (
                  jobs.map((job) => (
                    <TableRow key={job.id}>
                      <TableCell className="font-mono text-[10px]">{job.id.substring(0, 8)}...</TableCell>
                      <TableCell className="capitalize">{job.entity_type}</TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <Badge variant={
                            job.status === 'completed' ? 'success' : 
                            job.status === 'failed' ? 'destructive' : 
                            job.status === 'completed_with_errors' ? 'warning' : 
                            job.status === 'rolled_back' ? 'secondary' : 'outline'
                          }>
                            {job.status === 'processing' ? (
                              <div className="flex items-center gap-1">
                                <RefreshCw className="h-3 w-3 animate-spin" />
                                Processing
                              </div>
                            ) : job.status.replace(/_/g, ' ')}
                          </Badge>
                          {job.status === 'processing' && (
                            <p className="text-[10px] text-muted-foreground whitespace-nowrap">
                              {job.imported_count + job.updated_count + job.failed_count} / {job.total_rows} rows
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>{job.total_rows}</TableCell>
                      <TableCell>{job.imported_count + job.updated_count}</TableCell>
                      <TableCell className={job.skipped_count > 0 ? 'text-amber-600 dark:text-amber-400' : ''}>
                        {job.skipped_count || 0}
                      </TableCell>
                      <TableCell className={job.failed_count > 0 ? 'text-destructive font-bold' : ''}>
                        {job.failed_count - (job.skipped_count || 0)}
                      </TableCell>
                      <TableCell className="text-xs">
                        {new Date(job.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => fetchJobLogs(job)}>Details</Button>
                          {job.rollback_available && job.status === 'completed' && (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-warning border-warning/30 hover:bg-warning/10 gap-1"
                              onClick={() => undoImport(job)}
                              disabled={loading}
                            >
                              <Undo2 className="h-3 w-3" />
                              Undo
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Job Details Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={(open) => !open && setSelectedJob(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              Import Job Details
              {selectedJob && (
                <Badge variant={
                  selectedJob.status === 'completed' ? 'success' : 
                  selectedJob.status === 'failed' ? 'destructive' : 
                  selectedJob.status === 'completed_with_errors' ? 'warning' : 'outline'
                }>
                  {selectedJob.status?.replace(/_/g, ' ')}
                </Badge>
              )}
            </DialogTitle>
            <DialogDescription>
              {selectedJob && (
                <span className="flex items-center gap-4 text-xs">
                  <span>Entity: <strong className="capitalize">{selectedJob.entity_type}</strong></span>
                  <span>•</span>
                  <span>Total Rows: <strong>{selectedJob.total_rows}</strong></span>
                  <span>•</span>
                  <span>Imported: <strong>{selectedJob.imported_count}</strong></span>
                  <span>•</span>
                  <span>Updated: <strong>{selectedJob.updated_count}</strong></span>
                  <span>•</span>
                  <span className={selectedJob.failed_count > 0 ? 'text-destructive' : ''}>
                    Failed: <strong>{selectedJob.failed_count}</strong>
                  </span>
                </span>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="h-[50vh] mt-4">
            {loadingLogs ? (
              <div className="flex items-center justify-center py-12">
                <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : jobLogs.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                No row-level logs found for this job.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Row #</TableHead>
                    <TableHead className="w-24">Status</TableHead>
                    <TableHead>Errors / Details</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {jobLogs.map((log) => {
                    const errors = log.errors_json ? (typeof log.errors_json === 'string' ? JSON.parse(log.errors_json) : log.errors_json) : null;
                    return (
                      <TableRow key={log.id}>
                        <TableCell className="font-mono text-xs">{log.row_number}</TableCell>
                        <TableCell>
                          <Badge variant={
                            log.status === 'success' ? 'success' : 
                            log.status === 'failed' ? 'destructive' : 
                            log.status === 'skipped' ? 'secondary' : 'outline'
                          } className="text-[10px]">
                            {log.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs">
                          {errors ? (
                            <ul className="list-disc list-inside space-y-0.5 text-destructive">
                              {Array.isArray(errors) ? errors.map((err: string, i: number) => (
                                <li key={i}>{err}</li>
                              )) : (
                                <li>{typeof errors === 'object' ? JSON.stringify(errors) : String(errors)}</li>
                              )}
                            </ul>
                          ) : log.record_id_created_or_updated ? (
                            <span className="text-muted-foreground">
                              Record ID: <code className="bg-muted px-1 py-0.5 rounded text-[10px]">{log.record_id_created_or_updated}</code>
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Old ImportWizard placeholder removed