import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Campaign } from './CampaignsTab';
import { Mail, MousePointer2, Eye, AlertCircle, BarChart3 } from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from 'recharts';

interface CampaignAnalyticsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  campaign?: Campaign;
}

export const CampaignAnalytics: React.FC<CampaignAnalyticsProps> = ({ open, onOpenChange, campaign }) => {
  const [stats, setStats] = useState({
    sent: 0,
    opened: 0,
    clicked: 0,
    failed: 0
  });
  const [sequenceStats, setSequenceStats] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (campaign && open) {
      fetchAnalytics();
    }
  }, [campaign, open]);

  const fetchAnalytics = async () => {
    if (!campaign) return;
    setLoading(true);
    
    // Fetch overall stats
    const { data: logs, error } = await supabase
      .from('campaign_logs')
      .select('status, sequence_id')
      .eq('campaign_id', campaign.id);

    if (error) {
      console.error('Failed to fetch logs:', error);
    } else {
      const counts = { sent: 0, opened: 0, clicked: 0, failed: 0 };
      const seqCounts: Record<string, any> = {};

      logs?.forEach(log => {
        counts[log.status as keyof typeof counts]++;
        if (log.sequence_id) {
          if (!seqCounts[log.sequence_id]) {
            seqCounts[log.sequence_id] = { id: log.sequence_id, sent: 0, opened: 0, clicked: 0 };
          }
          seqCounts[log.sequence_id][log.status]++;
        }
      });

      setStats(counts);

      // Fetch sequence names
      const { data: sequences } = await supabase
        .from('campaign_sequences')
        .select('id, subject, sequence_order')
        .eq('campaign_id', campaign.id);
      
      const sequenceData = sequences?.map(s => ({
        name: `Email ${s.sequence_order}`,
        subject: s.subject,
        sent: seqCounts[s.id]?.sent || 0,
        opened: seqCounts[s.id]?.opened || 0,
        clicked: seqCounts[s.id]?.clicked || 0
      })) || [];

      setSequenceStats(sequenceData.sort((a, b) => a.name.localeCompare(b.name)));
    }
    setLoading(false);
  };

  const chartData = [
    { name: 'Sent', value: stats.sent, color: 'hsl(var(--primary))' },
    { name: 'Opened', value: stats.opened, color: 'hsl(var(--secondary))' },
    { name: 'Clicked', value: stats.clicked, color: 'hsl(var(--accent))' },
    { name: 'Failed', value: stats.failed, color: 'hsl(var(--destructive))' }
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            <DialogTitle>Campaign Analytics: {campaign?.name}</DialogTitle>
          </div>
          <DialogDescription>
            Performance metrics for this campaign's email sequences.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-20 text-center text-muted-foreground italic">Loading analytics...</div>
        ) : (
          <div className="space-y-6 mt-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                    <Mail className="h-3 w-3" /> Total Sent
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">{stats.sent}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                    <Eye className="h-3 w-3" /> Opened
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">{stats.opened}</div>
                  <p className="text-[10px] text-muted-foreground">
                    {stats.sent > 0 ? ((stats.opened / stats.sent) * 100).toFixed(1) : 0}% Open Rate
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                    <MousePointer2 className="h-3 w-3" /> Clicked
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">{stats.clicked}</div>
                  <p className="text-[10px] text-muted-foreground">
                    {stats.opened > 0 ? ((stats.clicked / stats.opened) * 100).toFixed(1) : 0}% Click-to-Open
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="p-4 pb-2">
                  <CardTitle className="text-xs font-medium text-muted-foreground flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> Failed
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-2xl font-bold">{stats.failed}</div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Performance by Email</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sequenceStats}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" fontSize={10} tickLine={false} axisLine={false} />
                      <YAxis fontSize={10} tickLine={false} axisLine={false} />
                      <Tooltip 
                        contentStyle={{ fontSize: '10px', borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        cursor={{ fill: 'rgba(0,0,0,0.05)' }}
                      />
                      <Bar dataKey="sent" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="opened" fill="hsl(var(--secondary))" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="clicked" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <div className="rounded-md border">
              <div className="bg-muted/50 p-3 border-b text-xs font-medium grid grid-cols-4 gap-4">
                <div className="col-span-2">Sequence Step</div>
                <div className="text-center">Sent</div>
                <div className="text-center">Engagement</div>
              </div>
              <div className="divide-y">
                {sequenceStats.map((seq, i) => (
                  <div key={i} className="p-3 grid grid-cols-4 gap-4 text-xs items-center">
                    <div className="col-span-2">
                      <div className="font-medium">{seq.name}</div>
                      <div className="text-[10px] text-muted-foreground truncate">{seq.subject}</div>
                    </div>
                    <div className="text-center font-mono">{seq.sent}</div>
                    <div className="text-center">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-[10px] text-muted-foreground">Open: {seq.sent > 0 ? ((seq.opened / seq.sent) * 100).toFixed(0) : 0}%</span>
                        <span className="text-[10px] text-muted-foreground">Click: {seq.opened > 0 ? ((seq.clicked / seq.opened) * 100).toFixed(0) : 0}%</span>
                      </div>
                    </div>
                  </div>
                ))}
                {sequenceStats.length === 0 && (
                  <div className="p-10 text-center text-muted-foreground text-xs italic">
                    No data available for this campaign yet.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
