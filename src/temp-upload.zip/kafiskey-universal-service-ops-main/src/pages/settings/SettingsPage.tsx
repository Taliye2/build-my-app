import React, { useState, useEffect } from 'react';
import { blink } from '@/lib/blink';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useTheme } from 'next-themes';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Separator } from '@/components/ui/separator';
import { Building2, Mail, Bell, ShieldAlert, ShieldCheck, Palette, Info, DollarSign, Moon, Sun, Monitor, Link2, ExternalLink, Database, History, Lock, QrCode, Printer, Download, Copy, Check } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { QRCodeSVG } from 'qrcode.react';
import { ServicePricingSettings } from './components/ServicePricingSettings';
import { DataMigrationTab } from './components/DataMigrationTab';
import { AuditLogTab } from './components/AuditLogTab';
import { HIPAAConfigurationTab } from './components/HIPAAConfigurationTab';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useSearchParams } from 'react-router-dom';
import { TrialPreviewBanner } from '@/components/TrialPreviewBanner';

export const SettingsPage: React.FC<{ defaultTab?: string }> = ({ defaultTab = 'general' }) => {
  const { activeWorkspace, refreshWorkspaces, activeMember, hasAdvancedReporting, isTrialActive } = useWorkspace();
  const { theme, setTheme } = useTheme();
  const [searchParams, setSearchParams] = useSearchParams();
  const [name, setName] = useState(activeWorkspace?.name || '');
  const [slug, setSlug] = useState(activeWorkspace?.slug || '');
  const [senderName, setSenderName] = useState(activeWorkspace?.email_sender_name || '');
  const [senderEmail, setSenderEmail] = useState(activeWorkspace?.email_sender_address || '');
  const [replyTo, setReplyTo] = useState(activeWorkspace?.email_reply_to || '');
  const [authKey, setAuthKey] = useState(activeWorkspace?.resend_api_key || '');
  const [emailMethod, setEmailMethod] = useState<'kafiskey' | 'organization'>(
    activeWorkspace?.resend_api_key ? 'organization' : 'kafiskey'
  );
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [isCheckInEnabled, setIsCheckInEnabled] = useState(activeWorkspace?.is_check_in_enabled || false);
  const [qbStatus, setQbStatus] = useState<{ connected: boolean; connection?: any } | null>(null);

  useEffect(() => {
    if (activeWorkspace) {
      setName(activeWorkspace.name || '');
      setSlug(activeWorkspace.slug || '');
      setSenderName(activeWorkspace.email_sender_name || '');
      setSenderEmail(activeWorkspace.email_sender_address || '');
      setReplyTo(activeWorkspace.email_reply_to || '');
      setAuthKey(activeWorkspace.resend_api_key || '');
      setEmailMethod(activeWorkspace.resend_api_key ? 'organization' : 'kafiskey');
      setIsCheckInEnabled(activeWorkspace.is_check_in_enabled || false);
    }
  }, [activeWorkspace]);

  useEffect(() => {
    if (searchParams.get('connected') === '1') {
      toast.success('QuickBooks connected successfully');
      searchParams.delete('connected');
      setSearchParams(searchParams);
    }
    if (searchParams.get('disconnected') === '1') {
      toast.success('QuickBooks disconnected successfully');
      searchParams.delete('disconnected');
      setSearchParams(searchParams);
    }
  }, [searchParams, setSearchParams]);

  useEffect(() => {
    if (activeTab === 'integrations' && activeWorkspace) {
      fetchQbStatus();
    }
  }, [activeTab, activeWorkspace]);

  const fetchQbStatus = async () => {
    if (!activeWorkspace) return;
    try {
      const { data, error } = await blink.functions.invoke('quickbooks-oauth', {
        method: 'POST',
        body: { action: 'status', workspaceId: activeWorkspace.id }
      });
      if (error) throw error;
      setQbStatus(data);
    } catch (error) {
      console.error('Failed to fetch QB status:', error);
    }
  };

  const handleConnectQb = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    try {
      const { data, error } = await blink.functions.invoke('quickbooks-oauth', {
        method: 'POST',
        body: { action: 'authorize', workspaceId: activeWorkspace.id }
      });
      
      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (error: any) {
      toast.error('Failed to initiate QuickBooks connection');
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnectQb = async () => {
    if (!activeWorkspace) return;
    if (!confirm('Are you sure you want to disconnect QuickBooks?')) return;
    setLoading(true);
    try {
      const { data, error } = await blink.functions.invoke('quickbooks-oauth', {
        method: 'POST',
        body: { action: 'disconnect', workspaceId: activeWorkspace.id }
      });
      
      if (error) throw error;
      
      setQbStatus({ connected: false });
      window.location.href = '/settings/integrations?disconnected=1';
    } catch (error: any) {
      toast.error('Failed to disconnect QuickBooks');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace) return;
    
    // Basic slug validation
    const validSlug = slug.toLowerCase().replace(/[^a-z0-9-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
    if (slug !== validSlug) {
      toast.error('Invalid slug format. Use only lowercase letters, numbers, and hyphens.');
      setSlug(validSlug);
      return;
    }

    if (!validSlug) {
      toast.error('Slug cannot be empty');
      return;
    }

    setLoading(true);

    const { error } = await supabase
      .from('workspaces')
      .update({ name, slug: validSlug })
      .eq('id', activeWorkspace.id);

    if (error) {
      if (error.code === '23505') {
        toast.error('This slug is already taken. Please choose another one.');
      } else {
        toast.error(error.message);
      }
    } else {
      toast.success('Workspace updated');
      await refreshWorkspaces();
    }
    setLoading(false);
  };

  const handleUpdateCommunication = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace) return;
    setLoading(true);
    
    const isKafiskey = emailMethod === 'kafiskey';
    
    // Basic validation for Resend API key
    if (!isKafiskey && authKey && !authKey.trim().startsWith('re_')) {
      toast.error('Invalid Resend API key format. It should start with "re_"');
      return;
    }

    const updateData = {
      email_sender_name: senderName,
      email_reply_to: replyTo,
      email_sender_address: isKafiskey ? null : senderEmail,
      resend_api_key: isKafiskey ? null : authKey
    };
    
    const { error } = await supabase
      .from('workspaces')
      .update(updateData)
      .eq('id', activeWorkspace.id);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('Communication settings updated');
      await refreshWorkspaces();
    }
    setLoading(false);
  };

  const handleToggleCheckIn = async (enabled: boolean) => {
    if (!activeWorkspace) return;
    setLoading(true);
    
    try {
      const { error } = await supabase
        .from('workspaces')
        .update({ is_check_in_enabled: enabled })
        .eq('id', activeWorkspace.id);

      if (error) throw error;
      
      setIsCheckInEnabled(enabled);
      toast.success(`Check-in feature ${enabled ? 'enabled' : 'disabled'}`);
      await refreshWorkspaces();
    } catch (err: any) {
      toast.error(err.message || 'Failed to update check-in status');
    } finally {
      setLoading(false);
    }
  };

  const downloadQRCode = () => {
    const svg = document.querySelector('.qr-code-svg svg') as SVGGraphicsElement;
    if (!svg) return;
    
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      canvas.width = 500;
      canvas.height = 500;
      if (ctx) {
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 50, 50, 400, 400);
        
        const pngFile = canvas.toDataURL('image/png');
        const downloadLink = document.createElement('a');
        downloadLink.download = `check-in-qr-${activeWorkspace?.slug || 'workspace'}.png`;
        downloadLink.href = pngFile;
        downloadLink.click();
      }
    };
    
    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };

  const printQRCode = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    
    const svg = document.querySelector('.qr-code-svg svg') as SVGGraphicsElement;
    if (!svg) return;
    
    const svgData = new XMLSerializer().serializeToString(svg);
    const baseUrl = import.meta.env.VITE_PUBLIC_APP_URL || window.location.origin;
    const qrUrl = `${baseUrl}/check-in/${activeWorkspace?.slug}`;
    
    printWindow.document.write(`
      <html>
        <head>
          <title>Print QR Code - ${activeWorkspace?.name}</title>
          <style>
            body { 
              font-family: sans-serif; 
              display: flex; 
              flex-direction: column; 
              align-items: center; 
              justify-content: center; 
              height: 100vh; 
              margin: 0;
            }
            .container { text-align: center; max-width: 500px; }
            h1 { margin-bottom: 20px; }
            .qr-container { margin-bottom: 30px; }
            .url { font-family: monospace; font-size: 14px; color: #666; word-break: break-all; margin-top: 20px; }
            svg { width: 300px; height: 300px; }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>${activeWorkspace?.name}</h1>
            <p>Scan to Check-In</p>
            <div class="qr-container">
              ${svgData}
            </div>
            <div class="url">${qrUrl}</div>
          </div>
          <script>
            window.onload = () => {
              window.print();
              setTimeout(() => window.close(), 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const isOwner = activeMember?.role === 'OWNER';
  const isAdmin = activeMember?.role === 'ADMIN';
  const isPrivileged = isOwner || isAdmin;

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <aside className="md:col-span-1 space-y-1">
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'general' ? 'bg-muted' : ''}`}
            onClick={() => setActiveTab('general')}
          >
            <Building2 className="h-4 w-4" />
            Workspace
          </Button>
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'pricing' ? 'bg-muted' : ''}`}
            onClick={() => setActiveTab('pricing')}
          >
            <DollarSign className="h-4 w-4" />
            Service Pricing
          </Button>
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'branding' ? 'bg-muted' : ''}`}
            onClick={() => setActiveTab('branding')}
          >
            <Palette className="h-4 w-4" />
            Identity
          </Button>
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'communication' ? 'bg-muted' : ''}`}
            onClick={() => setActiveTab('communication')}
          >
            <Mail className="h-4 w-4" />
            Communication
          </Button>
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'notifications' ? 'bg-muted' : ''}`}
            onClick={() => setActiveTab('notifications')}
          >
            <Bell className="h-4 w-4" />
            Notifications
          </Button>
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'integrations' ? 'bg-muted' : ''}`}
            onClick={() => (hasAdvancedReporting || isTrialActive) ? setActiveTab('integrations') : toast.error('Scale tier required for integrations')}
            disabled={!(hasAdvancedReporting || isTrialActive)}
          >
            <Link2 className={`h-4 w-4 ${!(hasAdvancedReporting || isTrialActive) ? 'text-muted-foreground' : ''}`} />
            Integrations {!(hasAdvancedReporting || isTrialActive) && <Lock className="h-3 w-3 ml-auto opacity-50" />}
            {isTrialActive && <Badge variant="secondary" className="h-3.5 px-1 ml-auto text-[9px] font-bold bg-amber-100 text-amber-800 border-amber-200">Trial</Badge>}
          </Button>
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'check-in' ? 'bg-muted' : ''}`}
            onClick={() => setActiveTab('check-in')}
          >
            <QrCode className="h-4 w-4" />
            Walk-In Check-In
          </Button>
          <Button
            variant="ghost"
            className={`w-full justify-start gap-2 ${activeTab === 'security' ? 'bg-muted' : ''}`}
            onClick={() => setActiveTab('security')}
          >
            <ShieldAlert className="h-4 w-4" />
            Security
          </Button>
          {(activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN') && (
            <Button
              variant="ghost"
              className={`w-full justify-start gap-2 ${activeTab === 'compliance' ? 'bg-muted' : ''}`}
              onClick={() => setActiveTab('compliance')}
            >
              <ShieldCheck className="h-4 w-4" />
              Compliance
            </Button>
          )}
          {(activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN') && (
            <Button
              variant="ghost"
              className={`w-full justify-start gap-2 ${activeTab === 'audit' ? 'bg-muted' : ''}`}
              onClick={() => (hasAdvancedReporting || isTrialActive) ? setActiveTab('audit') : toast.error('Scale tier required for audit logs')}
              disabled={!(hasAdvancedReporting || isTrialActive)}
            >
              <History className={`h-4 w-4 ${!(hasAdvancedReporting || isTrialActive) ? 'text-muted-foreground' : ''}`} />
              Audit Logs {!(hasAdvancedReporting || isTrialActive) && <Lock className="h-3 w-3 ml-auto opacity-50" />}
              {isTrialActive && <Badge variant="secondary" className="h-3.5 px-1 ml-auto text-[9px] font-bold bg-amber-100 text-amber-800 border-amber-200">Trial</Badge>}
            </Button>
          )}
          {isPrivileged && (
            <Button
              variant="ghost"
              className={`w-full justify-start gap-2 ${activeTab === 'migration' ? 'bg-muted' : ''}`}
              onClick={() => (hasAdvancedReporting || isTrialActive) ? setActiveTab('migration') : toast.error('Scale tier required for data migration')}
              disabled={!(hasAdvancedReporting || isTrialActive)}
            >
              <Database className={`h-4 w-4 ${!(hasAdvancedReporting || isTrialActive) ? 'text-muted-foreground' : ''}`} />
              Data Migration {!(hasAdvancedReporting || isTrialActive) && <Lock className="h-3 w-3 ml-auto opacity-50" />}
              {isTrialActive && <Badge variant="secondary" className="h-3.5 px-1 ml-auto text-[9px] font-bold bg-amber-100 text-amber-800 border-amber-200">Trial</Badge>}
            </Button>
          )}
        </aside>

        <div className="md:col-span-3 space-y-6">
          {activeTab === 'general' && (
            <Card>
              <CardHeader>
                <CardTitle>Workspace Identity</CardTitle>
                <CardDescription>Manage your workspace name and identification details.</CardDescription>
              </CardHeader>
              <form onSubmit={handleUpdateName}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="wsName">Organization Name</Label>
                    <Input
                      id="wsName"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      disabled={!isOwner}
                      placeholder="Enter organization name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wsSlug">Workspace Slug (URL)</Label>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground font-mono">/check-in/</span>
                      <Input
                        id="wsSlug"
                        value={slug}
                        onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/\s+/g, '-'))}
                        disabled={!isOwner}
                        placeholder="my-organization"
                        className="font-mono text-xs"
                      />
                    </div>
                    <p className="text-[10px] text-muted-foreground">This is used for the public check-in URL. Keep it simple and recognizable.</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wsId">Workspace ID</Label>
                    <Input id="wsId" value={activeWorkspace?.id} disabled className="bg-muted font-mono text-xs" />
                    <p className="text-[10px] text-muted-foreground">Unique identifier for system and compliance integrations.</p>
                  </div>
                </CardContent>
                <CardFooter className="border-t px-6 py-4">
                  <Button type="submit" disabled={loading || !isOwner || name === activeWorkspace?.name}>
                    {loading ? 'Saving...' : 'Update Workspace'}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          )}

          {activeTab === 'pricing' && <ServicePricingSettings />}
          
          {activeTab === 'compliance' && <HIPAAConfigurationTab />}
          
          {activeTab === 'branding' && (
            <Card>
              <CardHeader>
                <CardTitle>Workspace Identity</CardTitle>
                <CardDescription>Customize how your workspace appears to you and your team.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Theme Preference</Label>
                    <p className="text-xs text-muted-foreground mb-3">Choose how the application looks for you.</p>
                    <RadioGroup 
                      value={theme} 
                      onValueChange={setTheme}
                      className="grid grid-cols-1 sm:grid-cols-3 gap-4"
                    >
                      <div>
                        <RadioGroupItem value="light" id="light" className="peer sr-only" />
                        <Label
                          htmlFor="light"
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                        >
                          <Sun className="mb-3 h-6 w-6" />
                          <span className="text-sm font-medium">Light</span>
                        </Label>
                      </div>
                      <div>
                        <RadioGroupItem value="dark" id="dark" className="peer sr-only" />
                        <Label
                          htmlFor="dark"
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                        >
                          <Moon className="mb-3 h-6 w-6" />
                          <span className="text-sm font-medium">Dark</span>
                        </Label>
                      </div>
                      <div>
                        <RadioGroupItem value="system" id="system" className="peer sr-only" />
                        <Label
                          htmlFor="system"
                          className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                        >
                          <Monitor className="mb-3 h-6 w-6" />
                          <span className="text-sm font-medium">System</span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Workspace Logo</Label>
                    <div className="flex items-center gap-4">
                      <div className="h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center text-primary text-2xl font-bold border border-primary/20">
                        {activeWorkspace?.name[0]}
                      </div>
                      <div className="space-y-1">
                        <Button variant="outline" size="sm" disabled>Upload Logo</Button>
                        <p className="text-[10px] text-muted-foreground">Recommend 400x400px PNG or SVG. Max 2MB.</p>
                      </div>
                      <Badge variant="outline" className="ml-auto">Pro</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'integrations' && (
            <div className="space-y-6">
              <TrialPreviewBanner featureName="Integrations" />
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <CardTitle>QuickBooks Online</CardTitle>
                      <CardDescription>Sync your invoices and payroll data directly with QuickBooks.</CardDescription>
                    </div>
                    {qbStatus?.connected ? (
                      <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">Connected</Badge>
                    ) : (
                      <Badge variant="secondary">Not Connected</Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 p-4 rounded-lg border bg-muted/30">
                    <div className="h-12 w-12 rounded bg-white p-2 flex items-center justify-center border shadow-sm">
                      <img src="https://upload.wikimedia.org/wikipedia/commons/0/01/QuickBooks_Logo.svg" alt="QuickBooks" className="h-full w-full object-contain" />
                    </div>
                    <div className="flex-1 space-y-0.5">
                      <p className="text-sm font-medium">QuickBooks Online Accounting</p>
                      <p className="text-xs text-muted-foreground">
                        {qbStatus?.connected 
                          ? `Connected to company ID: ${qbStatus.connection?.realm_id}` 
                          : 'Connect your Intuit account to enable automated financial workflows.'}
                      </p>
                    </div>
                  </div>

                  {qbStatus?.connected && qbStatus.connection?.updated_at && (
                    <p className="text-[10px] text-muted-foreground">
                      Last synchronized: {new Date(qbStatus.connection.updated_at).toLocaleString()}
                    </p>
                  )}

                  <div className="flex items-center gap-2 text-xs text-primary hover:underline cursor-pointer" onClick={() => window.open('https://www.kafiskey.com/legal/privacy', '_blank')}>
                    <Info className="h-3 w-3" />
                    Privacy Policy
                    <ExternalLink className="h-3 w-3 ml-1" />
                  </div>
                </CardContent>
                <CardFooter className="border-t px-6 py-4 flex justify-between items-center">
                  <p className="text-xs text-muted-foreground italic">
                    Requires a valid QuickBooks Online subscription.
                  </p>
                  {qbStatus?.connected ? (
                    <Button variant="outline" size="sm" onClick={handleDisconnectQb} disabled={loading}>
                      {loading ? 'Disconnecting...' : 'Disconnect'}
                    </Button>
                  ) : (
                    <Button size="sm" onClick={handleConnectQb} disabled={loading}>
                      {loading ? 'Initiating...' : 'Connect QuickBooks'}
                    </Button>
                  )}
                </CardFooter>
              </Card>
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Email Notifications</CardTitle>
                  <CardDescription>Configure when and how you receive email notifications.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Service Event Reminders</Label>
                        <p className="text-xs text-muted-foreground">Receive reminders for upcoming service events.</p>
                      </div>
                      <Badge variant="outline">Coming Soon</Badge>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Approval Requests</Label>
                        <p className="text-xs text-muted-foreground">Get notified when service events need your approval.</p>
                      </div>
                      <Badge variant="outline">Coming Soon</Badge>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Invoice Updates</Label>
                        <p className="text-xs text-muted-foreground">Receive notifications for invoice status changes.</p>
                      </div>
                      <Badge variant="outline">Coming Soon</Badge>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Team Activity</Label>
                        <p className="text-xs text-muted-foreground">Get updates when team members join or leave.</p>
                      </div>
                      <Badge variant="outline">Coming Soon</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>In-App Notifications</CardTitle>
                  <CardDescription>Manage your notification preferences within the application.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Desktop Notifications</Label>
                      <p className="text-xs text-muted-foreground">Show browser notifications for important updates.</p>
                    </div>
                    <Badge variant="outline">Coming Soon</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Sound Alerts</Label>
                      <p className="text-xs text-muted-foreground">Play a sound when you receive new notifications.</p>
                    </div>
                    <Badge variant="outline">Coming Soon</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'communication' && (
            <Card>
              <CardHeader>
                <CardTitle>Email Settings</CardTitle>
                <CardDescription>Configure how your organization communicates with clients via email.</CardDescription>
              </CardHeader>
              <form onSubmit={handleUpdateCommunication}>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <Label className="text-base">Email Sending Method</Label>
                    <RadioGroup 
                      value={emailMethod} 
                      onValueChange={(v) => setEmailMethod(v as 'kafiskey' | 'organization')}
                      className="grid grid-cols-1 gap-4"
                      disabled={!isOwner}
                    >
                      <div className="flex items-start space-x-3 space-y-0 rounded-md border p-4">
                        <RadioGroupItem value="kafiskey" id="kafiskey" className="mt-1" />
                        <div className="space-y-1">
                          <Label htmlFor="kafiskey" className="font-medium cursor-pointer flex items-center gap-2">
                            Send emails using Kafiskey (recommended)
                            <Badge variant="secondary" className="text-[10px] bg-emerald-500/10 text-emerald-500 border-emerald-500/20">Recommended</Badge>
                          </Label>
                          <p className="text-xs text-muted-foreground">
                            Kafiskey handles email delivery for you. Replies will go to your chosen reply email.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start space-x-3 space-y-0 rounded-md border p-4">
                        <RadioGroupItem value="organization" id="organization" className="mt-1" />
                        <div className="space-y-1">
                          <Label htmlFor="organization" className="font-medium cursor-pointer">
                            Send emails from my organization
                          </Label>
                          <p className="text-xs text-muted-foreground">
                            Use your organization's email address when communicating with clients.
                          </p>
                        </div>
                      </div>
                    </RadioGroup>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="senderName">From Name</Label>
                        <Input
                          id="senderName"
                          value={senderName}
                          onChange={(e) => setSenderName(e.target.value)}
                          disabled={!isOwner}
                          placeholder="e.g. Acme Support"
                        />
                        <p className="text-[10px] text-muted-foreground">The name recipients see in their inbox.</p>
                      </div>
                      
                      {emailMethod === 'organization' && (
                        <div className="space-y-2">
                          <Label htmlFor="senderEmail">From Email</Label>
                          <Input
                            id="senderEmail"
                            value={senderEmail}
                            onChange={(e) => setSenderEmail(e.target.value)}
                            disabled={!isOwner}
                            placeholder="e.g. hello@company.com"
                            />
                            <p className="text-[10px] text-muted-foreground">The email address recipients see.</p>
                            </div>
                            )}
                            
                            <div className={`space-y-2 ${emailMethod === 'kafiskey' ? 'md:col-span-1' : 'md:col-span-2'}`}>
                            <Label htmlFor="replyTo">Reply-To Email</Label>
                            <Input
                            id="replyTo"
                            value={replyTo}
                            onChange={(e) => setReplyTo(e.target.value)}
                            disabled={!isOwner}
                            placeholder="e.g. support@company.com"
                            />
                        <p className="text-[10px] text-muted-foreground">Where replies will be sent.</p>
                      </div>
                    </div>

                    {emailMethod === 'organization' && (
                      <div className="space-y-2 pt-2">
                        <Label htmlFor="authKey">Email Authorization</Label>
                        <Input
                          id="authKey"
                          type="password"
                          value={authKey}
                          onChange={(e) => setAuthKey(e.target.value)}
                          disabled={!isOwner}
                          placeholder="••••••••••••••••"
                        />
                        <p className="text-[10px] text-muted-foreground">
                          Required only if sending emails from your organization.
                        </p>
                      </div>
                    )}

                    {emailMethod === 'kafiskey' && (
                      <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-2">
                        <Info className="h-4 w-4 text-emerald-500" />
                        <p className="text-xs text-emerald-500 font-medium">Emails are sent reliably through Kafiskey.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="border-t px-6 py-4">
                  <Button type="submit" disabled={loading || !isOwner}>
                    {loading ? 'Saving...' : 'Save Email Settings'}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          )}

          {activeTab === 'check-in' && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <CardTitle>Walk-In QR Check-In</CardTitle>
                      <CardDescription>Allow walk-in visitors to check-in via a QR code and join the queue.</CardDescription>
                    </div>
                    <Switch 
                      checked={isCheckInEnabled} 
                      onCheckedChange={handleToggleCheckIn}
                      disabled={loading || !isPrivileged}
                    />
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {isCheckInEnabled ? (
                    <div className="space-y-6 animate-in fade-in duration-500">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                        <div className="space-y-4">
                          <div className="p-4 rounded-lg bg-muted/50 border space-y-3">
                            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Public Check-In URL</Label>
                            <div className="flex items-center gap-2">
                              <Input 
                                readOnly 
                                value={`${import.meta.env.VITE_PUBLIC_APP_URL || window.location.origin}/check-in/${activeWorkspace?.slug}`}
                                className="bg-background font-mono text-[10px]"
                              />
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => {
                                  const url = `${import.meta.env.VITE_PUBLIC_APP_URL || window.location.origin}/check-in/${activeWorkspace?.slug}`;
                                  navigator.clipboard.writeText(url);
                                  toast.success('Link copied to clipboard');
                                }}
                              >
                                Copy
                              </Button>
                            </div>
                            <p className="text-[10px] text-muted-foreground">
                              Point your QR code to this URL for visitors to access.
                            </p>
                          </div>

                          <div className="space-y-2">
                            <Label className="text-sm font-semibold">Location Tracking</Label>
                            <p className="text-xs text-muted-foreground">
                              Add <code className="bg-muted px-1 rounded">?loc=frontdesk</code> to the URL to track check-in locations (e.g. Front Desk, Lobby, Room 1).
                            </p>
                          </div>
                        </div>

                        <div className="flex flex-col items-center justify-center p-6 bg-white rounded-xl border shadow-sm">
                          <div className="p-4 bg-white border-2 border-slate-100 rounded-lg shadow-sm qr-code-svg">
                            <QRCodeSVG 
                              value={`${import.meta.env.VITE_PUBLIC_APP_URL || window.location.origin}/check-in/${activeWorkspace?.slug}`}
                              size={180}
                              level="H"
                              includeMargin={true}
                              imageSettings={{
                                src: "/brand/kafiskey-logo-tight.png",
                                x: undefined,
                                y: undefined,
                                height: 34,
                                width: 34,
                                excavate: true,
                              }}
                            />
                          </div>
                          
                          <div className="flex items-center gap-2 mt-4">
                            <Button variant="outline" size="sm" onClick={printQRCode}>
                              <Printer className="h-3.5 w-3.5 mr-2" />
                              Print
                            </Button>
                            <Button variant="outline" size="sm" onClick={downloadQRCode}>
                              <Download className="h-3.5 w-3.5 mr-2" />
                              Download
                            </Button>
                          </div>

                          <Button 
                            variant="link" 
                            size="sm" 
                            className="mt-2 text-xs"
                            onClick={() => window.open(`${import.meta.env.VITE_PUBLIC_APP_URL || window.location.origin}/check-in/${activeWorkspace?.slug}`, '_blank')}
                          >
                            <ExternalLink className="h-3 w-3 mr-2" />
                            Test Public Page
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="py-8 text-center bg-muted/30 rounded-lg border border-dashed">
                      <QrCode className="h-12 w-12 mx-auto text-muted-foreground opacity-20 mb-3" />
                      <h3 className="text-sm font-semibold text-muted-foreground">Check-In is Disabled</h3>
                      <p className="text-xs text-muted-foreground mt-1">Enable this feature to generate your public QR check-in page.</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Queue Display Settings</CardTitle>
                  <CardDescription>Configure how the queue is displayed and managed.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Privacy Mode</Label>
                      <p className="text-xs text-muted-foreground">Mask phone numbers for staff-level users.</p>
                    </div>
                    <Badge variant="outline" className="bg-brand-blue/10 text-brand-blue border-brand-blue/20">Active</Badge>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Real-time Updates</Label>
                      <p className="text-xs text-muted-foreground">Queue automatically refreshes as visitors check in.</p>
                    </div>
                    <Badge variant="outline" className="bg-brand-blue/10 text-brand-blue border-brand-blue/20">Active</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Access Control</CardTitle>
                  <CardDescription>Workspace-wide security and session settings.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Require 2FA</Label>
                        <p className="text-xs text-muted-foreground">Force all members to use two-factor authentication.</p>
                      </div>
                      <Badge variant="outline">Pro</Badge>
                    </div>
                  </div>

                  {isPrivileged && (
                    <>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>System Audit Logs</Label>
                          <p className="text-xs text-muted-foreground">Review detailed history of all system activities and security events.</p>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => setActiveTab('audit')}>
                          <History className="h-4 w-4 mr-2" />
                          View Logs
                        </Button>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card className="border-destructive/30">
                <CardHeader>
                  <CardTitle className="text-destructive flex items-center gap-2">
                    <ShieldAlert className="h-5 w-5" />
                    Danger Zone
                  </CardTitle>
                  <CardDescription>Critical actions that cannot be undone.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="space-y-1 pr-4">
                      <p className="text-sm font-bold">Delete Workspace</p>
                      <p className="text-xs text-muted-foreground">
                        Deleting this workspace permanently removes all operational and compliance records,
                        including clients, service events, and invoices. This action is irreversible.
                      </p>
                    </div>
                    <Button variant="destructive" size="sm" disabled={!isOwner}>Delete Permanently</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="space-y-6">
              <TrialPreviewBanner featureName="Audit Logs" />
              {isPrivileged ? <AuditLogTab /> : <div className="p-8 text-center text-muted-foreground">You are not authorized to view audit logs.</div>}
            </div>
          )}

          {activeTab === 'migration' && isPrivileged && (
            <div className="space-y-6">
              <TrialPreviewBanner featureName="Data Migration" />
              <DataMigrationTab />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};