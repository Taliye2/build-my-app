import React, { useEffect, useState } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Plus, UserSquare2, MoreVertical, Mail, Phone, BadgeCheck, Shield, Search, ShieldCheck } from 'lucide-react';
import { Empty } from '@/components/ui/empty';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { ChangeRoleDialog } from './components/ChangeRoleDialog';
import { EditProviderDialog } from './components/EditProviderDialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { AddressFields } from '@/components/AddressFields';
import { LoginCredentialsFields } from '@/components/LoginCredentialsFields';
import { hashPassword } from '@/lib/auth-utils';
import { Separator } from '@/components/ui/separator';

const createProviderSchema = z.object({
  user_id: z.string().min(1, 'Team member selection is required'),
  full_name: z.string().min(1, 'Full name is required'),
  title: z.string().min(1, 'Title is required'),
  email: z.string().email('Invalid email address').optional().or(z.literal('')),
  phone: z.string().optional(),
  dob: z.string().optional(),
  street_address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip_code: z.string().optional(),
  mailing_same_as_physical: z.boolean().default(true),
  mailing_street_address: z.string().optional(),
  mailing_city: z.string().optional(),
  mailing_state: z.string().optional(),
  mailing_zip_code: z.string().optional(),
  saved_username: z.string().optional(),
  saved_password: z.string().optional(),
});

type CreateProviderFormValues = z.infer<typeof createProviderSchema>;

interface Provider {
  id: string;
  user_id: string;
  title: string;
  full_name?: string;
  first_name?: string;
  last_name?: string;
  email?: string;
  active: boolean;
  workspace_role?: string;
  user?: {
    full_name: string;
    email: string;
  };
}

interface WorkspaceMember {
  id: string;
  user_id: string;
  role: string;
  status: string;
  full_name?: string;
  display_name?: string;
  email?: string; 
}

export const ProvidersPage: React.FC = () => {
  const { activeWorkspace, activeMember } = useWorkspace();
  const [providers, setProviders] = useState<Provider[]>([]);
  const [availableMembers, setAvailableMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [search, setSearch] = useState('');
  
  // Dialog state
  const [isChangeRoleOpen, setIsChangeRoleOpen] = useState(false);
  const [isEditDetailsOpen, setIsEditDetailsOpen] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<(Provider & { workspace_role?: string }) | null>(null);

  const form = useForm<CreateProviderFormValues>({
    resolver: zodResolver(createProviderSchema),
    defaultValues: {
      user_id: '',
      full_name: '',
      title: '',
      email: '',
      phone: '',
      dob: '',
      street_address: '',
      city: '',
      state: '',
      zip_code: '',
      mailing_same_as_physical: true,
      mailing_street_address: '',
      mailing_city: '',
      mailing_state: '',
      mailing_zip_code: '',
      saved_username: '',
      saved_password: '',
    },
  });

  useEffect(() => {
    if (activeWorkspace) {
      fetchProviders();
    }
  }, [activeWorkspace]);

  const fetchProviders = async () => {
    setLoading(true);
    try {
      // Fetch both staff profiles and workspace members to get current roles
      const [profilesRes, membersRes] = await Promise.all([
        supabase
          .from('staff_profiles')
          .select('*')
          .eq('workspace_id', activeWorkspace?.id),
        supabase
          .from('workspace_members')
          .select('user_id, role')
          .eq('workspace_id', activeWorkspace?.id)
          .eq('status', 'active')
      ]);

      if (profilesRes.error) throw profilesRes.error;
      if (membersRes.error) throw membersRes.error;

      const membersMap: Record<string, string> = {};
      membersRes.data?.forEach(m => {
        membersMap[m.user_id] = m.role;
      });

      const providersData = (profilesRes.data || []).map(p => ({
        ...p,
        workspace_role: membersMap[p.user_id] || 'STAFF'
      }));

      setProviders(providersData);
      
      // Fetch available members after providers are loaded to avoid race condition
      fetchAvailableMembers(providersData);
    } catch (error: any) {
      console.error('Error fetching providers:', error);
      toast.error('Failed to load providers');
    } finally {
      setLoading(false);
    }
  };

  const fetchAvailableMembers = async (currentProviders = providers) => {
    if (!activeWorkspace) return;
    try {
      // Get all members
      const { data: members, error: membersError } = await supabase
        .from('workspace_members')
        .select('*')
        .eq('workspace_id', activeWorkspace.id)
        .eq('status', 'active');
      
      if (membersError) throw membersError;

      // Filter out those who already have a staff profile
      const providerUserIds = new Set(currentProviders.map(p => p.user_id));
      const filtered = (members || [])
        .filter(m => !providerUserIds.has(m.user_id))
        .map(m => ({
          ...m,
          // Use stored full_name if available
          display_name: m.full_name || `User ${m.user_id.slice(0, 8)}`,
          email: '' // workspace_members doesn't have email
        }));
      
      setAvailableMembers(filtered);
    } catch (error) {
      console.error('Error fetching available members:', error);
    }
  };

  const handleMemberSelect = (value: string) => {
    const selectedMember = availableMembers.find(m => m.user_id === value);
    if (selectedMember) {
      // Use full_name from member record, or fallback to display_name if it's not the generic "User ID"
      const fullName = selectedMember.full_name || 
        (selectedMember.display_name && !selectedMember.display_name.startsWith('User ') ? selectedMember.display_name : '');
      
      form.setValue('user_id', value);
      form.setValue('full_name', fullName);
      form.setValue('title', selectedMember.role === 'ADMIN' ? 'Administrator' : 
               selectedMember.role === 'MANAGER' ? 'Manager' : 
               selectedMember.role === 'OWNER' ? 'Owner' : 'Staff Member');
    } else {
      form.setValue('user_id', value);
    }
  };

  const handleAddProvider = async (values: CreateProviderFormValues) => {
    if (!activeWorkspace) return;

    try {
      const payload: any = {
        ...values,
        workspace_id: activeWorkspace.id,
        active: true,
        email: values.email || null,
        phone: values.phone || null,
        dob: values.dob || null,
      };

      const { error } = await supabase.from('staff_profiles').insert(payload);

      if (error) throw error;

      toast.success('Provider added successfully');
      setIsAddOpen(false);
      form.reset();
      fetchProviders();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const filteredProviders = providers.filter(p => 
    p.title?.toLowerCase().includes(search.toLowerCase()) ||
    p.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.first_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.last_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.user_id?.toLowerCase().includes(search.toLowerCase())
  );

  const canManageRoles = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN';

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="relative w-72">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search providers..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" onClick={() => fetchAvailableMembers()}>
              <Plus className="h-4 w-4" />
              Add Provider
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Provider</DialogTitle>
              <DialogDescription>
                Assign a staff profile to a team member to enable service delivery.
              </DialogDescription>
            </DialogHeader>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleAddProvider)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="user_id"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Member</FormLabel>
                      <Select 
                        value={field.value} 
                        onValueChange={handleMemberSelect}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a team member" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {availableMembers.length === 0 ? (
                            <div className="p-2 text-sm text-muted-foreground text-center">
                              No team members available.<br/>Invite them in Team settings first.
                            </div>
                          ) : (
                            availableMembers.map((member) => (
                              <SelectItem key={member.user_id} value={member.user_id}>
                                {member.display_name} ({member.role})
                              </SelectItem>
                            ))
                          )}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="full_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g. Jane Doe" required />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title / Role</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="e.g. Case Manager" required />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <LoginCredentialsFields form={form} />

                <div className="space-y-4 pt-4">
                  <div className="flex items-center gap-4">
                    <Separator className="flex-1" />
                    <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Contact & Location</span>
                    <Separator className="flex-1" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input type="email" {...field} placeholder="e.g. jane.doe@example.com" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <AddressFields form={form} />
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                  <FormField
                    control={form.control}
                    name="dob"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date of Birth</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsAddOpen(false)}>Cancel</Button>
                  <Button type="submit" disabled={!form.getValues('user_id')}>Add Provider</Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : filteredProviders.length === 0 ? (
        <Empty
          icon={UserSquare2}
          title="No providers found"
          description={search ? "No providers match your search." : "Add providers to assign services, track delivery, and manage payroll."}
          action={!search && (
            <Button className="gap-2" onClick={() => setIsAddOpen(true)}>
              <Plus className="h-4 w-4" />
              Add Provider
            </Button>
          )}
        />
      ) : (
        <div className="border rounded-md bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Role / Title</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProviders.map((provider) => (
                <TableRow key={provider.id}>
                  <TableCell>
                    <div className="flex flex-col">
                      <Link 
                        to={`/providers/${provider.id}`}
                        className="font-medium text-primary cursor-pointer hover:underline"
                      >
                        {provider.full_name || 
                         (provider.first_name && provider.last_name ? `${provider.first_name} ${provider.last_name}` : null) || 
                         provider.first_name || 
                         provider.last_name || 
                         provider.title || 
                         'Provider'}
                      </Link>
                      <span className="text-xs text-muted-foreground">ID: {provider.user_id.slice(0, 8)}...</span>
                    </div>
                  </TableCell>
                  <TableCell>{provider.title || 'N/A'}</TableCell>
                  <TableCell>
                    {provider.active ? (
                      <Badge variant="success" className="bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-400 dark:border-emerald-800/50">
                        Active
                      </Badge>
                    ) : (
                      <Badge variant="secondary">Inactive</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link to={`/providers/${provider.id}`}>View Profile</Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => {
                          setSelectedProvider(provider);
                          setIsEditDetailsOpen(true);
                        }}>
                          Edit Details
                        </DropdownMenuItem>
                        {canManageRoles && (
                          <DropdownMenuItem onClick={() => {
                            setSelectedProvider(provider);
                            setIsChangeRoleOpen(true);
                          }}>
                            <ShieldCheck className="mr-2 h-4 w-4 text-primary" />
                            Change Role/Title
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem>Assign Services</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-destructive">
                          Deactivate
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <ChangeRoleDialog
        isOpen={isChangeRoleOpen}
        onOpenChange={setIsChangeRoleOpen}
        provider={selectedProvider}
        onSuccess={fetchProviders}
      />

      {selectedProvider && (
        <EditProviderDialog
          isOpen={isEditDetailsOpen}
          onOpenChange={setIsEditDetailsOpen}
          provider={selectedProvider}
          onSuccess={fetchProviders}
        />
      )}
    </div>
  );
};