import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { ProviderHeader } from './components/ProviderHeader';
import { ProviderOverview } from './components/ProviderOverview';
import { AssignmentsTab } from './components/AssignmentsTab';
import { EditProviderDialog } from './components/EditProviderDialog';
import { NotesTab } from '../clients/components/NotesTab';
import { DocumentsTab } from '../clients/components/DocumentsTab';
import { TimelineTab } from '../clients/components/TimelineTab';
import { Users, FileText, MessageSquare, History } from 'lucide-react';
import { Spinner } from '@/components/ui/spinner';
import { Button } from '@/components/ui/button';

import { logAudit } from '@/lib/audit';

export const ProviderProfilePage: React.FC = () => {
  const { providerId } = useParams<{ providerId: string }>();
  const { activeWorkspace } = useWorkspace();
  const { user } = useAuth();
  const [provider, setProvider] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Modal states
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [isAddDocOpen, setIsAddDocOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('assignments');

  useEffect(() => {
    fetchProvider();
    if (providerId && activeWorkspace && user) {
      logAudit(activeWorkspace.id, user.id, 'VIEW', 'provider', providerId);
    }
  }, [providerId, activeWorkspace, user]);

  const fetchProvider = async () => {
    if (!providerId || !activeWorkspace) return;
    setLoading(true);
    try {
      // Fetch staff profile
      const { data, error } = await supabase
        .from('staff_profiles')
        .select('*')
        .eq('id', providerId)
        .eq('workspace_id', activeWorkspace.id)
        .single();

      if (error) throw error;
      
      let providerData = { ...data };
      
      setProvider(providerData);
    } catch (error: any) {
      toast.error('Error fetching provider details: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (active: boolean) => {
    if (!activeWorkspace || !providerId || !provider) return;

    try {
      const { error } = await supabase
        .from('staff_profiles')
        .update({ active })
        .eq('id', providerId);

      if (error) throw error;

      setProvider({ ...provider, active });
      toast.success(`Provider ${active ? 'activated' : 'deactivated'} successfully`);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  if (loading) {
    return (
      <div className="flex h-[400px] items-center justify-center">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    );
  }

  if (!provider) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-muted-foreground">Provider profile not found</h2>
      </div>
    );
  }

  return (
    <div className="max-w-[1600px] mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <ProviderHeader 
        provider={provider}
        onEditProfile={() => setIsEditModalOpen(true)}
        onAddDocument={() => {
          setActiveTab('documents');
          setIsAddDocOpen(true);
        }}
        onStatusChange={handleStatusChange}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Provider Overview */}
        <aside className="lg:col-span-4 xl:col-span-3 space-y-6 lg:sticky lg:top-8">
          <ProviderOverview provider={provider} />
        </aside>

        {/* Right Column: Main Content Tabs */}
        <main className="lg:col-span-8 xl:col-span-9">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent space-x-8 mb-6 overflow-x-auto scrollbar-hide">
              <TabsTrigger 
                value="assignments" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <Users className="h-4 w-4" />
                Assigned Clients
              </TabsTrigger>
              <TabsTrigger 
                value="notes" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <MessageSquare className="h-4 w-4" />
                Staff Notes
              </TabsTrigger>
              <TabsTrigger 
                value="documents" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <FileText className="h-4 w-4" />
                Documentation
              </TabsTrigger>
              <TabsTrigger 
                value="timeline" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <History className="h-4 w-4" />
                History
              </TabsTrigger>
            </TabsList>

            <TabsContent value="assignments" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <AssignmentsTab providerId={provider.id} userId={provider.user_id} />
            </TabsContent>

            <TabsContent value="notes" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <NotesTab 
                entityId={provider.id} 
                entityType="provider"
                isAddNoteOpen={isAddNoteOpen}
                onAddNoteClose={() => setIsAddNoteOpen(false)}
                onAddNoteOpen={() => setIsAddNoteOpen(true)}
                onNoteAdded={() => {}}
              />
            </TabsContent>

            <TabsContent value="documents" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <DocumentsTab 
                entityId={provider.id}
                entityType="provider"
                isAddDocOpen={isAddDocOpen}
                onAddDocClose={() => setIsAddDocOpen(false)}
                onDocAdded={() => {}}
              />
            </TabsContent>

            <TabsContent value="timeline" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <TimelineTab entityId={provider.id} entityType="provider" />
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <EditProviderDialog 
        isOpen={isEditModalOpen}
        onOpenChange={setIsEditModalOpen}
        provider={provider}
        onSuccess={fetchProvider}
      />
    </div>
  );
};
