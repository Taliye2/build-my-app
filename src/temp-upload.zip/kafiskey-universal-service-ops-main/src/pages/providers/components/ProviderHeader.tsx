import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  UserSquare2, 
  Mail, 
  Edit, 
  MoreHorizontal,
  ArrowLeft,
  Plus
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ProviderHeaderProps {
  provider: any;
  onEditProfile: () => void;
  onAddNote: () => void;
  onAddDocument: () => void;
  onStatusChange: (status: boolean) => void;
}

export const ProviderHeader: React.FC<ProviderHeaderProps> = ({ 
  provider, 
  onEditProfile,
  onAddNote,
  onAddDocument,
  onStatusChange 
}) => {
  const navigate = useNavigate();

  const displayFullName = provider.full_name || 
    (provider.first_name && provider.last_name ? `${provider.first_name} ${provider.last_name}` : null) || 
    provider.first_name || 
    provider.last_name || 
    provider.title || 
    'Service Provider';

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/providers')}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Providers
        </Button>
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex items-start gap-6">
          <div className="h-24 w-24 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border-4 border-background shadow-sm">
            <UserSquare2 className="h-12 w-12" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold tracking-tight">
                {displayFullName}
              </h1>
              <Badge variant={provider.active ? 'success' : 'secondary'} className="h-6">
                {provider.active ? 'Active' : 'Inactive'}
              </Badge>
            </div>
            <p className="text-lg text-muted-foreground font-medium">User ID: {provider.user_id?.slice(0, 12)}...</p>
            <div className="flex flex-wrap gap-4 pt-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Mail className="h-4 w-4" />
                {provider.email || 'Contact via Team page'}
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button variant="outline" onClick={onEditProfile} className="gap-2">
            <Edit className="h-4 w-4" />
            Edit Profile
          </Button>
          <Button className="gap-2" onClick={onAddDocument}>
            <Plus className="h-4 w-4" />
            Add Document
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onStatusChange(!provider.active)}>
                {provider.active ? 'Deactivate Provider' : 'Activate Provider'}
              </DropdownMenuItem>
              <DropdownMenuItem className="text-destructive">
                Remove from Workspace
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
};