import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { logAudit } from '@/lib/audit';

interface ChangeRoleDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  provider: {
    id: string;
    user_id: string;
    title: string;
    full_name?: string;
    workspace_role?: string;
  } | null;
  onSuccess: () => void;
}

const COMMON_TITLES = [
  'Staff Member',
  'Supervisor',
  'Manager',
  'Administrator',
  'Case Manager',
  'Clinical Lead',
  'Program Coordinator',
];

const WORKSPACE_ROLES = [
  { value: 'STAFF', label: 'Staff Member (Default)' },
  { value: 'MANAGER', label: 'Manager' },
  { value: 'ADMIN', label: 'Administrator' },
  { value: 'READ_ONLY', label: 'Read-Only Auditor' },
];

export const ChangeRoleDialog: React.FC<ChangeRoleDialogProps> = ({
  isOpen,
  onOpenChange,
  provider,
  onSuccess,
}) => {
  const { activeWorkspace, activeMember, refreshWorkspaces } = useWorkspace();
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState('');
  const [workspaceRole, setWorkspaceRole] = useState('STAFF');
  const [isCustomTitle, setIsCustomTitle] = useState(false);

  useEffect(() => {
    if (provider) {
      setTitle(provider.title || '');
      setWorkspaceRole(provider.workspace_role || 'STAFF');
      setIsCustomTitle(!COMMON_TITLES.includes(provider.title));
    }
  }, [provider]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!provider || !activeWorkspace) return;

    // Check if user is trying to change their own role
    const isSelf = activeMember?.user_id === provider.user_id;

    setLoading(true);
    try {
      // 1. Update staff profile title
      const { error: profileError } = await supabase
        .from('staff_profiles')
        .update({ title })
        .eq('id', provider.id);

      if (profileError) throw profileError;

      // 2. Update workspace membership role
      const { error: memberError } = await supabase
        .from('workspace_members')
        .update({ role: workspaceRole })
        .eq('workspace_id', activeWorkspace.id)
        .eq('user_id', provider.user_id);

      if (memberError) throw memberError;

      // 3. Log audit event
      if (activeWorkspace && activeMember) {
        logAudit(
          activeWorkspace.id,
          activeMember.user_id,
          'ROLE_CHANGE',
          'member',
          provider.user_id,
          { 
            old_role: provider.workspace_role, 
            new_role: workspaceRole,
            old_title: provider.title,
            new_title: title
          }
        );
      }

      toast.success('Provider role and permissions updated');
      
      // If updating self, we need to refresh the whole context
      if (isSelf) {
        await refreshWorkspaces();
      }

      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || 'Error updating role');
    } finally {
      setLoading(false);
    }
  };

  const isOwner = provider?.workspace_role === 'OWNER';

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Change Role/Permissions</DialogTitle>
          <DialogDescription>
            Update the professional title and workspace permissions for {provider?.full_name || 'this provider'}.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="role-select">Professional Title</Label>
              <Select 
                value={isCustomTitle ? 'custom' : title} 
                onValueChange={(value) => {
                  if (value === 'custom') {
                    setIsCustomTitle(true);
                  } else {
                    setIsCustomTitle(false);
                    setTitle(value);
                  }
                }}
              >
                <SelectTrigger id="role-select">
                  <SelectValue placeholder="Select a title" />
                </SelectTrigger>
                <SelectContent>
                  {COMMON_TITLES.map((role) => (
                    <SelectItem key={role} value={role}>
                      {role}
                    </SelectItem>
                  ))}
                  <SelectItem value="custom">Other / Custom...</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {isCustomTitle && (
              <div className="space-y-2 animate-in fade-in slide-in-from-top-1">
                <Label htmlFor="custom-title">Custom Title</Label>
                <Input
                  id="custom-title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Enter custom title"
                  required
                />
              </div>
            )}
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="workspace-role">Workspace Permissions</Label>
              {isOwner ? (
                <div className="p-3 bg-muted rounded-md text-sm text-muted-foreground border">
                  Owner role cannot be changed from this menu.
                </div>
              ) : (
                <Select 
                  value={workspaceRole} 
                  onValueChange={setWorkspaceRole}
                >
                  <SelectTrigger id="workspace-role">
                    <SelectValue placeholder="Select permissions" />
                  </SelectTrigger>
                  <SelectContent>
                    {WORKSPACE_ROLES.map((role) => (
                      <SelectItem key={role.value} value={role.value}>
                        {role.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <p className="text-[10px] text-muted-foreground pt-1">
                Changing permissions will immediately affect what the user can see and do in the app.
              </p>
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || !title}>
              {loading ? 'Updating...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
