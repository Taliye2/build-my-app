import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { supabase } from '@/lib/supabase';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { AddressFields } from '@/components/AddressFields';
import { LoginCredentialsFields } from '@/components/LoginCredentialsFields';
import { hashPassword } from '@/lib/auth-utils';

const providerSchema = z.object({
  full_name: z.string().min(1, 'Full name is required'),
  title: z.string().min(1, 'Title is required'),
  email: z.string().email('Invalid email address').optional().or(z.literal('')),
  phone: z.string().optional(),
  dob: z.string().optional(),
  street_address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip_code: z.string().optional(),
  mailing_same_as_physical: z.boolean().default(true),
  mailing_street_address: z.string().optional(),
  mailing_city: z.string().optional(),
  mailing_state: z.string().optional(),
  mailing_zip_code: z.string().optional(),
  staff_id: z.string().optional(),
  language: z.string().optional(),
  preferred_contact_method: z.string().optional(),
  emergency_contact_name: z.string().optional(),
  emergency_contact_phone: z.string().optional(),
  saved_username: z.string().optional(),
  saved_password: z.string().optional(),
});

type ProviderFormValues = z.infer<typeof providerSchema>;

interface EditProviderDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  provider: any;
  onSuccess: () => void;
}

export const EditProviderDialog: React.FC<EditProviderDialogProps> = ({
  isOpen,
  onOpenChange,
  provider,
  onSuccess,
}) => {
  const [loading, setLoading] = useState(false);

  const form = useForm<ProviderFormValues>({
    resolver: zodResolver(providerSchema),
    defaultValues: {
      full_name: '',
      title: '',
      email: '',
      phone: '',
      dob: '',
      street_address: '',
      city: '',
      state: '',
      zip_code: '',
      mailing_same_as_physical: true,
      mailing_street_address: '',
      mailing_city: '',
      mailing_state: '',
      mailing_zip_code: '',
      staff_id: '',
      language: 'English',
      preferred_contact_method: 'Email',
      emergency_contact_name: '',
      emergency_contact_phone: '',
      saved_username: '',
      saved_password: '',
    },
  });

  useEffect(() => {
    if (provider) {
      form.reset({
        full_name: provider.full_name || (provider.first_name && provider.last_name ? `${provider.first_name} ${provider.last_name}` : provider.first_name || provider.last_name || ''),
        title: provider.title || '',
        email: provider.email || '',
        phone: provider.phone || provider.phone_number || '',
        dob: provider.dob || '',
        street_address: provider.street_address || '',
        city: provider.city || '',
        state: provider.state || '',
        zip_code: provider.zip_code || '',
        mailing_same_as_physical: provider.mailing_same_as_physical ?? true,
        mailing_street_address: provider.mailing_street_address || '',
        mailing_city: provider.mailing_city || '',
        mailing_state: provider.mailing_state || '',
        mailing_zip_code: provider.mailing_zip_code || '',
        staff_id: provider.staff_id || '',
        language: provider.language || 'English',
        preferred_contact_method: provider.preferred_contact_method || 'Email',
        emergency_contact_name: provider.emergency_contact_name || '',
        emergency_contact_phone: provider.emergency_contact_phone || '',
        saved_username: provider.saved_username || '',
        saved_password: provider.saved_password || '',
      });
    }
  }, [provider, form]);

  const onSubmit = async (values: ProviderFormValues) => {
    setLoading(true);
    try {
      const payload: any = {
        ...values,
        email: values.email || null,
        phone: values.phone || null,
        phone_number: values.phone || null,
        dob: values.dob || null,
        staff_id: values.staff_id || null,
        emergency_contact_name: values.emergency_contact_name || null,
        emergency_contact_phone: values.emergency_contact_phone || null,
      };

      const { error } = await supabase
        .from('staff_profiles')
        .update(payload)
        .eq('id', provider.id);

      if (error) throw error;

      toast.success('Provider profile updated successfully');
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || 'Error updating profile');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Provider Profile</DialogTitle>
          <DialogDescription>
            Update the provider's personal and contact information.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="full_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Legal Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Professional Title</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g. Case Manager" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="staff_id"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Staff ID / License #</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="dob"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Date of Birth</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <LoginCredentialsFields form={form} isEdit={true} />

            <div className="space-y-4 pt-4">
              <div className="flex items-center gap-4">
                <Separator className="flex-1" />
                <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Contact & Location</span>
                <Separator className="flex-1" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <AddressFields form={form} />
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <FormField
                control={form.control}
                name="language"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Language</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="preferred_contact_method"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Method</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Separator className="my-4" />
            <h4 className="text-sm font-medium mb-2 text-destructive">Emergency Contact</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="emergency_contact_name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="emergency_contact_phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Phone</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? 'Saving...' : 'Save Changes'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};