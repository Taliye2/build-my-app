import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { User, Calendar, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Empty } from '@/components/ui/empty';
import { Spinner } from '@/components/ui/spinner';

interface AssignmentsTabProps {
  providerId: string;
  userId: string;
}

export const AssignmentsTab: React.FC<AssignmentsTabProps> = ({ providerId, userId }) => {
  const { activeWorkspace } = useWorkspace();
  const [assignments, setAssignments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAssignments();
  }, [userId, activeWorkspace]);

  const fetchAssignments = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    try {
      // In this schema, assignments might be derived from unique client_id in service_events
      // or we might have a dedicated assignments table. Let's assume we look at recent service events
      // to see which clients this provider has worked with.
      const { data, error } = await supabase
        .from('service_events')
        .select(`
          client:client_id (
            id,
            first_name,
            last_name,
            status
          )
        `)
        .eq('staff_user_id', userId)
        .eq('workspace_id', activeWorkspace.id);

      if (error) throw error;

      // Deduplicate clients
      const clientsMap = new Map();
      data?.forEach((event: any) => {
        if (event.client) {
          clientsMap.set(event.client.id, event.client);
        }
      });

      setAssignments(Array.from(clientsMap.values()));
    } catch (error) {
      console.error('Error fetching provider assignments:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-48 items-center justify-center">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold">Assigned Clients</h3>
        <p className="text-sm text-muted-foreground">Clients serviced by this provider</p>
      </div>

      <div className="border rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Client Name</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assignments.length === 0 ? (
              <TableRow>
                <TableCell colSpan={3} className="h-32">
                  <Empty
                    icon={User}
                    title="No assignments found"
                    description="This provider hasn't been assigned to any clients yet."
                  />
                </TableCell>
              </TableRow>
            ) : (
              assignments.map((client) => (
                <TableRow key={client.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                        <User className="h-4 w-4" />
                      </div>
                      {client.first_name} {client.last_name}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={client.status === 'ACTIVE' ? 'success' : 'secondary'}>
                      {client.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" asChild className="gap-2">
                      <Link to={`/clients/${client.id}`}>
                        View Profile
                        <ExternalLink className="h-3.3 w-3.3" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
