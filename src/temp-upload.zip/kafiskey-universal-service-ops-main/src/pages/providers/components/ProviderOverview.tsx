import React from 'react';
import { format, parseISO } from 'date-fns';
import { User, Calendar, ShieldCheck, Mail, Phone, MapPin, Globe, UserPlus, Briefcase, Fingerprint, Key } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

interface ProviderOverviewProps {
  provider: any;
}

export const ProviderOverview: React.FC<ProviderOverviewProps> = ({ provider }) => {
  const InfoItem = ({ icon: Icon, label, value, subValue }: any) => (
    <div className="flex items-start gap-3">
      <div className="mt-1 p-1.5 bg-primary/5 dark:bg-primary/10 rounded border border-primary/10">
        <Icon className="h-3.5 w-3.5 text-primary" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight mb-0.5">{label}</p>
        <p className="text-sm font-semibold truncate">
          {value || <span className="text-muted-foreground font-normal italic text-[10px]">Not Provided</span>}
        </p>
        {subValue && <p className="text-xs text-muted-foreground">{subValue}</p>}
      </div>
    </div>
  );

  const displayFullName = provider.full_name || 
    (provider.first_name && provider.last_name ? `${provider.first_name} ${provider.last_name}` : null) || 
    provider.first_name || 
    provider.last_name || 
    provider.title || 
    'N/A';

  const displayPhone = provider.phone || provider.phone_number || 'N/A';

  return (
    <div className="space-y-6">
      <Card className="border-primary/10 shadow-sm">
        <CardHeader className="pb-3 border-b bg-muted/30">
          <CardTitle className="text-sm font-bold uppercase tracking-wider text-foreground">Provider Overview</CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="space-y-5">
            <InfoItem icon={User} label="Legal Name" value={displayFullName} />
            <InfoItem icon={Calendar} label="Date of Birth" value={provider.dob ? format(parseISO(provider.dob), 'MMMM d, yyyy') : null} />
            <InfoItem icon={Fingerprint} label="Staff ID" value={provider.staff_id || provider.id.slice(0, 8).toUpperCase()} />
            <InfoItem icon={UserPlus} label="Joined Date" value={format(new Date(provider.created_at), 'MMMM d, yyyy')} />
          </div>
          
          <Separator />
          
          <div className="space-y-5">
            <InfoItem icon={Mail} label="Email Contact" value={provider.email || 'N/A'} />
            <InfoItem icon={Phone} label="Primary Phone" value={displayPhone} />
            <InfoItem 
              icon={MapPin} 
              label="Residential Address" 
              value={provider.street_address ? `${provider.street_address}${provider.city ? `, ${provider.city}` : ''}${provider.state ? ` ${provider.state}` : ''}${provider.zip_code ? ` ${provider.zip_code}` : ''}` : (provider.address || 'N/A')} 
            />
            {provider.mailing_same_as_physical === false && (
              <InfoItem 
                icon={MapPin} 
                label="Mailing Address" 
                value={`${provider.mailing_street_address}${provider.mailing_city ? `, ${provider.mailing_city}` : ''}${provider.mailing_state ? ` ${provider.mailing_state}` : ''}${provider.mailing_zip_code ? ` ${provider.mailing_zip_code}` : ''}`} 
              />
            )}
          </div>

          <Separator />

          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <InfoItem icon={Globe} label="Language" value={provider.language || 'English'} />
              <InfoItem icon={ShieldCheck} label="Contact Method" value={provider.preferred_contact_method || 'Email'} />
            </div>
          </div>

          {(provider.saved_username || provider.saved_password) && (
            <>
              <Separator />
              <div className="space-y-5">
                <div className="flex items-center gap-2 mb-2">
                  <Key className="h-4 w-4 text-primary" />
                  <span className="text-xs font-bold uppercase tracking-wider text-primary">Stored Portal Credentials</span>
                </div>
                <div className="grid grid-cols-2 gap-4 bg-muted/30 p-3 rounded-lg border border-border/50">
                  <InfoItem icon={User} label="Saved Username" value={provider.saved_username} />
                  <InfoItem icon={Key} label="Saved Password" value={provider.saved_password ? "••••••••" : null} subValue={provider.saved_password ? "(Confidential info stored for reference)" : null} />
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {(provider.emergency_contact_name || provider.emergency_contact_phone) && (
        <Card className="border-destructive/10">
          <CardHeader className="pb-3 border-b bg-destructive/5 dark:bg-destructive/10">
            <CardTitle className="text-sm font-bold uppercase tracking-wider text-destructive flex items-center gap-2">
              <ShieldCheck className="h-4 w-4" />
              Emergency Contact
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div>
              <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight">Full Name</p>
              <p className="text-sm font-semibold">{provider.emergency_contact_name || '—'}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight">Contact Phone</p>
              <p className="text-sm font-semibold">{provider.emergency_contact_phone || '—'}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
