import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { BrandLogo } from '@/components/BrandLogo';
import { toast } from 'sonner';
import { PlusCircle, LogOut, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export interface Invite {
  id: string;
  workspace_id: string;
  email: string;
  role: string;
  status: string;
  workspaces?: {
    name: string;
  };
}

export const OnboardingPage: React.FC = () => {
  const { user, signOut } = useAuth();
  const { activeWorkspace, refreshWorkspaces } = useWorkspace();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [workspaceName, setWorkspaceName] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [country, setCountry] = useState('United States');
  const [invites, setInvites] = useState<Invite[]>([]);

  useEffect(() => {
    if (activeWorkspace) {
      navigate('/');
    }
  }, [activeWorkspace, navigate]);

  useEffect(() => {
    const fetchInvites = async () => {
      if (!user?.email) return;
      // Use case-insensitive matching for email
      const { data, error } = await supabase
        .from('invites')
        .select('*, workspaces(name)')
        .ilike('email', user.email)
        .eq('status', 'pending');
      
      if (data) setInvites(data as any);
    };

    fetchInvites();
  }, [user]);

  const handleCreateWorkspace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    try {
      // 1. Create Workspace
      const trialStartDate = new Date();
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + 30);

      const generatedSlug = workspaceName
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '') + '-' + Math.random().toString(36).substring(2, 6);

      const { data: ws, error: wsError } = await supabase
        .from('workspaces')
        .insert({
          name: workspaceName,
          slug: generatedSlug,
          created_by: user.id,
          plan_status: 'trialing',
          access_state: 'TRIAL_ACTIVE',
          trial_start_date: trialStartDate.toISOString(),
          trial_ends_at: trialEndDate.toISOString(),
          address_line_1: addressLine1,
          address_line_2: addressLine2,
          city: city,
          state: state,
          zip_code: zipCode,
          country: country
        })
        .select()
        .single();

      if (wsError) throw wsError;

      // 2. Add as OWNER membership
      const { error: memberError } = await supabase
        .from('workspace_members')
        .insert({
          workspace_id: ws.id,
          user_id: user.id,
          role: 'OWNER',
          status: 'active',
          full_name: user.user_metadata?.full_name || `${user.user_metadata?.first_name} ${user.user_metadata?.last_name}`.trim() || 'Workspace Owner'
        });

      if (memberError) throw memberError;

      // 3. (Optional) Remove auto-profile creation for owner to allow manual addition in ProvidersPage
      /*
      const { error: profileError } = await supabase
        .from('staff_profiles')
        .insert({
          workspace_id: ws.id,
          user_id: user.id,
          title: 'Administrator',
          active: true,
          first_name: user.user_metadata?.first_name || '',
          last_name: user.user_metadata?.last_name || '',
          phone_number: user.user_metadata?.phone_number || ''
        });

      if (profileError) console.error('Error creating staff profile record:', profileError);
      */

      toast.success('Workspace created! Your 30-day free trial has started.');
      await refreshWorkspaces();
      navigate('/');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinWorkspace = async (invite: Invite) => {
    if (!user) return;
    setLoading(true);

    try {
      // 1. Add membership
      const { error: memberError } = await supabase
        .from('workspace_members')
        .insert({
          workspace_id: invite.workspace_id,
          user_id: user.id,
          role: invite.role,
          status: 'active',
          full_name: (invite as any).full_name || user.user_metadata?.full_name || 'Team Member'
        });

      if (memberError) throw memberError;

      // 2. Mark invite as accepted
      const { error: inviteError } = await supabase
        .from('invites')
        .update({ status: 'accepted' })
        .eq('id', invite.id);

      if (inviteError) console.error('Error updating invite status:', inviteError);

      // 3. (Optional) Remove auto-profile creation for joining members to allow manual addition in ProvidersPage
      /*
      await supabase
        .from('staff_profiles')
        .insert({
          workspace_id: invite.workspace_id,
          user_id: user.id,
          title: 'Staff Member',
          active: true
        });
      */

      toast.success(`Joined ${invite.workspaces?.name}!`);
      await refreshWorkspaces();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      setLoading(true);
      await signOut();
      navigate('/auth');
    } catch (error: any) {
      toast.error(error.message || 'Failed to sign out');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-muted/30 dark:bg-background relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-brand-purple/5 rounded-full blur-[120px] opacity-40 animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-brand-teal/5 rounded-full blur-[120px] opacity-30" />
      </div>
      <Card className="w-full max-w-md glass-card border-t-4 border-t-brand-blue shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-brand-gradient opacity-80" />
        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-4">
            <BrandLogo variant="auth" />
          </div>
          <CardTitle className="text-2xl font-bold bg-brand-gradient bg-clip-text text-transparent">Welcome to Kafiskey</CardTitle>
          <CardDescription className="mt-2 text-slate-600 dark:text-slate-300">
            Kafiskey organizes and standardizes operational data so it is ready for state mandates and audits.
          </CardDescription>
          <CardDescription className="mt-2 italic text-xs text-slate-500 dark:text-slate-300">
            {invites.length > 0 
              ? `You have ${invites.length} pending invitation(s) to join a workspace.`
              : "You are not part of any workspace yet. Create one to get started or wait for an invitation."}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {invites.length > 0 && (
            <div className="space-y-3">
              <Label>Pending Invitations</Label>
              {invites.map((invite) => (
                <div key={invite.id} className="flex items-center justify-between p-3 border rounded-lg bg-card shadow-sm">
                  <div className="flex flex-col">
                    <span className="font-medium text-slate-900 dark:text-slate-100">{invite.workspaces?.name}</span>
                    <span className="text-xs text-slate-500 dark:text-slate-300">Role: {invite.role}</span>
                  </div>
                  <Button size="sm" onClick={() => handleJoinWorkspace(invite)} disabled={loading}>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Join
                  </Button>
                </div>
              ))}
            </div>
          )}

          {invites.length === 0 && (
            <form onSubmit={handleCreateWorkspace} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="wsName">Organization Name</Label>
                <Input
                  id="wsName"
                  placeholder="e.g. Acme Services"
                  value={workspaceName}
                  onChange={(e) => setWorkspaceName(e.target.value)}
                  required
                />
              </div>
              
              <div className="space-y-4 pt-2 border-t">
                <Label className="text-xs uppercase text-slate-500 dark:text-slate-400 font-semibold">Business Address</Label>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="address1" className="text-xs">Address Line 1</Label>
                    <Input
                      id="address1"
                      placeholder="123 Main St"
                      value={addressLine1}
                      onChange={(e) => setAddressLine1(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="address2" className="text-xs">Address Line 2 (Optional)</Label>
                    <Input
                      id="address2"
                      placeholder="Suite 100"
                      value={addressLine2}
                      onChange={(e) => setAddressLine2(e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="city" className="text-xs">City</Label>
                      <Input
                        id="city"
                        placeholder="City"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="state" className="text-xs">State / Province</Label>
                      <Input
                        id="state"
                        placeholder="State"
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="zip" className="text-xs">ZIP / Postal Code</Label>
                      <Input
                        id="zip"
                        placeholder="12345"
                        value={zipCode}
                        onChange={(e) => setZipCode(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="country" className="text-xs">Country</Label>
                      <Input
                        id="country"
                        placeholder="United States"
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>

              <Button type="submit" className="w-full bg-brand-gradient hover:opacity-90 border-none font-bold shadow-elegant transition-smooth" disabled={loading}>
                <PlusCircle className="mr-2 h-4 w-4" />
                {loading ? 'Creating...' : 'Create Workspace'}
              </Button>
            </form>
          )}

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background dark:bg-card px-2 text-slate-500 dark:text-slate-300">or</span>
            </div>
          </div>

          <Button variant="outline" className="w-full" onClick={handleSignOut} disabled={loading}>
            <LogOut className="mr-2 h-4 w-4" />
            {loading ? 'Signing out...' : 'Sign Out'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
