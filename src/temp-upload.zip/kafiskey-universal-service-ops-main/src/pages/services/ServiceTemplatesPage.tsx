import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Copy, FileStack, PlusCircle } from 'lucide-react';
import { toast } from 'sonner';
import { ServiceType } from './ServiceTypesPage';
import { Empty } from '@/components/ui/empty';

export interface ServiceTemplate {
  id: string;
  name: string;
  service_type_id: string;
  default_rate: number;
  note_template: string | null;
  active: boolean;
  created_at: string;
  service_types?: {
    name: string;
    mode: 'HOURLY' | 'SESSION' | 'PROGRAM';
  };
}

export interface ServiceType {
  id: string;
  name: string;
  mode: 'HOURLY' | 'SESSION' | 'PROGRAM';
}

export const ServiceTemplatesPage: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [templates, setTemplates] = useState<ServiceTemplate[]>([]);
  const [serviceTypes, setServiceTypes] = useState<ServiceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form state
  const [name, setName] = useState('');
  const [serviceTypeId, setServiceTypeId] = useState('');
  const [defaultRate, setDefaultRate] = useState('0');

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    const [templatesRes, typesRes] = await Promise.all([
      supabase
        .from('service_templates')
        .select('*, service_types(*)')
        .eq('workspace_id', activeWorkspace.id),
      supabase
        .from('service_types')
        .select('*')
        .eq('workspace_id', activeWorkspace.id)
    ]);

    if (templatesRes.data) setTemplates(templatesRes.data);
    if (typesRes.data) setServiceTypes(typesRes.data);
    
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !serviceTypeId) return;

    const { error } = await supabase.from('service_templates').insert({
      workspace_id: activeWorkspace.id,
      name,
      service_type_id: serviceTypeId,
      default_rate: parseFloat(defaultRate),
    });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('Service template created');
      setIsDialogOpen(false);
      fetchData();
      setName('');
      setServiceTypeId('');
      setDefaultRate('0');
    }
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Standard Service Templates</h3>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              New Template
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Service Template</DialogTitle>
              <DialogDescription>
                Templates help staff quickly log service events with prefilled rates and note structures.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateTemplate} className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="templateName">Service Name</Label>
                  <Input 
                    id="templateName" 
                    placeholder="e.g. Individual Counseling" 
                    value={name} 
                    onChange={(e) => setName(e.target.value)} 
                    required 
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="typeSelect">Service Type / Model</Label>
                  <Select value={serviceTypeId} onValueChange={setServiceTypeId} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {serviceTypes.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name} ({t.mode})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="rate">Default Rate ($)</Label>
                <Input 
                  id="rate" 
                  type="number" 
                  step="0.01" 
                  value={defaultRate} 
                  onChange={(e) => setDefaultRate(e.target.value)} 
                  required
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button type="submit">Create Template</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Template Name</TableHead>
              <TableHead>Service Type</TableHead>
              <TableHead>Delivery Model</TableHead>
              <TableHead>Rate</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center">Loading templates...</TableCell>
              </TableRow>
            ) : templates.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-auto py-12">
                  <Empty 
                    icon={FileStack}
                    title="No templates found"
                    description="Create a service template to begin scheduling and documentation."
                    action={
                      <Button onClick={() => setIsDialogOpen(true)}>
                        <Plus className="mr-2 h-4 w-4" />
                        Create First Template
                      </Button>
                    }
                  />
                </TableCell>
              </TableRow>
            ) : (
              templates.map((template) => (
                <TableRow key={template.id}>
                  <TableCell className="font-medium">{template.name}</TableCell>
                  <TableCell>{template.service_types?.name}</TableCell>
                  <TableCell className="capitalize text-xs">
                    <Badge variant="secondary">{template.service_types?.mode}</Badge>
                  </TableCell>
                  <TableCell className="font-bold">${(template.default_rate || 0).toFixed(2)}</TableCell>
                  <TableCell className="text-xs">{new Date(template.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};