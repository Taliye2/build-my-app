import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ServiceMenuTab } from './components/ServiceMenuTab';
import { SchedulingTab } from './components/SchedulingTab';
import { ServiceRecordsTab } from './components/ServiceRecordsTab';

export const ServicesPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get('tab') || 'menu';

  const handleTabChange = (value: string) => {
    setSearchParams({ tab: value });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2">
        <h2 className="text-3xl font-bold tracking-tight">Services</h2>
        <p className="text-muted-foreground">
          Define, schedule, and document services delivered by your organization.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 max-w-xl">
          <TabsTrigger value="menu">Service Menu</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>
        
        <TabsContent value="menu" className="space-y-4">
          <ServiceMenuTab />
        </TabsContent>

        <TabsContent value="schedule" className="space-y-4">
          <SchedulingTab />
        </TabsContent>
        
        <TabsContent value="history" className="space-y-4">
          <ServiceRecordsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};