import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Calendar as CalendarIcon, Clock, MapPin, User, CheckCircle2, XCircle, CalendarX, MoreHorizontal, RotateCcw, Filter, Search, Trash2, Info } from 'lucide-react';
import { toast } from 'sonner';
import { logAudit } from '@/lib/audit';
import { format, parseISO, addDays, addWeeks, addMonths, isBefore } from 'date-fns';
import { Client } from '../../clients/ClientListPage';
import { ServiceTemplate } from './ServiceMenuTab';
import { Empty } from '@/components/ui/empty';
import { Combobox } from '@/components/ui/combobox';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export interface ServiceEvent {
  id: string;
  client_id: string;
  staff_user_id: string | null;
  service_template_id: string;
  date: string;
  start_time: string | null;
  end_time: string | null;
  units: number;
  location: string | null;
  status: 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'MISSED' | 'CANCELED' | 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'BILLED' | 'NO_SHOW';
  recurrence_rule?: string | null;
  recurrence_series_id?: string | null;
  clients?: Client;
  service_templates?: ServiceTemplate;
  staff_profile?: any;
  service_records?: any[];
}

export const SchedulingTab: React.FC = () => {
  const { activeWorkspace, activeMember } = useWorkspace();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [events, setEvents] = useState<ServiceEvent[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [templates, setTemplates] = useState<ServiceTemplate[]>([]);
  const [providers, setProviders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [eventToDelete, setEventToDelete] = useState<ServiceEvent | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Form state
  const [clientId, setClientId] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [providerId, setProviderId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  
  // Recurrence state
  const [isRecurring, setIsRecurring] = useState(false);
  const [frequency, setFrequency] = useState<'DAILY' | 'WEEKLY' | 'BIWEEKLY' | 'MONTHLY'>('WEEKLY');
  const [occurrences, setOccurrences] = useState('10');
  const [endDate, setEndDate] = useState('');

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    const [eventsRes, clientsRes, templatesRes, providersRes] = await Promise.all([
      supabase
        .from('service_events')
        .select('*, clients(*), service_templates(*), service_records(*)')
        .eq('workspace_id', activeWorkspace.id)
        .order('date', { ascending: true }),
      supabase.from('clients').select('*').eq('workspace_id', activeWorkspace.id).eq('status', 'ACTIVE'),
      supabase.from('service_templates').select('*').eq('workspace_id', activeWorkspace.id).eq('active', true),
      supabase.from('staff_profiles').select('*').eq('workspace_id', activeWorkspace.id)
    ]);

    if (eventsRes.data) setEvents(eventsRes.data);
    if (clientsRes.data) setClients(clientsRes.data);
    if (templatesRes.data) setTemplates(templatesRes.data);
    if (providersRes.data) setProviders(providersRes.data);
    
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  const handleTemplateChange = (val: string) => {
    setTemplateId(val);
    const template = templates.find(t => t.id === val);
    if (template && template.default_duration) {
      // If we have a start time, auto-calculate end time
      if (startTime) {
        const [hours, minutes] = startTime.split(':').map(Number);
        const startDateObj = new Date();
        startDateObj.setHours(hours, minutes, 0);
        const endDateObj = new Date(startDateObj.getTime() + template.default_duration * 60000);
        setEndTime(format(endDateObj, 'HH:mm'));
      }
    }
  };

  const handleCreateSchedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace) return;

    const seriesId = isRecurring ? crypto.randomUUID() : null;
    const rule = isRecurring ? JSON.stringify({ frequency, occurrences, endDate }) : null;

    const baseEvent = {
      workspace_id: activeWorkspace.id,
      client_id: clientId,
      staff_user_id: providerId || null,
      service_template_id: templateId,
      start_time: startTime || null,
      end_time: endTime || null,
      location: location || null,
      status: 'SCHEDULED',
      recurrence_rule: rule,
      recurrence_series_id: seriesId,
      units: 1, // Default units
    };

    const eventsToCreate = [];
    
    if (isRecurring) {
      let currentDate = parseISO(date);
      const count = parseInt(occurrences) || 1;
      const finalDate = endDate ? parseISO(endDate) : addDays(currentDate, 90);

      for (let i = 0; i < count; i++) {
        if (endDate && isBefore(finalDate, currentDate)) break;
        if (i >= 50) break; // Safety cap

        eventsToCreate.push({
          ...baseEvent,
          date: format(currentDate, 'yyyy-MM-dd'),
        });

        if (frequency === 'DAILY') currentDate = addDays(currentDate, 1);
        else if (frequency === 'WEEKLY') currentDate = addWeeks(currentDate, 1);
        else if (frequency === 'BIWEEKLY') currentDate = addWeeks(currentDate, 2);
        else if (frequency === 'MONTHLY') currentDate = addMonths(currentDate, 1);
      }
    } else {
      eventsToCreate.push({
        ...baseEvent,
        date: date,
      });
    }

    const { error } = await supabase.from('service_events').insert(eventsToCreate);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(isRecurring ? `Scheduled ${eventsToCreate.length} recurring services` : 'Service scheduled');
      setIsDialogOpen(false);
      fetchData();
      resetForm();
    }
  };

  const resetForm = () => {
    setClientId('');
    setTemplateId('');
    setProviderId('');
    setStartTime('');
    setEndTime('');
    setLocation('');
    setIsRecurring(false);
    setFrequency('WEEKLY');
    setOccurrences('10');
    setEndDate('');
  };

  const handleUpdateStatus = async (id: string, status: string) => {
    const { error } = await supabase
      .from('service_events')
      .update({ status })
      .eq('id', id);

    if (error) toast.error(error.message);
    else {
      toast.success(`Status updated to ${status}`);
      fetchData();
    }
  };

  const handleStartService = async (event: ServiceEvent) => {
    const now = new Date().toISOString();
    setLoading(true);
    try {
      // 1. Update event status to IN_PROGRESS
      const { error: eventError } = await supabase
        .from('service_events')
        .update({ status: 'IN_PROGRESS' })
        .eq('id', event.id);
      
      if (eventError) throw eventError;

      // 2. Create or find Service Record
      let recordId;
      const { data: existingRecord } = await supabase
        .from('service_records')
        .select('id')
        .eq('service_event_id', event.id)
        .single();
      
      if (existingRecord) {
        recordId = existingRecord.id;
        await supabase
          .from('service_records')
          .update({ record_status: 'In Progress', started_at: now, time_in: now })
          .eq('id', recordId);
      } else {
        const { data: newRecord, error: recordError } = await supabase
          .from('service_records')
          .insert({
            workspace_id: activeWorkspace?.id,
            service_event_id: event.id,
            record_status: 'In Progress',
            started_at: now,
            time_in: now
          })
          .select()
          .single();
        if (recordError) throw recordError;
        recordId = newRecord.id;
      }

      toast.success('Service started');
      navigate(`/documentation/edit/${event.id}`);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteEvent = async (eventId: string) => {
    if (!activeWorkspace) return;

    setLoading(true);
    try {
      const event = events.find(e => e.id === eventId);
      if (!event) throw new Error('Event not found');

      // 1. Delete associated service records if they exist
      // Only delete if status is not completed/approved/billed
      const { error: recordError } = await supabase
        .from('service_records')
        .delete()
        .eq('service_event_id', eventId);
      
      if (recordError) console.error('Error deleting records:', recordError);

      // 2. Delete the service event
      const { error: eventError } = await supabase
        .from('service_events')
        .delete()
        .eq('id', eventId);

      if (eventError) throw eventError;

      // 3. Log audit
      await logAudit(
        activeWorkspace.id,
        user?.id,
        'DELETE',
        'service_events',
        eventId,
        { status: event.status, reason: 'user_initiated_delete' }
      );

      toast.success('Scheduled service deleted');
      setEventToDelete(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const isManagerOrAbove = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN' || activeMember?.role === 'MANAGER';
  const canDelete = (event: ServiceEvent) => {
    return isManagerOrAbove && !['COMPLETED', 'APPROVED', 'BILLED'].includes(event.status);
  };

  const filteredEvents = events.filter(e => {
    const matchesSearch = 
      e.clients?.first_name.toLowerCase().includes(search.toLowerCase()) ||
      e.clients?.last_name.toLowerCase().includes(search.toLowerCase()) ||
      e.service_templates?.name.toLowerCase().includes(search.toLowerCase());
    
    const matchesStatus = statusFilter === 'ALL' || e.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Service Schedule</h3>
          <p className="text-sm text-muted-foreground">Plan and manage service delivery assignments.</p>
        </div>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Book Appointment
        </Button>
      </div>

      {events.some(e => e.status === 'IN_PROGRESS') && (
        <Card className="border-primary/20 dark:border-primary/30 bg-primary/5 dark:bg-primary/10">
          <CardHeader className="py-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary animate-pulse" />
              Active Sessions
            </CardTitle>
          </CardHeader>
          <CardContent className="py-0 pb-3">
            <div className="space-y-2">
              {events.filter(e => e.status === 'IN_PROGRESS').map(event => (
                <div key={event.id} className="flex items-center justify-between p-2 rounded-md bg-background border">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">{event.clients?.first_name} {event.clients?.last_name}</span>
                    <span className="text-xs text-muted-foreground">{event.service_templates?.name}</span>
                  </div>
                  <Button size="sm" asChild>
                    <Link to={`/documentation/edit/${event.id}`}>Resume Session</Link>
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search by client or service..." 
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <Filter className="mr-2 h-4 w-4" />
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Statuses</SelectItem>
            <SelectItem value="SCHEDULED">Scheduled</SelectItem>
            <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
            <SelectItem value="COMPLETED">Completed</SelectItem>
            <SelectItem value="CANCELED">Canceled</SelectItem>
            <SelectItem value="MISSED">Missed</SelectItem>
            <SelectItem value="NO_SHOW">No-show</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Book Appointment</DialogTitle>
            <DialogDescription>Create a single or recurring service entry.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateSchedule} className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Client</Label>
                <Combobox
                  items={clients.map(c => ({
                    value: c.id,
                    label: `${c.first_name} ${c.last_name}`,
                    secondaryLabel: c.phone || c.email || undefined
                  }))}
                  value={clientId}
                  onValueChange={setClientId}
                  placeholder="Select client"
                  searchPlaceholder="Search clients..."
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Service Type</Label>
                <Select value={templateId} onValueChange={handleTemplateChange} required>
                  <SelectTrigger><SelectValue placeholder="Select service" /></SelectTrigger>
                  <SelectContent>
                    {templates.map(t => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Provider (Worker)</Label>
                <Combobox
                  items={providers.map(p => ({
                    value: p.user_id,
                    label: p.full_name || p.email || p.user_id,
                    secondaryLabel: p.title || undefined
                  }))}
                  value={providerId}
                  onValueChange={setProviderId}
                  placeholder="Assign provider"
                  searchPlaceholder="Search providers..."
                />
              </div>
              <div className="space-y-2">
                <Label>Location / Mode</Label>
                <Input placeholder="In-home, Virtual, etc." value={location} onChange={(e) => setLocation(e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Date</Label>
                <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label>Start Time</Label>
                <Input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>End Time</Label>
                <Input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
              </div>
            </div>

            <div className="space-y-4 border-t pt-4">
              <div className="flex items-center space-x-2">
                <Switch id="recurring" checked={isRecurring} onCheckedChange={setIsRecurring} />
                <Label htmlFor="recurring">Make Recurring</Label>
              </div>

              {isRecurring && (
                <div className="grid grid-cols-2 gap-4 animate-in fade-in slide-in-from-top-1">
                  <div className="space-y-2">
                    <Label>Frequency</Label>
                    <Select value={frequency} onValueChange={(v: any) => setFrequency(v)}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DAILY">Daily</SelectItem>
                        <SelectItem value="WEEKLY">Weekly</SelectItem>
                        <SelectItem value="BIWEEKLY">Every 2 Weeks</SelectItem>
                        <SelectItem value="MONTHLY">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Number of Occurrences</Label>
                    <Input type="number" value={occurrences} onChange={(e) => setOccurrences(e.target.value)} />
                  </div>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button type="submit">Book Appointment</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Provider</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">Loading schedule...</TableCell>
              </TableRow>
            ) : filteredEvents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-48">
                  <Empty
                    icon={CalendarX}
                    title="No services found"
                    description="Try adjusting your filters or schedule a new service."
                  />
                </TableCell>
              </TableRow>
            ) : (
              filteredEvents.map((event) => (
                <TableRow key={event.id}>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="font-medium text-sm">{format(parseISO(event.date), 'EEE, MMM d')}</span>
                      <span className="text-[10px] text-muted-foreground">{event.start_time} - {event.end_time}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">
                    {event.clients?.first_name} {event.clients?.last_name}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{event.service_templates?.name}</span>
                      {event.recurrence_series_id && <RotateCcw className="h-3 w-3 text-muted-foreground" />}
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">
                    {providers.find(p => p.user_id === event.staff_user_id)?.full_name || 'Unassigned'}
                  </TableCell>
                  <TableCell>
                    <Badge variant={
                      event.status === 'COMPLETED' ? 'success' : 
                      event.status === 'IN_PROGRESS' ? 'default' :
                      event.status === 'SCHEDULED' ? 'outline' : 'secondary'
                    } className="text-[10px]">
                      {event.status.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      {event.status === 'SCHEDULED' && (
                        <Button size="sm" onClick={() => handleStartService(event)}>
                          Start
                        </Button>
                      )}
                      {event.status === 'IN_PROGRESS' && (
                        <Button size="sm" asChild>
                          <Link to={`/documentation/edit/${event.id}`}>Resume</Link>
                        </Button>
                      )}
                      {(event.status === 'COMPLETED' || event.status === 'APPROVED' || event.status === 'BILLED') && (
                        <Button variant="outline" size="sm" asChild>
                          <Link to={`/documentation/edit/${event.id}`}>View Note</Link>
                        </Button>
                      )}

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {event.status === 'SCHEDULED' && (
                            <>
                              <DropdownMenuItem onClick={() => handleUpdateStatus(event.id, 'COMPLETED')}>
                                Mark Completed
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleUpdateStatus(event.id, 'CANCELED')}>
                                Cancel
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleUpdateStatus(event.id, 'NO_SHOW')}>
                                No-show
                              </DropdownMenuItem>
                            </>
                          )}
                          
                          {canDelete(event) ? (
                            <DropdownMenuItem 
                              className="text-destructive focus:text-destructive" 
                              onClick={() => setEventToDelete(event)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete Scheduled Service
                            </DropdownMenuItem>
                          ) : (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <div className="flex w-full">
                                    <DropdownMenuItem disabled className="w-full opacity-50 cursor-not-allowed">
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      Delete Scheduled Service
                                      <Info className="ml-auto h-3 w-3" />
                                    </DropdownMenuItem>
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent side="left">
                                  Completed services can't be deleted
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      <AlertDialog open={!!eventToDelete} onOpenChange={(open) => !open && setEventToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete scheduled service?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the scheduled appointment for {eventToDelete?.clients?.first_name} {eventToDelete?.clients?.last_name} — {eventToDelete?.service_templates?.name} on {eventToDelete && format(parseISO(eventToDelete.date), 'EEE, MMM d')} {eventToDelete?.start_time}–{eventToDelete?.end_time}. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => eventToDelete && handleDeleteEvent(eventToDelete.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
