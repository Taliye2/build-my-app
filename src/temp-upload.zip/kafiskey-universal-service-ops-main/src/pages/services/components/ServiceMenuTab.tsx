import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Copy, FileStack, Edit2, Trash2, CheckCircle2, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Empty } from '@/components/ui/empty';
import { Switch } from '@/components/ui/switch';

export interface ServiceTemplate {
  id: string;
  name: string;
  service_type_id: string;
  default_duration: number | null;
  description: string | null;
  documentation_required: boolean;
  signature_required: boolean;
  active: boolean;
  created_at: string;
  service_types?: {
    id: string;
    name: string;
    mode: 'HOURLY' | 'SESSION' | 'PROGRAM';
  };
  service_pricing?: {
    id: string;
    pricing_model: 'hourly' | 'flat' | 'unit';
    rate_amount: number;
    currency: string;
    is_active: boolean;
  }[];
}

export const ServiceMenuTab: React.FC = () => {
  const { activeWorkspace, hasAdvancedReporting } = useWorkspace();
  const [templates, setTemplates] = useState<ServiceTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<ServiceTemplate | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [categoryName, setCategoryName] = useState('');
  const [billingMode, setBillingMode] = useState<'HOURLY' | 'SESSION' | 'PROGRAM'>('HOURLY');
  const [rateAmount, setRateAmount] = useState('0');
  const [pricingModel, setPricingModel] = useState<'hourly' | 'flat' | 'unit'>('hourly');
  const [duration, setDuration] = useState('60');
  const [description, setDescription] = useState('');
  const [docRequired, setDocRequired] = useState(true);
  const [sigRequired, setSigRequired] = useState(false);
  const [active, setActive] = useState(true);

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    try {
      const { data, error } = await supabase
        .from('service_templates')
        .select('*, service_types(*), service_pricing(*)')
        .eq('workspace_id', activeWorkspace.id)
        .order('name');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  useEffect(() => {
    if (editingTemplate) {
      setName(editingTemplate.name);
      setCategoryName(editingTemplate.service_types?.name || '');
      setBillingMode(editingTemplate.service_types?.mode || 'HOURLY');
      
      const price = editingTemplate.service_pricing?.[0];
      setRateAmount(price?.rate_amount?.toString() || '0');
      setPricingModel(price?.pricing_model || 'hourly');
      
      setDuration(editingTemplate.default_duration?.toString() || '60');
      setDescription(editingTemplate.description || '');
      setDocRequired(editingTemplate.documentation_required);
      setSigRequired(editingTemplate.signature_required);
      setActive(editingTemplate.active);
    } else {
      setName('');
      setCategoryName('');
      setBillingMode('HOURLY');
      setRateAmount('0');
      setPricingModel('hourly');
      setDuration('60');
      setDescription('');
      setDocRequired(true);
      setSigRequired(false);
      setActive(true);
    }
  }, [editingTemplate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace) return;

    try {
      // 1. Get or Create Service Type
      let serviceTypeId = '';
      const { data: existingTypes } = await supabase
        .from('service_types')
        .select('id')
        .eq('workspace_id', activeWorkspace.id)
        .eq('name', categoryName)
        .eq('mode', billingMode)
        .maybeSingle();

      if (existingTypes) {
        serviceTypeId = existingTypes.id;
      } else {
        const { data: newType, error: typeError } = await supabase
          .from('service_types')
          .insert({
            workspace_id: activeWorkspace.id,
            name: categoryName,
            mode: billingMode
          })
          .select()
          .single();
        
        if (typeError) throw typeError;
        serviceTypeId = newType.id;
      }

      // 2. Create or Update Template
      const templatePayload = {
        workspace_id: activeWorkspace.id,
        name,
        service_type_id: serviceTypeId,
        default_duration: parseInt(duration),
        description,
        documentation_required: docRequired,
        signature_required: sigRequired,
        active,
      };

      let templateId = '';
      if (editingTemplate) {
        const { error: tError } = await supabase
          .from('service_templates')
          .update(templatePayload)
          .eq('id', editingTemplate.id);
        if (tError) throw tError;
        templateId = editingTemplate.id;
      } else {
        const { data: newTemplate, error: tError } = await supabase
          .from('service_templates')
          .insert(templatePayload)
          .select()
          .single();
        if (tError) throw tError;
        templateId = newTemplate.id;
      }

      // 3. Upsert Pricing
      const pricingPayload = {
        workspace_id: activeWorkspace.id,
        service_template_id: templateId,
        pricing_model: pricingModel,
        rate_amount: parseFloat(rateAmount) || 0,
        currency: 'USD',
        is_active: true
      };

      const existingPriceId = editingTemplate?.service_pricing?.[0]?.id;
      if (existingPriceId) {
        await supabase
          .from('service_pricing')
          .update(pricingPayload)
          .eq('id', existingPriceId);
      } else {
        await supabase
          .from('service_pricing')
          .insert(pricingPayload);
      }

      toast.success(editingTemplate ? 'Service updated' : 'Service created');
      setIsDialogOpen(false);
      setEditingTemplate(null);
      fetchData();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const toggleActive = async (template: ServiceTemplate) => {
    const { error } = await supabase
      .from('service_templates')
      .update({ active: !template.active })
      .eq('id', template.id);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(`Service ${!template.active ? 'activated' : 'deactivated'}`);
      fetchData();
    }
  };

  const handleDuplicate = async (template: ServiceTemplate) => {
    if (!activeWorkspace) return;

    try {
      const { data: newTemplate, error: tError } = await supabase
        .from('service_templates')
        .insert({
          workspace_id: activeWorkspace.id,
          name: `${template.name} (Copy)`,
          service_type_id: template.service_type_id,
          default_duration: template.default_duration,
          description: template.description,
          documentation_required: template.documentation_required,
          signature_required: template.signature_required,
          active: template.active,
        })
        .select()
        .single();

      if (tError) throw tError;

      // Duplicate pricing if exists
      if (template.service_pricing && template.service_pricing.length > 0) {
        const price = template.service_pricing[0];
        await supabase.from('service_pricing').insert({
          workspace_id: activeWorkspace.id,
          service_template_id: newTemplate.id,
          pricing_model: price.pricing_model,
          rate_amount: price.rate_amount,
          currency: price.currency,
          is_active: price.is_active
        });
      }

      toast.success('Service duplicated');
      fetchData();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service? This action cannot be undone.')) return;

    const { error } = await supabase
      .from('service_templates')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('Service deleted');
      fetchData();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Service Menu</h3>
          <p className="text-sm text-muted-foreground">Manage your organization's services, categories, and pricing.</p>
        </div>
        <Button onClick={() => { setEditingTemplate(null); setIsDialogOpen(true); }}>
          <Plus className="mr-2 h-4 w-4" />
          Create Service
        </Button>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) setEditingTemplate(null); }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingTemplate ? 'Edit Service' : 'Create Service'}</DialogTitle>
            <DialogDescription>
              Services define what you offer, how it's billed, and what documentation is required.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Service Name (Display Name)</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required placeholder="e.g. Initial Assessment" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Category (Type of Service)</Label>
                <Input id="category" value={categoryName} onChange={(e) => setCategoryName(e.target.value)} required placeholder="e.g. Physical Therapy" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="mode">Billing Mode</Label>
                <Select value={billingMode} onValueChange={(v: any) => setBillingMode(v)} required>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="HOURLY">Hourly (Time-based)</SelectItem>
                    <SelectItem value="SESSION">Session (Per-visit)</SelectItem>
                    <SelectItem value="PROGRAM" disabled={!hasAdvancedReporting}>
                      Program (Fixed-period) {!hasAdvancedReporting && " - Scale Tier Required"}
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="duration">Default Duration (minutes)</Label>
                <Input id="duration" type="number" value={duration} onChange={(e) => setDuration(e.target.value)} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 border-t pt-4">
              <div className="space-y-2">
                <Label htmlFor="pricing_model">Pricing Model</Label>
                <Select value={pricingModel} onValueChange={(v: any) => setPricingModel(v)} required>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hourly">Hourly Rate</SelectItem>
                    <SelectItem value="flat">Flat Fee</SelectItem>
                    <SelectItem value="unit">Unit-based</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="rate">Rate (USD)</Label>
                <Input id="rate" type="number" step="0.01" value={rateAmount} onChange={(e) => setRateAmount(e.target.value)} required />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Public Description (Optional)</Label>
              <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} />
            </div>

            <div className="grid grid-cols-3 gap-4 border-t pt-4">
              <div className="flex items-center space-x-2">
                <Switch id="doc" checked={docRequired} onCheckedChange={setDocRequired} />
                <Label htmlFor="doc">Doc Required</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="sig" checked={sigRequired} onCheckedChange={setSigRequired} />
                <Label htmlFor="sig">Sig Required</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="active" checked={active} onCheckedChange={setActive} />
                <Label htmlFor="active">Active</Label>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button type="submit">{editingTemplate ? 'Update Service' : 'Create Service'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Service Name</TableHead>
              <TableHead>Category / Mode</TableHead>
              <TableHead>Rate</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">Loading service menu...</TableCell>
              </TableRow>
            ) : templates.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-48 text-center">
                  <Empty
                    icon={FileStack}
                    title="No services defined"
                    description="Create your first service to begin scheduling and documenting work."
                  />
                </TableCell>
              </TableRow>
            ) : (
              templates.map((template) => {
                const price = template.service_pricing?.[0];
                return (
                  <TableRow key={template.id}>
                    <TableCell className="font-medium">{template.name}</TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className="text-sm">{template.service_types?.name}</span>
                        <span className="text-[10px] text-muted-foreground uppercase">{template.service_types?.mode}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {price ? (
                        <div className="flex flex-col">
                          <span className="text-sm font-semibold">
                            {price.rate_amount.toLocaleString('en-US', { style: 'currency', currency: price.currency })}
                          </span>
                          <span className="text-[10px] text-muted-foreground uppercase">{price.pricing_model}</span>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground italic">No rate set</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm">{template.default_duration} min</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Switch 
                          checked={template.active} 
                          onCheckedChange={() => toggleActive(template)}
                        />
                        {template.active ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                        ) : (
                          <XCircle className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon" onClick={() => handleDuplicate(template)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => { setEditingTemplate(template); setIsDialogOpen(true); }}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => handleDelete(template.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
