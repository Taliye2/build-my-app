import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Copy, FileStack, Edit2, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Empty } from '@/components/ui/empty';
import { Switch } from '@/components/ui/switch';
import { useSearchParams } from 'react-router-dom';

export interface ServiceTemplate {
  id: string;
  name: string;
  service_type_id: string;
  default_duration: number | null;
  description: string | null;
  documentation_required: boolean;
  signature_required: boolean;
  active: boolean;
  created_at: string;
  service_types?: {
    name: string;
    mode: 'HOURLY' | 'SESSION' | 'PROGRAM';
  };
}

export interface ServiceType {
  id: string;
  name: string;
  mode: 'HOURLY' | 'SESSION' | 'PROGRAM';
}

export const ServiceCatalogTab: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [searchParams, setSearchParams] = useSearchParams();
  const [templates, setTemplates] = useState<ServiceTemplate[]>([]);
  const [serviceTypes, setServiceTypes] = useState<ServiceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<ServiceTemplate | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [serviceTypeId, setServiceTypeId] = useState('');
  const [duration, setDuration] = useState('60');
  const [description, setDescription] = useState('');
  const [docRequired, setDocRequired] = useState(true);
  const [sigRequired, setSigRequired] = useState(false);
  const [active, setActive] = useState(true);

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    const [templatesRes, typesRes] = await Promise.all([
      supabase
        .from('service_templates')
        .select('*, service_types(*)')
        .eq('workspace_id', activeWorkspace.id)
        .order('name'),
      supabase
        .from('service_types')
        .select('*')
        .eq('workspace_id', activeWorkspace.id)
    ]);

    if (templatesRes.data) setTemplates(templatesRes.data);
    if (typesRes.data) setServiceTypes(typesRes.data);
    
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  useEffect(() => {
    if (editingTemplate) {
      setName(editingTemplate.name);
      setServiceTypeId(editingTemplate.service_type_id);
      setDuration(editingTemplate.default_duration?.toString() || '60');
      setDescription(editingTemplate.description || '');
      setDocRequired(editingTemplate.documentation_required);
      setSigRequired(editingTemplate.signature_required);
      setActive(editingTemplate.active);
      setIsDialogOpen(true);
    } else {
      setName('');
      setServiceTypeId('');
      setDuration('60');
      setDescription('');
      setDocRequired(true);
      setSigRequired(false);
      setActive(true);
    }
  }, [editingTemplate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !serviceTypeId) return;

    const payload = {
      workspace_id: activeWorkspace.id,
      name,
      service_type_id: serviceTypeId,
      default_duration: parseInt(duration),
      description,
      documentation_required: docRequired,
      signature_required: sigRequired,
      active,
    };

    let error;
    if (editingTemplate) {
      const { error: err } = await supabase
        .from('service_templates')
        .update(payload)
        .eq('id', editingTemplate.id);
      error = err;
    } else {
      const { error: err } = await supabase
        .from('service_templates')
        .insert(payload);
      error = err;
    }

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(editingTemplate ? 'Service template updated' : 'Service template created');
      setIsDialogOpen(false);
      setEditingTemplate(null);
      fetchData();
    }
  };

  const handleDuplicate = async (template: ServiceTemplate) => {
    if (!activeWorkspace) return;

    const { error } = await supabase.from('service_templates').insert({
      workspace_id: activeWorkspace.id,
      name: `${template.name} (Copy)`,
      service_type_id: template.service_type_id,
      default_duration: template.default_duration,
      description: template.description,
      documentation_required: template.documentation_required,
      signature_required: template.signature_required,
      active: template.active,
    });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('Template duplicated');
      fetchData();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service template? This action cannot be undone.')) return;

    const { error } = await supabase
      .from('service_templates')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('Service template deleted');
      fetchData();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Service Catalog</h3>
          <p className="text-sm text-muted-foreground">Define reusable service types for your organization.</p>
        </div>
        <Button onClick={() => { setEditingTemplate(null); setIsDialogOpen(true); }}>
          <Plus className="mr-2 h-4 w-4" />
          Create Service Template
        </Button>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) setEditingTemplate(null); }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingTemplate ? 'Edit Service Template' : 'Create Service Template'}</DialogTitle>
            <DialogDescription>
              Templates define default settings for services provided by your organization.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Service Name</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">Service Type (Category)</Label>
                {serviceTypes.length === 0 ? (
                  <div className="text-sm text-destructive bg-destructive/5 p-2 rounded border border-destructive/20">
                    No service types found. <button type="button" onClick={() => setSearchParams({ tab: 'types' })} className="underline font-medium">Create a service type first</button> to define the billing category.
                  </div>
                ) : (
                  <Select value={serviceTypeId} onValueChange={setServiceTypeId} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {serviceTypes.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name} ({t.mode})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="duration">Default Duration (minutes)</Label>
                <Input id="duration" type="number" value={duration} onChange={(e) => setDuration(e.target.value)} />
              </div>
              <div className="flex items-center gap-4 pt-8">
                <div className="flex items-center space-x-2">
                  <Switch id="active" checked={active} onCheckedChange={setActive} />
                  <Label htmlFor="active">Active</Label>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
            </div>
            <div className="grid grid-cols-2 gap-4 border-t pt-4">
              <div className="flex items-center space-x-2">
                <Switch id="doc" checked={docRequired} onCheckedChange={setDocRequired} />
                <Label htmlFor="doc">Documentation Required</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="sig" checked={sigRequired} onCheckedChange={setSigRequired} />
                <Label htmlFor="sig">Signature Required</Label>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button type="submit">{editingTemplate ? 'Update Template' : 'Create Template'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Service Name</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Reqs</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">Loading catalog...</TableCell>
              </TableRow>
            ) : templates.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="h-48">
                  <Empty
                    icon={FileStack}
                    title="No templates found"
                    description="Define your services to begin scheduling and documentation."
                  />
                </TableCell>
              </TableRow>
            ) : (
              templates.map((template) => (
                <TableRow key={template.id}>
                  <TableCell className="font-medium">{template.name}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="capitalize">{template.service_types?.mode.toLowerCase()}</Badge>
                  </TableCell>
                  <TableCell className="text-sm">{template.default_duration} min</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {template.documentation_required && <Badge variant="outline" className="text-[10px]">Doc</Badge>}
                      {template.signature_required && <Badge variant="outline" className="text-[10px]">Sig</Badge>}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={template.active ? "success" : "secondary"}>
                      {template.active ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleDuplicate(template)}>
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setEditingTemplate(template)}>
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(template.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
