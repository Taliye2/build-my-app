import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Plus, Edit2, Trash2, Layers } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';
import { Empty } from '@/components/ui/empty';

export interface ServiceType {
  id: string;
  name: string;
  mode: 'HOURLY' | 'SESSION' | 'PROGRAM';
  created_at: string;
}

export const ServiceTypesTab: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [types, setTypes] = useState<ServiceType[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingType, setEditingType] = useState<ServiceType | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [mode, setMode] = useState<'HOURLY' | 'SESSION' | 'PROGRAM'>('HOURLY');

  const fetchTypes = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('service_types')
      .select('*')
      .eq('workspace_id', activeWorkspace.id)
      .order('name');
    
    if (error) {
      toast.error(error.message);
    } else {
      setTypes(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchTypes();
  }, [activeWorkspace]);

  useEffect(() => {
    if (editingType) {
      setName(editingType.name);
      setMode(editingType.mode);
      setIsDialogOpen(true);
    } else {
      setName('');
      setMode('HOURLY');
    }
  }, [editingType]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace) return;

    const payload = {
      workspace_id: activeWorkspace.id,
      name,
      mode,
    };

    let error;
    if (editingType) {
      const { error: err } = await supabase
        .from('service_types')
        .update(payload)
        .eq('id', editingType.id);
      error = err;
    } else {
      const { error: err } = await supabase
        .from('service_types')
        .insert(payload);
      error = err;
    }

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(editingType ? 'Service type updated' : 'Service type created');
      setIsDialogOpen(false);
      setEditingType(null);
      fetchTypes();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this service type? It may be used by templates.')) return;

    const { error } = await supabase
      .from('service_types')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('Service type deleted');
      fetchTypes();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Service Types</h3>
          <p className="text-sm text-muted-foreground">Define the high-level categories of services your organization provides.</p>
        </div>
        <Button onClick={() => { setEditingType(null); setIsDialogOpen(true); }}>
          <Plus className="mr-2 h-4 w-4" />
          Create Service Type
        </Button>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={(open) => { setIsDialogOpen(open); if (!open) setEditingType(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingType ? 'Edit Service Type' : 'Create Service Type'}</DialogTitle>
            <DialogDescription>
              Service types define the billing mode (Hourly, Session, or Program).
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label htmlFor="type-name">Type Name (e.g., Physical Therapy, Consulting)</Label>
              <Input 
                id="type-name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                placeholder="Enter type name..."
                required 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mode">Category ( Hourly / Session / Program )</Label>
              <Select value={mode} onValueChange={(v: any) => setMode(v)} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="HOURLY">Hourly</SelectItem>
                  <SelectItem value="SESSION">Session-based</SelectItem>
                  <SelectItem value="PROGRAM">Program-based</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">
                {mode === 'HOURLY' && 'Billed by start and end time.'}
                {mode === 'SESSION' && 'Billed by count of sessions.'}
                {mode === 'PROGRAM' && 'Billed as part of a multi-week program.'}
              </p>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button type="submit">{editingType ? 'Update Type' : 'Create Type'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Type Name</TableHead>
              <TableHead>Mode</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={3} className="h-24 text-center text-muted-foreground">Loading types...</TableCell>
              </TableRow>
            ) : types.length === 0 ? (
              <TableRow>
                <TableCell colSpan={3} className="h-48">
                  <Empty
                    icon={Layers}
                    title="No service types"
                    description="Create your first service type to start building your catalog."
                  />
                </TableCell>
              </TableRow>
            ) : (
              types.map((type) => (
                <TableRow key={type.id}>
                  <TableCell className="font-medium">{type.name}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="capitalize">{type.mode.toLowerCase()}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => setEditingType(type)}>
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => handleDelete(type.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
