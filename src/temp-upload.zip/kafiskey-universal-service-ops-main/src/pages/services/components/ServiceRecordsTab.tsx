import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { FileEdit, FileText, Printer, CheckCircle, FileX, Search, Filter, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { Empty } from '@/components/ui/empty';
import { Input } from '@/components/ui/input';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { format, parseISO } from 'date-fns';
import { logAudit } from '@/lib/audit';
import { useAuth } from '@/contexts/AuthContext';

export const ServiceRecordsTab: React.FC = () => {
  const { user } = useAuth();
  const { activeWorkspace } = useWorkspace();
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const fetchRecords = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    
    const { data, error } = await supabase
      .from('service_events')
      .select('*, clients(*), service_templates(*), service_records(*), staff_user_id')
      .eq('workspace_id', activeWorkspace.id)
      .order('date', { ascending: false });

    if (error) {
      toast.error('Error fetching records');
    } else {
      setEvents(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchRecords();
  }, [activeWorkspace]);

  const [printingEvent, setPrintingEvent] = useState<any>(null);
  const [printingProvider, setPrintingProvider] = useState<any>(null);

  const handlePrint = async (event: any) => {
    try {
      setLoading(true);
      // Fetch provider profile
      if (event.staff_user_id) {
        const { data: staffData } = await supabase
          .from('staff_profiles')
          .select('*')
          .eq('user_id', event.staff_user_id)
          .eq('workspace_id', activeWorkspace?.id)
          .maybeSingle();
        setPrintingProvider(staffData);
      }
      
      setPrintingEvent(event);
      
      // Log the print action
      if (user && activeWorkspace) {
        logAudit(activeWorkspace.id, user.id, 'DOWNLOAD', 'service_record', event.id, { method: 'print', source: 'records_tab' });
      }
      
      // Give time for the component to render before printing
      setTimeout(() => {
        window.print();
        setPrintingEvent(null);
        setPrintingProvider(null);
        setLoading(false);
      }, 500);
    } catch (err: any) {
      toast.error('Failed to prepare record for printing: ' + err.message);
      setLoading(false);
    }
  };

  const filteredEvents = events.filter(e => {
    const hasRecord = e.service_records && e.service_records.length > 0;
    const record = hasRecord ? e.service_records[0] : null;
    const isSigned = record?.signed_at != null;
    const isCompleted = record?.record_status === 'Completed';
    const isInProgress = record?.record_status === 'In Progress';

    const matchesSearch = 
      e.clients?.first_name.toLowerCase().includes(search.toLowerCase()) ||
      e.clients?.last_name.toLowerCase().includes(search.toLowerCase()) ||
      e.service_templates?.name.toLowerCase().includes(search.toLowerCase());
    
    let matchesStatus = true;
    if (statusFilter !== 'ALL') {
      if (statusFilter === 'MISSING') matchesStatus = !hasRecord;
      if (statusFilter === 'NEEDS_APPROVAL') matchesStatus = e.status === 'SUBMITTED';
      if (statusFilter === 'COMPLETED') matchesStatus = isSigned || isCompleted || e.status === 'APPROVED' || e.status === 'BILLED';
    }
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">History</h3>
          <p className="text-sm text-muted-foreground">Compliance documentation and delivery evidence.</p>
        </div>
        <Button variant="outline" asChild>
          <Link to="/services?tab=schedule">
            <Plus className="mr-2 h-4 w-4" />
            New Service Record
          </Link>
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row items-center gap-4">
        <div className="flex items-center gap-1 bg-muted p-1 rounded-lg">
          <Button 
            variant={statusFilter === 'ALL' ? 'secondary' : 'ghost'} 
            size="sm" 
            className="h-8"
            onClick={() => setStatusFilter('ALL')}
          >
            All
          </Button>
          <Button 
            variant={statusFilter === 'MISSING' ? 'secondary' : 'ghost'} 
            size="sm" 
            className="h-8"
            onClick={() => setStatusFilter('MISSING')}
          >
            Missing Notes
          </Button>
          <Button 
            variant={statusFilter === 'NEEDS_APPROVAL' ? 'secondary' : 'ghost'} 
            size="sm" 
            className="h-8"
            onClick={() => setStatusFilter('NEEDS_APPROVAL')}
          >
            Needs Approval
          </Button>
          <Button 
            variant={statusFilter === 'COMPLETED' ? 'secondary' : 'ghost'} 
            size="sm" 
            className="h-8"
            onClick={() => setStatusFilter('COMPLETED')}
          >
            Completed
          </Button>
        </div>
        <div className="relative flex-1 w-full sm:w-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search records..." 
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">Loading records...</TableCell>
              </TableRow>
            ) : filteredEvents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-48">
                  <Empty
                    icon={FileX}
                    title="No records found"
                    description="Services that require documentation will appear here."
                  />
                </TableCell>
              </TableRow>
            ) : (
              filteredEvents.map((event) => {
                const hasRecord = event.service_records && event.service_records.length > 0;
                const record = hasRecord ? event.service_records[0] : null;
                const isSigned = record?.signed_at != null;
                const isCompleted = record?.record_status === 'Completed';
                const isInProgress = record?.record_status === 'In Progress';

                return (
                  <TableRow key={event.id}>
                    <TableCell className="text-sm font-medium">
                      {format(parseISO(event.date), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-sm">
                      {event.clients?.first_name} {event.clients?.last_name}
                    </TableCell>
                    <TableCell className="text-sm">{event.service_templates?.name}</TableCell>
                    <TableCell>
                      {isSigned ? (
                        <Badge variant="success" className="gap-1">
                          <CheckCircle className="h-3 w-3" /> Signed
                        </Badge>
                      ) : isCompleted ? (
                        <Badge variant="success">Completed</Badge>
                      ) : isInProgress ? (
                        <Badge variant="default">In Progress</Badge>
                      ) : hasRecord ? (
                        <Badge variant="warning">Draft</Badge>
                      ) : (
                        <Badge variant="secondary">Missing</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link to={`/documentation/edit/${event.id}`}>
                            {isSigned ? 'View PDF' : (hasRecord ? 'Resume' : 'Create Note')}
                          </Link>
                        </Button>
                        {isSigned && (
                          <Button variant="ghost" size="icon" onClick={() => handlePrint(event)}>
                            <Printer className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Hidden Print View */}
      {printingEvent && (
        <div className="hidden print:block fixed inset-0 bg-white z-[9999] p-12 overflow-y-auto">
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex justify-between items-start border-b pb-8">
              <div>
                <h1 className="text-4xl font-bold text-primary mb-2">{activeWorkspace?.name}</h1>
                <p className="text-sm text-muted-foreground uppercase tracking-widest mt-1">Service Documentation Record</p>
              </div>
              <div className="text-right">
                <p className="font-bold">Date: {new Date(printingEvent.date).toLocaleDateString()}</p>
                <p className="text-xs text-muted-foreground">Record ID: {printingEvent.service_records?.[0]?.id || 'N/A'}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-12 py-8">
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground border-b pb-2">Client Information</h3>
                <div className="space-y-1">
                  <p className="text-xl font-bold">{printingEvent.clients?.first_name} {printingEvent.clients?.last_name}</p>
                  <p className="text-sm">DOB: {printingEvent.clients?.dob ? new Date(printingEvent.clients.dob).toLocaleDateString() : 'N/A'}</p>
                  <p className="text-sm">{printingEvent.clients?.email}</p>
                </div>
              </div>
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground border-b pb-2">Service Details</h3>
                <div className="space-y-1">
                  <p className="text-lg font-bold">{printingEvent.service_templates?.name}</p>
                  <p className="text-sm">Provider: {printingProvider?.full_name || printingProvider?.email || 'N/A'}</p>
                  <p className="text-sm">Status: {printingEvent.status}</p>
                </div>
              </div>
            </div>

            <div className="space-y-6 py-8">
              {printingEvent.service_records?.[0] && (
                <>
                  {/* For legacy records that haven't been opened/merged yet */}
                  {printingEvent.service_records[0].goals && 
                   (!printingEvent.service_records[0].free_text || !printingEvent.service_records[0].free_text.includes(printingEvent.service_records[0].goals)) && (
                    <div className="space-y-2">
                      <h4 className="font-bold text-sm">Goals Addressed</h4>
                      <p className="text-sm border p-4 rounded bg-muted/10 whitespace-pre-wrap">{printingEvent.service_records[0].goals}</p>
                    </div>
                  )}
                  {printingEvent.service_records[0].interventions && 
                   (!printingEvent.service_records[0].free_text || !printingEvent.service_records[0].free_text.includes(printingEvent.service_records[0].interventions)) && (
                    <div className="space-y-2">
                      <h4 className="font-bold text-sm">Interventions & Activities</h4>
                      <p className="text-sm border p-4 rounded bg-muted/10 whitespace-pre-wrap">{printingEvent.service_records[0].interventions}</p>
                    </div>
                  )}
                  {printingEvent.service_records[0].outcome && 
                   (!printingEvent.service_records[0].free_text || !printingEvent.service_records[0].free_text.includes(printingEvent.service_records[0].outcome)) && (
                    <div className="space-y-2">
                      <h4 className="font-bold text-sm">Outcome / Response</h4>
                      <p className="text-sm border p-4 rounded bg-muted/10 whitespace-pre-wrap">{printingEvent.service_records[0].outcome}</p>
                    </div>
                  )}
                  {printingEvent.service_records[0].next_steps && 
                   (!printingEvent.service_records[0].free_text || !printingEvent.service_records[0].free_text.includes(printingEvent.service_records[0].next_steps)) && (
                    <div className="space-y-2">
                      <h4 className="font-bold text-sm">Next Steps</h4>
                      <p className="text-sm border p-4 rounded bg-muted/10 whitespace-pre-wrap">{printingEvent.service_records[0].next_steps}</p>
                    </div>
                  )}
                  {printingEvent.service_records[0].free_text && (
                    <div className="space-y-2">
                      <h4 className="font-bold text-sm">Session Notes</h4>
                      <p className="text-sm border p-4 rounded bg-muted/10 whitespace-pre-wrap">{printingEvent.service_records[0].free_text}</p>
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="pt-12 border-t mt-12">
              <div className="flex justify-between items-end">
                <div className="space-y-2">
                  <p className="text-xs font-bold uppercase text-muted-foreground">Provider Signature</p>
                  <p className="text-2xl font-serif italic border-b border-black min-w-[250px] pb-1">
                    {printingEvent.service_records?.[0]?.staff_signature_name}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    Digitally signed on {printingEvent.service_records?.[0]?.signed_at ? new Date(printingEvent.service_records[0].signed_at).toLocaleString() : 'N/A'}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-muted-foreground italic">
                    This document is a part of the permanent medical/operational record.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
