import React from 'react';
import { Users, Mail, Phone, MapPin, Search, Filter, MoreHorizontal, MessageSquare, Calendar } from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { LeadDialog } from './components/LeadDialog';

export const AdminLeadsPage: React.FC = () => {
  const [leads, setLeads] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [searchQuery, setSearchQuery] = React.useState('');
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [selectedLead, setSelectedLead] = React.useState<any>(null);

  React.useEffect(() => {
    fetchLeads();
  }, []);

  const fetchLeads = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setLeads(data || []);
    } catch (err) {
      console.error('Error fetching leads:', err);
      toast.error('Failed to load leads');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (lead: any) => {
    setSelectedLead(lead);
    setDialogOpen(true);
  };

  const handleCreate = () => {
    setSelectedLead(null);
    setDialogOpen(true);
  };

  const filteredLeads = leads.filter(lead => 
    lead.company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lead.contact_person.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lead.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Leads</h1>
          <p className="text-slate-500">Track and manage prospective organizations.</p>
        </div>
        <Button 
          className="bg-[#2563eb] hover:bg-blue-600 text-white gap-2"
          onClick={handleCreate}
        >
          <Users className="h-4 w-4" />
          Add Lead
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'New Leads', value: leads.filter(l => l.status === 'New').length.toString(), color: 'bg-blue-50 text-blue-700' },
          { label: 'Qualified', value: leads.filter(l => l.status === 'Qualified').length.toString(), color: 'bg-emerald-50 text-emerald-700' },
          { label: 'Conversion Rate', value: leads.length > 0 ? `${((leads.filter(l => l.status === 'Converted').length / leads.length) * 100).toFixed(1)}%` : '0%', color: 'bg-purple-50 text-purple-700' },
          { label: 'Total Leads', value: leads.length.toString(), color: 'bg-amber-50 text-amber-700' },
        ].map((stat) => (
          <Card key={stat.label} className="border-slate-200 shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{stat.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Search leads by name, company, or email..." 
            className="pl-10 bg-white border-slate-200"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2 border-slate-200">
          <Filter className="h-4 w-4 text-slate-400" />
          Filter
        </Button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-slate-50/50">
            <TableRow>
              <TableHead className="pl-6">Contact & Company</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Contact Info</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right pr-6">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                  Loading leads...
                </TableCell>
              </TableRow>
            ) : filteredLeads.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                  No leads found.
                </TableCell>
              </TableRow>
            ) : filteredLeads.map((lead) => (
              <TableRow key={lead.id} className="hover:bg-slate-50/50 transition-colors group">
                <TableCell className="pl-6">
                  <div className="flex flex-col">
                    <span className="text-sm font-semibold text-slate-900">{lead.contact_person}</span>
                    <span className="text-xs text-slate-500">{lead.company_name}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge 
                    variant="outline" 
                    className={cn(
                      "font-medium",
                      lead.status === 'New' ? "bg-blue-50 text-blue-700 border-blue-100" :
                      lead.status === 'Qualified' ? "bg-emerald-50 text-emerald-700 border-emerald-100" :
                      lead.status === 'Converted' ? "bg-emerald-50 text-emerald-700 border-emerald-100" :
                      "bg-amber-50 text-amber-700 border-amber-100"
                    )}
                  >
                    {lead.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="secondary" className="font-normal bg-slate-100 text-slate-700">
                    {lead.source || 'Direct'}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-1.5 text-xs text-slate-500">
                      <Mail className="h-3 w-3" />
                      {lead.email}
                    </div>
                    {lead.phone && (
                      <div className="flex items-center gap-1.5 text-xs text-slate-500">
                        <Phone className="h-3 w-3" />
                        {lead.phone}
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <span className="text-sm text-slate-500">{new Date(lead.created_at).toLocaleDateString()}</span>
                </TableCell>
                <TableCell className="text-right pr-6">
                  <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-[#2563eb]" title="Message">
                      <MessageSquare className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-[#2563eb]" title="Schedule Call">
                      <Calendar className="h-4 w-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 text-slate-400 hover:text-slate-900"
                      onClick={() => handleEdit(lead)}
                    >
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <LeadDialog 
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        lead={selectedLead}
        onSuccess={fetchLeads}
      />
    </div>
  );
};
