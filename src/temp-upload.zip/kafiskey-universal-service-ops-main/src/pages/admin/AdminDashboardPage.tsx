import React from 'react';
import { 
  DollarSign, 
  Building2, 
  Clock, 
  UserPlus, 
  ArrowUpRight,
  MoreHorizontal,
  Mail,
  Calendar,
  Megaphone,
  Activity
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

export const AdminDashboardPage: React.FC = () => {
  const [metrics, setMetrics] = React.useState<any[]>([]);
  const [trialWatch, setTrialWatch] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const { user } = useAuth();

  React.useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      // 1. Fetch Workspaces Stats
      const { data: workspaces, error: wsError } = await supabase
        .from('workspaces')
        .select('*');

      if (wsError) throw wsError;

      // 2. Fetch Leads Count
      const { count: leadsCount, error: leadsError } = await supabase
        .from('leads')
        .select('id', { count: 'exact', head: true });

      if (leadsError) throw leadsError;

      // Calculate metrics
      const activeOrgs = workspaces?.filter(ws => ws.subscription_status === 'active' || ws.subscription_status === 'trialing')?.length || 0;
      const trialingOrgs = workspaces?.filter(ws => ws.subscription_status === 'trialing')?.length || 0;
      
      const newMetrics = [
        { label: 'Total MRR', value: '$42,500', icon: DollarSign, trend: '+12.5%', color: 'text-emerald-600' }, // Dummy MRR for now
        { label: 'Active Workspaces', value: activeOrgs.toString(), icon: Building2, trend: '+4.2%', color: 'text-[#2563eb]' },
        { label: 'Trialing Orgs', value: trialingOrgs.toString(), icon: Clock, trend: '-2.1%', color: 'text-amber-600' },
        { label: 'New Leads', value: (leadsCount || 0).toString(), icon: UserPlus, trend: '+18.4%', color: 'text-purple-600' },
      ];

      setMetrics(newMetrics);

      // 3. Fetch Trial Watch (ending in next 10 days)
      const now = new Date();
      const tenDaysFromNow = new Date();
      tenDaysFromNow.setDate(now.getDate() + 10);

      // Filtering in JS for trial_start_date logic
      const watchList = (workspaces || [])
        .filter(ws => ws.subscription_status === 'trialing')
        .map(ws => {
          const start = new Date(ws.trial_start_date || ws.created_at);
          const diffTime = now.getTime() - start.getTime();
          const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
          const daysLeft = Math.max(0, 30 - diffDays);
          return { ...ws, daysLeft };
        })
        .filter(ws => ws.daysLeft <= 10)
        .sort((a, b) => a.daysLeft - b.daysLeft)
        .slice(0, 5);

      setTrialWatch(watchList);

    } catch (err) {
      console.error('Error fetching dashboard data:', err);
      toast.error('Failed to load dashboard metrics');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailOwner = async (org: any) => {
    try {
      const { daysLeft } = org;
      let subject = '';
      let body = '';

      if (daysLeft <= 3 && daysLeft > 0) {
        subject = "Your Kafiskey Trial is Ending Soon";
        body = `Hi Owner, you have ${daysLeft} days remaining in your trial. To avoid service interruption for your team, please select a plan in your billing settings.`;
      } else if (daysLeft <= 0) {
        subject = "Your Workspace has been Paused";
        body = `Your trial has ended. Your data is safe and encrypted, but access is restricted until a subscription is active.`;
      } else {
        subject = "Checking in on your Kafiskey Trial";
        body = `Hi, how is your trial going? You have ${daysLeft} days left. Let us know if you need help!`;
      }

      // Log the campaign action
      await supabase.from('system_audit_logs').insert({
        admin_id: user?.id,
        target_workspace_id: org.id,
        action: 'Trial Notification Email Sent',
        metadata: { subject, daysLeft }
      });

      // Use the send-email edge function if available, or just toast for now
      const { data, error } = await supabase.functions.invoke('send-email', {
        body: {
          to: org.owner_email || 'owner@example.com',
          subject,
          text: body,
          workspaceId: org.id
        }
      });

      if (error) throw error;

      toast.success(`Email sent to ${org.name} owner`);
    } catch (err) {
      console.error('Error sending trial email:', err);
      toast.error('Failed to send email');
    }
  };

  if (loading && metrics.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2563eb]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Command Center</h1>
        <p className="text-slate-500">Real-time overview of Kafiskey operations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric) => (
          <Card key={metric.label} className="border-slate-200 shadow-sm overflow-hidden group hover:border-[#2563eb] transition-colors">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium text-slate-500">{metric.label}</CardTitle>
              <div className={cn("p-2 rounded-lg bg-slate-50 group-hover:bg-slate-100 transition-colors", metric.color)}>
                <metric.icon className="h-4 w-4" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{metric.value}</div>
              <div className="flex items-center gap-1 mt-1">
                <span className={cn(
                  "text-xs font-medium",
                  metric.trend.startsWith('+') ? "text-emerald-600" : "text-rose-600"
                )}>
                  {metric.trend}
                </span>
                <span className="text-[10px] text-slate-400">vs last month</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-slate-200 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="text-lg">Trial Watch</CardTitle>
              <p className="text-sm text-slate-500">Organizations with trials ending in the next 10 days.</p>
            </div>
            <Button variant="outline" size="sm" className="gap-2">
              <Calendar className="h-4 w-4" />
              View Calendar
            </Button>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader className="bg-slate-50/50">
                <TableRow>
                  <TableHead className="pl-6">Organization</TableHead>
                  <TableHead>Plan</TableHead>
                  <TableHead>Trial Days Left</TableHead>
                  <TableHead className="text-right pr-6">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {trialWatch.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-slate-500">
                      No organizations currently in critical trial window.
                    </TableCell>
                  </TableRow>
                ) : trialWatch.map((org) => (
                  <TableRow key={org.id} className={cn(
                    "hover:bg-slate-50/50 transition-colors",
                    org.daysLeft <= 0 && "bg-rose-50/50"
                  )}>
                    <TableCell className="pl-6 font-medium text-slate-900">{org.name}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="font-normal bg-slate-100 text-slate-700 capitalize">
                        {org.plan_key || 'trial'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className={cn(
                          "h-2 w-2 rounded-full",
                          org.daysLeft <= 5 ? "bg-rose-500 animate-pulse" : "bg-amber-500"
                        )} />
                        <span className={cn(
                          "font-medium",
                          org.daysLeft <= 0 ? "text-rose-600" : org.daysLeft <= 5 ? "text-rose-600" : "text-amber-600"
                        )}>
                          {org.daysLeft <= 0 ? 'Expired' : `${org.daysLeft} days`}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right pr-6">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-slate-500 hover:text-[#2563eb]" 
                          title="Email Owner"
                          onClick={() => handleEmailOwner(org)}
                        >
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:text-[#2563eb]" title="Extend Trial">
                          <ArrowUpRight className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:text-slate-900">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="space-y-8">
          <Card className="border-slate-200 shadow-sm bg-[#0f172a] text-white">
            <CardHeader>
              <CardTitle className="text-lg">System Health</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-sm text-slate-400">Database</div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">99.99%</span>
                  <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-slate-400">Edge Functions</div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">100%</span>
                  <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-slate-400">Stripe Sync</div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">Healthy</span>
                  <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                </div>
              </div>
              <div className="pt-4 border-t border-slate-800">
                <Button className="w-full bg-[#2563eb] hover:bg-blue-600 text-white border-0">
                  Detailed Status
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Platform Announcements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="h-10 w-10 shrink-0 rounded-lg bg-blue-50 flex items-center justify-center">
                  <Megaphone className="h-5 w-5 text-[#2563eb]" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold">Scheduled Maintenance</h4>
                  <p className="text-xs text-slate-500 mt-1">Feb 15, 02:00 AM UTC. Expected downtime: 15 mins.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="h-10 w-10 shrink-0 rounded-lg bg-amber-50 flex items-center justify-center">
                  <Activity className="h-5 w-5 text-amber-600" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold">New HIPAA Controls</h4>
                  <p className="text-xs text-slate-500 mt-1">V2 audit logs are now being deployed to all orgs.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};