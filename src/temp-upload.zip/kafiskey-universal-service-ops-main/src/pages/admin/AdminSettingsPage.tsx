import React from 'react';
import { 
  Settings, 
  Shield, 
  Database, 
  Globe, 
  Lock, 
  Bell, 
  Save,
  RefreshCcw,
  AlertTriangle
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export const AdminSettingsPage: React.FC = () => {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">System Settings</h1>
        <p className="text-slate-500">Configure global platform parameters and security controls.</p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="bg-slate-100 p-1 border border-slate-200">
          <TabsTrigger value="general" className="gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Globe className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="security" className="gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Shield className="h-4 w-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="database" className="gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Database className="h-4 w-4" />
            Database
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2 data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Bell className="h-4 w-4" />
            Notifications
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <Card className="border-slate-200 shadow-sm">
            <CardHeader>
              <CardTitle>Platform Identity</CardTitle>
              <CardDescription>Global branding and platform-wide defaults.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="platformName">Platform Name</Label>
                  <Input id="platformName" defaultValue="Kafiskey" className="border-slate-200" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="supportEmail">Global Support Email</Label>
                  <Input id="supportEmail" defaultValue="support@kafiskey.com" className="border-slate-200" />
                </div>
              </div>
              <div className="pt-4 flex justify-end">
                <Button className="bg-[#2563eb] hover:bg-blue-600 text-white gap-2">
                  <Save className="h-4 w-4" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-200 shadow-sm border-amber-100 bg-amber-50/20">
            <CardHeader>
              <CardTitle className="text-amber-700 flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Maintenance Mode
              </CardTitle>
              <CardDescription className="text-amber-600/80">
                When enabled, all non-admin users will be redirected to a maintenance page.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-slate-700">Enable Maintenance Mode</Label>
                <p className="text-xs text-slate-500">Scheduled for Feb 15, 02:00 AM UTC</p>
              </div>
              <Switch />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card className="border-slate-200 shadow-sm">
            <CardHeader>
              <CardTitle>Global Security Controls</CardTitle>
              <CardDescription>Authentication and authorization overrides.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Force 2FA for Admins</Label>
                  <p className="text-xs text-slate-500">Require multi-factor auth for all owner/admin accounts.</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Strict HIPAA Logging</Label>
                  <p className="text-xs text-slate-500">Log all read operations on client PII across all orgs.</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>New Org Signups</Label>
                  <p className="text-xs text-slate-500">Allow new organizations to create accounts via public portal.</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="database" className="space-y-6">
          <Card className="border-slate-200 shadow-sm">
            <CardHeader>
              <CardTitle>Storage & Backups</CardTitle>
              <CardDescription>Monitor database health and backup status.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                    <RefreshCcw className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold">Automatic Backups</h4>
                    <p className="text-xs text-slate-500">Last successful: 42 minutes ago</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="border-slate-200">Run Now</Button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-100">
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Database Size</div>
                  <div className="text-xl font-bold text-slate-900">1.42 GB</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-100">
                  <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Row Count</div>
                  <div className="text-xl font-bold text-slate-900">4.2M</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};