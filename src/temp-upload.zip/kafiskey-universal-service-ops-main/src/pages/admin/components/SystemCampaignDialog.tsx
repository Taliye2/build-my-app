import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { Mail, Send, Loader2 } from 'lucide-react';

interface SystemCampaignDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  campaign?: any;
  onSuccess: () => void;
}

export const SystemCampaignDialog: React.FC<SystemCampaignDialogProps> = ({ 
  open, 
  onOpenChange, 
  campaign, 
  onSuccess 
}) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    content_html: '',
    target_audience: 'TRIALING',
    trigger_type: 'Manual'
  });

  useEffect(() => {
    if (campaign) {
      setFormData({
        name: campaign.name,
        subject: campaign.subject,
        content_html: campaign.content_html,
        target_audience: campaign.target_audience,
        trigger_type: campaign.trigger_type
      });
    } else {
      setFormData({
        name: '',
        subject: '',
        content_html: '',
        target_audience: 'TRIALING',
        trigger_type: 'Manual'
      });
    }
  }, [campaign, open]);

  const handleSave = async (isDraft: boolean = true) => {
    if (!formData.name || !formData.subject || !formData.content_html) {
      toast.error('Please fill in all required fields');
      return;
    }

    setLoading(true);
    try {
      const payload = {
        ...formData,
        status: isDraft ? 'draft' : 'scheduled',
        updated_at: new Date().toISOString()
      };

      let error;
      if (campaign?.id) {
        ({ error } = await supabase
          .from('system_campaigns')
          .update(payload)
          .eq('id', campaign.id));
      } else {
        ({ error } = await supabase
          .from('system_campaigns')
          .insert([payload]));
      }

      if (error) throw error;

      toast.success(campaign ? 'Campaign updated' : 'Campaign created');
      onSuccess();
      onOpenChange(false);
    } catch (err: any) {
      console.error('Error saving campaign:', err);
      toast.error(err.message || 'Failed to save campaign');
    } finally {
      setLoading(false);
    }
  };

  const handleLaunch = async () => {
    if (!campaign?.id) return;
    
    setLoading(true);
    try {
      // In a real app, this would trigger the campaign-processor edge function
      const { error } = await supabase.functions.invoke('campaign-processor', {
        body: { 
          action: 'launch-campaign',
          campaignId: campaign.id 
        }
      });

      if (error) throw error;

      toast.success('Campaign launched successfully');
      onSuccess();
      onOpenChange(false);
    } catch (err: any) {
      console.error('Error launching campaign:', err);
      toast.error(err.message || 'Failed to launch campaign');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle>{campaign ? 'Edit Campaign' : 'Create System Campaign'}</DialogTitle>
          <DialogDescription>
            Configure platform-wide communication for your organizations.
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 p-6">
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Campaign Name</Label>
                <Input 
                  id="name"
                  placeholder="e.g., Q1 Trial Extension Promo"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="audience">Target Audience</Label>
                <Select 
                  value={formData.target_audience}
                  onValueChange={(v) => setFormData({ ...formData, target_audience: v })}
                >
                  <SelectTrigger id="audience">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ALL">All Organizations</SelectItem>
                    <SelectItem value="TRIALING">Active Trials</SelectItem>
                    <SelectItem value="ACTIVE">Paying Customers</SelectItem>
                    <SelectItem value="EXPIRED">Expired Trials</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="subject">Email Subject</Label>
              <Input 
                id="subject"
                placeholder="Important: Your Kafiskey Trial"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content">Content (HTML)</Label>
              <Textarea 
                id="content"
                placeholder="<h1>Hello!</h1><p>Your trial is ending soon...</p>"
                className="min-h-[300px] font-mono text-sm"
                value={formData.content_html}
                onChange={(e) => setFormData({ ...formData, content_html: e.target.value })}
              />
              <p className="text-[10px] text-muted-foreground">
                Tip: You can use variables like {'{{organization_name}}'} or {'{{trial_days_left}}'}.
              </p>
            </div>
          </div>
        </ScrollArea>

        <DialogFooter className="p-6 border-t bg-slate-50/50">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)} disabled={loading}>
                Cancel
              </Button>
              <Button variant="secondary" onClick={() => handleSave(true)} disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Save as Draft
              </Button>
            </div>
            {campaign?.status === 'draft' && (
              <Button className="bg-[#2563eb] hover:bg-blue-600 text-white gap-2" onClick={handleLaunch} disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                Launch Now
              </Button>
            )}
            {!campaign && (
              <Button className="bg-[#2563eb] hover:bg-blue-600 text-white" onClick={() => handleSave(false)} disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Create & Schedule
              </Button>
            )}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
