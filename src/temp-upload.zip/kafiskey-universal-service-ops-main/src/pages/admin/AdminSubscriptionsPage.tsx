import React from 'react';
import { CreditCard, DollarSign, ArrowUpRight, ArrowDownRight, MoreHorizontal, Download, Filter, Search } from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const transactions = [
  { id: '1', org: 'Acme Health Care', amount: '$450.00', status: 'Succeeded', date: '2024-02-01', plan: 'Enterprise' },
  { id: '2', org: 'Coaching Pro', amount: '$150.00', status: 'Succeeded', date: '2024-01-20', plan: 'Professional' },
  { id: '3', org: 'Wellness Center', amount: '$49.00', status: 'Failed', date: '2024-01-15', plan: 'Basic' },
  { id: '4', org: 'Mountain View Care', amount: '$150.00', status: 'Succeeded', date: '2024-01-01', plan: 'Professional' },
  { id: '5', org: 'River Valley Therapy', amount: '$450.00', status: 'Refunded', date: '2023-12-28', plan: 'Enterprise' },
];

export const AdminSubscriptionsPage: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Subscriptions</h1>
          <p className="text-slate-500">Revenue overview and transaction history.</p>
        </div>
        <Button className="bg-[#2563eb] hover:bg-blue-600 text-white gap-2">
          <Download className="h-4 w-4" />
          Export CSV
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Gross Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">$128,450.00</div>
            <div className="flex items-center gap-1 mt-1">
              <ArrowUpRight className="h-3 w-3 text-emerald-600" />
              <span className="text-xs font-medium text-emerald-600">+8.2%</span>
              <span className="text-[10px] text-slate-400 font-normal">vs last month</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Active Subscriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">842</div>
            <div className="flex items-center gap-1 mt-1">
              <ArrowUpRight className="h-3 w-3 text-emerald-600" />
              <span className="text-xs font-medium text-emerald-600">+14</span>
              <span className="text-[10px] text-slate-400 font-normal">this month</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Churn Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">2.4%</div>
            <div className="flex items-center gap-1 mt-1">
              <ArrowDownRight className="h-3 w-3 text-emerald-600" />
              <span className="text-xs font-medium text-emerald-600">-0.2%</span>
              <span className="text-[10px] text-slate-400 font-normal">improvement</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Search transactions by organization or ID..." 
            className="pl-10 bg-white border-slate-200"
          />
        </div>
        <Button variant="outline" className="gap-2 border-slate-200">
          <Filter className="h-4 w-4 text-slate-400" />
          Filter
        </Button>
      </div>

      <Card className="border-slate-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-slate-50/50 border-b border-slate-200">
          <CardTitle className="text-base font-semibold text-slate-900">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="pl-6">Organization</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right pr-6">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.map((tx) => (
                <TableRow key={tx.id} className="hover:bg-slate-50/50 transition-colors group">
                  <TableCell className="pl-6 font-medium text-slate-900">{tx.org}</TableCell>
                  <TableCell>
                    <span className="text-sm font-semibold">{tx.amount}</span>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "font-medium",
                        tx.status === 'Succeeded' ? "bg-emerald-50 text-emerald-700 border-emerald-100" :
                        tx.status === 'Failed' ? "bg-rose-50 text-rose-700 border-rose-100" :
                        "bg-slate-100 text-slate-600 border-slate-200"
                      )}
                    >
                      {tx.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">{tx.plan}</span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm text-slate-500">{tx.date}</span>
                  </TableCell>
                  <TableCell className="text-right pr-6">
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-slate-900">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};