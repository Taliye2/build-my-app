import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Search, 
  Filter, 
  MoreHorizontal, 
  ExternalLink,
  Shield,
  CreditCard,
  Mail,
  User
} from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    case 'active': return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    case 'trialing': return 'bg-amber-50 text-amber-700 border-amber-100';
    case 'past due': return 'bg-rose-50 text-rose-700 border-rose-100';
    case 'canceled': return 'bg-slate-100 text-slate-600 border-slate-200';
    default: return 'bg-slate-50 text-slate-500 border-slate-100';
  }
};

export const AdminOrganizationsPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [organizations, setOrganizations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { setImpersonatedWorkspaceId, user } = useAuth();

  useEffect(() => {
    fetchOrganizations();
  }, []);

  const fetchOrganizations = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('workspaces')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // For each workspace, get member count
      const orgsWithCounts = await Promise.all((data || []).map(async (org) => {
        const { count } = await supabase
          .from('workspace_members')
          .select('id', { count: 'exact', head: true })
          .eq('workspace_id', org.id);
        
        return {
          ...org,
          members: count || 0
        };
      }));

      setOrganizations(orgsWithCounts);
    } catch (err) {
      console.error('Error fetching organizations:', err);
      toast.error('Failed to load organizations');
    } finally {
      setLoading(false);
    }
  };

  const handleImpersonate = async (orgId: string, orgName: string) => {
    try {
      // Log impersonation
      await supabase.from('system_audit_logs').insert({
        admin_id: user?.id,
        target_workspace_id: orgId,
        action: 'Impersonation Started',
        metadata: { orgName }
      });

      setImpersonatedWorkspaceId(orgId);
      toast.success(`Now impersonating ${orgName}`);
      window.location.href = '/';
    } catch (err) {
      console.error('Error starting impersonation:', err);
      toast.error('Failed to start impersonation');
    }
  };

  const getTrialDaysLeft = (startDate: string | null) => {
    if (!startDate) return 30;
    const start = new Date(startDate);
    const now = new Date();
    const diffTime = now.getTime() - start.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return Math.max(0, 30 - diffDays);
  };

  const filteredOrgs = organizations.filter(org => 
    org.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    org.id.includes(searchQuery)
  );

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Organizations</h1>
          <p className="text-slate-500">Manage all client workspaces and subscriptions.</p>
        </div>
        <Button className="bg-[#2563eb] hover:bg-blue-600 text-white gap-2">
          <Building2 className="h-4 w-4" />
          Create Organization
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input 
            placeholder="Search by organization name, domain, or ID..." 
            className="pl-10 bg-white border-slate-200"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2 border-slate-200">
          <Filter className="h-4 w-4 text-slate-400" />
          Filter
        </Button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <Table>
          <TableHeader className="bg-slate-50/50">
            <TableRow>
              <TableHead className="pl-6 w-[250px]">Organization</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Health</TableHead>
              <TableHead>Last Activity</TableHead>
              <TableHead>Members</TableHead>
              <TableHead className="text-right pr-6">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                  Loading organizations...
                </TableCell>
              </TableRow>
            ) : filteredOrgs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                  No organizations found.
                </TableCell>
              </TableRow>
            ) : filteredOrgs.map((org) => {
              const daysLeft = getTrialDaysLeft(org.trial_start_date);
              const status = org.subscription_status || 'trialing';
              
              // Health status logic
              const lastActivity = org.last_activity ? new Date(org.last_activity) : null;
              const now = new Date();
              const hoursSinceActivity = lastActivity ? (now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60) : Infinity;
              
              const healthStatus = hoursSinceActivity < 24 ? 'Healthy' : hoursSinceActivity > 72 ? 'Stale' : 'Neutral';
              const healthColor = healthStatus === 'Healthy' ? 'bg-emerald-500' : healthStatus === 'Stale' ? 'bg-amber-500' : 'bg-slate-400';

              return (
                <TableRow key={org.id} className={cn(
                  "hover:bg-slate-50/50 transition-colors group",
                  daysLeft <= 0 && status === 'trialing' && "bg-rose-50/30",
                  daysLeft <= 5 && daysLeft > 0 && status === 'trialing' && "bg-amber-50/30"
                )}>
                  <TableCell className="pl-6 font-medium">
                    <div className="flex flex-col">
                      <span className="text-slate-900">{org.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">ID: {org.id.substring(0, 8)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={cn("font-medium capitalize", getStatusColor(status))}>
                      {status === 'trialing' && daysLeft <= 0 ? 'Expired' : status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className={cn("h-2 w-2 rounded-full", healthColor)} />
                      <span className={cn(
                        "text-xs font-medium",
                        healthStatus === 'Healthy' ? "text-emerald-600" : healthStatus === 'Stale' ? "text-amber-600" : "text-slate-500"
                      )}>
                        {healthStatus}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span className="text-sm text-slate-600">
                        {lastActivity ? lastActivity.toLocaleDateString() : 'Never'}
                      </span>
                      {lastActivity && (
                        <span className="text-[10px] text-slate-400">
                          {lastActivity.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <User className="h-3 w-3" />
                      <span className="text-sm">{org.members}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right pr-6">
                    <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-8 gap-1.5 text-[#2563eb] hover:bg-blue-50"
                        onClick={() => handleImpersonate(org.id, org.name)}
                      >
                        <Shield className="h-3.5 w-3.5" />
                        Impersonate
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-slate-900">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem className="gap-2">
                            <ExternalLink className="h-4 w-4" /> View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem className="gap-2">
                            <Mail className="h-4 w-4" /> Contact Owner
                          </DropdownMenuItem>
                          <DropdownMenuItem className="gap-2">
                            <CreditCard className="h-4 w-4" /> Billing Settings
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="gap-2 text-rose-600 focus:text-rose-600">
                            Suspend Org
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
