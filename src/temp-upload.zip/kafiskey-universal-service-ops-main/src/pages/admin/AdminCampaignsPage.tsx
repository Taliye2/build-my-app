import React from 'react';
import { 
  Megaphone, 
  Plus, 
  Mail, 
  Users, 
  BarChart3, 
  Eye, 
  MousePointer2,
  MoreHorizontal
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { SystemCampaignDialog } from './components/SystemCampaignDialog';

export const AdminCampaignsPage: React.FC = () => {
  const [campaigns, setCampaigns] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [selectedCampaign, setSelectedCampaign] = React.useState<any>(null);

  React.useEffect(() => {
    fetchCampaigns();
  }, []);

  const fetchCampaigns = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('system_campaigns')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCampaigns(data || []);
    } catch (err) {
      console.error('Error fetching campaigns:', err);
      toast.error('Failed to load campaigns');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (campaign: any) => {
    setSelectedCampaign(campaign);
    setDialogOpen(true);
  };

  const handleCreate = () => {
    setSelectedCampaign(null);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Campaigns</h1>
          <p className="text-slate-500">Communicate with your users and drive growth.</p>
        </div>
        <Button 
          className="bg-[#2563eb] hover:bg-blue-600 text-white gap-2 shadow-sm"
          onClick={handleCreate}
        >
          <Plus className="h-4 w-4" />
          New Campaign
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Total Campaigns</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{campaigns.length}</div>
            <p className="text-xs text-emerald-600 font-medium mt-1 flex items-center gap-1">
              Active tracking <span className="text-slate-400 font-normal">in system</span>
            </p>
          </CardContent>
        </Card>
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Emails Sent (30d)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">12,482</div>
            <p className="text-xs text-emerald-600 font-medium mt-1 flex items-center gap-1">
              +12.5% <span className="text-slate-400 font-normal">vs last month</span>
            </p>
          </CardContent>
        </Card>
        <Card className="border-slate-200 shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-500">Active Sequences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">8</div>
            <p className="text-xs text-slate-400 font-medium mt-1">2 scheduled for next week</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <Card className="border-slate-200 shadow-sm overflow-hidden">
            <CardHeader className="bg-slate-50/50 border-b border-slate-200">
              <CardTitle className="text-base">Campaign Builder</CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Target Audience</label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" className="justify-start gap-2 h-10 border-slate-200 text-slate-600">
                      <Users className="h-4 w-4" />
                      All Trialing
                    </Button>
                    <Button variant="outline" className="justify-start gap-2 h-10 border-slate-200 text-slate-600">
                      <Users className="h-4 w-4" />
                      Active Orgs
                    </Button>
                    <Button variant="outline" className="justify-start gap-2 h-10 border-slate-200 text-slate-600">
                      <Users className="h-4 w-4" />
                      Canceled
                    </Button>
                    <Button variant="outline" className="justify-start gap-2 h-10 border-slate-200 text-slate-600">
                      <Users className="h-4 w-4" />
                      Custom...
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Template Selection</label>
                  <div className="space-y-2">
                    {[
                      { name: 'Trial Expiry Warning', icon: Mail },
                      { name: 'Feature Announcement', icon: Megaphone },
                      { name: 'Onboarding Step 2', icon: Mail },
                    ].map((tpl) => (
                      <button 
                        key={tpl.name}
                        className="w-full flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:border-[#2563eb] hover:bg-blue-50/50 transition-all text-left group"
                      >
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded bg-slate-100 flex items-center justify-center text-slate-500 group-hover:bg-[#2563eb] group-hover:text-white transition-colors">
                            <tpl.icon className="h-4 w-4" />
                          </div>
                          <span className="text-sm font-medium text-slate-700">{tpl.name}</span>
                        </div>
                        <Plus className="h-4 w-4 text-slate-300 group-hover:text-[#2563eb]" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <Button className="w-full bg-[#2563eb] hover:bg-blue-600 text-white shadow-md">
                Launch Sequence
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2">
          <Card className="border-slate-200 shadow-sm overflow-hidden h-full">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Campaign Performance</CardTitle>
              <Button variant="ghost" size="sm" className="text-slate-500">View All</Button>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader className="bg-slate-50/50">
                  <TableRow>
                    <TableHead className="pl-6">Campaign</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Audience</TableHead>
                    <TableHead>Metrics</TableHead>
                    <TableHead className="text-right pr-6">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-slate-500">
                        Loading campaigns...
                      </TableCell>
                    </TableRow>
                  ) : campaigns.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center py-8 text-slate-500">
                        No campaigns found.
                      </TableCell>
                    </TableRow>
                  ) : campaigns.map((camp) => (
                    <TableRow key={camp.id} className="hover:bg-slate-50/50 transition-colors group">
                      <TableCell className="pl-6">
                        <div className="flex flex-col">
                          <span className="text-sm font-semibold text-slate-900">{camp.name}</span>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider">{camp.trigger_type}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={cn(
                            "font-medium capitalize",
                            camp.status === 'completed' ? "bg-emerald-50 text-emerald-700 border-emerald-100" :
                            camp.status === 'sending' ? "bg-blue-50 text-blue-700 border-blue-100 animate-pulse" :
                            "bg-slate-50 text-slate-700 border-slate-100"
                          )}
                        >
                          {camp.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="text-xs font-medium text-slate-700">{camp.target_audience}</span>
                          <span className="text-[10px] text-slate-400 capitalize">{camp.trigger_type}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-4">
                          <div className="flex flex-col">
                            <span className="text-xs text-slate-400">Sent</span>
                            <span className="text-sm font-semibold text-slate-700">{camp.stats?.sent || 0}</span>
                          </div>
                          <div className="flex flex-col border-l border-slate-200 pl-4">
                            <span className="text-xs text-slate-400">Opens</span>
                            <span className="text-sm font-semibold text-slate-700">{camp.stats?.opens || 0}</span>
                          </div>
                          <div className="flex flex-col border-l border-slate-200 pl-4">
                            <span className="text-xs text-slate-400">Clicks</span>
                            <span className="text-sm font-semibold text-slate-700">{camp.stats?.clicks || 0}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-right pr-6">
                        <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-slate-400 hover:text-[#2563eb]"
                            onClick={() => handleEdit(camp)}
                          >
                            <BarChart3 className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-slate-900">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </div>

      <SystemCampaignDialog 
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        campaign={selectedCampaign}
        onSuccess={fetchCampaigns}
      />
    </div>
  );
};
