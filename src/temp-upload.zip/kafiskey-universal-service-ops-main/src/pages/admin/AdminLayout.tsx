import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Building2, 
  Users, 
  CreditCard, 
  Megaphone, 
  Settings, 
  Activity,
  LogOut,
  Search,
  Bell,
  ShieldCheck
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { BrandLogo } from '@/components/BrandLogo';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';

const navItems = [
  { label: 'Command Center', icon: LayoutDashboard, href: '/admin' },
  { label: 'Organizations', icon: Building2, href: '/admin/organizations' },
  { label: 'Leads', icon: Users, href: '/admin/leads' },
  { label: 'Subscriptions', icon: CreditCard, href: '/admin/subscriptions' },
  { label: 'Campaigns', icon: Megaphone, href: '/admin/campaigns' },
  { label: 'System Settings', icon: Settings, href: '/admin/settings' },
];

export const AdminLayout: React.FC = () => {
  const location = useLocation();
  const { impersonatedWorkspaceId, setImpersonatedWorkspaceId } = useAuth();
  const { activeWorkspace } = useWorkspace();

  return (
    <div className="flex h-screen bg-[#f8fafc] flex-col">
      {impersonatedWorkspaceId && (
        <div className="bg-[#0f172a] text-white px-6 py-2 flex items-center justify-between text-sm font-medium z-50 shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-[#2563eb]" />
            <span>
              Viewing workspace: <span className="text-[#2563eb] font-bold">{activeWorkspace?.name}</span> (Impersonation Mode)
            </span>
          </div>
          <Button 
            size="sm" 
            className="h-7 bg-[#2563eb] hover:bg-blue-600 text-white border-0"
            onClick={() => {
              setImpersonatedWorkspaceId(null);
            }}
          >
            Stop Impersonating
          </Button>
        </div>
      )}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-[#0f172a] text-slate-300 flex flex-col shrink-0 border-r border-slate-800">
          <div className="h-16 flex items-center px-6 border-b border-slate-800/50">
            <Link to="/admin" className="flex items-center gap-2">
              <BrandLogo className="h-8 w-8 brightness-0 invert" />
              <span className="font-bold text-white text-lg tracking-tight">Kafiskey <span className="text-[#2563eb]">HQ</span></span>
            </Link>
          </div>

          <nav className="flex-1 overflow-y-auto p-4 space-y-1">
            <div className="px-2 mb-4">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-500">Main Menu</p>
            </div>
            {navItems.map((item) => {
              const isActive = location.pathname === item.href || (item.href !== '/admin' && location.pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  to={item.href}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    isActive 
                      ? "bg-[#2563eb] text-white" 
                      : "hover:bg-slate-800 hover:text-white"
                  )}
                >
                  <item.icon className={cn("h-4 w-4", isActive ? "text-white" : "text-slate-400")} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="p-4 border-t border-slate-800/50">
            <Button 
              variant="ghost" 
              className="w-full justify-start gap-3 text-slate-400 hover:text-white hover:bg-slate-800"
              onClick={() => window.location.href = '/logout'}
            >
              <LogOut className="h-4 w-4" />
              Exit Admin
            </Button>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header */}
          <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10">
            <div className="flex items-center gap-4 flex-1 max-w-xl">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input 
                  placeholder="Search organizations, users, or invoices..." 
                  className="pl-10 bg-slate-50 border-slate-200 focus-visible:ring-[#2563eb]"
                />
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-medium border border-emerald-100">
                <Activity className="h-3 w-3" />
                Systems Operational
              </div>
              <Button variant="ghost" size="icon" className="text-slate-500 relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-2 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-white" />
              </Button>
              <div className="h-8 w-8 rounded-full bg-[#0f172a] flex items-center justify-center text-white text-xs font-bold ring-2 ring-slate-100">
                HQ
              </div>
            </div>
          </header>

          {/* Page Content */}
          <main className="flex-1 overflow-y-auto p-8">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
};