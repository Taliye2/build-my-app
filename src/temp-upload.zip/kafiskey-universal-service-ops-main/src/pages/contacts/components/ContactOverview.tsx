import React from 'react';
import { format, parseISO } from 'date-fns';
import { User, Calendar, ShieldCheck, Mail, Phone, MapPin, Globe, UserPlus, Building2, Fingerprint, Link2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Link } from 'react-router-dom';

interface ContactOverviewProps {
  contact: any;
}

export const ContactOverview: React.FC<ContactOverviewProps> = ({ contact }) => {
  const InfoItem = ({ icon: Icon, label, value, subValue, isLink, to }: any) => (
    <div className="flex items-start gap-3">
      <div className="mt-1 p-1.5 bg-primary/5 dark:bg-primary/10 rounded border border-primary/10">
        <Icon className="h-3.5 w-3.5 text-primary" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight mb-0.5">{label}</p>
        {isLink && to && value ? (
          <Link to={to} className="text-sm font-semibold text-primary hover:underline truncate block">
            {value}
          </Link>
        ) : (
          <p className="text-sm font-semibold truncate">{value || <span className="text-muted-foreground font-normal italic text-[10px]">Not Provided</span>}</p>
        )}
        {subValue && <p className="text-xs text-muted-foreground">{subValue}</p>}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <Card className="border-primary/10 shadow-sm">
        <CardHeader className="pb-3 border-b bg-muted/30">
          <CardTitle className="text-sm font-bold uppercase tracking-wider text-foreground">Contact Overview</CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="space-y-5">
            <InfoItem icon={User} label="Legal Name" value={`${contact.first_name} ${contact.last_name}`} />
            <InfoItem icon={Calendar} label="Date of Birth" value={contact.dob ? format(parseISO(contact.dob), 'MMMM d, yyyy') : null} />
            <InfoItem icon={Link2} label="Relationship" value={contact.relationship} />
            <InfoItem icon={Building2} label="Organization" value={contact.organization} />
            {contact.client && (
              <InfoItem 
                icon={UserPlus} 
                label="Associated Client" 
                value={`${contact.client.first_name} ${contact.client.last_name}`}
                isLink
                to={`/clients/${contact.client_id}`}
              />
            )}
            <InfoItem icon={Fingerprint} label="Contact ID" value={contact.id.slice(0, 12).toUpperCase()} />
          </div>
          
          <Separator />
          
          <div className="space-y-5">
            <InfoItem icon={Mail} label="Email Contact" value={contact.email || 'N/A'} />
            <InfoItem icon={Phone} label="Primary Phone" value={contact.phone || 'N/A'} />
            <InfoItem icon={MapPin} label="Residential Address" value={contact.address || 'N/A'} />
          </div>

          <Separator />

          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <InfoItem icon={Globe} label="Language" value={contact.language || 'English'} />
              <InfoItem icon={ShieldCheck} label="Contact Method" value={contact.preferred_contact_method || 'Email'} />
            </div>
          </div>
        </CardContent>
      </Card>

      {(contact.emergency_contact_name || contact.emergency_contact_phone) && (
        <Card className="border-destructive/10">
          <CardHeader className="pb-3 border-b bg-destructive/5 dark:bg-destructive/10">
            <CardTitle className="text-sm font-bold uppercase tracking-wider text-destructive flex items-center gap-2">
              <ShieldCheck className="h-4 w-4" />
              Emergency Contact
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div>
              <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight">Full Name</p>
              <p className="text-sm font-semibold">{contact.emergency_contact_name || '—'}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight">Contact Phone</p>
              <p className="text-sm font-semibold">{contact.emergency_contact_phone || '—'}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
