import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Contact2, 
  Mail, 
  Phone, 
  Edit, 
  MoreHorizontal,
  ArrowLeft,
  Plus
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ContactHeaderProps {
  contact: any;
  onEditProfile: () => void;
  onAddDocument: () => void;
  onStatusChange: (active: boolean) => void;
  onDelete: () => void;
}

export const ContactHeader: React.FC<ContactHeaderProps> = ({ 
  contact, 
  onEditProfile,
  onAddDocument,
  onStatusChange,
  onDelete 
}) => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/contacts')}
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Contacts
        </Button>
      </div>

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex items-start gap-6">
          <div className="h-24 w-24 rounded-2xl bg-primary/10 flex items-center justify-center text-primary border-4 border-background shadow-sm">
            <Contact2 className="h-12 w-12" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold tracking-tight">
                {contact.first_name} {contact.last_name}
              </h1>
              <Badge variant={contact.active !== false ? 'success' : 'secondary'} className="h-6">
                {contact.active !== false ? 'Active' : 'Inactive'}
              </Badge>
            </div>
            <p className="text-lg text-muted-foreground font-medium">Contact ID: {contact.id?.slice(0, 12)}...</p>
            <div className="flex flex-wrap gap-4 pt-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Mail className="h-4 w-4" />
                {contact.email || 'No email provided'}
              </div>
              <div className="flex items-center gap-1.5">
                <Phone className="h-4 w-4" />
                {contact.phone || 'No phone provided'}
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button variant="outline" onClick={onEditProfile} className="gap-2">
            <Edit className="h-4 w-4" />
            Edit Profile
          </Button>
          <Button className="gap-2" onClick={onAddDocument}>
            <Plus className="h-4 w-4" />
            Add Document
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onStatusChange(contact.active === false)}>
                {contact.active !== false ? 'Deactivate Contact' : 'Activate Contact'}
              </DropdownMenuItem>
              <DropdownMenuItem className="text-destructive" onClick={onDelete}>
                Delete Contact
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
};
