import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { ContactHeader } from './components/ContactHeader';
import { ContactOverview } from './components/ContactOverview';
import { EditContactDialog } from './components/EditContactDialog';
import { NotesTab } from '../clients/components/NotesTab';
import { DocumentsTab } from '../clients/components/DocumentsTab';
import { TimelineTab } from '../clients/components/TimelineTab';
import { User, FileText, MessageSquare, History } from 'lucide-react';
import { Spinner } from '@/components/ui/spinner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { logAudit } from '@/lib/audit';
import { useAuth } from '@/contexts/AuthContext';

export const ContactProfilePage: React.FC = () => {
  const { contactId } = useParams<{ contactId: string }>();
  const { activeWorkspace } = useWorkspace();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [contact, setContact] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Modal states
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [isAddDocOpen, setIsAddDocOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchContact();
    if (contactId && activeWorkspace && user) {
      logAudit(activeWorkspace.id, user.id, 'VIEW', 'contact', contactId);
    }
  }, [contactId, activeWorkspace, user]);

  const fetchContact = async () => {
    if (!contactId || !activeWorkspace) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('contacts')
        .select(`
          *,
          client:client_id (
            id,
            first_name,
            last_name,
            status,
            dob,
            phone
          )
        `)
        .eq('id', contactId)
        .eq('workspace_id', activeWorkspace.id)
        .single();

      if (error) throw error;
      setContact(data);
    } catch (error: any) {
      toast.error('Error fetching contact details: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (active: boolean) => {
    if (!activeWorkspace || !contactId || !contact) return;

    try {
      const { error } = await supabase
        .from('contacts')
        .update({ active })
        .eq('id', contactId);

      if (error) throw error;

      setContact({ ...contact, active });
      toast.success(`Contact ${active ? 'activated' : 'deactivated'} successfully`);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleDelete = async () => {
    if (!contactId || !activeWorkspace) return;
    if (!confirm('Are you sure you want to delete this contact?')) return;

    try {
      const { error } = await supabase
        .from('contacts')
        .delete()
        .eq('id', contactId);

      if (error) throw error;

      toast.success('Contact deleted successfully');
      navigate('/contacts');
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  if (loading) {
    return (
      <div className="flex h-[400px] items-center justify-center">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    );
  }

  if (!contact) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-muted-foreground">Contact profile not found</h2>
      </div>
    );
  }

  return (
    <div className="max-w-[1600px] mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <ContactHeader 
        contact={contact}
        onEditProfile={() => setIsEditModalOpen(true)}
        onAddDocument={() => {
          setActiveTab('documents');
          setIsAddDocOpen(true);
        }}
        onStatusChange={handleStatusChange}
        onDelete={handleDelete}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Contact Overview */}
        <aside className="lg:col-span-4 xl:col-span-3 space-y-6 lg:sticky lg:top-8">
          <ContactOverview contact={contact} />
        </aside>

        {/* Right Column: Main Content Tabs */}
        <main className="lg:col-span-8 xl:col-span-9">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent space-x-8 mb-6 overflow-x-auto scrollbar-hide">
              <TabsTrigger 
                value="overview" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-semibold"
              >
                <User className="h-4 w-4" />
                Associated Client
              </TabsTrigger>
              <TabsTrigger 
                value="notes" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-semibold"
              >
                <MessageSquare className="h-4 w-4" />
                Contact Notes
              </TabsTrigger>
              <TabsTrigger 
                value="documents" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-semibold"
              >
                <FileText className="h-4 w-4" />
                Documentation
              </TabsTrigger>
              <TabsTrigger 
                value="timeline" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-semibold"
              >
                <History className="h-4 w-4" />
                History
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              {contact.client ? (
                <Card className="border-primary/10">
                  <CardHeader className="bg-muted/30 pb-4">
                    <CardTitle className="text-lg font-bold">Primary Client Connection</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between p-4 rounded-xl border border-primary/10 hover:bg-muted/30 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                          <User className="h-6 w-6" />
                        </div>
                        <div>
                          <p className="font-bold text-lg">{contact.client.first_name} {contact.client.last_name}</p>
                          <p className="text-sm text-muted-foreground">Status: {contact.client.status}</p>
                        </div>
                      </div>
                      <Link to={`/clients/${contact.client.id}`}>
                        <Button variant="outline" size="sm">View Client Profile</Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="p-12 border-2 border-dashed rounded-xl text-center">
                  <User className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-bold">No client connection</h3>
                  <p className="text-muted-foreground max-w-sm mx-auto">
                    This contact is currently not linked to any specific client.
                  </p>
                  <Button variant="outline" className="mt-6" onClick={() => setIsEditModalOpen(true)}>Link a Client</Button>
                </div>
              )}
            </TabsContent>

            <TabsContent value="notes" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <NotesTab 
                entityId={contact.id} 
                entityType="contact"
                isAddNoteOpen={isAddNoteOpen}
                onAddNoteClose={() => setIsAddNoteOpen(false)}
                onAddNoteOpen={() => setIsAddNoteOpen(true)}
                onNoteAdded={() => {}}
              />
            </TabsContent>

            <TabsContent value="documents" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <DocumentsTab 
                entityId={contact.id}
                entityType="contact"
                isAddDocOpen={isAddDocOpen}
                onAddDocClose={() => setIsAddDocOpen(false)}
                onDocAdded={() => {}}
              />
            </TabsContent>

            <TabsContent value="timeline" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <TimelineTab entityId={contact.id} entityType="contact" />
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <EditContactDialog 
        isOpen={isEditModalOpen}
        onOpenChange={setIsEditModalOpen}
        contact={contact}
        onSuccess={fetchContact}
      />
    </div>
  );
};
