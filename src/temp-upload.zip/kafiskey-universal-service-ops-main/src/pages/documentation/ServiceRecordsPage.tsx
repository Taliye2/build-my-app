import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { FileEdit, FileText, Printer, CheckCircle, FileX } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { ServiceEvent } from '../scheduling/SchedulingPage';
import { Empty } from '@/components/ui/empty';

export const ServiceRecordsPage: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [events, setEvents] = useState<ServiceEvent[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRecords = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    
    // We fetch events and their associated records
    const { data, error } = await supabase
      .from('service_events')
      .select('*, clients(*), service_templates(*), service_records(*)')
      .eq('workspace_id', activeWorkspace.id)
      .order('date', { ascending: false });

    if (error) {
      toast.error('Error fetching records');
    } else {
      setEvents(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchRecords();
  }, [activeWorkspace]);

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold tracking-tight">Service Records</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Documentation records confirm services delivered and support compliance, review, and billing.
          </p>
        </div>
      </div>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Record Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center">Loading documentation...</TableCell>
              </TableRow>
            ) : events.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-auto py-12">
                  <Empty 
                    icon={FileX}
                    title="No documentation required"
                    description="Documentation is generated automatically when services are completed."
                    action={
                      <Button asChild>
                        <Link to="/scheduling">View Schedule</Link>
                      </Button>
                    }
                  />
                </TableCell>
              </TableRow>
            ) : (
              events.map((event: any) => {
                const hasRecord = event.service_records && event.service_records.length > 0;
                const record = hasRecord ? event.service_records[0] : null;
                const isSigned = record?.signed_at != null;

                // Map database statuses to professional display statuses
                let statusBadge = <Badge variant="secondary">Missing Note</Badge>;
                if (hasRecord) {
                  if (isSigned) {
                    statusBadge = (
                      <Badge variant="success" className="gap-1">
                        <CheckCircle className="h-3 w-3" /> Approved
                      </Badge>
                    );
                  } else {
                    // We can use the event status to determine if it's submitted or draft
                    if (event.status === 'SUBMITTED') {
                      statusBadge = <Badge variant="warning">Submitted</Badge>;
                    } else if (event.status === 'REJECTED') {
                      statusBadge = <Badge variant="destructive">Returned</Badge>;
                    } else {
                      statusBadge = <Badge variant="secondary">Draft</Badge>;
                    }
                  }
                }

                return (
                  <TableRow key={event.id}>
                    <TableCell className="font-medium">
                      {new Date(event.date || event.occurs_at).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      {event.clients?.first_name} {event.clients?.last_name}
                    </TableCell>
                    <TableCell>{event.service_templates?.name}</TableCell>
                    <TableCell>
                      {statusBadge}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link to={`/documentation/edit/${event.id}`}>
                            {hasRecord ? <FileEdit className="mr-2 h-4 w-4" /> : <FileEdit className="mr-2 h-4 w-4" />}
                            {hasRecord ? 'Edit Note' : 'Create Note'}
                          </Link>
                        </Button>
                        {isSigned && (
                          <Button variant="ghost" size="icon">
                            <Printer className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
