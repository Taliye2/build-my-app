import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { blink } from '@/lib/blink';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { ChevronLeft, Save, PenTool, CheckCircle, User, Printer } from 'lucide-react';
import { toast } from 'sonner';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { logAudit } from '@/lib/audit';

export const ServiceRecordEditor: React.FC = () => {
  const { eventId } = useParams<{ eventId: string }>();
  const { activeWorkspace, activeMember } = useWorkspace();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [event, setEvent] = useState<any>(null);
  const [recordId, setRecordId] = useState<string | null>(null);
  const [provider, setProvider] = useState<any>(null);

  // Form state
  const [goals, setGoals] = useState('');
  const [interventions, setInterventions] = useState('');
  const [outcome, setOutcome] = useState('');
  const [nextSteps, setNextSteps] = useState('');
  const [freeText, setFreeText] = useState('');
  const [signature, setSignature] = useState('');
  const [isSigned, setIsSigned] = useState(false);
  const [timeIn, setTimeIn] = useState('');
  const [timeOut, setTimeOut] = useState('');

  const isManager = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN' || activeMember?.role === 'MANAGER';

  useEffect(() => {
    const fetchData = async () => {
      if (!eventId || !activeWorkspace) return;
      setLoading(true);

      const { data, error } = await supabase
        .from('service_events')
        .select(`
          *, 
          clients:client_id(*), 
          service_templates(*), 
          service_records(*),
          staff_user_id
        `)
        .eq('id', eventId)
        .eq('workspace_id', activeWorkspace.id)
        .single();

      if (error) {
        toast.error('Error fetching event details');
        navigate('/services');
      } else {
        setEvent(data);
        
        // Fetch provider separately since there is no FK
        if (data.staff_user_id) {
          const { data: staffData } = await supabase
            .from('staff_profiles')
            .select('*')
            .eq('user_id', data.staff_user_id)
            .eq('workspace_id', activeWorkspace.id)
            .single();
          if (staffData) setProvider(staffData);
        }

        if (data.service_records && data.service_records.length > 0) {
          const r = data.service_records[0];
          setRecordId(r.id);
          setGoals(r.goals || '');
          setInterventions(r.interventions || '');
          setOutcome(r.outcome || '');
          setNextSteps(r.next_steps || '');
          
          let consolidatedNotes = r.free_text || '';
          const legacyItems = [];
          if (r.goals) legacyItems.push(`Goals Addressed:\n${r.goals}`);
          if (r.interventions) legacyItems.push(`Interventions & Activities:\n${r.interventions}`);
          if (r.outcome) legacyItems.push(`Client Outcome / Response:\n${r.outcome}`);
          if (r.next_steps) legacyItems.push(`Next Steps / Recommendations:\n${r.next_steps}`);
          
          if (legacyItems.length > 0) {
            const legacyString = legacyItems.join('\n\n');
            // Basic heuristic to avoid duplication if user saves and re-opens
            // We check if the first legacy item is already present in the notes
            const firstItemHeader = legacyItems[0].split('\n')[0];
            if (!consolidatedNotes.includes(firstItemHeader)) {
              consolidatedNotes = consolidatedNotes 
                ? `${consolidatedNotes}\n\n${legacyString}` 
                : legacyString;
            }
          }
          
          setFreeText(consolidatedNotes);
          setSignature(r.staff_signature_name || '');
          setIsSigned(r.signed_at != null);
          if (r.time_in) setTimeIn(new Date(r.time_in).toISOString().slice(11, 16));
          if (r.time_out) setTimeOut(new Date(r.time_out).toISOString().slice(11, 16));
        }
      }
      setLoading(false);
    };

    fetchData();

    if (eventId && activeWorkspace) {
      supabase.auth.getUser().then(({ data: { user } }) => {
        if (user) {
          logAudit(activeWorkspace.id, user.id, 'VIEW', 'service_record', eventId);
        }
      });
    }
  }, [eventId, activeWorkspace]);

  const handleSave = async (sign: boolean = false) => {
    if (!eventId || !activeWorkspace) return;
    setSaving(true);

    try {
      const now = new Date();
      const dateStr = event.date; // yyyy-MM-dd
      
      const timeInDate = timeIn ? new Date(`${dateStr}T${timeIn}`) : null;
      const timeOutDate = timeOut ? new Date(`${dateStr}T${timeOut}`) : (sign ? now : null);

      let duration = 0;
      if (timeInDate && timeOutDate) {
        duration = Math.round((timeOutDate.getTime() - timeInDate.getTime()) / (1000 * 60));
      }

      const payload: any = {
        workspace_id: activeWorkspace.id,
        service_event_id: eventId,
        goals,
        interventions,
        outcome,
        next_steps: nextSteps,
        free_text: freeText,
        staff_signature_name: signature,
        time_in: timeInDate?.toISOString(),
        time_out: timeOutDate?.toISOString(),
        performed_duration_minutes: duration > 0 ? duration : null,
      };

      if (sign) {
        payload.signed_at = now.toISOString();
        payload.completed_at = now.toISOString();
        payload.record_status = 'Signed';
      } else {
        payload.record_status = 'In Progress';
      }

      let res;
      let finalRecordId = recordId;
      if (recordId) {
        res = await supabase.from('service_records').update(payload).eq('id', recordId);
      } else {
        res = await supabase.from('service_records').insert(payload).select().single();
        if (res.data) finalRecordId = res.data.id;
      }

      if (res.error) throw res.error;

      // Also update the service_event status to COMPLETED if signing
      if (sign) {
        const { error: eventError } = await supabase
          .from('service_events')
          .update({ 
            status: 'COMPLETED', 
            submitted_at: now.toISOString() 
          })
          .eq('id', eventId);
        
        if (eventError) throw eventError;

        // Generate Billing Item
        await generateBillingItem(finalRecordId!);

        // Audit Log
        if (user && activeWorkspace) {
          await logAudit(
            activeWorkspace.id,
            user.id,
            'service_record_signed',
            'service_record',
            finalRecordId!,
            { client_id: event.client_id, service_template_id: event.service_template_id }
          );
        }
      } else {
        // Audit Log for saving draft
        if (user && activeWorkspace) {
          await logAudit(
            activeWorkspace.id,
            user.id,
            'service_record_draft_saved',
            'service_record',
            finalRecordId!,
            { client_id: event.client_id }
          );
        }
      }

      toast.success(sign ? 'Record signed and submitted!' : 'Progress saved');
      if (sign) navigate('/services');
      else {
        setRecordId(finalRecordId);
      }
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };

  const generateBillingItem = async (recordId: string) => {
    try {
      // 1. Fetch record and template
      const { data: record } = await supabase
        .from('service_records')
        .select(`
          *,
          service_events(
            client_id,
            staff_user_id,
            service_template_id,
            date
          )
        `)
        .eq('id', recordId)
        .single();
      
      if (!record) return;

      const eventData = record.service_events;
      const templateId = eventData.service_template_id;

      // 2. Fetch active pricing and provider profile
      const [pricingRes, providerRes] = await Promise.all([
        supabase
          .from('service_pricing')
          .select('*')
          .eq('service_template_id', templateId)
          .eq('is_active', true)
          .maybeSingle(),
        eventData.staff_user_id ? 
          supabase
            .from('staff_profiles')
            .select('id')
            .eq('user_id', eventData.staff_user_id)
            .eq('workspace_id', activeWorkspace?.id)
            .maybeSingle() : 
          Promise.resolve({ data: null })
      ]);
      
      const pricing = pricingRes.data;
      const providerProfile = providerRes.data;

      let rate = 0;
      let qty = 1;
      let total = 0;
      let missingRate = false;

      if (!pricing) {
        missingRate = true;
      } else {
        rate = pricing.rate_amount;
        if (pricing.pricing_model === 'hourly') {
          qty = (record.performed_duration_minutes || 0) / 60;
          total = qty * rate;
        } else if (pricing.pricing_model === 'flat') {
          qty = 1;
          total = rate;
        } else if (pricing.pricing_model === 'unit') {
          // Units should probably come from somewhere, maybe units field in event?
          qty = eventData.units || 1;
          total = qty * rate;
        }
      }

      // 3. Create billing item
      const { error: billingError } = await supabase
        .from('billing_items')
        .upsert({
          workspace_id: activeWorkspace?.id,
          client_id: eventData.client_id,
          service_record_id: recordId,
          service_template_id: templateId,
          provider_id: providerProfile?.id || null,
          service_date: eventData.date,
          quantity: qty,
          rate_amount: rate,
          line_total: total,
          billing_status: 'Unbilled',
          missing_rate: missingRate,
          created_by: user?.id
        }, { onConflict: 'service_record_id' });
      
      if (billingError) throw billingError;
    } catch (err: any) {
      console.error('Error generating billing item:', err);
      toast.error('Failed to generate billing item: ' + err.message);
    }
  };

  const handleApprove = async () => {
    if (!eventId || !activeWorkspace) return;
    setSaving(true);
    try {
      const { data, error } = await blink.functions.invoke('update-service-event-status', {
        body: {
          eventId,
          workspaceId: activeWorkspace.id,
          newStatus: 'APPROVED'
        }
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success('Record approved');
      navigate('/services');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleReject = async () => {
    if (!eventId || !activeWorkspace) return;
    const reason = window.prompt('Reason for rejection:');
    if (reason === null) return;

    setSaving(true);
    try {
      const { data, error } = await blink.functions.invoke('update-service-event-status', {
        body: {
          eventId,
          workspaceId: activeWorkspace.id,
          newStatus: 'REJECTED',
          rejectionReason: reason
        }
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success('Record rejected');
      navigate('/services');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };

  const handlePrint = () => {
    if (user && activeWorkspace && eventId) {
      logAudit(activeWorkspace.id, user.id, 'DOWNLOAD', 'service_record', eventId, { method: 'print' });
    }
    window.print();
  };

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto pb-12">
      <div className="flex items-center gap-4 print:hidden">
        <Button variant="ghost" size="icon" asChild>
          <Link to="/services">
            <ChevronLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold tracking-tight">
              Service Note: {event.clients?.first_name} {event.clients?.last_name}
            </h2>
            <Badge variant="outline">{event.service_templates?.name}</Badge>
            <Badge variant="secondary">{event.status}</Badge>
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
            <p>{new Date(event.date).toLocaleDateString()}</p>
            {provider && (
              <div className="flex items-center gap-1">
                <User className="h-3 w-3" />
                <span>Provider: {provider.full_name || provider.email}</span>
              </div>
            )}
          </div>
        </div>
        <Button variant="outline" onClick={handlePrint}>
          <Printer className="mr-2 h-4 w-4" />
          Print Record
        </Button>
      </div>

      {/* Print Header (Only visible when printing) */}
      <div className="hidden print:block space-y-4 border-b pb-6 mb-8">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-primary">{activeWorkspace?.name}</h1>
            <p className="text-sm text-muted-foreground uppercase tracking-widest mt-1">Service Documentation Record</p>
          </div>
          <div className="text-right">
            <p className="font-bold">Date: {new Date(event.date).toLocaleDateString()}</p>
            <p className="text-xs text-muted-foreground">Record ID: {recordId || 'Draft'}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-8 pt-4">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase font-bold">Client</p>
            <p className="text-lg font-medium">{event.clients?.first_name} {event.clients?.last_name}</p>
            <p className="text-sm text-muted-foreground">DOB: {event.clients?.dob ? new Date(event.clients.dob).toLocaleDateString() : 'N/A'}</p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase font-bold">Provider</p>
            <p className="text-lg font-medium">{provider?.full_name || provider?.email}</p>
            <p className="text-sm text-muted-foreground">Service: {event.service_templates?.name}</p>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Structured Documentation</CardTitle>
          <CardDescription>Document the narrative and details of this session.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4 print:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="timeIn">Time In</Label>
              <Input
                id="timeIn"
                type="time"
                value={timeIn}
                onChange={(e) => setTimeIn(e.target.value)}
                disabled={isSigned}
                className="print:border-none print:p-0 print:h-auto"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="timeOut">Time Out</Label>
              <Input
                id="timeOut"
                type="time"
                value={timeOut}
                onChange={(e) => setTimeOut(e.target.value)}
                disabled={isSigned}
                className="print:border-none print:p-0 print:h-auto"
              />
            </div>
          </div>
          <Separator />
          <div className="space-y-2">
            <Label htmlFor="freeText">Session Notes</Label>
            <Textarea
              id="freeText"
              placeholder="Include goals addressed, interventions/activities, client response/outcome, and next steps/recommendations. Add any other relevant details..."
              className="min-h-[250px] print:min-h-0 print:border-none print:p-0"
              value={freeText}
              onChange={(e) => setFreeText(e.target.value)}
              disabled={isSigned}
              spellCheck={true}
              autoCorrect="on"
              autoCapitalize="sentences"
            />
          </div>
        </CardContent>
      </Card>

      <Card className={isSigned ? "bg-muted/50" : ""}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PenTool className="h-5 w-5" />
            Attestation & Signature
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            By signing this record, I certify that the information provided above is accurate and reflects the service performed on {new Date(event.date).toLocaleDateString()}.
          </p>
          <div className="space-y-2 max-w-sm">
            <Label htmlFor="signature">Full Name (Type to Sign)</Label>
            <Input
              id="signature"
              placeholder="Your full legal name"
              value={signature}
              onChange={(e) => setSignature(e.target.value)}
              disabled={isSigned}
              className="font-serif italic"
            />
          </div>
          {isSigned && (
            <div className="flex items-center gap-2 text-success font-medium">
              <CheckCircle className="h-4 w-4" />
              Digitally signed on {new Date(event.service_records[0].signed_at).toLocaleString()}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between border-t p-6 print:hidden">
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => handleSave(false)} disabled={saving || isSigned || event?.status === 'APPROVED'}>
              <Save className="mr-2 h-4 w-4" />
              Save Draft
            </Button>
            {event?.status === 'SUBMITTED' && isManager && (
              <>
                <Button variant="outline" className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200" onClick={handleApprove} disabled={saving}>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Approve Record
                </Button>
                <Button variant="outline" className="bg-rose-50 text-rose-700 hover:bg-rose-100 border-rose-200" onClick={handleReject} disabled={saving}>
                  Reject & Return
                </Button>
              </>
            )}
          </div>
          {!isSigned && event?.status !== 'APPROVED' && (
            <Button onClick={() => handleSave(true)} disabled={saving || !signature}>
              Finalize & Sign
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};