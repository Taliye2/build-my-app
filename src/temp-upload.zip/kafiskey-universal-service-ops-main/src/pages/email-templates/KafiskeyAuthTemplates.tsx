/**
 * Kafiskey Signup Confirmation Email Template
 * 
 * Use this HTML content in your Supabase Dashboard:
 * Authentication > Email Templates > Confirm Signup
 * 
 * Subject: Confirm your Kafiskey account
 */

export const SignupConfirmationHtml = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Confirm your Kafiskey account</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f8fafc; color: #1e293b;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" style="min-width: 100%; background-color: #f8fafc; padding: 40px 0;">
    <tr>
      <td align="center">
        <table width="600" border="0" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);">
          <!-- Header -->
          <tr>
            <td align="center" style="padding: 40px 40px 20px 40px;">
              <div style="font-size: 28px; font-weight: 800; color: #0d9488; letter-spacing: -0.025em;">
                Kafiskey
              </div>
              <div style="font-size: 14px; font-weight: 500; color: #64748b; margin-top: 4px;">
                Universal Service Operations
              </div>
            </td>
          </tr>
          
          <!-- Body -->
          <tr>
            <td style="padding: 20px 40px 40px 40px;">
              <h1 style="font-size: 24px; font-weight: 700; color: #0f172a; margin: 0 0 16px 0; text-align: center;">
                Welcome to Kafiskey!
              </h1>
              <p style="font-size: 16px; line-height: 24px; color: #475569; margin: 0 0 24px 0; text-align: center;">
                You're almost ready to start using Kafiskey. Please confirm your email address to activate your account and access your workspace.
              </p>
              
              <!-- CTA Button -->
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="center" style="padding: 20px 0;">
                    <a href="{{ .ConfirmationURL }}" style="display: inline-block; background-color: #0d9488; color: #ffffff; font-size: 16px; font-weight: 700; text-decoration: none; padding: 14px 32px; border-radius: 8px; box-shadow: 0 4px 6px -1px rgba(13, 148, 136, 0.2);">
                      Confirm your email
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="font-size: 14px; line-height: 20px; color: #64748b; margin: 24px 0 0 0; text-align: center;">
                If the button above doesn't work, copy and paste this link into your browser:
              </p>
              <p style="font-size: 12px; line-height: 18px; color: #0d9488; margin: 8px 0 0 0; text-align: center; word-break: break-all;">
                {{ .ConfirmationURL }}
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f1f5f9; padding: 32px 40px; border-top: 1px solid #e2e8f0;">
              <p style="font-size: 12px; line-height: 18px; color: #64748b; margin: 0 0 12px 0; text-align: center;">
                If you didn't create a Kafiskey account, you can safely ignore this email.
              </p>
              <p style="font-size: 12px; font-weight: 600; color: #94a3b8; margin: 0; text-align: center;">
                &copy; ${new Date().getFullYear()} Kafiskey Universal Service Ops. All rights reserved.
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;
