import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Mail, Edit2, Trash2, Copy, Search, Filter, Send } from 'lucide-react';
import { toast } from 'sonner';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SendEmailTemplateDialog } from './components/SendEmailTemplateDialog';
import { AuthTemplatesCard } from './components/AuthTemplatesCard';

export interface EmailTemplate {
  id: string;
  workspace_id: string;
  name: string;
  category: string;
  subject: string;
  body: string;
  created_at: string;
}

export const EmailTemplatesPage: React.FC = () => {
  const { user } = useAuth();
  const { activeWorkspace, activeMember } = useWorkspace();
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSendDialogOpen, setIsSendDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate | null>(null);
  const [emailActivity, setEmailActivity] = useState<any[]>([]);
  const [activityLoading, setActivityLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Other',
    subject: '',
    body: ''
  });

  const fetchTemplates = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('email_templates')
      .select('*')
      .eq('workspace_id', activeWorkspace.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Failed to fetch templates');
    } else {
      setTemplates(data || []);
    }
    setLoading(false);
  };

  const fetchActivity = async () => {
    if (!activeWorkspace) return;
    setActivityLoading(true);
    const { data, error } = await supabase
      .from('emails_sent')
      .select('*')
      .eq('workspace_id', activeWorkspace.id)
      .order('sent_at', { ascending: false, nullsFirst: false })
      .limit(10);

    if (error) {
      console.error('Error fetching activity:', error);
    } else {
      setEmailActivity(data || []);
    }
    setActivityLoading(false);
  };

  useEffect(() => {
    fetchTemplates();
    fetchActivity();
  }, [activeWorkspace]);

  const handleOpenDialog = (template?: EmailTemplate) => {
    if (template) {
      setSelectedTemplate(template);
      setFormData({
        name: template.name,
        category: template.category,
        subject: template.subject,
        body: template.body
      });
    } else {
      setSelectedTemplate(null);
      setFormData({
        name: '',
        category: 'Other',
        subject: '',
        body: ''
      });
    }
    setIsDialogOpen(true);
  };

  const handleOpenSendDialog = (template: EmailTemplate) => {
    setSelectedTemplate(template);
    setIsSendDialogOpen(true);
  };

  const handleSave = async () => {
    if (!activeWorkspace) return;
    if (!formData.name || !formData.subject || !formData.body) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      if (selectedTemplate) {
        const { error } = await supabase
          .from('email_templates')
          .update({
            name: formData.name,
            category: formData.category,
            subject: formData.subject,
            body: formData.body,
            updated_at: new Date().toISOString()
          })
          .eq('id', selectedTemplate.id);
        if (error) throw error;
        toast.success('Template updated');
      } else {
        const { error } = await supabase
          .from('email_templates')
          .insert({
            workspace_id: activeWorkspace.id,
            name: formData.name,
            category: formData.category,
            subject: formData.subject,
            body: formData.body
          });
        if (error) throw error;
        toast.success('Template created');
      }
      setIsDialogOpen(false);
      fetchTemplates();
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;
    const { error } = await supabase
      .from('email_templates')
      .delete()
      .eq('id', id);

    if (error) {
      toast.error('Failed to delete template');
    } else {
      toast.success('Template deleted');
      fetchTemplates();
    }
  };

  const handleDuplicate = async (template: EmailTemplate) => {
    if (!activeWorkspace) return;
    const { error } = await supabase
      .from('email_templates')
      .insert({
        workspace_id: activeWorkspace.id,
        name: `${template.name} (Copy)`,
        category: template.category,
        subject: template.subject,
        body: template.body
      });

    if (error) {
      toast.error('Failed to duplicate template');
    } else {
      toast.success('Template duplicated');
      fetchTemplates();
    }
  };

  const filteredTemplates = templates.filter(t => 
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const isPrivileged = ['OWNER', 'ADMIN', 'MANAGER'].includes(activeMember?.role || '');
  const isPlatformAdmin = user?.app_metadata?.is_super_admin || user?.user_metadata?.is_super_admin || import.meta.env.DEV;

  const insertVariable = (variable: string) => {
    setFormData(prev => ({
      ...prev,
      body: prev.body + `{{${variable}}}`
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Email Templates</h2>
          <p className="text-sm text-muted-foreground">
            Manage your workspace email templates for quick and consistent communication.
          </p>
        </div>
        {isPrivileged && (
          <Button onClick={() => handleOpenDialog()}>
            <Plus className="h-4 w-4 mr-2" />
            New Template
          </Button>
        )}
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {isPlatformAdmin && <AuthTemplatesCard />}

      <div className="space-y-6">
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">Loading templates...</TableCell>
                  </TableRow>
                ) : filteredTemplates.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Mail className="h-8 w-8 opacity-20" />
                        <p>No templates found</p>
                        {isPrivileged && (
                          <Button variant="link" onClick={() => handleOpenDialog()}>Create your first template</Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTemplates.map((template) => (
                    <TableRow key={template.id}>
                      <TableCell className="font-medium">{template.name}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="capitalize">
                          {template.category}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{template.subject}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {new Date(template.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {['OWNER', 'ADMIN'].includes(activeMember?.role || '') && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              onClick={() => handleOpenSendDialog(template)}
                              title="Send Template"
                              className="text-primary hover:text-primary hover:bg-primary/10"
                            >
                              <Send className="h-4 w-4" />
                            </Button>
                          )}
                          {isPrivileged && (
                            <>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleDuplicate(template)}
                                title="Duplicate"
                              >
                                <Copy className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleOpenDialog(template)}
                                title="Edit"
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="text-destructive hover:text-destructive hover:bg-destructive/10"
                                onClick={() => handleDelete(template.id)}
                                title="Delete"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="pt-6 border-t">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold tracking-tight flex items-center gap-2">
                <Mail className="h-5 w-5 text-muted-foreground" />
                Recent Email Activity
              </h3>
              <Button variant="ghost" size="sm" onClick={fetchActivity}>Refresh</Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Recipient</TableHead>
                      <TableHead>Template</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Sent At</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activityLoading ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8">Loading activity...</TableCell>
                      </TableRow>
                    ) : emailActivity.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground italic">
                          No recent email activity
                        </TableCell>
                      </TableRow>
                    ) : (
                      emailActivity.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell className="text-sm font-medium">{log.recipient}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {log.template_name || 'Direct Email'}
                          </TableCell>
                          <TableCell className="text-xs truncate max-w-[200px]">{log.subject}</TableCell>
                          <TableCell>
                            <Badge 
                              variant={log.status === 'sent' ? 'success' : 'secondary'}
                              className="text-[10px] px-1.5 py-0"
                            >
                              {log.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">
                            {log.sent_at ? new Date(log.sent_at).toLocaleString() : 'Pending'}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedTemplate ? 'Edit Template' : 'New Template'}</DialogTitle>
            <DialogDescription>
              Create or edit an email template. Use placeholders to personalize your messages.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Template Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Welcome Email"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(v) => setFormData({ ...formData, category: v })}
                >
                  <SelectTrigger id="category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Onboarding">Onboarding</SelectItem>
                    <SelectItem value="Billing">Billing</SelectItem>
                    <SelectItem value="Compliance">Compliance</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="subject">Subject Line</Label>
              <Input
                id="subject"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                placeholder="Enter email subject"
              />
            </div>

            <div className="space-y-2">
              <div className="flex flex-col gap-1.5 mb-2">
                <Label htmlFor="body">Email Body</Label>
                <p className="text-[11px] text-muted-foreground">
                  You can personalize emails using placeholders like recipient name or action links.
                </p>
              </div>
              <div className="flex items-center gap-1 mb-2">
                <span className="text-[10px] text-muted-foreground mr-1 font-medium uppercase tracking-wider">Available Placeholders:</span>
                {['workspace_name', 'user_name', 'client_name', 'action_link'].map(v => (
                  <Button 
                    key={v} 
                    type="button"
                    variant="outline" 
                    size="sm" 
                    className="h-6 text-[10px] px-2 font-mono"
                    onClick={() => insertVariable(v)}
                  >
                    {`{{${v}}}`}
                  </Button>
                ))}
              </div>
              <Textarea
                id="body"
                value={formData.body}
                onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                placeholder="Write your email content here..."
                className="min-h-[200px] font-sans"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave}>Save Template</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SendEmailTemplateDialog
        open={isSendDialogOpen}
        onOpenChange={(open) => {
          setIsSendDialogOpen(open);
          if (!open) fetchActivity();
        }}
        template={selectedTemplate}
      />
    </div>
  );
};
