import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from 'sonner';
import { sendEmail } from '@/lib/emails';
import { Mail, Send, User, Users, Briefcase, Globe, ShieldCheck } from 'lucide-react';
import { EmailTemplate } from '../EmailTemplatesPage';

interface SendEmailTemplateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  template: EmailTemplate | null;
}

type RecipientType = 'client' | 'contact' | 'team' | 'provider' | 'custom';

interface RecipientOption {
  id: string;
  email: string;
  name: string;
  category?: string;
}

export const SendEmailTemplateDialog: React.FC<SendEmailTemplateDialogProps> = ({
  open,
  onOpenChange,
  template
}) => {
  const { activeWorkspace } = useWorkspace();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [recipientType, setRecipientType] = useState<RecipientType>('client');
  const [recipients, setRecipients] = useState<RecipientOption[]>([]);
  const [selectedRecipientIds, setSelectedRecipientIds] = useState<string[]>([]);
  const [customEmail, setCustomEmail] = useState('');
  const [formData, setFormData] = useState({
    subject: '',
    body: ''
  });

  useEffect(() => {
    if (template) {
      setFormData({
        subject: template.subject,
        body: template.body
      });
    }
  }, [template]);

  useEffect(() => {
    if (open && activeWorkspace && recipientType !== 'custom') {
      fetchRecipients();
    }
  }, [open, activeWorkspace, recipientType]);

  const fetchRecipients = async () => {
    if (!activeWorkspace) return;
    
    setRecipients([]);
    setSelectedRecipientIds([]);

    try {
      if (recipientType === 'client') {
        const { data } = await supabase
          .from('clients')
          .select('id, email, first_name, last_name')
          .eq('workspace_id', activeWorkspace.id)
          .eq('status', 'ACTIVE')
          .order('first_name');
        
        if (data) {
          setRecipients(data.map(c => ({
            id: c.id,
            email: c.email || '',
            name: `${c.first_name} ${c.last_name}`
          })));
        }
      } else if (recipientType === 'contact') {
        const { data } = await supabase
          .from('contacts')
          .select('id, email, first_name, last_name')
          .eq('workspace_id', activeWorkspace.id)
          .order('first_name');
        
        if (data) {
          setRecipients(data.map(c => ({
            id: c.id,
            email: c.email || '',
            name: `${c.first_name} ${c.last_name}`
          })));
        }
      } else if (recipientType === 'team') {
        const { data: members } = await supabase
          .from('workspace_members')
          .select('id, user_id, full_name, role')
          .eq('workspace_id', activeWorkspace.id)
          .eq('status', 'active');
        
        if (members) {
          // Fetch corresponding staff profiles to get emails for team members
          const { data: profiles } = await supabase
            .from('staff_profiles')
            .select('user_id, email, full_name')
            .eq('workspace_id', activeWorkspace.id);
          
          const profileMap: Record<string, { email: string; full_name?: string }> = {};
          profiles?.forEach(p => {
            if (p.user_id && p.email) {
              profileMap[p.user_id] = { email: p.email, full_name: p.full_name };
            }
          });

          setRecipients(members.map(m => {
            const profile = profileMap[m.user_id];
            return {
              id: m.id,
              email: profile?.email || '',
              name: m.full_name || profile?.full_name || `Team Member ${m.user_id.slice(0, 8)}`,
              category: m.role
            };
          }));
        }
      } else if (recipientType === 'provider') {
        const { data: providersData } = await supabase
          .from('staff_profiles')
          .select('id, user_id, full_name, title, email')
          .eq('workspace_id', activeWorkspace.id)
          .eq('active', true)
          .order('title');
        
        if (providersData) {
          setRecipients(providersData.map(p => ({
            id: p.id,
            email: p.email || '',
            name: p.full_name || p.title || 'Unknown Provider',
            category: p.title || 'Staff'
          })));
        }
      }
    } catch (error) {
      console.error('Error fetching recipients:', error);
      toast.error('Failed to load recipients');
    }
  };

  const handleSend = async () => {
    if (!activeWorkspace || !template) return;

    const targets: { email: string; name: string; clientId?: string }[] = [];

    if (recipientType === 'custom') {
      if (!customEmail) {
        toast.error('Please enter an email address');
        return;
      }
      targets.push({ email: customEmail, name: 'Custom Recipient' });
    } else {
      if (selectedRecipientIds.length === 0) {
        toast.error('Please select at least one recipient');
        return;
      }

      selectedRecipientIds.forEach(id => {
        const recipient = recipients.find(r => r.id === id);
        if (recipient) {
          targets.push({
            email: recipient.email,
            name: recipient.name,
            clientId: recipientType === 'client' ? recipient.id : undefined
          });
        }
      });
    }

    if (!formData.subject || !formData.body) {
      toast.error('Subject and message cannot be empty');
      return;
    }

    setLoading(true);
    let successCount = 0;
    let failCount = 0;
    let skippedCount = 0;

    try {
      for (const target of targets) {
        if (!target.email) {
          skippedCount++;
          continue;
        }

        // Replace variables in the final message
        let finalBody = formData.body;
        let finalSubject = formData.subject;

        const vars: Record<string, string> = {
          workspace_name: activeWorkspace.name || '',
          user_name: user?.user_metadata?.full_name || user?.email || '',
          client_name: target.name || 'there',
          action_link: `${window.location.origin}/dashboard`
        };

        Object.entries(vars).forEach(([key, val]) => {
          const regex = new RegExp(`{{${key}}}`, 'g');
          finalBody = finalBody.replace(regex, val);
          finalSubject = finalSubject.replace(regex, val);
        });

        const result = await sendEmail({
          to: target.email,
          subject: finalSubject,
          html: finalBody.replace(/\n/g, '<br>'),
          workspaceId: activeWorkspace.id,
          userId: user?.id
        });

        if (result.success) {
          successCount++;
        } else {
          console.error(`Failed to send email to ${target.email}:`, result.error);
          failCount++;
        }
      }

      if (failCount === 0 && skippedCount === 0) {
        toast.success(`Successfully sent ${successCount} email(s)`);
        onOpenChange(false);
      } else if (successCount > 0) {
        toast.success(`Sent ${successCount} email(s). ${failCount > 0 ? `${failCount} failed. ` : ''}${skippedCount > 0 ? `${skippedCount} skipped (no email).` : ''}`);
        onOpenChange(false);
      } else {
        if (skippedCount > 0 && failCount === 0) {
          toast.warning(`All ${skippedCount} selected recipients were skipped because they have no email address.`);
        } else {
          toast.error(`Failed to send ${failCount} email(s)${skippedCount > 0 ? `. ${skippedCount} skipped.` : ''}`);
        }
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to send emails');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5 text-primary" />
            Send Email Template
          </DialogTitle>
          <DialogDescription>
            Choose a recipient and personalize the message before sending.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Recipient Type</Label>
                <Select 
                  value={recipientType} 
                  onValueChange={(v) => setRecipientType(v as RecipientType)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="client">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4" /> Client
                      </div>
                    </SelectItem>
                    <SelectItem value="contact">
                      <div className="flex items-center gap-2">
                        <Briefcase className="h-4 w-4" /> Contact
                      </div>
                    </SelectItem>
                    <SelectItem value="team">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" /> Team Member
                      </div>
                    </SelectItem>
                    <SelectItem value="provider">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="h-4 w-4" /> Provider
                      </div>
                    </SelectItem>
                    <SelectItem value="custom">
                      <div className="flex items-center gap-2">
                        <Globe className="h-4 w-4" /> Custom Email
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {recipientType === 'custom' && (
                <div className="space-y-2">
                  <Label htmlFor="customEmail">Email Address</Label>
                  <Input
                    id="customEmail"
                    type="email"
                    placeholder="recipient@example.com"
                    value={customEmail}
                    onChange={(e) => setCustomEmail(e.target.value)}
                  />
                </div>
              )}
            </div>

            {recipientType !== 'custom' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Select {recipientType}s ({selectedRecipientIds.length} selected)</Label>
                  {recipients.length > 0 && (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-7 text-[10px] font-bold uppercase tracking-wider text-primary"
                      onClick={() => {
                        const validRecipients = recipients.filter(r => r.email);
                        if (selectedRecipientIds.length === validRecipients.length) {
                          setSelectedRecipientIds([]);
                        } else {
                          setSelectedRecipientIds(validRecipients.map(r => r.id));
                        }
                      }}
                    >
                      {selectedRecipientIds.length === recipients.filter(r => r.email).length ? 'Deselect All' : 'Select All'}
                    </Button>
                  )}
                </div>
                <ScrollArea className="h-[160px] w-full border rounded-md p-3 bg-muted/5">
                  <div className="space-y-2">
                    {recipientType === 'provider' ? (
                      Object.entries(
                        recipients.reduce((acc, curr) => {
                          const cat = curr.category || 'Other';
                          if (!acc[cat]) acc[cat] = [];
                          acc[cat].push(curr);
                          return acc;
                        }, {} as Record<string, RecipientOption[]>)
                      ).map(([category, options]) => (
                        <div key={category} className="space-y-1.5">
                          <div className="px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-muted-foreground bg-muted/30 rounded border border-border/50">
                            {category}
                          </div>
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                            {options.map(r => (
                              <div key={r.id} className="flex items-center space-x-2 px-2 py-1 hover:bg-muted/50 rounded-sm group transition-colors">
                                <Checkbox 
                                  id={`recipient-${r.id}`}
                                  checked={selectedRecipientIds.includes(r.id)}
                                  disabled={!r.email}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      setSelectedRecipientIds([...selectedRecipientIds, r.id]);
                                    } else {
                                      setSelectedRecipientIds(selectedRecipientIds.filter(id => id !== r.id));
                                    }
                                  }}
                                />
                                <label 
                                  htmlFor={`recipient-${r.id}`}
                                  className={`text-xs font-medium leading-none cursor-pointer flex-1 truncate ${!r.email ? 'text-muted-foreground opacity-50' : ''}`}
                                  title={r.email ? `${r.name} (${r.email})` : `${r.name} (No email on file)`}
                                >
                                  {r.name}
                                  <span className="block text-[10px] text-muted-foreground font-normal">
                                    {r.email || 'No email on file'}
                                  </span>
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                        {recipients.map(r => (
                          <div key={r.id} className="flex items-center space-x-2 px-2 py-1 hover:bg-muted/50 rounded-sm group transition-colors">
                            <Checkbox 
                              id={`recipient-${r.id}`}
                              checked={selectedRecipientIds.includes(r.id)}
                              disabled={!r.email}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedRecipientIds([...selectedRecipientIds, r.id]);
                                } else {
                                  setSelectedRecipientIds(selectedRecipientIds.filter(id => id !== r.id));
                                }
                              }}
                            />
                            <label 
                              htmlFor={`recipient-${r.id}`}
                              className={`text-xs font-medium leading-none cursor-pointer flex-1 truncate ${!r.email ? 'text-muted-foreground opacity-50' : ''}`}
                              title={r.email ? `${r.name} (${r.email})` : `${r.name} (No email on file)`}
                            >
                              {r.name}
                              <span className="block text-[10px] text-muted-foreground font-normal">
                                {r.email || 'No email on file'}
                              </span>
                            </label>
                          </div>
                        ))}
                      </div>
                    )}
                    {recipients.length === 0 && (
                      <div className="p-8 text-center">
                        <p className="text-sm text-muted-foreground italic">
                          No {recipientType}s found matching criteria
                        </p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              placeholder="Enter subject"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="body">Message Body</Label>
            <Textarea
              id="body"
              value={formData.body}
              onChange={(e) => setFormData({ ...formData, body: e.target.value })}
              placeholder="Write your message..."
              className="min-h-[200px]"
            />
          </div>
        </div>

        <DialogFooter className="flex items-center justify-between sm:justify-between">
          <div className="text-left">
            <p className="text-[10px] text-muted-foreground italic">
              Sending from: {activeWorkspace?.email_sender_address || 'default identity'}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSend} disabled={loading}>
              <Send className="h-4 w-4 mr-2" />
              {loading ? 'Sending...' : 'Send Email'}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
