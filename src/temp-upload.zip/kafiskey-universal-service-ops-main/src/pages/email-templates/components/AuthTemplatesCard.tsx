import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, ShieldCheck, Mail, Info } from 'lucide-react';
import { toast } from 'sonner';
import { SignupConfirmationHtml } from '../KafiskeyAuthTemplates';

export const AuthTemplatesCard: React.FC = () => {
  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  return (
    <Card className="border-t-4 border-t-brand-blue overflow-hidden relative">
      <div className="absolute top-0 right-0 p-4 opacity-5">
        <ShieldCheck className="h-24 w-24" />
      </div>
      <CardHeader>
        <div className="flex items-center gap-2">
          <CardTitle className="text-xl font-bold">Platform Auth Templates</CardTitle>
          <div className="bg-brand-blue/10 text-brand-blue text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
            System
          </div>
        </div>
        <CardDescription>
          These templates are used by the platform for authentication and security. 
          To use these, copy the content into your Supabase Dashboard under <b>Authentication &gt; Email Templates</b>.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-muted/50 rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-brand-blue" />
              <div>
                <p className="font-bold text-sm">Signup Confirmation</p>
                <p className="text-xs text-muted-foreground">Sent to new users when they create an account</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="h-8 text-xs gap-2"
                onClick={() => copyToClipboard('Confirm your Kafiskey account', 'Subject')}
              >
                <Copy className="h-3 w-3" />
                Copy Subject
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="h-8 text-xs gap-2"
                onClick={() => copyToClipboard(SignupConfirmationHtml, 'HTML Content')}
              >
                <Copy className="h-3 w-3" />
                Copy HTML
              </Button>
            </div>
          </div>
          
          <div className="border border-brand-blue/20 bg-brand-blue/5 rounded-md p-3 text-xs flex gap-3">
            <Info className="h-4 w-4 text-brand-blue shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-semibold text-brand-blue">Setup Instructions</p>
              <p className="text-slate-600 dark:text-slate-400">
                1. Open your Supabase Dashboard and navigate to <b>Authentication &gt; Email Templates</b>.<br />
                2. Select <b>Confirm Signup</b> from the tabs.<br />
                3. Update the <b>Subject</b> and <b>Body</b> with the content provided here.<br />
                4. Set your sender name to <b>Kafiskey</b> in the Auth Settings.
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 border border-dashed rounded-lg opacity-50 flex items-center justify-center text-sm text-muted-foreground">
          Additional auth templates (Reset Password, Magic Link) coming soon.
        </div>
      </CardContent>
    </Card>
  );
};
