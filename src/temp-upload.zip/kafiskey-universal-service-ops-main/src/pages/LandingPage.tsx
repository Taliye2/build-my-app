import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Users, 
  ShieldCheck, 
  FileText, 
  CreditCard, 
  Activity, 
  MessageSquare, 
  Clock, 
  CheckCircle2,
  ArrowRight,
  Menu,
  X,
  PlusCircle,
  BarChart3,
  Globe,
  Layout,
  Zap,
  Lock,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BrandLogo } from '@/components/BrandLogo';
import { blink } from '@/lib/blink';
import { supabase } from '@/lib/supabase'; // Assuming supabase is imported here

export const LandingPage: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [healthStats, setHealthStats] = React.useState<any>(null);

  const navLinks = [
    { name: 'Features', href: '#features' },
    { name: 'Who It\'s For', href: '#who-its-for' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'Onboarding', href: '#onboarding' },
  ];

  const coreCapabilities = [
    {
      title: 'Structured Documentation',
      description: 'Create and manage records with clear formats and built-in approvals.',
      icon: FileText,
      color: 'brand-teal'
    },
    {
      title: 'Credential & Document Tracking',
      description: 'Automatic reminders help teams stay up to date without manual follow-up.',
      icon: ShieldCheck,
      color: 'brand-emerald'
    },
    {
      title: 'Service Tracking',
      description: 'Track hours, sessions, and programs accurately in one place.',
      icon: Clock,
      color: 'brand-indigo'
    },
    {
      title: 'Your data is handled using industry-standard security practices by default.',
      description: 'Client records and documents are handled using industry-standard administrative, technical, and access controls.',
      icon: Lock,
      color: 'brand-slate'
    },
    {
      title: 'Billing & Invoicing',
      description: 'Generate invoices directly from approved service activity—no duplicate entry.',
      icon: CreditCard,
      color: 'brand-emerald'
    },
    {
      title: 'Role-Based Access',
      description: 'Give each team member access to exactly what they need.',
      icon: Users,
      color: 'brand-teal'
    },
    {
      title: 'Internal Messaging',
      description: 'Keep communication organized and tied to real work.',
      icon: MessageSquare,
      color: 'brand-indigo'
    },
    {
      title: 'Operational Insights',
      description: 'Understand activity, progress, and workload at a glance.',
      icon: BarChart3,
      color: 'brand-slate'
    },
  ];

  const whoItsFor = [
    { title: 'Community and human service organizations', icon: Globe },
    { title: 'Healthcare-adjacent service providers', icon: Activity },
    { title: 'Case management teams', icon: Layout },
    { title: 'Hour-based and session-based agencies', icon: Clock },
    { title: 'Program-driven organizations', icon: Zap },
  ];

  const onboardingSteps = [
    { step: '01', title: 'Create your workspace', desc: 'Define your organization and service structure.' },
    { step: '02', title: 'Invite your team', desc: 'Add staff and assign roles.' },
    { step: '03', title: 'Add clients and programs', desc: 'Bring your records into one place.' },
    { step: '04', title: 'Start working', desc: 'Track services and manage operations immediately.' },
  ];

  const pricingPlans = [
    {
      name: 'Community',
      price: '$0',
      period: '/ month',
      desc: 'For small teams getting started.',
      features: ['1 staff member', 'Up to 3 active clients', 'Document management', 'Service tracking'],
      cta: 'Start Free',
      variant: 'outline' as const
    },
    {
      name: 'Growth',
      price: '$39',
      period: '/ month',
      desc: 'For teams ready to streamline operations.',
      features: ['Up to 10 staff', 'Unlimited clients', 'Billing workflows', 'Automated reminders'],
      highlight: true,
      cta: 'Start 30-Day Free Trial',
      variant: 'default' as const
    },
    {
      name: 'Scale',
      price: '$79',
      period: '/ month',
      desc: 'For organizations managing larger teams and programs.',
      features: ['Unlimited staff', 'Unlimited clients', 'Program management', 'Advanced reporting'],
      cta: 'Start 30-Day Free Trial',
      variant: 'outline' as const
    }
  ];

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  React.useEffect(() => {
    const fetchStats = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('get-health-stats');
        if (!error && data) {
          setHealthStats(data);
        }
      } catch (err) {
        console.error('Error fetching health stats:', err);
      }
    };
    fetchStats();
  }, []);

  return (
    <div className="min-h-screen bg-background selection:bg-primary/10 font-sans overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-xl border-b border-border/40">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center hover:opacity-90 transition-smooth group shrink-0">
            <BrandLogo variant="navbar" className="group-hover:scale-105 transition-smooth" />
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <div className="flex items-center gap-6">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="text-sm font-semibold text-slate-600 dark:text-slate-300 hover:text-primary transition-smooth"
                >
                  {link.name}
                </a>
              ))}
            </div>
            <div className="flex items-center gap-3 pl-6 border-l border-border/40">
              <Button variant="ghost" size="sm" className="text-sm font-semibold" asChild>
                <Link to="/auth?tab=login">Sign In</Link>
              </Button>
              <Button size="sm" className="text-sm font-bold shadow-elegant" asChild>
                <Link to="/auth?tab=register">Start Free Trial</Link>
              </Button>
            </div>
          </div>

          {/* Mobile Nav Toggle */}
          <button 
            className="md:hidden p-2 text-slate-600 dark:text-slate-300"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="md:hidden border-b border-border bg-background px-4 py-6 space-y-4 shadow-xl"
          >
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                className="block text-base font-semibold text-slate-600 dark:text-slate-300"
                onClick={() => setIsMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <div className="pt-4 flex flex-col gap-3">
              <Button variant="outline" className="w-full" asChild>
                <Link to="/auth?tab=login">Sign In</Link>
              </Button>
              <Button className="w-full" asChild>
                <Link to="/auth?tab=register">Start Free Trial</Link>
              </Button>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 md:pt-48 md:pb-32 overflow-hidden">
        {/* Background Depth */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full opacity-30">
            <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-brand-teal/20 rounded-full blur-[120px] animate-pulse" />
            <div className="absolute bottom-[20%] right-[-5%] w-[40%] h-[40%] bg-brand-emerald/10 rounded-full blur-[100px]" />
          </div>
          <div className="absolute inset-0 bg-grid-slate-900/[0.02] bg-[size:32px_32px]" />
        </div>

        <div className="container mx-auto px-6">
          <motion.div 
            initial="initial"
            animate="animate"
            variants={staggerContainer}
            className="max-w-4xl mx-auto text-center space-y-8"
          >
            <motion.div {...fadeIn} className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/5 dark:bg-primary/10 border border-primary/10 text-xs font-bold uppercase tracking-wider text-primary dark:text-primary-glow">
              <Badge className="bg-brand-teal/20 text-brand-teal hover:bg-brand-teal/30 border-none">New</Badge>
              Enterprise-ready service management
            </motion.div>
            
            <motion.h1 {...fadeIn} className="text-5xl md:text-7xl font-extrabold tracking-tight text-foreground leading-[1.1]">
              A clearer way to run your <br />
              <span className="text-brand-teal">service organization.</span>
            </motion.h1>

            <motion.p {...fadeIn} className="text-xl md:text-2xl text-slate-600 dark:text-slate-200 max-w-2xl mx-auto leading-relaxed">
              Bring structure to your clients, teams, and programs—without slowing anyone down.
            </motion.p>

            <motion.div {...fadeIn} className="pt-4 space-y-4">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button size="lg" className="h-14 px-8 text-lg font-bold rounded-xl shadow-elegant hover:scale-[1.02] active:scale-[0.98] transition-all bg-brand-teal hover:bg-brand-teal/90" asChild>
                  <Link to="/auth?tab=register">Start Free Trial</Link>
                </Button>
                <Button size="lg" variant="ghost" className="h-14 px-8 text-lg font-semibold rounded-xl" asChild>
                  <Link to="/auth?tab=login">Sign In</Link>
                </Button>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Kafiskey is a unified workspace that helps service organizations stay organized, consistent, and in control as they grow.
              </p>
            </motion.div>

            {/* Primary Values Pill */}
            <motion.div {...fadeIn} className="pt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {[
                'Records that stay complete',
                'Workflows that guide team',
                'Real service models',
                'Clear visibility'
              ].map((val) => (
                <div key={val} className="p-4 rounded-2xl bg-white dark:bg-card border border-border/40 shadow-sm flex items-center justify-center text-center">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-200 uppercase tracking-tight">{val}</span>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Primary Value / Deep Dive Section */}
      <section id="features" className="py-24 bg-accent/30 relative">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div {...fadeIn} className="space-y-12">
              <div className="space-y-4">
                <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-slate-50">Records that stay complete</h2>
                <p className="text-xl text-slate-600 dark:text-slate-300">Standardized documentation and approvals are built into daily work, so nothing gets missed.</p>
              </div>

              <div className="space-y-8">
                {[
                  {
                    title: 'Workflows that guide your team',
                    desc: 'Clear steps help staff follow the right process consistently—without extra training or oversight.',
                    icon: Zap
                  },
                  {
                    title: 'Designed for real service models',
                    desc: 'Support hourly work, sessions, and multi-week programs without custom setups.',
                    icon: Layout
                  },
                  {
                    title: 'Clear visibility across operations',
                    desc: 'See what’s happening across clients, staff, and programs in real time.',
                    icon: BarChart3
                  }
                ].map((item) => (
                  <div key={item.title} className="flex gap-4">
                    <div className="w-12 h-12 rounded-xl bg-white border border-border/40 flex items-center justify-center shrink-0 shadow-sm">
                      <item.icon className="w-6 h-6 text-brand-teal" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">{item.title}</h3>
                      <p className="text-slate-600 dark:text-slate-300">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div {...fadeIn} className="relative">
              <div className="aspect-square rounded-[2.5rem] bg-gradient-to-br from-brand-teal/20 to-brand-emerald/10 border border-brand-teal/20 p-8 shadow-inner overflow-hidden flex items-center justify-center group">
                <div className="relative w-full h-full bg-white rounded-[2rem] shadow-elegant p-6 border border-border/40 flex flex-col gap-6 transform group-hover:-translate-y-2 transition-smooth">
                  <div className="h-8 w-1/3 bg-muted rounded-lg" />
                  <div className="space-y-3">
                    <div className="h-4 w-full bg-muted/60 rounded" />
                    <div className="h-4 w-full bg-muted/60 rounded" />
                    <div className="h-4 w-2/3 bg-muted/60 rounded" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="h-20 bg-brand-teal/5 rounded-xl border border-brand-teal/10" />
                    <div className="h-20 bg-brand-emerald/5 rounded-xl border border-brand-emerald/10" />
                  </div>
                  <div className="mt-auto h-12 w-full bg-brand-teal rounded-xl" />
                </div>
                {/* Decorative Elements */}
                <div className="absolute top-1/4 -right-8 w-32 h-32 bg-brand-teal/20 rounded-full blur-3xl" />
                <div className="absolute bottom-1/4 -left-8 w-32 h-32 bg-brand-emerald/20 rounded-full blur-3xl" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Who It's For */}
      <section id="who-its-for" className="py-24 bg-background">
        <div className="container mx-auto px-6 text-center space-y-16">
          <div className="space-y-4 max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-slate-50">Built for service organizations of all kinds</h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">Kafiskey supports teams across a wide range of service environments, including:</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {whoItsFor.map((item) => (
              <motion.div 
                key={item.title}
                {...fadeIn}
                className="p-8 rounded-2xl bg-accent/20 border border-border/40 hover:border-brand-teal/40 transition-smooth text-left space-y-4 group"
              >
                <div className="w-12 h-12 rounded-xl bg-white dark:bg-card border border-border/40 flex items-center justify-center group-hover:scale-110 transition-smooth shadow-sm">
                  <item.icon className="w-6 h-6 text-brand-teal" />
                </div>
                <h3 className="font-bold text-lg leading-snug">{item.title}</h3>
              </motion.div>
            ))}
            <div className="lg:col-span-1 p-8 rounded-2xl bg-brand-teal text-white flex flex-col justify-center text-left space-y-2 shadow-elegant">
              <p className="text-lg font-bold">Something else?</p>
              <p className="text-white text-sm">If your work depends on consistency and structure, Kafiskey fits naturally.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-24 bg-brand-slate text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl" />
        <div className="container mx-auto px-6 text-center max-w-4xl relative z-10">
          <motion.div {...fadeIn} className="space-y-8">
            <MessageSquare className="w-12 h-12 text-brand-teal mx-auto" />
            <p className="text-2xl md:text-4xl font-medium italic leading-relaxed">
              “Kafiskey finally gave us a system that matches how we actually work. Everything is clearer, faster, and easier to manage.”
            </p>
            <div className="pt-4">
              <p className="text-lg font-bold">— Program Director</p>
              <p className="text-white/90">Human Services Organization</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Core Capabilities */}
      <section className="py-24 bg-accent/30">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-6">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-slate-50">One system. Fewer tools. Less friction.</h2>
            <p className="text-xl text-slate-600 dark:text-slate-300">Kafiskey replaces spreadsheets, shared folders, and disconnected tools with a single workspace designed for modern service teams.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {coreCapabilities.map((item, idx) => (
              <motion.div
                key={item.title}
                {...fadeIn}
                style={{ transitionDelay: `${idx * 50}ms` }}
                className="group p-8 rounded-[2rem] bg-background border border-border/40 hover:border-brand-teal/40 hover:shadow-elegant transition-smooth space-y-6"
              >
                <div className={`w-14 h-14 rounded-2xl bg-${item.color}/10 flex items-center justify-center group-hover:scale-110 transition-smooth`}>
                  <item.icon className="w-7 h-7 text-brand-teal" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-xl leading-tight text-slate-900 dark:text-slate-100">{item.title}</h3>
                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">{item.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Built for Scale */}
      <section className="py-24 bg-background relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-4xl opacity-[0.03] pointer-events-none">
          <BrandLogo variant="full" />
        </div>
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-20 items-center">
            <motion.div {...fadeIn} className="space-y-12">
              <div className="space-y-4">
                <Badge className="bg-brand-teal/20 text-brand-teal border-none">Built for Scale</Badge>
                <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-slate-50">Designed to support growth—without rework</h2>
                <p className="text-xl text-slate-600 dark:text-slate-300">Kafiskey supports organizations as they expand, add programs, and grow teams—without changing systems later.</p>
              </div>

              <div className="space-y-6">
                {[
                  'Clear records from day one',
                  'Visibility into activity across the organization',
                  'Consistent data as teams and client volumes grow',
                  'Full access to your information whenever you need it'
                ].map((text) => (
                  <div key={text} className="flex items-center gap-4 group">
                    <div className="w-8 h-8 rounded-full bg-brand-teal/10 flex items-center justify-center group-hover:scale-110 transition-smooth">
                      <CheckCircle2 className="w-4 h-4 text-brand-teal" />
                    </div>
                    <span className="font-bold text-slate-800 dark:text-slate-200">{text}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div {...fadeIn} className="relative">
              <div className="p-10 rounded-[2.5rem] bg-accent/20 border border-border/40 shadow-xl space-y-8">
                <div className="text-center space-y-2">
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-50">Workspace Overview</h3>
                  <p className="text-slate-600 dark:text-slate-400">Everything is running smoothly</p>
                </div>
                <div className="grid gap-6">
                  {[
                    { label: 'Client records clearly tracked', val: '100%' },
                    { label: 'Team credentials up to date', val: '100%' },
                    { label: 'Programs on track', val: '100%' }
                  ].map((stat) => (
                    <div key={stat.label} className="flex items-center justify-between p-4 bg-white dark:bg-card rounded-2xl border border-border/40 shadow-sm">
                      <span className="font-bold text-slate-700 dark:text-slate-300">{stat.label}</span>
                      <span className="text-brand-teal font-extrabold">{stat.val}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Onboarding */}
      <section id="onboarding" className="py-24 bg-accent/20 relative">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-slate-50">Get started without disruption</h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">Most organizations are fully set up in under an hour.</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {onboardingSteps.map((item, idx) => (
              <motion.div
                key={item.step}
                {...fadeIn}
                style={{ transitionDelay: `${idx * 100}ms` }}
                className="text-center space-y-6 group"
              >
                <div className="w-16 h-16 rounded-2xl bg-white dark:bg-card border border-border/40 shadow-sm mx-auto flex items-center justify-center text-xl font-black text-brand-teal group-hover:scale-110 group-hover:shadow-elegant transition-smooth">
                  {item.step}
                </div>
                <div className="space-y-2">
                  <h3 className="font-bold text-lg text-slate-900 dark:text-slate-100">{item.title}</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed px-4">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-white dark:bg-slate-900 border border-border/40 shadow-sm">
              <Clock className="w-5 h-5 text-brand-teal" />
              <span className="font-bold text-slate-600 dark:text-slate-300">Setup typically takes about 15 minutes.</span>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24 bg-background overflow-hidden relative">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-slate-900 dark:text-slate-50">Simple pricing that grows with you</h2>
            <p className="text-lg text-slate-600 dark:text-slate-300">Choose the plan that fits today. Scale when you’re ready.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingPlans.map((plan) => (
              <motion.div
                key={plan.name}
                {...fadeIn}
                className={`p-10 rounded-[2.5rem] border ${plan.highlight ? 'border-brand-teal ring-4 ring-brand-teal/10 bg-brand-teal/5 dark:bg-brand-teal/10' : 'border-border/60 bg-white dark:bg-card'} relative flex flex-col gap-8 shadow-sm hover:shadow-elegant transition-smooth`}
              >
                {plan.highlight && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-brand-teal text-white border-none px-4 py-1 font-bold">Recommended</Badge>
                )}
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-50">{plan.name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-5xl font-black tracking-tight text-slate-900 dark:text-slate-50">{plan.price}</span>
                    <span className="text-slate-600 dark:text-slate-300 font-semibold">{plan.period}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 text-sm font-medium">{plan.desc}</p>
                </div>

                <div className="space-y-4 flex-1">
                  {plan.features.map((feature) => (
                    <div key={feature} className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-brand-teal shrink-0" />
                      <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{feature}</span>
                    </div>
                  ))}
                </div>

                <Button 
                  size="lg" 
                  variant={plan.variant} 
                  className={`w-full h-14 rounded-xl text-lg font-bold ${plan.highlight ? 'bg-brand-teal hover:bg-brand-teal/90 shadow-elegant' : ''}`}
                  asChild
                >
                  <Link to="/auth?tab=register">{plan.cta}</Link>
                </Button>
              </motion.div>
            ))}
          </div>

          <div className="mt-16 text-center space-y-4">
            <p className="text-slate-600 dark:text-slate-300 font-bold tracking-tight uppercase text-xs">Risk-free trial • No credit card required • Cancel anytime</p>
            <div className="flex items-center justify-center gap-8 text-sm font-bold text-slate-500 dark:text-slate-300">
              <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> Fully Featured</span>
              <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> Enterprise Ready</span>
              <span className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4" /> Secure Infrastructure</span>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-brand-teal text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-brand-emerald opacity-20 -z-10" />
        <div className="absolute top-0 left-0 w-full h-full bg-grid-white/[0.05]" />
        <div className="container mx-auto px-6 text-center relative z-10 space-y-12">
          <motion.div {...fadeIn} className="space-y-6">
            <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight">Bring clarity to your operations</h2>
            <p className="text-xl text-white max-w-2xl mx-auto">Join teams using Kafiskey to stay organized, consistent, and ready to grow.</p>
          </motion.div>
          
          <motion.div {...fadeIn} className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <Button size="lg" className="h-16 px-10 text-xl font-bold rounded-2xl bg-white text-brand-teal hover:bg-white/90 shadow-2xl" asChild>
              <Link to="/auth?tab=register">Start Your Trial</Link>
            </Button>
            <Button size="lg" variant="ghost" className="h-16 px-10 text-xl font-bold rounded-2xl text-white hover:bg-white/10" asChild>
              <Link to="/auth?tab=login">Sign In</Link>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-background border-t border-border/40">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-4 text-center md:text-left">
              <BrandLogo variant="navbar" />
              <p className="text-sm text-slate-600 dark:text-slate-400 font-medium max-w-xs">
                Infrastructure that helps service organizations run smoothly—today and as they grow.
              </p>
            </div>
            
            <div className="flex items-center gap-8 text-sm font-bold text-slate-500 dark:text-slate-300 uppercase tracking-widest">
              <Link to="/legal/privacy" className="hover:text-primary transition-smooth">Privacy</Link>
              <a href="#" className="hover:text-primary transition-smooth">Terms</a>
              <a href="#" className="hover:text-primary transition-smooth">Contact</a>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-border/20 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">© {new Date().getFullYear()} Kafiskey. All rights reserved.</p>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-medium">
              <Lock className="w-3 h-3" /> Encrypted & Secure
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
