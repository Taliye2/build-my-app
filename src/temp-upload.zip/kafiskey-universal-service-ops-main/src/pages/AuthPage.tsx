import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { blink } from '@/lib/blink';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { BrandLogo } from '@/components/BrandLogo';
import { toast } from 'sonner';
import { Eye, EyeOff, Lock, Mail, Phone, User, ShieldCheck } from 'lucide-react';
import { logAudit } from '@/lib/audit';

export const AuthPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, session, loading: authLoading } = useAuth();
  const { activeWorkspace, loading: workspaceLoading } = useWorkspace();
  const location = useLocation();

  // All hooks must be declared before any conditional returns
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('login');
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [inviteToken, setInviteToken] = useState<string | null>(null);
  const [verificationSent, setVerificationSent] = useState(false);
  const [sentToEmail, setSentToEmail] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [resendSuccess, setResendSuccess] = useState(false);

  // Handle resend cooldown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCooldown > 0) {
      timer = setTimeout(() => setResendCooldown(prev => prev - 1), 1000);
    }
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [resendCooldown]);

  // Set initial tab and invite token from search params
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tab = params.get('tab');
    const invite = params.get('invite');

    if (invite) {
      setInviteToken(invite);
      setActiveTab('register');
    } else if (tab === 'register' || tab === 'login') {
      setActiveTab(tab);
    }
  }, [location.search]);
  
  // Separate state for login and register forms to avoid conflicts
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  
  const [registerEmail, setRegisterEmail] = useState('');
  const [registerPassword, setRegisterPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Handle email confirmation callback - check for auth tokens in URL hash
  useEffect(() => {
    const handleAuthCallback = async () => {
      // Check if we have an access_token or error in the URL (email confirmation callback)
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const accessToken = hashParams.get('access_token');
      const error = hashParams.get('error');
      const errorDescription = hashParams.get('error_description');
      
      if (error) {
        console.error('Auth callback error:', error, errorDescription);
        toast.error(errorDescription || 'Email confirmation failed. Please try again.');
        // Clear the hash from URL
        window.history.replaceState(null, '', window.location.pathname);
        return;
      }
      
      if (accessToken) {
        // Supabase will automatically handle the token exchange via onAuthStateChange
        // Just show a success message and clear the URL hash
        toast.success('Email confirmed successfully! You are now signed in.');
        window.history.replaceState(null, '', window.location.pathname);
      }
    };
    
    handleAuthCallback();
  }, []);

  // Redirect if already authenticated
  useEffect(() => {
    if (!authLoading && !workspaceLoading && session) {
      if (activeWorkspace) {
        navigate('/', { replace: true });
      } else {
        navigate('/onboarding', { replace: true });
      }
    }
  }, [session, authLoading, workspaceLoading, activeWorkspace, navigate]);

  // Show loading spinner while checking auth state
  if (authLoading || (session && workspaceLoading)) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-muted/50 dark:bg-slate-950/50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (registerPassword !== confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }

    if (registerPassword.length < 8) {
      toast.error('Password must be at least 8 characters long');
      return;
    }

    // Basic phone normalization (E.164 for US if not specified)
    let normalizedPhone = phone.trim();
    if (normalizedPhone && !normalizedPhone.startsWith('+')) {
      // Remove non-numeric characters
      const digits = normalizedPhone.replace(/\D/g, '');
      if (digits.length === 10) {
        normalizedPhone = `+1${digits}`;
      } else if (digits.length === 11 && digits.startsWith('1')) {
        normalizedPhone = `+${digits}`;
      }
    }
    
    setLoading(true);
    
    // Use the production domain for email confirmation redirects
    // This ensures the confirmation link always works regardless of how user accessed the app
    const productionUrl = 'https://kafiskey.com';
    const redirectUrl = `${productionUrl}/auth`;
    
    const { data, error } = await supabase.auth.signUp({
      email: registerEmail,
      password: registerPassword,
      options: {
        data: {
          first_name: firstName,
          last_name: lastName,
          full_name: `${firstName} ${lastName}`,
          phone_number: normalizedPhone,
        },
        emailRedirectTo: redirectUrl,
      },
    });

    if (error) {
      // Handle common signup errors with clearer messages
      const errorMsg = error.message?.toLowerCase() || '';
      if (
        errorMsg.includes('already registered') || 
        errorMsg.includes('user already registered') ||
        errorMsg.includes('email address is already') ||
        error.status === 422
      ) {
        toast.error('An account with this email already exists. Please sign in instead.');
        setActiveTab('login');
        setLoginEmail(registerEmail);
      } else if (errorMsg.includes('valid email') || errorMsg.includes('invalid email')) {
        toast.error('Please enter a valid email address.');
      } else if (errorMsg.includes('password')) {
        toast.error('Password must be at least 8 characters long.');
      } else {
        toast.error(error.message || 'An error occurred during registration. Please try again.');
      }
      setLoading(false);
      return;
    }
    
    if (data?.user?.identities?.length === 0) {
      // This happens when email confirmation is disabled and user already exists
      toast.error('An account with this email already exists. Please sign in instead.');
      setActiveTab('login');
      setLoginEmail(registerEmail);
      setLoading(false);
      return;
    }
    
    if (data?.session) {
      // User was created and auto-confirmed - session exists
      toast.success('Account created successfully!');
      setLoading(false);
      return;
    }
    
    // User created but needs confirmation - check if they have a pending invite
    // If so, auto-confirm them since their email was verified via invitation token
    if (data?.user?.id && inviteToken) {
      try {
        const { data: confirmData, error: confirmError } = await blink.functions.invoke('confirm-invited-user', {
          body: {
            token: inviteToken,
            userId: data.user.id
          }
        }) as any;
        
        if (confirmError) throw confirmError;
        
        if (confirmData?.confirmed) {
          // User was confirmed via token
          toast.success('Account created and verified via invitation! You can now sign in.');
          setActiveTab('login');
          setLoginEmail(registerEmail);
          // Clear registration form
          setRegisterPassword('');
          setConfirmPassword('');
          setFirstName('');
          setLastName('');
          setPhone('');
          setLoading(false);
          return;
        }
      } catch (confirmError) {
        console.error('Error checking invite status:', confirmError);
        // Fall through to default message
      }
    }
    
    // No invite found or confirmation failed - show standard message
    setSentToEmail(registerEmail);
    setVerificationSent(true);
    toast.success('Registration successful! Please check your email to confirm your account.');
    // Clear form on success
    setRegisterEmail('');
    setRegisterPassword('');
    setConfirmPassword('');
    setFirstName('');
    setLastName('');
    setPhone('');
    setLoading(false);
  };

  const handleResendEmail = async () => {
    if (!sentToEmail || resendCooldown > 0) return;
    
    setLoading(true);
    setResendSuccess(false);
    
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email: sentToEmail,
      options: {
        emailRedirectTo: `${window.location.origin}/auth`,
      },
    });

    if (error) {
      toast.error(error.message);
    } else {
      setResendSuccess(true);
      setResendCooldown(30);
      toast.success(`Verification email resent to ${sentToEmail}!`);
    }
    setLoading(false);
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { data, error } = await supabase.auth.signInWithPassword({
      email: loginEmail,
      password: loginPassword,
    });

    if (error) {
      toast.error(error.message);
      setLoading(false);
    } else {
      if (data.user) {
        // Log login - logAudit will handle finding the workspace ID
        logAudit('', data.user.id, 'LOGIN', 'auth', data.user.id);
      }
      toast.success('Signed in successfully!');
      // Navigation will be handled by the useEffect watching session state
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const { error } = await supabase.auth.resetPasswordForEmail(forgotPasswordEmail, {
      redirectTo: `${window.location.origin}/reset-password`,
    });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('If an account exists for this email, a password reset link has been sent.');
      setIsForgotPassword(false);
    }
    setLoading(false);
  };

  if (verificationSent) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4 bg-muted/30 dark:bg-background relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-brand-purple/5 rounded-full blur-[120px] opacity-40 animate-pulse" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-brand-teal/5 rounded-full blur-[120px] opacity-30" />
        </div>
        <Card className="w-full max-w-md glass-card border-t-4 border-t-brand-blue shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-brand-gradient opacity-80" />
          <CardHeader className="text-center pb-2">
            <Link to="/" className="inline-flex flex-col items-center group mb-4">
              <BrandLogo variant="auth" className="group-hover:scale-105 transition-smooth" />
            </Link>
            <CardTitle className="text-2xl font-bold text-brand-blue">Verification email sent</CardTitle>
            <CardDescription className="mt-2 font-medium text-slate-600 dark:text-slate-300">
              Check your inbox to confirm your account
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-6 py-4">
            <div className="flex justify-center">
              <div className="bg-brand-blue/10 p-4 rounded-full">
                <Mail className="h-10 w-10 text-brand-blue animate-bounce" />
              </div>
            </div>
            
            <div className="space-y-2">
              <p className="text-slate-600 dark:text-slate-300">
                We've sent a confirmation email to:
              </p>
              <p className="font-bold text-lg text-foreground break-all">{sentToEmail}</p>
              <button 
                type="button"
                onClick={() => {
                  setVerificationSent(false);
                  setActiveTab('register');
                  setRegisterEmail(sentToEmail);
                }}
                className="text-xs text-brand-blue hover:underline font-medium mt-1"
              >
                Entered the wrong email? Go back
              </button>
            </div>

            <p className="text-sm text-slate-500 dark:text-slate-400">
              Please check your inbox and spam folder. You'll need to confirm your email before signing in.
            </p>

            <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-900/30 p-4 rounded-lg text-xs text-amber-700 dark:text-amber-400 text-left space-y-2">
              <p className="flex items-start gap-2 font-semibold">
                <ShieldCheck className="h-4 w-4 shrink-0" />
                <span>Email trust & clarity</span>
              </p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Emails may take a few minutes to arrive.</li>
                <li>Check your spam folder if you don't see it in your inbox.</li>
                <li>The sender will be "Kafiskey" with a "Confirm your Kafiskey account" subject.</li>
              </ul>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col gap-3">
            <div className="w-full space-y-2">
              <Button 
                className="w-full bg-brand-gradient hover:opacity-90 border-none font-bold shadow-elegant transition-smooth" 
                onClick={handleResendEmail}
                disabled={loading || resendCooldown > 0}
              >
                {loading ? 'Resending...' : resendCooldown > 0 ? `Resend available in ${resendCooldown}s` : 'Resend verification email'}
              </Button>
              {resendSuccess && (
                <p className="text-center text-xs text-emerald-600 dark:text-emerald-400 font-medium animate-in fade-in slide-in-from-top-1">
                  Verification email resent to {sentToEmail}
                </p>
              )}
            </div>
            <Button 
              variant="ghost" 
              className="w-full text-slate-500 hover:text-brand-blue" 
              onClick={() => {
                setVerificationSent(false);
                setActiveTab('login');
              }}
              disabled={loading}
            >
              Back to Login
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-muted/30 dark:bg-background relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-brand-purple/5 rounded-full blur-[120px] opacity-40 animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-brand-teal/5 rounded-full blur-[120px] opacity-30" />
      </div>
      <Card className="w-full max-w-md glass-card border-t-4 border-t-brand-blue shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-brand-gradient opacity-80" />
        <CardHeader className="text-center pb-2">
          <Link to="/" className="inline-flex flex-col items-center group">
            <BrandLogo variant="auth" className="group-hover:scale-105 transition-smooth" />
          </Link>
          <CardDescription className="mt-2 font-medium text-slate-600 dark:text-slate-300">Universal Service Operations Platform</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
            <TabsContent value="login">
              {isForgotPassword ? (
                <form onSubmit={handleForgotPassword} className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="forgot-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="forgot-email"
                        type="email"
                        className="pl-9"
                        placeholder="name@example.com"
                        value={forgotPasswordEmail}
                        onChange={(e) => setForgotPasswordEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <Button type="submit" className="w-full bg-brand-gradient hover:opacity-90 border-none font-bold shadow-elegant transition-smooth" disabled={loading}>
                    {loading ? 'Sending link...' : 'Send Reset Link'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    className="w-full" 
                    onClick={() => setIsForgotPassword(false)}
                  >
                    Back to Login
                  </Button>
                </form>
              ) : (
                <form onSubmit={handleSignIn} className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="login-email"
                        type="email"
                        className="pl-9"
                        placeholder="name@example.com"
                        value={loginEmail}
                        onChange={(e) => setLoginEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="login-password">Password</Label>
                      <button
                        type="button"
                        onClick={() => {
                          setIsForgotPassword(true);
                          setForgotPasswordEmail(loginEmail);
                        }}
                        className="text-xs text-slate-500 dark:text-slate-300 hover:text-primary transition-colors"
                      >
                        Forgot password?
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="login-password"
                        type={showPassword ? "text" : "password"}
                        className="pl-9 pr-10"
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        required
                        minLength={6}
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>
                  <Button type="submit" className="w-full bg-brand-gradient hover:opacity-90 border-none font-bold shadow-elegant transition-smooth" disabled={loading}>
                    {loading ? 'Signing in...' : 'Sign In'}
                  </Button>
                </form>
              )}
            </TabsContent>
            <TabsContent value="register">
              <form onSubmit={handleSignUp} className="space-y-4 pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="firstName"
                        className="pl-9"
                        placeholder="John"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="lastName"
                        className="pl-9"
                        placeholder="Doe"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="register-email"
                      type="email"
                      className="pl-9"
                      placeholder="name@example.com"
                      value={registerEmail}
                      onChange={(e) => setRegisterEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-phone">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="register-phone"
                      type="tel"
                      className="pl-9"
                      placeholder="(555) 000-0000"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      required
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">Used only for account security and support</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="register-password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="register-password"
                      type={showPassword ? "text" : "password"}
                      className="pl-9 pr-10"
                      value={registerPassword}
                      onChange={(e) => setRegisterPassword(e.target.value)}
                      required
                      minLength={8}
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Minimum 8 characters</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirm Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="confirm-password"
                      type={showPassword ? "text" : "password"}
                      className="pl-9"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                      minLength={8}
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-brand-gradient hover:opacity-90 border-none font-bold shadow-elegant transition-smooth" disabled={loading}>
                  {loading ? 'Creating account...' : 'Create Account'}
                </Button>
                <p className="text-center text-xs text-slate-500 dark:text-slate-400 mt-2">
                  You’ll be taken directly to your new workspace.
                </p>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col text-center text-sm text-slate-500 dark:text-slate-400">
          <p>By continuing, you agree to our Terms of Service and Privacy Policy.</p>
        </CardFooter>
      </Card>
    </div>
  );
};
