import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { blink } from '@/lib/blink';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { BrandLogo } from '@/components/BrandLogo';
import { toast } from 'sonner';
import { CheckCircle2, Loader2, UserPlus } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export const CheckInPage: React.FC = () => {
  const { workspaceSlug } = useParams<{ workspaceSlug: string }>();
  const [searchParams] = useSearchParams();
  const locationTag = searchParams.get('loc');
  
  const [workspace, setWorkspace] = useState<{ workspace_id: string, name: string, is_check_in_enabled: boolean } | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    honeypot: '',
  });

  const [startTime] = useState(Date.now());

  useEffect(() => {
    const fetchWorkspace = async () => {
      if (!workspaceSlug) return;
      
      setLoading(true);
      setError(null);
      
      try {
        const { data, error: functionError } = await blink.functions.invoke('public-workspace', {
          body: { slug: workspaceSlug }
        }) as any;
        
        if (import.meta.env.DEV) {
          console.log(`[CheckInPage] Resolver for ${workspaceSlug}:`, { data, functionError });
        }
        
        if (functionError) {
          console.error('[CheckInPage] Resolver error details:', functionError);
          // Handle specific error cases from the function
          const status = (functionError as any).status;
          const errorData = (functionError as any).data || {};
          
          if (status === 404) {
            setError(`Workspace "${workspaceSlug}" not found. Please check the link.`);
            return;
          }
          if (status === 403) {
            setWorkspace(errorData.workspace);
            setError('Check-in is disabled by this organization.');
            return;
          }
          if (status >= 500) {
            setError('Service unavailable. Please try again.');
            return;
          }
          throw new Error(errorData.error || 'Could not find workspace');
        }
        
        if (!data || !data.workspace_id) {
          throw new Error('Workspace details missing from response');
        }
        
        setWorkspace(data);
      } catch (err) {
        console.error('Error fetching workspace:', err);
        setError('Service unavailable. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    
    fetchWorkspace();
  }, [workspaceSlug]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.honeypot) {
      // Silent fail for bots
      setSubmitted(true);
      return;
    }

    if (!formData.firstName || !formData.lastName || !formData.phone) {
      toast.error('Please fill in all fields');
      return;
    }

    setSubmitting(true);
    
    try {
      // Call the edge function via blink SDK
      const { data, error: functionError } = await blink.functions.invoke('check-in', {
        body: {
          workspaceSlug,
          firstName: formData.firstName,
          lastName: formData.lastName,
          phone: formData.phone,
          locationTag,
          submissionTime: startTime,
        }
      });
      
      if (functionError) {
        const errorData = (functionError as any).data || {};
        throw new Error(errorData.error || 'Check-in failed');
      }

      setSubmitted(true);
      toast.success('Successfully checked in!');
    } catch (err: any) {
      console.error('Check-in error:', err);
      toast.error(err.message || 'Check-in failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <Loader2 className="h-8 w-8 animate-spin text-brand-blue" />
      </div>
    );
  }

  if (error || !workspace || (workspace && !workspace.is_check_in_enabled)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <Card className="max-w-md w-full shadow-lg border-red-100">
          <CardHeader className="text-center">
            <div className="mx-auto bg-red-100 p-3 rounded-full w-fit mb-4">
              <UserPlus className="h-10 w-10 text-red-600" />
            </div>
            <CardTitle className="text-xl font-bold text-red-700">Check-In Unavailable</CardTitle>
            <CardDescription className="text-base mt-2">
              {error || (!workspace ? `Workspace "${workspaceSlug}" could not be found.` : 'Check-in is disabled by this organization.')}
            </CardDescription>
          </CardHeader>
          <CardFooter className="flex flex-col gap-4 border-t pt-6">
            {error?.includes('Service unavailable') && (
              <Button 
                onClick={() => window.location.reload()}
                variant="outline"
                className="w-full"
              >
                Retry
              </Button>
            )}
            <p className="text-xs text-muted-foreground italic text-center">
              Please contact the organization for assistance.
            </p>
          </CardFooter>
        </Card>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
        <Card className="max-w-md w-full shadow-lg border-green-100 animate-in fade-in zoom-in duration-500">
          <CardHeader className="text-center">
            <div className="mx-auto bg-green-100 p-3 rounded-full w-fit mb-4">
              <CheckCircle2 className="h-10 w-10 text-green-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-green-700">You're checked in ✅</CardTitle>
            <CardDescription className="text-base mt-2">
              Thank you for visiting {workspace.name}. Someone will be with you shortly.
            </CardDescription>
          </CardHeader>
          <CardFooter className="flex justify-center border-t pt-6">
            <p className="text-xs text-muted-foreground italic">
              Kafiskey QR Check-In System
            </p>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 p-4">
      <div className="mb-8 animate-in fade-in slide-in-from-top duration-700">
        <BrandLogo className="h-12 w-auto mx-auto mb-2" />
        <h2 className="text-center text-xl font-bold text-slate-900 tracking-tight">
          {workspace.name}
        </h2>
      </div>

      <Card className="max-w-md w-full shadow-xl border-none ring-1 ring-slate-200 animate-in fade-in slide-in-from-bottom duration-700">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold flex items-center gap-2">
            <UserPlus className="h-6 w-6 text-brand-blue" />
            Walk-In Check-In
          </CardTitle>
          <CardDescription>
            Please enter your information to join the queue.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  placeholder="John"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  required
                  autoFocus
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  placeholder="Doe"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  required
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="(555) 123-4567"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                required
              />
            </div>

            {/* Honeypot field - hidden from users */}
            <div className="hidden" aria-hidden="true">
              <Input
                type="text"
                name="b_phone"
                tabIndex={-1}
                value={formData.honeypot}
                onChange={(e) => setFormData({ ...formData, honeypot: e.target.value })}
                autoComplete="off"
              />
            </div>

            <div className="pt-2">
              <p className="text-[10px] text-muted-foreground leading-tight text-center mb-4">
                By submitting, you confirm this information is accurate.
              </p>
              <Button 
                type="submit" 
                className="w-full h-12 text-base font-bold bg-brand-gradient hover:opacity-90 transition-opacity shadow-lg"
                disabled={submitting}
              >
                {submitting ? (
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                ) : (
                  'Check In Now'
                )}
              </Button>
            </div>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center border-t pt-4">
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold opacity-50">
            Powered by Kafiskey
          </p>
        </CardFooter>
      </Card>
      
      {locationTag && (
        <Badge variant="outline" className="mt-4 bg-white/50 text-[10px] font-mono text-muted-foreground border-slate-200">
          LOC: {locationTag}
        </Badge>
      )}
    </div>
  );
};
