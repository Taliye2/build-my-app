import React, { useEffect, useState } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { BarChart3, TrendingUp, Users, Clock, AlertCircle } from 'lucide-react';
import { Empty } from '@/components/ui/empty';
import { toast } from 'sonner';
import { TrialPreviewBanner } from '@/components/TrialPreviewBanner';

export const AnalyticsPage: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    if (activeWorkspace) {
      fetchAnalyticsData();
    }
  }, [activeWorkspace]);

  const fetchAnalyticsData = async () => {
    setLoading(true);
    try {
      // In a real app, these would be complex queries or pre-aggregated metrics
      // For now, we'll fetch some basic counts and simulate others
      const { count: clientCount } = await supabase
        .from('clients')
        .select('*', { count: 'exact', head: true })
        .eq('workspace_id', activeWorkspace?.id);

      const { count: eventCount } = await supabase
        .from('service_events')
        .select('*', { count: 'exact', head: true })
        .eq('workspace_id', activeWorkspace?.id);

      const { count: pendingApproval } = await supabase
        .from('service_events')
        .select('*', { count: 'exact', head: true })
        .eq('workspace_id', activeWorkspace?.id)
        .eq('status', 'SUBMITTED');

      const { count: providerCount } = await supabase
        .from('staff_profiles')
        .select('*', { count: 'exact', head: true })
        .eq('workspace_id', activeWorkspace?.id);

      const { count: approvedCount } = await supabase
        .from('service_events')
        .select('*', { count: 'exact', head: true })
        .eq('workspace_id', activeWorkspace?.id)
        .eq('status', 'APPROVED');

      setData({
        clientCount: clientCount || 0,
        eventCount: eventCount || 0,
        pendingApproval: pendingApproval || 0,
        providerCount: providerCount || 0,
        approvedCount: approvedCount || 0,
        deliveryVolume: [
          { name: 'Mon', value: Math.floor(Math.random() * 10) + 5 },
          { name: 'Tue', value: Math.floor(Math.random() * 10) + 10 },
          { name: 'Wed', value: Math.floor(Math.random() * 10) + 8 },
          { name: 'Thu', value: Math.floor(Math.random() * 10) + 15 },
          { name: 'Fri', value: Math.floor(Math.random() * 10) + 12 },
          { name: 'Sat', value: Math.floor(Math.random() * 5) + 2 },
          { name: 'Sun', value: Math.floor(Math.random() * 5) + 1 },
        ],
        providerProductivity: [
          { name: 'Provider A', value: 45 },
          { name: 'Provider B', value: 38 },
          { name: 'Provider C', value: 52 },
          { name: 'Provider D', value: 28 },
        ],
        documentationStatus: [
          { name: 'Draft', value: (eventCount || 0) - (pendingApproval || 0) - (approvedCount || 0), color: '#94a3b8' },
          { name: 'Submitted', value: pendingApproval || 0, color: '#f59e0b' },
          { name: 'Approved', value: approvedCount || 0, color: '#10b981' },
          { name: 'Rejected', value: 0, color: '#ef4444' },
        ]
      });
    } catch (error: any) {
      console.error('Error fetching analytics:', error);
      toast.error('Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!data || data.eventCount === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Analytics</h2>
          <p className="text-muted-foreground">Insight, oversight, and accountability.</p>
        </div>
        <Empty
          icon={BarChart3}
          title="No data to analyze"
          description="Analytics appear as your organization delivers services."
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <TrialPreviewBanner featureName="Advanced Analytics" />
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Analytics</h2>
        <p className="text-muted-foreground">Insight, oversight, and accountability.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Clients</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.clientCount}</div>
            <p className="text-xs text-muted-foreground">+2 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Services Delivered</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.eventCount}</div>
            <p className="text-xs text-muted-foreground">+12% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Turnaround</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">14h</div>
            <p className="text-xs text-muted-foreground">-2h from last month</p>
          </CardContent>
        </Card>
        <Card className="border-warning/20 bg-warning/5 dark:bg-warning/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <AlertCircle className="h-4 w-4 text-warning" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-warning">{data.pendingApproval}</div>
            <p className="text-xs text-warning/80">Requires attention</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle>Service Delivery Volume</CardTitle>
            <CardDescription>Number of services delivered per day this week.</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.deliveryVolume}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <RechartsTooltip />
                  <Bar dataKey="value" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        <Card className="col-span-3">
          <CardHeader>
            <CardTitle>Documentation Status</CardTitle>
            <CardDescription>Overview of service record statuses.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data.documentationStatus}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {data.documentationStatus.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex justify-center gap-4 text-xs">
                {data.documentationStatus.map((entry: any, index: number) => (
                  <div key={index} className="flex items-center gap-1.5">
                    <div className="h-2 w-2 rounded-full" style={{ backgroundColor: entry.color }} />
                    <span className="text-muted-foreground">{entry.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
