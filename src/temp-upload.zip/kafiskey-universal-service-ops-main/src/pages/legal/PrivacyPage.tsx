import React from 'react';
import { Shield } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-background p-6 md:p-12">
      <div className="max-w-3xl mx-auto space-y-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 rounded-lg bg-primary/10">
            <Shield className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Privacy Policy</h1>
        </div>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-100">1. Introduction</h2>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            Kafiskey ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you use our universal service operations platform.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-100">2. Information Collection</h2>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            We collect information you provide directly to us when creating a workspace, inviting team members, or managing client records. This includes:
          </p>
          <ul className="list-disc pl-6 text-slate-600 dark:text-slate-400 space-y-2">
            <li>Account details (name, email, password)</li>
            <li>Workspace and organization information</li>
            <li>Client data and service records</li>
            <li>Billing information through our payment processors</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-100">3. Integration with Third-Party Services</h2>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            Kafiskey integrates with third-party services like QuickBooks Online to streamline your financial operations. When you connect your QuickBooks account:
          </p>
          <ul className="list-disc pl-6 text-slate-600 dark:text-slate-400 space-y-2">
            <li>We securely store OAuth tokens to maintain the connection.</li>
            <li>We only access the data necessary to perform the requested synchronization (e.g., invoices, customers).</li>
            <li>You can disconnect these services at any time through your workspace settings.</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-100">4. Compliance and Security</h2>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            We provide industry-standard security controls, including Row-Level Security (RLS) and encryption, designed to support organizational data isolation and protection. We do not sell your data to third parties.
          </p>
        </section>

        <section className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-100">5. Contact Us</h2>
          <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
            If you have any questions about this Privacy Policy, please contact us at privacy@kafiskey.com.
          </p>
        </section>

        <div className="pt-12 border-t text-sm text-slate-500 dark:text-slate-400">
          <p>Last updated: January 7, 2026</p>
        </div>
      </div>
    </div>
  );
};
