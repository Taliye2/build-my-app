import React, { useState, useEffect } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, Rocket, Calendar, ShieldCheck, Users, Settings, ArrowRight, Loader2, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { blink } from '@/lib/blink';
import { toast } from 'sonner';
import { useNavigate, useSearchParams } from 'react-router-dom';

export const LaunchpadPage: React.FC = () => {
  const { activeWorkspace, activeMember } = useWorkspace();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const isSuccess = searchParams.get('launchpad') === 'true';

  const handleCheckout = async () => {
    if (!activeWorkspace || !user) {
      toast.error('You must be logged in to secure your Launchpad');
      navigate('/auth?tab=register&redirect=/billing/launchpad');
      return;
    }

    if (activeMember?.role !== 'OWNER' && activeMember?.role !== 'ADMIN') {
      toast.error('Only workspace owners or admins can purchase Launchpad');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await blink.functions.invoke('stripe-checkout', {
        body: {
          workspaceId: activeWorkspace.id,
          planKey: 'launchpad',
          userEmail: user.email
        }
      });
      
      if (error) throw error;
      
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      toast.error(err.message || 'Failed to start checkout process');
    } finally {
      setLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="max-w-4xl mx-auto py-20 px-6 text-center space-y-10 animate-fade-in">
        <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
          <Sparkles className="w-12 h-12 text-primary animate-pulse" />
        </div>
        <div className="space-y-4">
          <Badge variant="outline" className="text-primary dark:text-primary-glow border-primary/20 bg-primary/5 dark:bg-primary/10">Order Confirmed</Badge>
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">Your Launchpad is Ready.</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Welcome to the Kafiskey Launchpad. We've upgraded your workspace and our team will be in touch within 24 hours to schedule your operations setup call.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-6 pt-10">
          {[
            { icon: Calendar, title: 'Setup Call', desc: 'Check your email for the scheduling link.' },
            { icon: ShieldCheck, title: 'Compliance Base', desc: 'Your workspace is now configured for Scale features.' },
            { icon: Rocket, title: 'Get Started', desc: 'Explore the dashboard while we prepare your session.' },
          ].map((item, i) => (
            <Card key={i} className="border-border/40 bg-background/50 backdrop-blur-sm">
              <CardContent className="pt-8 space-y-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto">
                  <item.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-bold text-lg">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="pt-10">
          <Button size="lg" className="h-16 px-12 text-xl font-bold rounded-2xl shadow-elegant" onClick={() => navigate('/')}>
            Go to Dashboard
            <ArrowRight className="ml-3 w-6 h-6" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-12 px-6 space-y-16 animate-fade-in">
      <div className="text-center space-y-6">
        <Badge variant="outline" className="text-primary dark:text-primary-glow border-primary/20 bg-primary/5 dark:bg-primary/10 px-4 py-1.5 text-sm font-bold rounded-full mb-4">Accelerated Readiness</Badge>
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight leading-[1.1]">Kafiskey Launchpad</h1>
        <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
          The guided implementation program for agencies that need to be operational, compliant, and audit-ready fast.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-16 items-center">
        <div className="space-y-10">
          <div className="space-y-4">
            <h2 className="text-3xl font-bold tracking-tight">What's included in your setup?</h2>
            <p className="text-muted-foreground text-lg leading-relaxed">
              Skip the trial-and-error. We provide the expert guidance and configuration needed to protect your organization from compliance risk.
            </p>
          </div>

          <div className="grid gap-6">
            {[
              { icon: ShieldCheck, title: '3 Months of Scale Plan', desc: 'Full access to our most powerful features included.' },
              { icon: Users, title: '60-Min Ops Strategy Call', desc: 'A dedicated session to map your specific service models.' },
              { icon: Settings, title: 'Done-With-You Config', desc: 'We help you configure service types, templates, and roles.' },
              { icon: Rocket, title: 'Priority Support', desc: 'Direct line to our implementation specialists.' },
            ].map((item, i) => (
              <div key={i} className="flex gap-6 group">
                <div className="w-14 h-14 rounded-2xl bg-primary/5 dark:bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/10 dark:group-hover:bg-primary/20 transition-smooth">
                  <item.icon className="w-7 h-7 text-primary" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-bold text-xl">{item.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <Card className="border-primary ring-2 ring-primary/20 shadow-2xl overflow-hidden bg-background/50 backdrop-blur-xl">
          <CardHeader className="p-10 pb-6 border-b border-border/40">
            <div className="flex items-center justify-between mb-4">
              <Badge className="bg-primary text-primary-foreground font-black tracking-widest uppercase">One-Time Secure Checkout</Badge>
              <div className="text-right">
                <span className="text-4xl font-bold tracking-tight">$997</span>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mt-1">Single Investment</p>
              </div>
            </div>
            <CardTitle className="text-2xl">Kafiskey Launchpad Package</CardTitle>
            <CardDescription className="text-base">Everything needed to establish a professional service agency foundation.</CardDescription>
          </CardHeader>
          <CardContent className="p-10 space-y-8">
            <div className="space-y-4">
              <p className="text-sm font-bold text-foreground/70 uppercase tracking-widest">Standard Deliverables</p>
              <ul className="space-y-4">
                {[
                  '3 months of Scale Plan subscription',
                  'Operational strategy & setup session',
                  'Client data import assistance',
                  'Customized service record templates',
                  'Staff role & permission audit',
                  'Compliance workflow walkthrough'
                ].map((f) => (
                  <li key={f} className="flex items-center gap-3 text-base font-medium">
                    <CheckCircle2 className="w-5 h-5 text-primary shrink-0" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Button 
              className="w-full h-16 text-xl font-bold rounded-2xl shadow-elegant group" 
              size="lg"
              onClick={handleCheckout}
              disabled={loading}
            >
              {loading ? (
                <Loader2 className="mr-3 h-6 w-6 animate-spin" />
              ) : (
                <>
                  Secure Your Launchpad
                  <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-1 transition-smooth" />
                </>
              )}
            </Button>
            
            <p className="text-center text-xs text-muted-foreground font-medium italic">
              *Secure checkout via Stripe. After purchase, you will be redirected to schedule your strategy call.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="py-20 border-y border-border/40 grid md:grid-cols-3 gap-12">
        <div className="text-center space-y-4">
          <h4 className="font-bold text-lg">Who is this for?</h4>
          <p className="text-sm text-muted-foreground leading-relaxed px-4">New agencies, teams scaling from 1 to 5+ staff, or anyone needing to fix messy records before an audit.</p>
        </div>
        <div className="text-center space-y-4 border-x border-border/40">
          <h4 className="font-bold text-lg">Why $997?</h4>
          <p className="text-sm text-muted-foreground leading-relaxed px-4">Includes 3 months of our Scale plan ($237 value) plus dedicated expert time to ensure your foundation is solid.</p>
        </div>
        <div className="text-center space-y-4">
          <h4 className="font-bold text-lg">Can I use it later?</h4>
          <p className="text-sm text-muted-foreground leading-relaxed px-4">Yes. If you start on a free or growth plan today, you can upgrade to Launchpad at any time to fix your ops.</p>
        </div>
      </div>
    </div>
  );
};
