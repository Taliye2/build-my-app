import React, { useEffect, useState } from 'react';
import { blink } from '@/lib/blink';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Receipt, Plus, Filter, Download, ExternalLink, CreditCard, CheckCircle2, AlertCircle as AlertCircleIcon, FileClock, DollarSign, FileText, Mail, Loader2, ChevronDown, Printer } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { Client } from '../clients/ClientListPage';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Empty } from '@/components/ui/empty';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { sendEmail } from '@/lib/emails';
import { logAudit } from '@/lib/audit';
import { useAuth } from '@/contexts/AuthContext';

export interface Invoice {
  id: string;
  invoice_number: string;
  client_id: string;
  period_start: string;
  period_end: string;
  subtotal: number;
  status: 'Draft' | 'Sent' | 'Paid' | 'Void';
  created_at: string;
  clients?: Client;
}

export interface BillingItem {
  id: string;
  client_id: string;
  service_record_id: string;
  service_template_id: string;
  service_date: string;
  quantity: number;
  rate_amount: number;
  line_total: number;
  billing_status: 'Unbilled' | 'Invoiced' | 'Paid' | 'Void' | 'Partially Paid' | 'Denied';
  missing_rate: boolean;
  invoice_id?: string;
  paid_amount?: number;
  remaining_amount?: number;
  clients?: Client;
  service_templates?: any;
}

export const BillingPage: React.FC = () => {
  const { activeWorkspace, trialDaysRemaining, isLocked, isTrialActive, hasBillingAccess } = useWorkspace();
  const { user } = useAuth();
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [unbilledItems, setUnbilledItems] = useState<BillingItem[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [portalLoading, setPortalLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState<'all' | 'Unbilled' | 'Paid' | 'Partially Paid' | 'Denied'>('all');
  const [stats, setStats] = useState({
    templatesCount: 0,
    approvedEventsCount: 0,
    trialDaysRemaining: 12,
    totalPaid: 0,
    totalPartiallyPaid: 0,
    totalRemaining: 0,
    totalDenied: 0,
    totalUnbilled: 0
  });

  // Form state for generating invoice
  const [selectedClientId, setSelectedClientId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Partial Payment State
  const [partialPaymentItem, setPartialPaymentItem] = useState<BillingItem | null>(null);
  const [paidAmount, setPaidAmount] = useState('');
  const [remainingAmount, setRemainingAmount] = useState('');

  // Print state
  const [printingInvoice, setPrintingInvoice] = useState<Invoice | null>(null);
  const [printingLines, setPrintingLines] = useState<any[]>([]);

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    const [invoicesRes, itemsRes, clientsRes, templatesRes, approvedRes] = await Promise.all([
      supabase.from('invoices').select('*, clients:client_id(*)').eq('workspace_id', activeWorkspace.id).order('created_at', { ascending: false }),
      supabase.from('billing_items').select('*, clients:client_id(*), service_templates(*)').eq('workspace_id', activeWorkspace.id).in('billing_status', ['Unbilled', 'Partially Paid', 'Denied', 'Paid', 'unbilled', 'paid', 'denied', 'partially paid', 'partial paid', 'partial_paid']),
      supabase.from('clients').select('*').eq('workspace_id', activeWorkspace.id),
      supabase.from('service_templates').select('id').eq('workspace_id', activeWorkspace.id),
      supabase.from('service_events').select('id').eq('workspace_id', activeWorkspace.id).eq('status', 'APPROVED')
    ]);

    if (invoicesRes.data) setInvoices(invoicesRes.data);
    if (itemsRes.data) setUnbilledItems(itemsRes.data);
    if (clientsRes.data) setClients(clientsRes.data);
    
    const financialStats = (itemsRes.data || []).reduce((acc, item) => {
      // Normalize status for aggregation (defensive guard against mixed case)
      const status = (item.billing_status || '').toLowerCase();
      
      if (status === 'paid') {
        acc.totalPaid += Number(item.line_total || 0);
      } else if (status === 'partially paid' || status === 'partial paid' || status === 'partial_paid') {
        acc.totalPartiallyPaid += Number(item.paid_amount || 0);
        acc.totalRemaining += Number(item.remaining_amount || (Number(item.line_total || 0) - Number(item.paid_amount || 0)));
      } else if (status === 'denied') {
        acc.totalDenied += Number(item.line_total || 0);
      } else if (status === 'unbilled') {
        acc.totalUnbilled += Number(item.line_total || 0);
      }
      return acc;
    }, { totalPaid: 0, totalPartiallyPaid: 0, totalRemaining: 0, totalDenied: 0, totalUnbilled: 0 });

    setStats(prev => ({
      ...prev,
      templatesCount: templatesRes.data?.length || 0,
      approvedEventsCount: approvedRes.data?.length || 0,
      ...financialStats
    }));
    
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  const handleGenerateInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !selectedClientId) return;

    try {
      setLoading(true);
      const { data, error } = await blink.functions.invoke('generate-invoice', {
        body: {
          workspaceId: activeWorkspace.id,
          clientId: selectedClientId,
          billingItemIds: selectedItemIds,
          startDate,
          endDate
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      toast.success('Invoice generated successfully');
      setIsDialogOpen(false);
      setSelectedItemIds([]);
      fetchData();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleManageSubscription = async () => {
    if (!activeWorkspace) return;
    
    setPortalLoading(true);
    try {
      const { data, error } = await blink.functions.invoke('stripe-portal', {
        body: { workspaceId: activeWorkspace.id }
      });

      if (error) throw error;
      if (data?.url) {
        window.open(data.url, '_blank');
      }
    } catch (err: any) {
      console.error('Portal error:', err);
      toast.error(err.message || 'Failed to open billing portal');
    } finally {
      setPortalLoading(false);
    }
  };

  const handleEmailInvoice = async (invoice: Invoice) => {
    if (!activeWorkspace || !invoice.clients?.email) {
      toast.error('Client email not found');
      return;
    }

    try {
      setLoading(true);
      await sendEmail({
        to: invoice.clients.email,
        subject: `Invoice ${invoice.invoice_number} from ${activeWorkspace.name}`,
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #7C3AED;">Invoice ${invoice.invoice_number}</h2>
            <p>Hello ${invoice.clients.first_name},</p>
            <p>Please find the details of your latest invoice from <strong>${activeWorkspace.name}</strong>.</p>
            
            <div style="background-color: #f9f9f9; padding: 20px; border-radius: 12px; margin: 24px 0; border: 1px solid #eee;">
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #666;">Invoice Number:</td>
                  <td style="padding: 8px 0; font-weight: bold; text-align: right;">${invoice.invoice_number}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;">Period:</td>
                  <td style="padding: 8px 0; font-weight: bold; text-align: right;">
                    ${new Date(invoice.period_start).toLocaleDateString()} - ${new Date(invoice.period_end).toLocaleDateString()}
                  </td>
                </tr>
                <tr style="border-top: 1px solid #eee;">
                  <td style="padding: 16px 0 8px; color: #666; font-size: 18px;">Total Amount:</td>
                  <td style="padding: 16px 0 8px; font-weight: bold; text-align: right; color: #7C3AED; font-size: 24px;">
                    ${Number(invoice.subtotal).toFixed(2)}
                  </td>
                </tr>
              </table>
            </div>

            <p>Thank you for your business!</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 32px 0;" />
            <p style="color: #999; font-size: 12px;">&copy; ${new Date().getFullYear()} Kafiskey Universal Service Ops. All rights reserved.</p>
          </div>
        `,
        workspaceId: activeWorkspace.id
      });

      await supabase
        .from('invoices')
        .update({ status: 'Sent', sent_at: new Date().toISOString() })
        .eq('id', invoice.id);

      // Audit Log
      if (user) {
        await logAudit(
          activeWorkspace.id,
          user.id,
          'invoice_sent',
          'invoice',
          invoice.id,
          { invoice_number: invoice.invoice_number, recipient: invoice.clients.email }
        );
      }

      toast.success(`Invoice ${invoice.invoice_number} emailed to ${invoice.clients.email}`);
      fetchData();
    } catch (error: any) {
      toast.error(`Failed to email invoice: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const toggleItemSelection = (id: string) => {
    setSelectedItemIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleUpdateStatus = async (item: BillingItem, status: BillingItem['billing_status']) => {
    if (!activeWorkspace) return;

    if (status === 'Partially Paid') {
      setPartialPaymentItem(item);
      setPaidAmount(item.paid_amount ? item.paid_amount.toString() : '');
      setRemainingAmount(item.remaining_amount !== undefined && item.remaining_amount !== null ? item.remaining_amount.toString() : Number(item.line_total).toString());
      return;
    }

    try {
      const { error } = await supabase
        .from('billing_items')
        .update({ billing_status: status })
        .eq('id', item.id);

      if (error) throw error;
      toast.success(`Status updated to ${status}`);
      fetchData();
    } catch (error: any) {
      toast.error(`Failed to update status: ${error.message}`);
    }
  };

  const handlePartialPaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !partialPaymentItem) return;

    try {
      const paid = parseFloat(paidAmount);
      const remaining = parseFloat(remainingAmount);
      
      // Determine final status - if balance is cleared, mark as Paid
      const status = remaining <= 0 ? 'Paid' : 'Partially Paid';

      const { error } = await supabase
        .from('billing_items')
        .update({ 
          billing_status: status,
          paid_amount: paid,
          remaining_amount: remaining
        })
        .eq('id', partialPaymentItem.id);

      if (error) throw error;
      toast.success(status === 'Paid' ? 'Payment fully recorded' : 'Partial payment recorded');
      setPartialPaymentItem(null);
      fetchData();
    } catch (error: any) {
      toast.error(`Failed to record partial payment: ${error.message}`);
    }
  };

  const handlePrintInvoice = async (invoice: Invoice) => {
    try {
      const { data: lines, error } = await supabase
        .from('invoice_lines')
        .select('*')
        .eq('invoice_id', invoice.id);
      
      if (error) throw error;
      
      setPrintingInvoice(invoice);
      setPrintingLines(lines || []);
      
      // Give time for the component to render before printing
      setTimeout(() => {
        window.print();
        setPrintingInvoice(null);
      }, 500);
    } catch (error: any) {
      toast.error('Failed to prepare invoice for printing: ' + error.message);
    }
  };

  const filteredItems = unbilledItems.filter(item => {
    const status = (item.billing_status || '').toLowerCase();
    if (statusFilter === 'all') {
      // Show Unbilled, Partially Paid, and Denied by default
      return ['unbilled', 'partially paid', 'partial paid', 'partial_paid', 'denied'].includes(status);
    }
    
    const targetStatus = statusFilter.toLowerCase();
    if (targetStatus === 'partially paid') {
      return status === 'partially paid' || status === 'partial paid' || status === 'partial_paid';
    }
    return status === targetStatus;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {!hasBillingAccess && (
        <Alert className="bg-amber-50 border-amber-200 text-amber-800">
          <AlertCircleIcon className="h-4 w-4" />
          <AlertTitle>Invoicing Restricted</AlertTitle>
          <AlertDescription>
            The Community tier does not include invoicing functionality. Please upgrade to the <strong>Growth</strong> or <strong>Scale</strong> plan to manage invoices and billing workflows.
            <div className="mt-4">
              <Button size="sm" asChild>
                <Link to="/billing/plan">View Pricing Plans</Link>
              </Button>
            </div>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <Card className="lg:col-span-1 border-brand-blue/20 bg-brand-blue/5 dark:bg-brand-blue/10 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-brand-blue" />
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold text-brand-blue uppercase">Subscription Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <span className="text-2xl font-bold">
                {isTrialActive ? 'Scale (Trial)' : (
                  activeWorkspace?.plan_key === 'community' ? 'Community' : 
                  activeWorkspace?.plan_key === 'growth' ? 'Growth' : 
                  activeWorkspace?.plan_key === 'scale' ? 'Scale' : 'Community'
                )}
              </span>
              <Badge variant={activeWorkspace?.access_state === 'ACTIVE_PAID' || activeWorkspace?.plan_status === 'active' ? 'success' : 'secondary'}>
                {activeWorkspace?.access_state === 'ACTIVE_PAID' || activeWorkspace?.plan_status === 'active' ? 'Active' : 
                 isLocked ? 'Expired' : 'Trialing'}
              </Badge>
            </div>
            {trialDaysRemaining !== null && !isLocked && (
              <p className="text-xs text-muted-foreground dark:text-slate-400 mt-1 italic">
                {trialDaysRemaining === 0 ? 'Trial ends today' : `${trialDaysRemaining} days remaining in trial`}
              </p>
            )}
            <div className="flex gap-2 mt-2">
              <Button 
                variant="link" 
                className="px-0 h-auto text-xs" 
                asChild
              >
                <Link to="/billing/plan" className="flex items-center gap-1">
                  <CreditCard className="h-3 w-3" /> Plans
                </Link>
              </Button>
              {activeWorkspace?.stripe_customer_id && (
                <Button 
                  variant="link" 
                  className="px-0 h-auto text-xs text-primary" 
                  onClick={handleManageSubscription}
                  disabled={portalLoading}
                >
                  {portalLoading ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : <ExternalLink className="h-3 w-3 mr-1" />}
                  Manage
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:col-span-3">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground dark:text-slate-300 uppercase">Billing Readiness & Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div 
                className={`flex flex-col gap-1 p-3 rounded-lg cursor-pointer transition-all border ${statusFilter === 'Unbilled' ? 'bg-primary/10 border-primary shadow-sm dark:bg-primary/20' : 'hover:bg-muted border-transparent dark:hover:bg-muted/20'}`}
                onClick={() => setStatusFilter(statusFilter === 'Unbilled' ? 'all' : 'Unbilled')}
              >
                <span className="text-[10px] text-primary font-semibold uppercase dark:text-primary-glow">Not Billed</span>
                <div className="text-sm font-bold text-primary dark:text-primary-glow">
                  ${stats.totalUnbilled.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
              
              <div 
                className={`flex flex-col gap-1 p-3 rounded-lg cursor-pointer transition-all border ${statusFilter === 'Paid' ? 'bg-success/10 border-success shadow-sm dark:bg-success/20' : 'hover:bg-muted border-transparent dark:hover:bg-muted/20'}`}
                onClick={() => setStatusFilter(statusFilter === 'Paid' ? 'all' : 'Paid')}
              >
                <span className="text-[10px] text-success font-semibold uppercase dark:text-success">Fully Paid</span>
                <div className="text-sm font-bold text-success dark:text-success">
                  ${stats.totalPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
              
              <div 
                className={`flex flex-col gap-1 p-3 rounded-lg cursor-pointer transition-all border ${statusFilter === 'Partially Paid' ? 'bg-warning/10 border-warning shadow-sm dark:bg-warning/20' : 'hover:bg-muted border-transparent dark:hover:bg-muted/20'}`}
                onClick={() => setStatusFilter(statusFilter === 'Partially Paid' ? 'all' : 'Partially Paid')}
              >
                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-warning font-semibold uppercase dark:text-warning">Partial Paid</span>
                  {stats.totalRemaining > 0 && (
                    <Badge variant="outline" className="h-4 text-[8px] bg-warning/20 border-warning/30 text-warning-foreground dark:text-warning-foreground font-bold">
                      Pending: ${stats.totalRemaining.toLocaleString()}
                    </Badge>
                  )}
                </div>
                <div className="text-sm font-bold text-warning dark:text-warning">
                  ${stats.totalPartiallyPaid.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
              
              <div 
                className={`flex flex-col gap-1 p-3 rounded-lg cursor-pointer transition-all border ${statusFilter === 'Denied' ? 'bg-destructive/10 border-destructive shadow-sm dark:bg-destructive/20' : 'hover:bg-muted border-transparent dark:hover:bg-muted/20'}`}
                onClick={() => setStatusFilter(statusFilter === 'Denied' ? 'all' : 'Denied')}
              >
                <span className="text-[10px] text-destructive font-semibold uppercase dark:text-destructive">Denied</span>
                <div className="text-sm font-bold text-destructive dark:text-destructive">
                  ${stats.totalDenied.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground dark:text-slate-300 uppercase">Total Invoiced</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold dark:text-slate-50">
              ${invoices.reduce((sum, inv) => sum + Number(inv.subtotal), 0).toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground dark:text-slate-400 mt-1">Current workspace total</p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <Tabs defaultValue="unbilled" className="w-full">
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger 
                value="unbilled" 
                className="gap-2 data-[state=active]:text-brand-blue data-[state=active]:border-brand-blue"
                disabled={!hasBillingAccess}
              >
                <DollarSign className="h-4 w-4" />
                Not Billed Items
              </TabsTrigger>
              <TabsTrigger 
                value="invoices" 
                className="gap-2 data-[state=active]:text-brand-blue data-[state=active]:border-brand-blue"
                disabled={!hasBillingAccess}
              >
                <FileText className="h-4 w-4" />
                Invoices
              </TabsTrigger>
            </TabsList>
            
            <div className="flex gap-2">
              <Button size="sm" onClick={() => setIsDialogOpen(true)} disabled={!hasBillingAccess} variant="brand">
                <Plus className="mr-2 h-4 w-4" />
                {selectedItemIds.length > 0 ? `Invoice Selected (${selectedItemIds.length})` : 'Generate Invoice'}
              </Button>
            </div>
          </div>

          <TabsContent value="unbilled">
            <div className="rounded-md border bg-card overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40px]"></TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Client</TableHead>
                    <TableHead>Service</TableHead>
                    <TableHead>Qty</TableHead>
                    <TableHead>Rate</TableHead>
                    {statusFilter === 'Partially Paid' ? (
                      <>
                        <TableHead>Paid</TableHead>
                        <TableHead>Remaining</TableHead>
                      </>
                    ) : (
                      <TableHead>Total</TableHead>
                    )}
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center">Loading unbilled items...</TableCell>
                    </TableRow>
                  ) : filteredItems.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="h-auto py-12">
                        <Empty 
                          icon={DollarSign}
                          title={statusFilter === 'all' ? "No unbilled items" : `No ${statusFilter} items`}
                          description={statusFilter === 'all' ? "Not billed items appear here automatically when services are completed." : `Items marked as ${statusFilter} will appear here.`}
                        />
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredItems.map((item) => (
                      <TableRow key={item.id} className={item.missing_rate ? "bg-destructive/5" : ""}>
                        <TableCell>
                          <Checkbox 
                            checked={selectedItemIds.includes(item.id)}
                            onCheckedChange={() => toggleItemSelection(item.id)}
                          />
                        </TableCell>
                        <TableCell className="text-sm">
                          {new Date(item.service_date).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="text-sm">
                          {item.clients?.first_name} {item.clients?.last_name}
                          {(item.billing_status?.toLowerCase() === 'partially paid' || item.billing_status?.toLowerCase() === 'partial paid' || item.billing_status?.toLowerCase() === 'partial_paid') && (
                            <div className="flex items-center gap-1 mt-0.5">
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Badge variant="outline" className="text-[9px] h-4 py-0 bg-warning/10 text-warning border-warning/20 cursor-help">
                                      Reminder
                                    </Badge>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p className="text-[10px]">Follow up on remaining balance: ${Number(item.remaining_amount).toFixed(2)}</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-sm">
                          {item.service_templates?.name}
                        </TableCell>
                        <TableCell className="text-sm">
                          {Number(item.quantity).toFixed(2)}
                        </TableCell>
                        <TableCell className="text-sm">
                          ${Number(item.rate_amount).toFixed(2)}
                        </TableCell>
                        {statusFilter.toLowerCase() === 'partially paid' ? (
                          <>
                            <TableCell className="text-sm font-medium text-success">
                              ${Number(item.paid_amount || 0).toFixed(2)}
                            </TableCell>
                            <TableCell className="text-sm font-medium text-warning">
                              ${Number(item.remaining_amount !== undefined && item.remaining_amount !== null ? item.remaining_amount : item.line_total).toFixed(2)}
                            </TableCell>
                          </>
                        ) : (
                          <TableCell className="text-sm font-medium">
                            ${Number(item.line_total).toFixed(2)}
                            {(item.billing_status?.toLowerCase() === 'partially paid' || item.billing_status?.toLowerCase() === 'partial paid' || item.billing_status?.toLowerCase() === 'partial_paid') && (
                              <div className="text-[10px] text-muted-foreground dark:text-slate-400 flex flex-col">
                                <span>Paid: ${Number(item.paid_amount || 0).toFixed(2)}</span>
                                <span className="text-warning font-medium dark:text-warning">Bal: ${Number(item.remaining_amount ?? (Number(item.line_total) - Number(item.paid_amount || 0))).toFixed(2)}</span>
                              </div>
                            )}
                          </TableCell>
                        )}
                        <TableCell>
                          {item.missing_rate ? (
                            <Badge variant="destructive" className="text-[10px]">Missing Rate</Badge>
                          ) : (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className={`h-7 px-2 text-[10px] gap-1 border-dashed hover:border-solid ${(item.billing_status?.toLowerCase() === 'partially paid' || item.billing_status?.toLowerCase() === 'partial paid' || item.billing_status?.toLowerCase() === 'partial_paid') ? 'border-warning text-warning bg-warning/5 dark:bg-warning/10 dark:text-warning' : ''}`}
                                >
                                  {item.billing_status?.toLowerCase() === 'unbilled' ? 'Not Billed' : item.billing_status}
                                  {(item.billing_status?.toLowerCase() === 'partially paid' || item.billing_status?.toLowerCase() === 'partial paid' || item.billing_status?.toLowerCase() === 'partial_paid') && <AlertCircleIcon className="h-3 w-3" />}
                                  <ChevronDown className="h-3 w-3 opacity-50" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => handleUpdateStatus(item, 'Unbilled')}>
                                  Not Billed
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleUpdateStatus(item, 'Paid')}>
                                  Fully Paid
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleUpdateStatus(item, 'Partially Paid')}>
                                  Partially Paid
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleUpdateStatus(item, 'Denied')}>
                                  Denied
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="invoices">
            <div className="rounded-md border bg-card overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice #</TableHead>
                    <TableHead>Client</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="h-24 text-center">Loading invoices...</TableCell>
                    </TableRow>
                  ) : invoices.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="h-auto py-12">
                        <Empty 
                          icon={FileClock}
                          title="No invoices generated"
                          description="Invoices are generated from approved service records."
                          action={
                            <Button onClick={() => setIsDialogOpen(true)} disabled={stats.approvedEventsCount === 0 && unbilledItems.length === 0}>
                              <Plus className="mr-2 h-4 w-4" />
                              Generate First Invoice
                            </Button>
                          }
                        />
                      </TableCell>
                    </TableRow>
                  ) : (
                    invoices.map((inv) => (
                      <TableRow key={inv.id}>
                        <TableCell className="font-medium">
                          <Link to={`/billing/invoices/${inv.id}`} className="text-primary hover:underline flex items-center gap-2">
                            <Receipt className="h-3 w-3" />
                            {inv.invoice_number}
                          </Link>
                        </TableCell>
                        <TableCell>{inv.clients?.first_name} {inv.clients?.last_name}</TableCell>
                        <TableCell className="text-xs dark:text-slate-300">
                          {new Date(inv.period_start).toLocaleDateString()} - {new Date(inv.period_end).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="font-medium">${Number(inv.subtotal).toFixed(2)}</TableCell>
                        <TableCell>
                          <Badge variant={
                            inv.status === 'Paid' ? 'success' : 
                            inv.status === 'Sent' ? 'warning' : 'secondary'
                          }>
                            {inv.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="ghost" 
                                    size="icon"
                                    onClick={() => handleEmailInvoice(inv)}
                                    disabled={loading || !inv.clients?.email}
                                  >
                                    <Mail className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs">Email Invoice to Client</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                            <Button variant="ghost" size="icon" onClick={() => handlePrintInvoice(inv)}>
                              <Printer className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Generate New Invoice</DialogTitle>
              <DialogDescription>
                Select a client and date range to pull approved service events.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleGenerateInvoice} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="clientSelect">Client</Label>
                <Select value={selectedClientId} onValueChange={setSelectedClientId} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select client" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.first_name} {c.last_name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start">Period Start</Label>
                  <Input id="start" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end">Period End</Label>
                  <Input id="end" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} required />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button type="submit">Generate</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={!!partialPaymentItem} onOpenChange={(open) => !open && setPartialPaymentItem(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Record Partial Payment</DialogTitle>
              <DialogDescription>
                Enter the amount paid and the remaining balance for this service.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handlePartialPaymentSubmit} className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="paidAmount">Amount Paid</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="paidAmount" 
                      type="number" 
                      step="0.01" 
                      className="pl-9"
                      value={paidAmount} 
                      onChange={(e) => {
                        setPaidAmount(e.target.value);
                        if (partialPaymentItem) {
                          const total = Number(partialPaymentItem.line_total);
                          const paid = parseFloat(e.target.value) || 0;
                          setRemainingAmount((total - paid).toFixed(2));
                        }
                      }} 
                      required 
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="remainingAmount">Remaining Balance</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input 
                      id="remainingAmount" 
                      type="number" 
                      step="0.01" 
                      className="pl-9"
                      value={remainingAmount} 
                      onChange={(e) => setRemainingAmount(e.target.value)} 
                      required 
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setPartialPaymentItem(null)}>Cancel</Button>
                <Button type="submit">Save Payment</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Invoice Print View (Only visible when printing) */}
        {printingInvoice && (
          <div className="hidden print:block fixed inset-0 bg-white z-[9999] p-12 overflow-y-auto">
            <div className="max-w-4xl mx-auto space-y-8">
              <div className="flex justify-between items-start border-b pb-8">
                <div>
                  <h1 className="text-4xl font-bold text-primary mb-2">{activeWorkspace?.name}</h1>
                  <div className="text-sm text-muted-foreground">
                    <p>Invoicing & Financial Services</p>
                    <p>{activeWorkspace?.id}</p>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  <h2 className="text-2xl font-bold uppercase tracking-widest text-muted-foreground">Invoice</h2>
                  <p className="text-lg font-bold">#{printingInvoice.invoice_number}</p>
                  <p className="text-sm">Date: {new Date(printingInvoice.created_at).toLocaleDateString()}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-12 py-8">
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground border-b pb-2">Bill To</h3>
                  <div className="space-y-1">
                    <p className="text-xl font-bold">{printingInvoice.clients?.first_name} {printingInvoice.clients?.last_name}</p>
                    <p className="text-sm">{printingInvoice.clients?.address || 'No address provided'}</p>
                    <p className="text-sm">{printingInvoice.clients?.email}</p>
                    <p className="text-sm">{printingInvoice.clients?.phone}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground border-b pb-2">Invoice Summary</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground dark:text-slate-400">Service Period:</span>
                      <span className="font-medium dark:text-slate-200">
                        {new Date(printingInvoice.period_start).toLocaleDateString()} - {new Date(printingInvoice.period_end).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Status:</span>
                      <Badge variant="outline" className="h-5">{printingInvoice.status}</Badge>
                    </div>
                  </div>
                </div>
              </div>

              <div className="py-8">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b-2 border-primary text-left">
                      <th className="py-4 text-xs font-bold uppercase tracking-wider">Description</th>
                      <th className="py-4 text-xs font-bold uppercase tracking-wider text-right">Qty</th>
                      <th className="py-4 text-xs font-bold uppercase tracking-wider text-right">Rate</th>
                      <th className="py-4 text-xs font-bold uppercase tracking-wider text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {printingLines.map((line) => (
                      <tr key={line.id} className="border-b">
                        <td className="py-4 text-sm font-medium">{line.description}</td>
                        <td className="py-4 text-sm text-right">{Number(line.qty).toFixed(2)}</td>
                        <td className="py-4 text-sm text-right">${Number(line.rate).toFixed(2)}</td>
                        <td className="py-4 text-sm font-bold text-right">${Number(line.line_total).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan={3} className="py-8 text-right font-bold text-lg">Invoice Total</td>
                      <td className="py-8 text-right font-bold text-2xl text-primary">${Number(printingInvoice.subtotal).toFixed(2)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              <div className="pt-12 border-t mt-12 space-y-4">
                <p className="text-xs text-muted-foreground text-center">
                  Thank you for choosing {activeWorkspace?.name}. Please include invoice #{printingInvoice.invoice_number} with your payment.
                </p>
                <p className="text-[10px] text-muted-foreground text-center italic">
                  This is a computer-generated document and does not require a physical signature for validity.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
