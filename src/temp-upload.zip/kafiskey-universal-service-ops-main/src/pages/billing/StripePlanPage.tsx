import React, { useState, useEffect } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check, Zap, Building, Crown, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { blink } from '@/lib/blink';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { clsx } from 'clsx';

export const StripePlanPage: React.FC = () => {
  const { activeWorkspace, refreshWorkspaces, activeMember } = useWorkspace();
  const { user, signOut, isSuperAdmin } = useAuth();
  const [loading, setLoading] = useState<string | null>(null);
  const [interval, setIntervalType] = useState<'monthly' | 'yearly'>('monthly');
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [isActivating, setIsActivating] = useState(false);

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    if (sessionId && activeWorkspace?.plan_status === 'pending_payment') {
      setIsActivating(true);
      const interval = setInterval(async () => {
        const { data } = await supabase
          .from('workspaces')
          .select('plan_status')
          .eq('id', activeWorkspace.id)
          .single();
        
        if (data?.plan_status && data.plan_status !== 'pending_payment') {
          clearInterval(interval);
          await refreshWorkspaces();
          setIsActivating(false);
          toast.success('Subscription activated! Redirecting to dashboard...');
          navigate('/');
        }
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [searchParams, activeWorkspace, refreshWorkspaces, navigate]);

  const plans = [
    {
      key: 'community',
      name: 'Community',
      monthlyPrice: '$0',
      yearlyPrice: '$0',
      monthlyPriceId: 'free',
      yearlyPriceId: 'free',
      description: 'Stop using notebooks. Start professionalizing.',
      features: ['1 user only', 'Maximum 3 active clients', 'Client intake profiles', 'Secure document storage', 'Basic case notes', 'Service/session tracking'],
      icon: Building,
      current: activeWorkspace?.plan_key === 'community' || !activeWorkspace?.plan_key
    },
    {
      key: 'growth',
      name: 'Growth',
      monthlyPrice: '$39',
      yearlyPrice: '$390',
      monthlyPriceId: 'price_1Smd1yE2BM4BBmCcVlAXayeO', // Keep old ID but rename
      yearlyPriceId: 'price_1Smd1yE2BM4BBmCcVlAXayeO_yearly', 
      description: 'Run daily operations without the headache.',
      features: ['Up to 10 users', 'Unlimited clients', 'Invoicing & billing workflows', 'Staff scheduling & assignments', 'Expiring document alerts', 'Timesheets', 'Digital signatures'],
      icon: Zap,
      recommended: true,
      current: activeWorkspace?.plan_key === 'growth'
    },
    {
      key: 'scale',
      name: 'Scale',
      monthlyPrice: '$79',
      yearlyPrice: '$790',
      monthlyPriceId: 'price_1Smd2AE2BM4BBmCctdgST4Sd', // Keep old ID but rename
      yearlyPriceId: 'price_1Smd2AE2BM4BBmCctdgST4Sd_yearly',
      description: 'Scale with audit-ready confidence.',
      features: ['Unlimited users', 'Unlimited clients', 'Program-based management', 'Payroll exports', 'Audit preparation & review logs', 'Quality assurance (QA) workflows', 'Advanced reporting & permissions', 'Data exports & integrations'],
      icon: Crown,
      current: activeWorkspace?.plan_key === 'scale'
    }
  ];

  const handleSubscribe = async (planKey: string) => {
    if (!activeWorkspace || !user) {
      toast.error('You must be logged in to subscribe');
      return;
    }

    if (activeMember?.role !== 'OWNER' && activeMember?.role !== 'ADMIN') {
      toast.error('Only workspace owners or admins can manage subscriptions');
      return;
    }

    setLoading(planKey);
    try {
      const selectedPlan = plans.find(p => p.key === planKey);
      const finalPriceId = interval === 'monthly' ? selectedPlan?.monthlyPriceId : selectedPlan?.yearlyPriceId;

      const { data, error } = await blink.functions.invoke('stripe-checkout', {
        body: {
          workspaceId: activeWorkspace.id,
          planKey,
          priceId: finalPriceId,
          userEmail: user.email
        }
      });
      
      if (error) throw error;
      
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      toast.error(err.message || 'Failed to start checkout process');
    } finally {
      setLoading(null);
    }
  };

  const isPaid = activeWorkspace?.access_state === 'ACTIVE_PAID' || activeWorkspace?.plan_status === 'active';
  const isTrialActive = activeWorkspace?.access_state === 'TRIAL_ACTIVE' || ['trialing', 'trial'].includes(activeWorkspace?.plan_status || '');
  const isPendingPayment = !isPaid && !isTrialActive && !isSuperAdmin;
  const canManage = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN' || isSuperAdmin;

  return (
    <div className="space-y-8 animate-fade-in">
      {isActivating && (
        <Alert className="bg-primary/10 border-primary/20">
          <RefreshCw className="h-4 w-4 animate-spin text-primary" />
          <AlertTitle>Activating your workspace...</AlertTitle>
          <AlertDescription>
            We've received your payment information. Hang tight while we set up your subscription.
          </AlertDescription>
        </Alert>
      )}

      {isPendingPayment && !isActivating && (
        <Alert variant="destructive" className="bg-destructive/10 border-destructive/20 text-destructive-foreground">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Action Required: Complete Billing</AlertTitle>
          <AlertDescription>
            {canManage 
              ? "Your workspace has been created, but a payment method is required to start your 30-day free trial and access the platform."
              : "This workspace is currently awaiting payment. Please contact your workspace administrator to activate the subscription."}
          </AlertDescription>
        </Alert>
      )}

      <div className="text-center space-y-4">
        <div className="flex justify-center mb-2">
          <div className="w-12 h-1 bg-brand-gradient rounded-full" />
        </div>
        <h2 className="text-3xl font-bold uppercase tracking-tight bg-brand-gradient bg-clip-text text-transparent drop-shadow-sm">Select Your Plan</h2>
        <p className="text-muted-foreground dark:text-slate-300 max-w-2xl mx-auto">
          Kafiskey organizes and standardizes operational data so it is ready for state mandates and audits. Choose the plan that fits your growth stage.
        </p>
        
        <div className="flex items-center justify-center gap-4 pt-4">
          <span className={`text-sm font-medium ${interval === 'monthly' ? 'text-foreground' : 'text-muted-foreground'}`}>Monthly</span>
          <Button
            variant="outline"
            size="sm"
            className="w-12 h-6 p-0 rounded-full relative bg-muted"
            onClick={() => setIntervalType(prev => prev === 'monthly' ? 'yearly' : 'monthly')}
          >
            <div className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-primary transition-all duration-200 ${interval === 'yearly' ? 'translate-x-6' : ''}`} />
          </Button>
          <div className="flex items-center gap-2">
            <span className={`text-sm font-medium ${interval === 'yearly' ? 'text-foreground' : 'text-muted-foreground'}`}>Yearly</span>
            <Badge variant="success" className="text-[10px] px-1.5 py-0 h-4">Save ~17%</Badge>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8">
        {plans.map((plan) => (
          <Card key={plan.name} className={clsx(
            "relative flex flex-col transition-all overflow-hidden",
            plan.recommended ? 'border-brand-blue ring-2 ring-brand-blue/30 shadow-2xl scale-105 z-10 bg-white dark:bg-card/95' : 'border-border/60 hover:border-brand-blue/30 bg-white dark:bg-card/90'
          )}>
            {plan.recommended && (
              <div className="absolute top-0 right-0">
                <div className="bg-brand-gradient text-white text-[10px] font-black uppercase tracking-widest px-10 py-2 rotate-45 translate-x-10 translate-y-2 shadow-lg">
                  Recommended
                </div>
              </div>
            )}
            <div className={clsx(
              "absolute top-0 left-0 w-full h-1",
              plan.key === 'community' ? 'bg-brand-teal' : 
              plan.key === 'growth' ? 'bg-brand-blue' : 'bg-brand-purple'
            )} />
            <CardHeader>
              <div className={clsx(
                "flex items-center gap-2 mb-2 font-bold uppercase tracking-wider text-xs",
                plan.key === 'community' ? 'text-brand-teal' : 
                plan.key === 'growth' ? 'text-brand-blue' : 'text-brand-purple'
              )}>
                <plan.icon className="h-5 w-5" />
                <span>{plan.name}</span>
              </div>
              <CardTitle className="text-3xl font-bold">
                {interval === 'monthly' ? plan.monthlyPrice : plan.yearlyPrice}
                <span className="text-sm font-normal text-muted-foreground dark:text-slate-400">/{interval === 'monthly' ? 'mo' : 'yr'}</span>
              </CardTitle>
              <CardDescription className="dark:text-slate-300">{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 text-sm text-foreground dark:text-slate-200">
                    <Check className="h-4 w-4 text-success shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter className="pt-6">
              <Button 
                className="w-full font-bold" 
                variant={plan.recommended ? 'brand' : 'outline'}
                disabled={plan.current || (loading !== null) || !canManage}
                onClick={() => handleSubscribe(plan.key)}
              >
                {loading === plan.key ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : null}
                {plan.current ? 'Current Plan' : (canManage ? 'Subscribe' : 'Awaiting Payment')}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {!canManage && (
        <div className="flex justify-center mt-8">
          <Button variant="outline" onClick={() => signOut()}>
            Sign Out & Try Another Account
          </Button>
        </div>
      )}

      <Card className="bg-muted/50 dark:bg-slate-900/50 border-dashed">
        <CardContent className="py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1">
            <h4 className="font-semibold dark:text-slate-100">Need help choosing the right plan?</h4>
            <p className="text-sm text-muted-foreground dark:text-slate-400">Our team can help you find the best setup for your organization's compliance needs.</p>
          </div>
          <Button variant="outline">Schedule a Demo</Button>
        </CardContent>
      </Card>
    </div>
  );
};