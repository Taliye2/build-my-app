import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Mail, Shield, MoreHorizontal, UserPlus, Info, RotateCcw, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { sendEmail } from '@/lib/emails';
import { Link } from 'react-router-dom';
import { logAudit } from '@/lib/audit';

interface Member {
  id: string;
  user_id: string;
  role: string;
  status: string;
  created_at: string;
  user_email?: string;
  full_name?: string;
}

interface Invite {
  id: string;
  email: string;
  role: string;
  status: string;
  created_at: string;
  full_name?: string;
  token?: string;
}

export const TeamPage: React.FC = () => {
  const { activeWorkspace, activeMember, canAddUser, planLimits, userCount } = useWorkspace();
  const [members, setMembers] = useState<Member[]>([]);
  const [invites, setInvites] = useState<Invite[]>([]);
  const [loading, setLoading] = useState(true);
  const [isInviteOpen, setIsInviteOpen] = useState(false);

  // Form state
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteRole, setInviteRole] = useState('Staff');

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    // Fetch workspace_members and invites for this workspace
    const [membersRes, invitesRes] = await Promise.all([
      supabase.from('workspace_members').select('*').eq('workspace_id', activeWorkspace.id),
      supabase.from('invites').select('*').eq('workspace_id', activeWorkspace.id).eq('status', 'pending')
    ]);

    if (membersRes.data) setMembers(membersRes.data);
    if (invitesRes.data) setInvites(invitesRes.data as any);
    
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace) return;

    if (!canAddUser) {
      toast.error('User limit reached for your current plan. Please upgrade to add more teammates.');
      return;
    }

    const token = window.crypto.randomUUID();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const { error } = await supabase.from('invites').insert({
      workspace_id: activeWorkspace.id,
      email: inviteEmail.toLowerCase().trim(),
      full_name: inviteName.trim(),
      role: inviteRole.toUpperCase(),
      token,
      status: 'pending',
      expires_at: expiresAt.toISOString()
    });

    if (error) {
      toast.error(error.message);
    } else {
      // Log audit event for invitation
      if (activeWorkspace && activeMember) {
        logAudit(
          activeWorkspace.id,
          activeMember.user_id,
          'INVITE_SENT',
          'invite',
          inviteEmail,
          { role: inviteRole, name: inviteName }
        );
      }

      // Send the email invitation
      try {
        const inviteLink = `${window.location.origin}/auth?invite=${token}`;
        await sendEmail({
          to: inviteEmail,
          subject: `You've been invited to join ${activeWorkspace.name} on Kafiskey`,
          html: `
            <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #0D9488;">Welcome to Kafiskey</h2>
              <p>You have been invited to join the <strong>${activeWorkspace.name}</strong> workspace as a <strong>${inviteRole}</strong>.</p>
              <p>Kafiskey is your universal service operations platform for documentation, compliance, and team collaboration.</p>
              <div style="margin: 32px 0;">
                <a href="${inviteLink}" style="background-color: #0D9488; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">
                  Accept Invitation
                </a>
              </div>
              <p style="color: #666; font-size: 14px;">If you didn't expect this invitation, you can safely ignore this email.</p>
              <hr style="border: none; border-top: 1px solid #eee; margin: 32px 0;" />
              <p style="color: #999; font-size: 12px;">&copy; ${new Date().getFullYear()} Kafiskey Universal Service Ops. All rights reserved.</p>
            </div>
          `,
          workspaceId: activeWorkspace.id
        });
        toast.success(`Invitation sent to ${inviteEmail}`);
      } catch (emailError) {
        console.error('Email error:', emailError);
        toast.error(`Invitation saved but email failed to send: ${emailError.message}`);
      }

      setIsInviteOpen(false);
      setInviteEmail('');
      fetchData();
    }
  };

  const getInitials = (id: string) => id.slice(0, 2).toUpperCase();

  const isManager = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN' || activeMember?.role === 'MANAGER';

  const handleRevokeInvite = async (inviteId: string) => {
    if (!activeWorkspace) return;
    
    if (!window.confirm('Are you sure you want to revoke this invitation?')) return;

    try {
      const { error } = await supabase
        .from('invites')
        .update({ status: 'revoked' })
        .eq('id', inviteId)
        .eq('workspace_id', activeWorkspace.id);

      if (error) {
        toast.error(`Failed to revoke invitation: ${error.message}`);
        return;
      }

      // Log audit event for revocation
      if (activeWorkspace && activeMember) {
        logAudit(
          activeWorkspace.id,
          activeMember.user_id,
          'INVITE_REVOKED',
          'invite',
          inviteId
        );
      }

      toast.success('Invitation revoked successfully');
      fetchData();
    } catch (err) {
      console.error('Revoke error:', err);
      toast.error('Failed to revoke invitation');
    }
  };

  const handleResendInvite = async (invite: any) => {
    if (!activeWorkspace) return;

    try {
      setLoading(true);
      const inviteLink = `${window.location.origin}/auth?invite=${invite.token}`;
      await sendEmail({
        to: invite.email,
        subject: `Reminder: You've been invited to join ${activeWorkspace.name} on Kafiskey`,
        html: `
          <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #0D9488;">Invitation Reminder</h2>
            <p>This is a reminder that you have a pending invitation to join the <strong>${activeWorkspace.name}</strong> workspace as a <strong>${invite.role}</strong>.</p>
            <div style="margin: 32px 0;">
              <a href="${inviteLink}" style="background-color: #0D9488; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; font-weight: bold;">
                Accept Invitation
              </a>
            </div>
            <p style="color: #666; font-size: 14px;">If you already have an account, please sign in to see your workspace switcher.</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 32px 0;" />
            <p style="color: #999; font-size: 12px;">&copy; ${new Date().getFullYear()} Kafiskey Universal Service Ops. All rights reserved.</p>
          </div>
        `,
        workspaceId: activeWorkspace.id
      });

      // Log audit event for resend
      if (activeWorkspace && activeMember) {
        logAudit(
          activeWorkspace.id,
          activeMember.user_id,
          'INVITE_RESENT',
          'invite',
          invite.id,
          { email: invite.email }
        );
      }

      toast.success(`Invitation resent to ${invite.email}`);
    } catch (err: any) {
      toast.error(`Failed to resend invitation: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const roleDescriptions: Record<string, string> = {
    'OWNER': 'Full control over workspace, billing, and all settings.',
    'ADMIN': 'Operational control and team management.',
    'MANAGER': 'Manage clients, service events, and invoices.',
    'STAFF': 'Primary service delivery and documentation.',
    'READ_ONLY': 'View-only access for auditors or supervisors.'
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {!canAddUser && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
              <UserPlus className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-sm font-bold text-amber-900">User Limit Reached</p>
              <p className="text-xs text-amber-700">Your current plan is limited to {planLimits.maxUsers} user{planLimits.maxUsers === 1 ? '' : 's'}. Upgrade your plan to add more teammates.</p>
            </div>
          </div>
          <Button size="sm" variant="outline" className="border-amber-300 hover:bg-amber-100" asChild>
            <Link to="/billing/plan">View Plans</Link>
          </Button>
        </div>
      )}

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold tracking-tight flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              Team Management
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Invite team members once services and workflows are configured.
            </p>
          </div>
          {isManager && (
            <Dialog open={isInviteOpen} onOpenChange={setIsInviteOpen}>
              <DialogTrigger asChild>
                <Button size="sm" disabled={!canAddUser}>
                  <UserPlus className="mr-2 h-4 w-4" />
                  Invite Teammate
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Invite Teammate</DialogTitle>
                  <DialogDescription>
                    Send an invitation to join your workspace.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSendInvite} className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="full_name">Full Name</Label>
                    <Input 
                      id="full_name" 
                      placeholder="Jane Doe" 
                      value={inviteName} 
                      onChange={(e) => setInviteName(e.target.value)} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="teammate@company.com" 
                      value={inviteEmail} 
                      onChange={(e) => setInviteEmail(e.target.value)} 
                      required 
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="role">Role</Label>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                          </TooltipTrigger>
                          <TooltipContent className="max-w-xs p-3">
                            <div className="space-y-2">
                              {Object.entries(roleDescriptions).map(([role, desc]) => (
                                <div key={role} className="text-xs">
                                  <span className="font-bold">{role}:</span> {desc}
                                </div>
                              ))}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <Select value={inviteRole} onValueChange={setInviteRole}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Admin">Admin</SelectItem>
                        <SelectItem value="Manager">Manager</SelectItem>
                        <SelectItem value="Staff">Staff</SelectItem>
                        <SelectItem value="READ_ONLY">ReadOnly (Auditor)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsInviteOpen(false)}>Cancel</Button>
                    <Button type="submit">Send Invitation</Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>

        <div className="rounded-md border bg-card overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center">Loading members...</TableCell>
                </TableRow>
              ) : members.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">
                    No team members yet. Invite your first teammate to get started.
                  </TableCell>
                </TableRow>
              ) : (
                members.map((member) => (
                  <TableRow key={member.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback>{getInitials(member.full_name || member.user_id)}</AvatarFallback>
                        </Avatar>
                        <div className="flex flex-col">
                          <span className="text-sm">{member.full_name || `User ${member.user_id.slice(0, 8)}`}</span>
                          {member.user_id === activeMember?.user_id && <span className="text-[10px] text-primary font-bold">(You)</span>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="flex items-center gap-1.5 w-fit">
                        {member.role}
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Info className="h-3 w-3 text-muted-foreground cursor-help" />
                            </TooltipTrigger>
                            <TooltipContent>
                              <p className="text-xs">{roleDescriptions[member.role] || 'Standard access'}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={member.status?.toLowerCase() === 'active' ? 'success' : 'secondary'}>
                        {member.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs">{new Date(member.created_at).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {invites.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium flex items-center gap-2">
              <Mail className="h-5 w-5 text-muted-foreground" />
              Active Invitations
            </h3>
            <p className="text-xs text-muted-foreground italic">Invitations expire after 7 days.</p>
          </div>
          <div className="rounded-md border bg-card overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Sent At</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invites.map((invite: any) => (
                  <TableRow key={invite.id}>
                    <TableCell className="font-medium">{invite.full_name || 'N/A'}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{invite.email}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{invite.role}</Badge>
                    </TableCell>
                    <TableCell className="text-xs">{new Date(invite.created_at).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 gap-1.5"
                          onClick={() => handleResendInvite(invite)}
                        >
                          <RotateCcw className="h-3.5 w-3.5" />
                          Resend
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 text-destructive hover:text-destructive hover:bg-destructive/10 gap-1.5"
                          onClick={() => handleRevokeInvite(invite.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          Revoke
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
};
