import React, { useEffect, useState } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Wallet, Search, Filter, Download, CheckCircle2, ChevronRight, Eye } from 'lucide-react';
import { Empty } from '@/components/ui/empty';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { format, startOfMonth, endOfMonth, parseISO } from 'date-fns';
import { QuickBooksSync } from './components/QuickBooksSync';
import { TrialPreviewBanner } from '@/components/TrialPreviewBanner';

interface PayrollItem {
  provider_id: string;
  provider_name: string;
  service_count: number;
  total_units: number;
  total_amount: number;
  status: 'Pending' | 'Approved' | 'Paid';
  events: any[];
}

export const PayrollPage: React.FC = () => {
  const { activeWorkspace } = useWorkspace();
  const [payrollItems, setPayrollItems] = useState<PayrollItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState(format(new Date(), 'yyyy-MM'));
  const [selectedProvider, setSelectedProvider] = useState<PayrollItem | null>(null);

  useEffect(() => {
    if (activeWorkspace) {
      fetchPayrollData();
    }
  }, [activeWorkspace, period]);

  const fetchPayrollData = async () => {
    setLoading(true);
    try {
      const start = startOfMonth(new Date(period));
      const end = endOfMonth(new Date(period));

      // Fetch service events with related data (no FK for staff_user_id)
      const { data, error } = await supabase
        .from('service_events')
        .select(`
          *,
          service_template:service_template_id (
            name,
            default_rate
          ),
          client:client_id (
            first_name,
            last_name
          )
        `)
        .eq('workspace_id', activeWorkspace?.id)
        .eq('status', 'APPROVED')
        .gte('date', format(start, 'yyyy-MM-dd'))
        .lte('date', format(end, 'yyyy-MM-dd'));

      if (error) throw error;

      // Get unique staff user IDs to fetch their names
      const staffUserIds = [...new Set(data?.map(e => e.staff_user_id).filter(Boolean) || [])];
      
      // Fetch workspace members to get display info
      let staffNameMap: Record<string, string> = {};
      if (staffUserIds.length > 0) {
        const { data: members } = await supabase
          .from('workspace_members')
          .select('user_id')
          .eq('workspace_id', activeWorkspace?.id)
          .in('user_id', staffUserIds);
        
        // For now, use truncated user IDs as names since auth.users is not directly accessible
        // In production, you'd have a profiles table with display names
        staffUserIds.forEach(id => {
          staffNameMap[id] = `Staff ${id.slice(0, 8)}`;
        });
      }

      // Aggregate by provider
      const aggregated: Record<string, PayrollItem> = {};
      
      data?.forEach((event) => {
        const providerId = event.staff_user_id;
        const providerName = staffNameMap[providerId] || `User ${providerId?.slice(0, 8) || 'Unknown'}`;
        const rate = event.service_template?.default_rate || 0;
        const units = event.units || 1;
        const amount = units * rate;

        if (!aggregated[providerId]) {
          aggregated[providerId] = {
            provider_id: providerId,
            provider_name: providerName,
            service_count: 0,
            total_units: 0,
            total_amount: 0,
            status: 'Pending',
            events: [],
          };
        }

        aggregated[providerId].service_count += 1;
        aggregated[providerId].total_units += units;
        aggregated[providerId].total_amount += amount;
        aggregated[providerId].events.push(event);
      });

      setPayrollItems(Object.values(aggregated));
    } catch (error: any) {
      console.error('Error fetching payroll data:', error);
      toast.error('Failed to load payroll data');
    } finally {
      setLoading(false);
    }
  };

  const handleApproveAll = () => {
    toast.success('All payroll items approved for payment');
  };

  const handleExport = () => {
    toast.success('Payroll report exported to CSV');
  };

  return (
    <div className="space-y-6">
      <TrialPreviewBanner featureName="Payroll" />
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Payroll</h2>
          <p className="text-muted-foreground">
            Provider compensation tracking based on approved service records.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <QuickBooksSync payrollItems={payrollItems} period={period} />
          <Button variant="outline" className="gap-2" onClick={handleExport}>
            <Download className="h-4 w-4" />
            Export CSV
          </Button>
          <Button className="gap-2" onClick={handleApproveAll} disabled={payrollItems.length === 0}>
            <CheckCircle2 className="h-4 w-4" />
            Approve All
          </Button>
        </div>
      </div>

      <div className="flex items-center gap-4 bg-muted/50 p-4 rounded-lg border">
        <div className="flex flex-col gap-1.5 flex-1 max-w-[200px]">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Pay Period</span>
          <Select value={period} onValueChange={setPeriod}>
            <SelectTrigger>
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2026-01">January 2026</SelectItem>
              <SelectItem value="2025-12">December 2025</SelectItem>
              <SelectItem value="2025-11">November 2025</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-col gap-1.5 border-l pl-4">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Total Amount</span>
          <span className="text-xl font-bold">
            ${payrollItems.reduce((acc, item) => acc + item.total_amount, 0).toLocaleString()}
          </span>
        </div>
        <div className="flex flex-col gap-1.5 border-l pl-4">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Total Providers</span>
          <span className="text-xl font-bold">{payrollItems.length}</span>
        </div>
      </div>

      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      ) : payrollItems.length === 0 ? (
        <Empty
          icon={Wallet}
          title="No payroll records"
          description="Payroll is generated from approved service records."
          action={
            <Button variant="outline" onClick={() => fetchPayrollData()}>
              Refresh Data
            </Button>
          }
        />
      ) : (
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Provider</TableHead>
                <TableHead>Approved Services</TableHead>
                <TableHead>Units / Hours</TableHead>
                <TableHead>Total Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payrollItems.map((item) => (
                <TableRow key={item.provider_id}>
                  <TableCell className="font-medium">{item.provider_name}</TableCell>
                  <TableCell>{item.service_count}</TableCell>
                  <TableCell>{item.total_units.toFixed(2)}</TableCell>
                  <TableCell>${item.total_amount.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="capitalize">
                      {item.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" className="gap-2" onClick={() => setSelectedProvider(item)}>
                      <Eye className="h-4 w-4" />
                      View Details
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={!!selectedProvider} onOpenChange={(open) => !open && setSelectedProvider(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>{selectedProvider?.provider_name} - Payroll Details</DialogTitle>
            <DialogDescription>
              Service events for the period {period}.
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto mt-4 border rounded-md">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Units</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {selectedProvider?.events.map((event) => {
                  const rate = event.service_template?.default_rate || 0;
                  const units = event.units || 1;
                  const total = units * rate;
                  return (
                    <TableRow key={event.id}>
                      <TableCell className="text-xs">
                        {format(parseISO(event.date), 'MMM d, yyyy')}
                      </TableCell>
                      <TableCell className="text-xs font-medium">
                        {event.client?.first_name} {event.client?.last_name}
                      </TableCell>
                      <TableCell className="text-xs">
                        {event.service_template?.name}
                      </TableCell>
                      <TableCell className="text-xs">{units.toFixed(2)}</TableCell>
                      <TableCell className="text-xs">${rate.toLocaleString()}</TableCell>
                      <TableCell className="text-right text-xs font-bold">${total.toLocaleString()}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
          <div className="mt-4 flex justify-between items-center p-4 bg-muted rounded-lg">
            <span className="font-bold">Total Compensation</span>
            <span className="text-xl font-black text-primary">${selectedProvider?.total_amount.toLocaleString()}</span>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
