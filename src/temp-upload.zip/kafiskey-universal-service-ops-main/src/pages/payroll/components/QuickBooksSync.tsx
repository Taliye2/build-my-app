import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { blink } from '@/lib/blink';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { toast } from 'sonner';
import { ExternalLink, RefreshCw, CheckCircle2 } from 'lucide-react';

interface QuickBooksSyncProps {
  payrollItems: any[];
  period: string;
}

export const QuickBooksSync: React.FC<QuickBooksSyncProps> = ({ payrollItems, period }) => {
  const { activeWorkspace } = useWorkspace();
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    if (activeWorkspace) {
      checkConnection();
    }
  }, [activeWorkspace]);

  const checkConnection = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('quickbooks_connections')
        .select('id')
        .eq('workspace_id', activeWorkspace?.id)
        .single();
      
      setIsConnected(!!data);
    } catch (error) {
      setIsConnected(false);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async () => {
    try {
      const { data, error } = await blink.functions.invoke('quickbooks-oauth', {
        method: 'POST',
        body: { action: 'authorize', workspaceId: activeWorkspace?.id }
      });
      
      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (error: any) {
      console.error('QuickBooks connect error:', error);
      toast.error(error.message || 'Failed to initiate QuickBooks connection');
    }
  };

  const handleSync = async () => {
    if (payrollItems.length === 0) {
      toast.error('No payroll items to sync');
      return;
    }

    setSyncing(true);
    try {
      const { data, error } = await blink.functions.invoke('quickbooks-sync', {
        body: {
          workspaceId: activeWorkspace?.id,
          payrollItems,
          period,
        },
      });

      if (error) throw error;

      toast.success('Payroll synced to QuickBooks successfully');
    } catch (error: any) {
      console.error('QuickBooks sync error:', error);
      toast.error(error.message || 'Failed to sync to QuickBooks');
    } finally {
      setSyncing(false);
    }
  };

  if (loading) return null;

  return (
    <div className="flex items-center gap-2">
      {!isConnected ? (
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2 bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
          onClick={handleConnect}
        >
          <ExternalLink className="h-4 w-4" />
          Connect QuickBooks
        </Button>
      ) : (
        <Button 
          variant="outline" 
          size="sm" 
          className="gap-2"
          onClick={handleSync}
          disabled={syncing || payrollItems.length === 0}
        >
          {syncing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
          {syncing ? 'Syncing...' : 'Sync to QuickBooks'}
        </Button>
      )}
    </div>
  );
};
