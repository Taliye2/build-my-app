import React, { useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';

export const QuickBooksCallbackPage: React.FC = () => {
  const [searchParams] = useSearchParams();

  useEffect(() => {
    // Redirect to the edge function with all query params
    const projectId = import.meta.env.VITE_BLINK_PROJECT_ID;
    const shortId = projectId.split('-').pop();
    const edgeFunctionUrl = `https://${shortId}--quickbooks-oauth.functions.blink.new`;
    const params = searchParams.toString();
    window.location.href = `${edgeFunctionUrl}?action=callback&${params}`;
  }, [searchParams]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-4">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        <p className="text-sm text-muted-foreground">Authenticating with QuickBooks...</p>
      </div>
    </div>
  );
};
