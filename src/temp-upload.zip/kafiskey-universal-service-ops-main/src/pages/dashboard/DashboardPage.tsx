import React, { useEffect, useState } from 'react';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Calendar,
  CalendarDays, 
  FileText, 
  TrendingUp, 
  Plus, 
  ArrowRight, 
  Clock, 
  AlertCircle,
  Receipt,
  CheckCircle2,
  CheckCircle,
  Briefcase,
  FileCheck,
  Sparkles
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';

export const DashboardPage: React.FC = () => {
  const { activeWorkspace, isLaunchpad } = useWorkspace();
  const [stats, setStats] = useState({
    clients: 0,
    activeServices: 0,
    pendingDocumentation: 0,
    pendingApprovals: 0,
    templates: 0,
    activePlan: false,
    scheduledToday: 0
  });
  const [activeSessions, setActiveSessions] = useState<any[]>([]);
  const [recentEvents, setRecentEvents] = useState<any[]>([]);
  const [chartData, setChartData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    const today = new Date();
    const todayStr = format(today, 'yyyy-MM-dd');

    const [clientsCount, servicesCount, approvalsCount, templatesCount, activeRes, recentRes, scheduledRes, activityRes] = await Promise.all([
      supabase.from('clients').select('*', { count: 'exact', head: true }).eq('workspace_id', activeWorkspace.id).eq('status', 'ACTIVE'),
      supabase.from('service_events').select('*', { count: 'exact', head: true }).eq('workspace_id', activeWorkspace.id),
      supabase.from('service_events').select('*', { count: 'exact', head: true }).eq('workspace_id', activeWorkspace.id).eq('status', 'SUBMITTED'),
      supabase.from('service_templates').select('*', { count: 'exact', head: true }).eq('workspace_id', activeWorkspace.id),
      supabase.from('service_events').select('*, clients(*), service_templates(*)').eq('workspace_id', activeWorkspace.id).eq('status', 'IN_PROGRESS'),
      supabase.from('service_events')
        .select('*, clients(*), service_templates(*)')
        .eq('workspace_id', activeWorkspace.id)
        .order('created_at', { ascending: false })
        .limit(5),
      supabase.from('service_events')
        .select('*', { count: 'exact', head: true })
        .eq('workspace_id', activeWorkspace.id)
        .eq('date', todayStr),
      supabase.from('service_events')
        .select('date')
        .eq('workspace_id', activeWorkspace.id)
        .gte('date', format(subDays(today, 6), 'yyyy-MM-dd'))
        .lte('date', todayStr)
    ]);

    // Calculate pending documentation (events without notes)
    // In our new schema, notes are in service_records
    const { data: events } = await supabase
      .from('service_events')
      .select('id')
      .eq('workspace_id', activeWorkspace.id);
    
    const { data: records } = await supabase
      .from('service_records')
      .select('service_event_id')
      .eq('workspace_id', activeWorkspace.id);
    
    const recordEventIds = new Set(records?.map(r => r.service_event_id) || []);
    const pendingDocs = events?.filter(ev => !recordEventIds.has(ev.id)).length || 0;

    setStats({
      clients: clientsCount.count || 0,
      activeServices: servicesCount.count || 0,
      pendingDocumentation: pendingDocs,
      pendingApprovals: approvalsCount.count || 0,
      templates: templatesCount.count || 0,
      activePlan: activeWorkspace.plan_status === 'active' || activeWorkspace.plan_status === 'trialing' || activeWorkspace.plan_status === 'trial',
      scheduledToday: scheduledRes.count || 0
    });
    
    setActiveSessions(activeRes.data || []);
    setRecentEvents(recentRes.data || []);

    // Process activity data for chart
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = subDays(today, i);
      const dateStr = format(d, 'yyyy-MM-dd');
      const count = activityRes.data?.filter(ev => ev.date === dateStr).length || 0;
      days.push({
        name: format(d, 'EEE'),
        events: count
      });
    }
    setChartData(days);

    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  const showChecklist = stats.clients === 0 || stats.templates === 0 || stats.activeServices === 0 || isLaunchpad;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-1.5 h-10 bg-brand-gradient rounded-full" />
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
            <p className="text-muted-foreground">Operational command center for your workspace.</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Badge variant="outline" className="px-3 py-1 border-brand-blue/20 bg-brand-blue/5 dark:bg-brand-blue/10 text-brand-blue dark:text-brand-teal font-bold">
            <Clock className="mr-2 h-3 w-3" />
            Operational Awareness &bull; {new Date().toLocaleDateString()}
          </Badge>
        </div>
      </div>

      {showChecklist && (
        <Card className={`relative overflow-hidden border-brand-blue/20 ${isLaunchpad ? 'bg-brand-blue/5 dark:bg-brand-blue/10 ring-2 ring-brand-blue/10' : 'bg-brand-blue/5 dark:bg-brand-blue/10'} shadow-sm`}>
          <div className="absolute top-0 left-0 w-1 h-full bg-brand-gradient" />
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <CardTitle className="text-lg flex items-center gap-2">
                  {isLaunchpad ? (
                    <>
                      <Sparkles className="h-5 w-5 text-brand-purple animate-pulse" />
                      Launchpad Guided Setup
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-5 w-5 text-brand-blue" />
                      Workspace Readiness
                    </>
                  )}
                </CardTitle>
                <CardDescription>
                  {isLaunchpad 
                    ? "Your high-touch implementation is active. Complete these steps to prepare for your setup call."
                    : "Complete these steps to activate full service delivery and documentation workflows."}
                </CardDescription>
              </div>
              {isLaunchpad && (
                <Badge className="bg-brand-gradient text-white border-none font-bold tracking-wider uppercase text-[10px]">Launchpad Active</Badge>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
              <ChecklistItem 
                title={isLaunchpad ? "1. Import Clients" : "Add a client"} 
                completed={stats.clients > 0} 
                link="/clients" 
              />
              <ChecklistItem 
                title={isLaunchpad ? "2. Add Staff" : "Add a provider"} 
                completed={stats.activeServices > 0} // Placeholder for provider check
                link="/providers" 
              />
              <ChecklistItem 
                title={isLaunchpad ? "3. Map Services" : "Create service templates"} 
                completed={stats.templates > 0} 
                link="/services" 
              />
              <ChecklistItem 
                title={isLaunchpad ? "4. Schedule Kickoff" : "Schedule services"} 
                completed={stats.activeServices > 0} 
                link="/services?tab=scheduling" 
              />
              <ChecklistItem 
                title={isLaunchpad ? "5. Document Initial" : "Complete documentation"} 
                completed={stats.pendingDocumentation === 0 && stats.activeServices > 0} 
                link="/services?tab=records" 
              />
              <ChecklistItem 
                title={isLaunchpad ? "6. Ready for Audit" : "Activate billing"} 
                completed={stats.activePlan} 
                link="/billing" 
              />
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-all hover:border-brand-purple/30 group relative overflow-hidden bg-white dark:bg-card">
          <div className="absolute top-0 left-0 w-full h-1 bg-brand-purple/10 dark:bg-brand-purple/20 group-hover:bg-brand-purple transition-smooth" />
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium dark:text-slate-200">Total Clients</CardTitle>
            <Users className="h-4 w-4 text-brand-purple" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold dark:text-slate-50">{loading ? '...' : stats.clients}</div>
            {stats.clients === 0 ? (
              <p className="text-xs text-muted-foreground dark:text-slate-400 mt-1">
                Add your first client to begin service delivery.
              </p>
            ) : (
              <p className="text-xs text-brand-green flex items-center gap-1 mt-1 font-bold">
                <TrendingUp className="h-3 w-3" /> Active and tracked
              </p>
            )}
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-all hover:border-brand-blue/30 group relative overflow-hidden bg-white dark:bg-card">
          <div className="absolute top-0 left-0 w-full h-1 bg-brand-blue/10 dark:bg-brand-blue/20 group-hover:bg-brand-blue transition-smooth" />
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium dark:text-slate-200">Services Delivered</CardTitle>
            <Briefcase className="h-4 w-4 text-brand-blue" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold dark:text-slate-50">{loading ? '...' : stats.activeServices}</div>
            {stats.activeServices === 0 ? (
              <p className="text-xs text-muted-foreground dark:text-slate-400 mt-1">
                Schedule services to track organizational activity.
              </p>
            ) : (
              <p className="text-xs text-muted-foreground dark:text-slate-400 mt-1">Total workspace lifetime</p>
            )}
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-all hover:border-brand-teal/30 group relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-brand-teal/10 group-hover:bg-brand-teal transition-smooth" />
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Documentation Due</CardTitle>
            <FileText className="h-4 w-4 text-brand-red" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : stats.pendingDocumentation}</div>
            <p className="text-xs text-brand-red font-medium mt-1">
              {stats.pendingDocumentation > 0 
                ? 'Requires completion for compliance.' 
                : 'All service events are documented.'}
            </p>
          </CardContent>
        </Card>
        <Card className="hover:shadow-md transition-all hover:border-brand-green/30 group relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-brand-green/10 group-hover:bg-brand-green transition-smooth" />
          <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <FileCheck className="h-4 w-4 text-brand-green" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : stats.pendingApprovals}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {stats.pendingApprovals > 0 
                ? 'Awaiting supervisory review.' 
                : 'No pending approvals required.'}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {activeSessions.length > 0 && (
            <Card className="border-brand-blue/20 bg-brand-blue/5 dark:bg-brand-blue/10 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-brand-blue" />
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 dark:text-slate-100">
                  <Clock className="h-5 w-5 text-brand-blue animate-pulse" />
                  Active Service Sessions
                </CardTitle>
                <CardDescription className="dark:text-slate-300">You have sessions currently in progress.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {activeSessions.map((session) => (
                    <div key={session.id} className="flex items-center justify-between p-3 rounded-lg bg-background dark:bg-slate-900 border shadow-sm">
                      <div>
                        <p className="font-medium dark:text-slate-100">{session.clients?.first_name} {session.clients?.last_name}</p>
                        <p className="text-xs text-muted-foreground dark:text-slate-400">{session.service_templates?.name}</p>
                      </div>
                      <Button size="sm" asChild>
                        <Link to={`/documentation/edit/${session.id}`}>Resume Session</Link>
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Service Activity</CardTitle>
              <CardDescription>Daily service delivery volume for the current week.</CardDescription>
            </CardHeader>
            <CardContent>
              {stats.activeServices === 0 ? (
                <div className="h-80 w-full flex flex-col items-center justify-center border-2 border-dashed rounded-lg text-muted-foreground p-8">
                  <TrendingUp className="h-12 w-12 opacity-10 mb-4" />
                  <p className="text-center font-medium">No activity data yet</p>
                  <p className="text-center text-sm max-w-xs mt-1">
                    Once you start scheduling and delivering services, activity patterns will appear here.
                  </p>
                </div>
              ) : (
                <div className="h-80 w-full mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData}>
                      <defs>
                        <linearGradient id="colorEvents" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--brand-blue))" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="hsl(var(--brand-blue))" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted))" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                      <YAxis axisLine={false} tickLine={false} tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 12}} />
                      <Tooltip 
                        contentStyle={{backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--brand-blue)/0.2)', borderRadius: '12px', boxShadow: 'var(--shadow-elegant)'}}
                        itemStyle={{color: 'hsl(var(--brand-blue))', fontWeight: 'bold'}}
                      />
                      <Area type="monotone" dataKey="events" stroke="hsl(var(--brand-blue))" fillOpacity={1} fill="url(#colorEvents)" strokeWidth={3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="hover:border-brand-blue/30 transition-smooth">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <CalendarDays className="h-5 w-5 text-brand-blue" />
                Today's Focus
              </CardTitle>
              <CardDescription>Daily operational awareness.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg border bg-muted/30">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Services Scheduled</p>
                  <p className="text-xs text-muted-foreground">{stats.scheduledToday} sessions scheduled today</p>
                </div>
                <Button size="icon" variant="ghost" asChild>
                  <Link to="/services?tab=scheduling"><ArrowRight className="h-4 w-4" /></Link>
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg border bg-muted/30">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Documentation Due</p>
                  <p className="text-xs text-muted-foreground">{stats.pendingDocumentation} records pending</p>
                </div>
                <Button size="icon" variant="ghost" asChild>
                  <Link to="/services?tab=records"><ArrowRight className="h-4 w-4" /></Link>
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg border bg-muted/30">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Payroll Pending</p>
                  <p className="text-xs text-muted-foreground">Review approved service records</p>
                </div>
                <Button size="icon" variant="ghost" asChild>
                  <Link to="/payroll"><ArrowRight className="h-4 w-4" /></Link>
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg border bg-muted/30">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Invoices Pending</p>
                  <p className="text-xs text-muted-foreground">Generate invoices for period</p>
                </div>
                <Button size="icon" variant="ghost" asChild>
                  <Link to="/billing"><ArrowRight className="h-4 w-4" /></Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Recent Events</CardTitle>
              <CardDescription>Latest entries across all clients.</CardDescription>
            </CardHeader>
            <CardContent>
              {recentEvents.length === 0 ? (
                <div className="py-8 flex flex-col items-center justify-center text-muted-foreground">
                  <Clock className="h-10 w-10 opacity-10 mb-3" />
                  <p className="text-sm">No recent events recorded.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {recentEvents.map((event, i) => (
                    <div key={event.id} className="flex items-center gap-4">
                      <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center text-muted-foreground font-medium text-xs">
                        {i + 1}
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-sm font-medium leading-none">
                          {event.clients?.first_name} {event.clients?.last_name}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          {event.service_templates?.name || 'General Service'}
                        </p>
                      </div>
                      <Badge 
                        variant={
                          event.status === 'APPROVED' ? 'success' : 
                          event.status === 'SUBMITTED' ? 'warning' : 
                          event.status === 'REJECTED' ? 'destructive' : 'secondary'
                        } 
                        className="text-[10px] px-1.5 py-0 h-4"
                      >
                        {event.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

const ChecklistItem = ({ title, completed, link }: { title: string, completed: boolean, link: string }) => (
  <Link 
    to={link} 
    className={`p-3 rounded-lg border transition-all flex flex-col gap-2 ${
      completed ? 'bg-background/50 dark:bg-slate-900/50 border-muted opacity-60 dark:opacity-80' : 'bg-background dark:bg-card hover:border-brand-blue/50 hover:shadow-sm group/item'
    }`}
  >
    <div className="flex items-center justify-between">
      {completed ? (
        <CheckCircle className="h-4 w-4 text-brand-green" />
      ) : (
        <div className="h-4 w-4 rounded-full border border-brand-blue/30 group-hover/item:border-brand-blue transition-smooth" />
      )}
      {!completed && <ArrowRight className="h-3 w-3 text-brand-blue opacity-0 group-hover/item:opacity-100 group-hover/item:translate-x-0.5 transition-all" />}
    </div>
    <span className={`text-xs font-bold leading-tight ${completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>{title}</span>
  </Link>
);