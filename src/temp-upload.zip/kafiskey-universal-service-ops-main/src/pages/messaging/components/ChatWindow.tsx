import React, { useState, useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, ChevronLeft } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { logAudit } from '@/lib/audit';

interface Message {
  id: string;
  sender_id: string;
  content: string;
  created_at: string;
  sender?: {
    full_name: string;
  };
}

interface ChatWindowProps {
  conversationId: string;
  onBack?: () => void;
  otherMember?: {
    full_name: string;
    email: string;
  };
}

export const ChatWindow: React.FC<ChatWindowProps> = ({ 
  conversationId, 
  onBack,
  otherMember 
}) => {
  const { user } = useAuth();
  const { activeWorkspace } = useWorkspace();
  const [messages, setMessages] = useState<Message[]>([]);
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchMessages();
    if (conversationId && activeWorkspace && user) {
      logAudit(activeWorkspace.id, user.id, 'VIEW', 'message_thread', conversationId);
    }

    // Subscribe to new messages
    const channel = supabase
      .channel(`messages:${conversationId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${conversationId}`,
        },
        async (payload) => {
          const newMessage = payload.new as Message;
          
          // Check if message already exists in state
          setMessages((prev) => {
            if (prev.some(m => m.id === newMessage.id)) return prev;
            
            // We'll add it without sender info first, then update it
            return [...prev, { ...newMessage }];
          });

          // Fetch sender info and update
          const { data: senderData } = await supabase
            .from('staff_profiles')
            .select('full_name')
            .eq('user_id', newMessage.sender_id)
            .maybeSingle();
          
          if (senderData) {
            setMessages((prev) => 
              prev.map((msg) => 
                msg.id === newMessage.id ? { ...msg, sender: senderData } : msg
              )
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [conversationId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const fetchMessages = async () => {
    setLoading(true);
    try {
      // Fetch messages
      const { data: messagesData, error: messagesError } = await supabase
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      if (messagesError) throw messagesError;

      if (!messagesData || messagesData.length === 0) {
        setMessages([]);
        return;
      }

      // Get unique sender IDs
      const senderIds = [...new Set(messagesData.map((m) => m.sender_id))];

      // Fetch sender profiles
      const { data: senderProfiles } = await supabase
        .from('staff_profiles')
        .select('user_id, full_name')
        .in('user_id', senderIds);

      // Create a map for quick lookup
      const senderMap = new Map(
        senderProfiles?.map((p) => [p.user_id, { full_name: p.full_name }]) || []
      );

      // Merge sender info with messages
      const messagesWithSender = messagesData.map((msg) => ({
        ...msg,
        sender: senderMap.get(msg.sender_id) || { full_name: 'Unknown' },
      }));

      setMessages(messagesWithSender);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() || !user || !activeWorkspace) return;

    const messageContent = content.trim();
    setContent('');

    // Optimistic update
    const tempId = `temp-${Date.now()}`;
    const optimisticMessage: Message = {
      id: tempId,
      sender_id: user.id,
      content: messageContent,
      created_at: new Date().toISOString(),
      sender: {
        full_name: user.user_metadata?.full_name || 'You'
      }
    };
    
    setMessages((prev) => [...prev, optimisticMessage]);

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          workspace_id: activeWorkspace.id,
          sender_id: user.id,
          content: messageContent,
        })
        .select()
        .single();

      if (error) throw error;

      // Update the optimistic message with the real one
      if (data) {
        setMessages((prev) => 
          prev.map((msg) => msg.id === tempId ? { ...data, sender: optimisticMessage.sender } : msg)
        );
      }
    } catch (error) {
      console.error('Error sending message:', error);
      // Remove optimistic message on error
      setMessages((prev) => prev.filter((msg) => msg.id !== tempId));
      setContent(messageContent); // Restore content
    }
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full overflow-hidden bg-background">
      {/* Mobile Chat Header */}
      {onBack && (
        <div className="p-3 border-b flex items-center gap-3 bg-card shrink-0">
          <Button variant="ghost" size="icon" onClick={onBack} className="md:hidden">
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2 min-w-0">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-[10px]">
                {otherMember?.full_name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col min-w-0">
              <span className="text-sm font-semibold truncate">{otherMember?.full_name || 'Chat'}</span>
              <span className="text-[10px] text-muted-foreground truncate">{otherMember?.email}</span>
            </div>
          </div>
        </div>
      )}

      <ScrollArea className="flex-1 p-4 md:p-6">
        <div className="space-y-4 pb-4">
          {messages.map((msg, index) => {
            const isMe = msg.sender_id === user?.id;
            const prevMsg = messages[index - 1];
            const isSameSender = prevMsg?.sender_id === msg.sender_id;
            
            return (
              <div
                key={msg.id}
                className={cn(
                  "flex flex-col max-w-[85%] md:max-w-[75%]",
                  isMe ? "ml-auto items-end" : "mr-auto items-start",
                  isSameSender ? "mt-1" : "mt-4"
                )}
              >
                {!isSameSender && (
                  <div className="flex items-center gap-2 mb-1 px-1">
                    <span className="text-[10px] font-medium text-muted-foreground">
                      {isMe ? 'You' : msg.sender?.full_name}
                    </span>
                    <span className="text-[10px] text-muted-foreground">
                      {format(new Date(msg.created_at), 'HH:mm')}
                    </span>
                  </div>
                )}
                <div
                  className={cn(
                    "px-3 py-2 text-sm shadow-sm transition-all break-words overflow-hidden",
                    isMe
                      ? "bg-primary text-primary-foreground rounded-2xl rounded-tr-sm"
                      : "bg-muted text-foreground rounded-2xl rounded-tl-sm"
                  )}
                >
                  {msg.content}
                </div>
              </div>
            );
          })}
          <div ref={scrollRef} className="h-2" />
        </div>
      </ScrollArea>
      
      <div className="p-4 border-t bg-card sticky bottom-0">
        <form onSubmit={handleSendMessage} className="flex gap-2 max-w-4xl mx-auto">
          <Input
            placeholder="Type a message..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="flex-1 rounded-full px-4"
            autoFocus={!onBack}
          />
          <Button 
            type="submit" 
            size="icon" 
            disabled={!content.trim()}
            className="rounded-full shrink-0"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
};
