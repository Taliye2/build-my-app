import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Search, UserPlus } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';

interface NewChatDialogProps {
  onSelectUser: (userId: string) => void | Promise<void>;
}

export const NewChatDialog: React.FC<NewChatDialogProps> = ({ onSelectUser }) => {
  const { activeWorkspace } = useWorkspace();
  const { user: currentUser } = useAuth();
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && activeWorkspace && currentUser) {
      fetchMembers();
    }
  }, [open, activeWorkspace, currentUser]);

  const fetchMembers = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('staff_profiles')
        .select('*')
        .eq('workspace_id', activeWorkspace?.id)
        .neq('user_id', currentUser?.id);

      if (error) throw error;
      setMembers(data || []);
    } catch (error) {
      console.error('Error fetching members:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredMembers = members.filter(member => 
    member.user_id && (
      (member.full_name || '').toLowerCase().includes(search.toLowerCase()) ||
      (member.email || '').toLowerCase().includes(search.toLowerCase())
    )
  );

  const handleSelect = async (userId: string) => {
    setOpen(false);
    await onSelectUser(userId);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon">
          <UserPlus className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>New Conversation</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search members..."
              className="pl-8"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <ScrollArea className="h-[300px] pr-4">
            {loading ? (
              <div className="flex items-center justify-center h-full">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredMembers.length > 0 ? (
              <div className="space-y-2">
                {filteredMembers.map((member) => (
                  <button
                    key={member.user_id}
                    onClick={() => handleSelect(member.user_id)}
                    className="flex items-center gap-3 w-full p-2 rounded-lg hover:bg-accent text-left transition-colors"
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        {member.full_name?.split(' ').map((n: string) => n[0]).join('').toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col truncate">
                      <span className="font-medium text-sm truncate">{member.full_name}</span>
                      <span className="text-xs text-muted-foreground truncate">{member.email}</span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
                <p>No members found</p>
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
};
