import React from 'react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface Conversation {
  id: string;
  name?: string;
  last_message_at: string;
  other_member?: {
    full_name: string;
    email: string;
  };
}

interface ConversationListProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  loading?: boolean;
}

export const ConversationList: React.FC<ConversationListProps> = ({
  conversations,
  activeId,
  onSelect,
  loading,
}) => {
  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U';
  };

  if (loading) {
    return (
      <div className="p-4 space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex items-center gap-3 animate-pulse">
            <div className="h-10 w-10 rounded-full bg-muted shrink-0" />
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-muted rounded w-3/4" />
              <div className="h-3 bg-muted rounded w-1/2" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <ScrollArea className="h-full">
      <div className="p-2 space-y-1">
        {conversations.length > 0 ? (
          conversations.sort((a, b) => new Date(b.last_message_at).getTime() - new Date(a.last_message_at).getTime()).map((conv) => (
            <button
              key={conv.id}
              onClick={() => onSelect(conv.id)}
              className={cn(
                "flex items-center gap-3 w-full p-4 md:p-3 rounded-lg text-left transition-colors active:scale-[0.98] md:active:scale-100",
                activeId === conv.id ? "bg-accent shadow-sm" : "hover:bg-accent/50"
              )}
            >
              <Avatar className="h-12 w-12 md:h-10 md:w-10 shrink-0 border border-border/50">
                <AvatarFallback className="bg-primary/5 dark:bg-primary/10 text-primary dark:text-primary-glow">
                  {getInitials(conv.other_member?.full_name || conv.name || 'Group')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-sm md:text-base truncate">
                    {conv.other_member?.full_name || conv.name || 'Conversation'}
                  </span>
                  <span className="text-[10px] md:text-xs text-muted-foreground whitespace-nowrap">
                    {format(new Date(conv.last_message_at), 'HH:mm')}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground truncate mt-0.5">
                  {conv.other_member?.email || 'No messages yet'}
                </p>
              </div>
            </button>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-10 text-center px-4">
            <p className="text-sm text-muted-foreground italic">No conversations yet</p>
          </div>
        )}
      </div>
    </ScrollArea>
  );
};
