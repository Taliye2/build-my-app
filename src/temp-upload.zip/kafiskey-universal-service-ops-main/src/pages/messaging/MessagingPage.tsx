import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card } from '@/components/ui/card';
import { ConversationList } from './components/ConversationList';
import { ChatWindow } from './components/ChatWindow';
import { NewChatDialog } from './components/NewChatDialog';
import { MessageSquare, Inbox, ChevronLeft } from 'lucide-react';
import { toast } from 'sonner';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export const MessagingPage: React.FC = () => {
  const { user } = useAuth();
  const { activeWorkspace } = useWorkspace();
  const isMobile = useIsMobile();
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchConversations = useCallback(async () => {
    if (!user || !activeWorkspace) return;

    try {
      // Fetch conversations where current user is a member
      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          members:conversation_members!inner(user_id)
        `)
        .eq('workspace_id', activeWorkspace.id)
        .eq('conversation_members.user_id', user.id)
        .order('last_message_at', { ascending: false });

      if (error) throw error;

      // For each conversation, fetch the other member's profile
      const conversationsWithMembers = await Promise.all(
        (data || []).map(async (conv) => {
          const { data: otherMemberData } = await supabase
            .from('conversation_members')
            .select('user_id')
            .eq('conversation_id', conv.id)
            .neq('user_id', user.id)
            .maybeSingle();

          if (otherMemberData) {
            const { data: profile } = await supabase
              .from('staff_profiles')
              .select('full_name, email')
              .eq('user_id', otherMemberData.user_id)
              .maybeSingle();
            
            return { ...conv, other_member: profile };
          }
          return conv;
        })
      );

      setConversations(conversationsWithMembers);
    } catch (error) {
      console.error('Error fetching conversations:', error);
    } finally {
      setLoading(false);
    }
  }, [user, activeWorkspace]);

  useEffect(() => {
    fetchConversations();

    // Subscribe to new conversations or members
    const channel = supabase
      .channel('conversations_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'conversations',
          filter: `workspace_id=eq.${activeWorkspace?.id}`,
        },
        () => {
          fetchConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchConversations, activeWorkspace]);

  const handleStartChat = async (targetUserId: string) => {
    if (!user || !activeWorkspace) return;

    try {
      // Check if conversation already exists between these two users
      const { data: existingMemberships, error: membershipError } = await supabase
        .from('conversation_members')
        .select('conversation_id')
        .eq('workspace_id', activeWorkspace.id)
        .eq('user_id', user.id);

      if (membershipError) throw membershipError;

      const convIds = existingMemberships?.map(m => m.conversation_id) || [];

      if (convIds.length > 0) {
        const { data: commonConvs, error: commonError } = await supabase
          .from('conversation_members')
          .select('conversation_id')
          .in('conversation_id', convIds)
          .eq('user_id', targetUserId);

        if (commonError) throw commonError;

        if (commonConvs && commonConvs.length > 0) {
          setActiveConversationId(commonConvs[0].conversation_id);
          toast.success('Continuing conversation');
          return;
        }
      }

      // Create new conversation
      const { data: newConv, error: convError } = await supabase
        .from('conversations')
        .insert({ 
          workspace_id: activeWorkspace.id,
          last_message_at: new Date().toISOString()
        })
        .select()
        .maybeSingle(); // Changed from .single() to .maybeSingle()

      if (convError) throw convError;

      // Add members
      const { error: membersError } = await supabase
        .from('conversation_members')
        .insert([
          { conversation_id: newConv.id, user_id: user.id, workspace_id: activeWorkspace.id },
          { conversation_id: newConv.id, user_id: targetUserId, workspace_id: activeWorkspace.id }
        ]);

      if (membersError) throw membersError;

      setActiveConversationId(newConv.id);
      fetchConversations();
      toast.success('Conversation started');
    } catch (error: any) {
      console.error('Error starting chat:', error);
      toast.error(error.message || 'Failed to start conversation');
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] md:h-[calc(100vh-10rem)] max-h-[900px]">
      <div className="flex items-center justify-between mb-4 px-2 md:px-0">
        <div className="flex items-center gap-2">
          {isMobile && activeConversationId && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="mr-1" 
              onClick={() => setActiveConversationId(null)}
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
          )}
          <MessageSquare className="h-6 w-6 text-primary shrink-0" />
          <h2 className="text-xl md:text-2xl font-bold tracking-tight truncate">Internal Messaging</h2>
        </div>
      </div>

      <div className="flex-1 flex gap-4 min-h-0 overflow-hidden">
        {(!isMobile || !activeConversationId) && (
          <Card className={cn(
            "flex flex-col min-w-0 md:min-w-[280px] md:w-80 h-full",
            isMobile ? "w-full" : ""
          )}>
            <div className="p-4 border-b flex items-center justify-between shrink-0">
              <h3 className="font-semibold text-sm">Conversations</h3>
              <NewChatDialog onSelectUser={handleStartChat} />
            </div>
            <div className="flex-1 overflow-hidden">
              <ConversationList
                conversations={conversations}
                activeId={activeConversationId}
                onSelect={setActiveConversationId}
                loading={loading}
              />
            </div>
          </Card>
        )}

        {(!isMobile || activeConversationId) && (
          <Card className={cn(
            "flex-1 flex flex-col min-w-0 h-full overflow-hidden",
            isMobile && !activeConversationId ? "hidden" : "flex"
          )}>
            {activeConversationId ? (
              <ChatWindow 
                conversationId={activeConversationId} 
                onBack={isMobile ? () => setActiveConversationId(null) : undefined}
                otherMember={conversations.find(c => c.id === activeConversationId)?.other_member}
              />
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-muted-foreground">
                <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-4">
                  <Inbox className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-medium text-foreground">No conversation selected</h3>
                <p className="max-w-xs mt-1">
                  Select a conversation from the list or start a new one to begin messaging.
                </p>
              </div>
            )}
          </Card>
        )}
      </div>
    </div>
  );
};

export default MessagingPage;
