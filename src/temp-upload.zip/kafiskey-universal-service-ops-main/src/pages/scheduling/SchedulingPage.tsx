import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Calendar, Clock, MapPin, User, CheckCircle2, XCircle, CalendarX, MoreHorizontal } from 'lucide-react';
import { toast } from 'sonner';
import { Client } from '../clients/ClientListPage';
import { ServiceTemplate } from '../services/ServiceTemplatesPage';
import { Empty } from '@/components/ui/empty';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export interface ServiceEvent {
  id: string;
  client_id: string;
  staff_user_id: string;
  service_template_id: string;
  date: string;
  start_time: string | null;
  end_time: string | null;
  units: number;
  location: string | null;
  status: 'SCHEDULED' | 'COMPLETED' | 'MISSED' | 'CANCELED' | 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'REJECTED' | 'BILLED';
  clients?: Client;
  service_templates?: ServiceTemplate;
}

export const SchedulingPage: React.FC = () => {
  const { activeWorkspace, activeMember } = useWorkspace();
  const { user } = useAuth();
  const [events, setEvents] = useState<ServiceEvent[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [templates, setTemplates] = useState<ServiceTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Form state
  const [clientId, setClientId] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [units, setUnits] = useState('1');
  const [location, setLocation] = useState('');

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    const [eventsRes, clientsRes, templatesRes] = await Promise.all([
      supabase
        .from('service_events')
        .select('*, clients:client_id(*), service_templates(*)')
        .eq('workspace_id', activeWorkspace.id)
        .order('date', { ascending: false }),
      supabase.from('clients').select('*').eq('workspace_id', activeWorkspace.id).eq('status', 'ACTIVE'),
      supabase.from('service_templates').select('*').eq('workspace_id', activeWorkspace.id)
    ]);

    if (eventsRes.data) setEvents(eventsRes.data);
    if (clientsRes.data) setClients(clientsRes.data);
    if (templatesRes.data) setTemplates(templatesRes.data);
    
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [activeWorkspace]);

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !user) return;

    const template = templates.find(t => t.id === templateId);
    if (!template) return;

    const { error } = await supabase.from('service_events').insert({
      workspace_id: activeWorkspace.id,
      client_id: clientId,
      staff_user_id: user.id, // Current user is the staff by default
      service_template_id: templateId,
      date: date,
      start_time: startTime || null,
      end_time: endTime || null,
      units: parseFloat(units),
      location: location || null,
      status: 'DRAFT',
    });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success('Service event scheduled');
      setIsDialogOpen(false);
      fetchData();
      // Reset
      setClientId('');
      setTemplateId('');
      setStartTime('');
      setEndTime('');
      setUnits('1');
      setLocation('');
    }
  };

  const handleStatusUpdate = async (eventId: string, newStatus: string) => {
    const { error } = await supabase
      .from('service_events')
      .update({ 
        status: newStatus.toUpperCase(),
        submitted_at: newStatus.toUpperCase() === 'SUBMITTED' ? new Date().toISOString() : undefined,
        approved_by: newStatus.toUpperCase() === 'APPROVED' ? user?.id : null,
        approved_at: newStatus.toUpperCase() === 'APPROVED' ? new Date().toISOString() : null
      })
      .eq('id', eventId);

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(`Event ${newStatus.toLowerCase()}`);
      fetchData();
    }
  };

  const canApprove = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN' || activeMember?.role === 'MANAGER';

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold tracking-tight">Service Schedule</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Plan service delivery. Completed services automatically generate documentation records.
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Schedule Service
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Schedule Service Event</DialogTitle>
              <DialogDescription>
                Create a new entry for service performed or planned.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateEvent} className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="clientSelect">Client</Label>
                  <Select value={clientId} onValueChange={setClientId} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select client" />
                    </SelectTrigger>
                    <SelectContent>
                      {clients.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.first_name} {c.last_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="templateSelect">Service Template</Label>
                  <Select value={templateId} onValueChange={setTemplateId} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      {templates.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="start">Start Time</Label>
                  <Input id="start" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end">End Time</Label>
                  <Input id="end" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="units">Units / Hours</Label>
                  <Input id="units" type="number" step="0.25" value={units} onChange={(e) => setUnits(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input id="location" placeholder="e.g. Office, Remote" value={location} onChange={(e) => setLocation(e.target.value)} />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button type="submit">Schedule Event</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Time</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Units</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">Loading events...</TableCell>
              </TableRow>
            ) : events.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-auto py-12">
                  <Empty 
                    icon={CalendarX}
                    title="No services scheduled"
                    description="No services scheduled yet. Schedule services to track delivery and generate documentation."
                    action={
                      <Button onClick={() => setIsDialogOpen(true)}>
                        <Plus className="mr-2 h-4 w-4" />
                        Schedule First Service
                      </Button>
                    }
                  />
                </TableCell>
              </TableRow>
            ) : (
              events.map((event) => (
                <TableRow key={event.id}>
                  <TableCell className="font-medium text-xs">
                    {format(parseISO(event.date), 'MMM d, yyyy')}
                  </TableCell>
                  <TableCell className="text-xs">
                    {event.start_time || '--:--'}
                    {event.end_time && ` - ${event.end_time}`}
                  </TableCell>
                  <TableCell className="text-xs">
                    <div className="flex items-center gap-2">
                      <User className="h-3 w-3 text-muted-foreground" />
                      {event.clients?.first_name} {event.clients?.last_name}
                    </div>
                  </TableCell>
                  <TableCell className="text-xs">{event.service_templates?.name}</TableCell>
                  <TableCell className="text-xs font-bold">{event.units} units</TableCell>
                  <TableCell>
                    <Badge variant={
                      event.status === 'APPROVED' || event.status === 'COMPLETED' ? 'success' : 
                      event.status === 'SUBMITTED' || event.status === 'SCHEDULED' ? 'warning' :
                      event.status === 'REJECTED' || event.status === 'CANCELED' || event.status === 'MISSED' ? 'destructive' : 'secondary'
                    } className="text-[10px] capitalize">
                      {event.status.toLowerCase()}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      {event.status === 'SCHEDULED' && (
                        <>
                          <Button variant="outline" size="sm" onClick={() => handleStatusUpdate(event.id, 'COMPLETED')}>
                            Complete
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleStatusUpdate(event.id, 'MISSED')}>
                                Mark as Missed
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStatusUpdate(event.id, 'CANCELED')}>
                                Mark as Canceled
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </>
                      )}
                      {event.status === 'DRAFT' && (
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link to={`/documentation/edit/${event.id}`}>Document</Link>
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => handleStatusUpdate(event.id, 'SUBMITTED')}>
                            Submit
                          </Button>
                        </div>
                      )}
                      {event.status === 'SUBMITTED' && canApprove && (
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border-emerald-200" onClick={() => handleStatusUpdate(event.id, 'APPROVED')}>
                            Approve
                          </Button>
                          <Button variant="outline" size="sm" className="bg-rose-50 text-rose-700 hover:bg-rose-100 border-rose-200" onClick={() => handleStatusUpdate(event.id, 'REJECTED')}>
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
