import React, { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format, subDays, startOfDay, endOfDay, differenceInDays } from 'date-fns';
import { 
  Search, 
  History, 
  Filter, 
  Download, 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight,
  Copy,
  Info,
  ShieldAlert,
  LogIn,
  PenTool,
  Download as DownloadIcon,
  Edit,
  Eye,
  AlertTriangle,
  X,
  User
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

interface AuditLog {
  id: string;
  action: string;
  entity_type: string;
  entity_id: string;
  actor_user_id: string;
  metadata: string | any;
  created_at: string;
}

interface Member {
  user_id: string;
  full_name: string | null;
  email: string | null;
  first_name?: string | null;
  last_name?: string | null;
}

export const AuditLogViewer: React.FC = () => {
  const { activeWorkspace, isTrialActive } = useWorkspace();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [workspaceMembers, setWorkspaceMembers] = useState<Member[]>([]);
  const [resolvedIdentities, setResolvedIdentities] = useState<Record<string, Member>>({});
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('all');
  const [resourceFilter, setResourceFilter] = useState('all');
  const [actorFilter, setActorFilter] = useState('all');
  const [presetFilter, setPresetFilter] = useState('all');
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: subDays(new Date(), 7),
    to: new Date()
  });
  const [page, setPage] = useState(0);
  const [pageSize] = useState(50);
  const [totalCount, setTotalCount] = useState(0);
  const [isExporting, setIsExporting] = useState(false);
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  useEffect(() => {
    fetchData();
  }, [activeWorkspace, actionFilter, resourceFilter, actorFilter, dateRange, page, presetFilter]);

  const fetchData = async () => {
    if (!activeWorkspace) return;
    setLoading(true);

    try {
      // 1. Fetch current workspace members for the filter dropdown
      const { data: membersData } = await supabase
        .from('workspace_members')
        .select('user_id, full_name')
        .eq('workspace_id', activeWorkspace.id);
      
      if (membersData) {
        // Map to Member interface (adding email as null since workspace_members doesn't have it)
        const members: Member[] = membersData.map(m => ({
          user_id: m.user_id,
          full_name: m.full_name,
          email: null
        }));

        setWorkspaceMembers(members);
        // Pre-populate resolved identities with current members
        const initialIdentities: Record<string, Member> = {};
        members.forEach(m => {
          initialIdentities[m.user_id] = m;
        });
        setResolvedIdentities(initialIdentities);
      }

      // 2. Fetch logs
      const start = startOfDay(dateRange.from);
      const end = endOfDay(dateRange.to);
      
      // Limit to last 7 days for trial
      const effectiveStart = isTrialActive && differenceInDays(new Date(), start) > 7 
        ? startOfDay(subDays(new Date(), 7)) 
        : start;

      let query = supabase
        .from('audit_logs')
        .select('*', { count: 'exact' })
        .eq('workspace_id', activeWorkspace.id)
        .gte('created_at', effectiveStart.toISOString())
        .lte('created_at', end.toISOString());

      // Apply action filter or preset filter
      if (presetFilter !== 'all') {
        const presetActions: Record<string, string[]> = {
          logins: ['LOGIN', 'LOGOUT'],
          signatures: ['SIGN'],
          downloads: ['DOWNLOAD'],
          edits: ['CREATE', 'UPDATE', 'DELETE'],
          views: ['VIEW'],
          high_risk: ['SIGN', 'DOWNLOAD', 'DELETE']
        };
        const actions = presetActions[presetFilter];
        if (actions) {
          query = query.in('action', actions);
        }
      } else if (actionFilter !== 'all') {
        query = query.eq('action', actionFilter.toUpperCase());
      }

      if (resourceFilter !== 'all') {
        query = query.eq('entity_type', resourceFilter);
      }

      if (actorFilter !== 'all') {
        query = query.eq('actor_user_id', actorFilter);
      }

      const { data: logsData, count, error } = await query
        .order('created_at', { ascending: false })
        .range(page * pageSize, (page + 1) * pageSize - 1);

      if (error) throw error;

      if (logsData) {
        setLogs(logsData);
        
        // Extract unique actor IDs that we haven't resolved yet
        const idsToResolve = Array.from(new Set(logsData.map(l => l.actor_user_id)))
          .filter(id => id && !resolvedIdentities[id]);
        
        if (idsToResolve.length > 0) {
          // Priority: staff_profiles (might have names/emails for users who left workspace or have more complete info)
          const { data: staffData } = await supabase
            .from('staff_profiles')
            .select('user_id, full_name, email, first_name, last_name')
            .in('user_id', idsToResolve)
            .eq('workspace_id', activeWorkspace.id);

          // Merge results into resolvedIdentities
          setResolvedIdentities(prev => {
            const next = { ...prev };
            staffData?.forEach(s => {
              // Only overwrite if we find a name or email and the previous record was missing them
              if (!next[s.user_id] || (!next[s.user_id].full_name && (s.full_name || s.first_name))) {
                next[s.user_id] = {
                  user_id: s.user_id,
                  full_name: s.full_name,
                  email: s.email,
                  first_name: s.first_name,
                  last_name: s.last_name
                };
              } else if (s.email && !next[s.user_id].email) {
                // Keep the existing name but add the email if found
                next[s.user_id].email = s.email;
              }
            });
            
            // Debug: Log resolved identity for an example user
            const exampleId = idsToResolve[0] || (membersData && membersData[0]?.user_id);
            if (exampleId && next[exampleId]) {
              console.log('[AuditLogViewer] Resolved example:', { 
                user_id: exampleId, 
                full_name: next[exampleId].full_name || `${next[exampleId].first_name} ${next[exampleId].last_name}`.trim(), 
                email: next[exampleId].email 
              });
            }

            return next;
          });
        } else if (membersData && membersData.length > 0) {
          // Debug if no external IDs to resolve
          console.log('[AuditLogViewer] Resolved example (member):', { 
            user_id: membersData[0].user_id, 
            full_name: membersData[0].full_name, 
            email: null 
          });
        }
      }
      
      if (count !== null) setTotalCount(count);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      toast.error('Failed to retrieve audit logs');
    } finally {
      setLoading(false);
    }
  };

  const getMemberDisplay = (userId: string) => {
    const member = resolvedIdentities[userId];
    
    // Fallback if ID exists but no lookup found
    if (!member) {
      if (!userId) {
        return { 
          name: 'System / No Session', 
          email: null,
          isFallback: true 
        };
      }
      return { 
        name: `User ${userId.slice(0, 8)}`, 
        email: null,
        isFallback: true 
      };
    }
    
    // Priority: Full Name > First+Last > Email > Short ID
    if (member.full_name) {
      return { 
        name: member.full_name, 
        email: member.email,
        isFallback: false 
      };
    }

    if (member.first_name || member.last_name) {
      const constructedName = `${member.first_name || ''} ${member.last_name || ''}`.trim();
      if (constructedName) {
        return { 
          name: constructedName, 
          email: member.email,
          isFallback: false 
        };
      }
    }
    
    if (member.email) {
      return { 
        name: member.email, 
        email: null,
        isFallback: false 
      };
    }

    return { 
      name: `User ${userId.slice(0, 8)}`, 
      email: null,
      isFallback: true 
    };
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  const exportCSV = async () => {
    if (!activeWorkspace) return;
    
    if (isTrialActive) {
      toast.error('CSV export is disabled during trial evaluation. Upgrade to SCALE for full export capabilities.');
      return;
    }

    setIsExporting(true);

    try {
      let query = supabase
        .from('audit_logs')
        .select('*')
        .eq('workspace_id', activeWorkspace.id)
        .gte('created_at', startOfDay(dateRange.from).toISOString())
        .lte('created_at', endOfDay(dateRange.to).toISOString());

      if (presetFilter !== 'all') {
        const presetActions: Record<string, string[]> = {
          logins: ['LOGIN', 'LOGOUT'],
          signatures: ['SIGN'],
          downloads: ['DOWNLOAD'],
          edits: ['CREATE', 'UPDATE', 'DELETE'],
          views: ['VIEW'],
          high_risk: ['SIGN', 'DOWNLOAD', 'DELETE']
        };
        const actions = presetActions[presetFilter];
        if (actions) query = query.in('action', actions);
      } else if (actionFilter !== 'all') {
        query = query.eq('action', actionFilter.toUpperCase());
      }

      if (resourceFilter !== 'all') {
        query = query.eq('entity_type', resourceFilter);
      }

      if (actorFilter !== 'all') {
        query = query.eq('actor_user_id', actorFilter);
      }

      const { data: allLogs, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      if (!allLogs || allLogs.length === 0) {
        toast.error('No logs to export');
        return;
      }

      const headers = ['Timestamp (ISO)', 'Actor Name', 'Actor Email', 'Actor ID', 'Action', 'Resource Type', 'Resource ID', 'Route', 'User Agent'];
      const rows = allLogs.map(log => {
        const member = getMemberDisplay(log.actor_user_id);
        const meta = typeof log.metadata === 'string' ? JSON.parse(log.metadata) : log.metadata;
        return [
          log.created_at,
          member.name,
          member.email || '',
          log.actor_user_id,
          log.action,
          log.entity_type,
          log.entity_id || '',
          meta?.route || '',
          meta?.userAgent || ''
        ];
      });

      const csvContent = [
        headers.join(','),
        ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `audit_logs_${format(new Date(), 'yyyyMMdd')}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error exporting CSV:', error);
      toast.error('Failed to export CSV');
    } finally {
      setIsExporting(false);
    }
  };

  const getActionColor = (action: string) => {
    const act = action.toLowerCase();
    if (act.includes('create')) return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
    if (act.includes('update')) return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
    if (act.includes('delete')) return 'bg-rose-500/10 text-rose-500 border-rose-500/20';
    if (act.includes('approve') || act.includes('sign')) return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
    if (act.includes('login') || act.includes('logout')) return 'bg-purple-500/10 text-purple-500 border-purple-500/20';
    if (act.includes('view') || act.includes('download')) return 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20';
    return 'bg-muted text-muted-foreground border-border';
  };

  const filteredLogs = useMemo(() => {
    return logs.filter(log => {
      const member = getMemberDisplay(log.actor_user_id);
      const searchStr = searchTerm.toLowerCase();
      return (
        log.action.toLowerCase().includes(searchStr) ||
        log.entity_type.toLowerCase().includes(searchStr) ||
        member.name.toLowerCase().includes(searchStr) ||
        (member.email && member.email.toLowerCase().includes(searchStr)) ||
        (log.entity_id && log.entity_id.toLowerCase().includes(searchStr))
      );
    });
  }, [logs, searchTerm, resolvedIdentities]);

  const presets = [
    { id: 'all', label: 'All', icon: History },
    { id: 'logins', label: 'Logins', icon: LogIn },
    { id: 'signatures', label: 'Signatures', icon: PenTool },
    { id: 'downloads', label: 'Downloads', icon: DownloadIcon },
    { id: 'edits', label: 'Edits', icon: Edit },
    { id: 'views', label: 'Views', icon: Eye },
    { id: 'high_risk', label: 'High-Risk', icon: AlertTriangle, variant: 'destructive' },
  ];

  return (
    <Card className="shadow-none border-none bg-transparent">
      <CardHeader className="px-0 pt-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <History className="h-6 w-6 text-primary" />
              Administrative Audit Logs
            </CardTitle>
            <CardDescription className="text-sm">
              Immutable record of all administrative and security actions within this workspace.
            </CardDescription>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={exportCSV} 
            disabled={totalCount === 0 || loading || isExporting}
            className="h-9"
          >
            {isExporting ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
            ) : (
              <Download className="h-4 w-4 mr-2" />
            )}
            {isExporting ? 'Exporting...' : 'Export Filtered CSV'}
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="px-0 space-y-6">
        {/* Quick Presets */}
        <div className="flex flex-wrap items-center gap-2 pb-2">
          {presets.map((preset) => {
            const Icon = preset.icon;
            const isActive = presetFilter === preset.id;
            return (
              <Button
                key={preset.id}
                variant={isActive ? (preset.variant as any || 'default') : 'outline'}
                size="sm"
                className={cn(
                  "h-8 gap-2 rounded-full px-4",
                  !isActive && preset.variant === 'destructive' && "text-rose-500 hover:text-rose-600 hover:bg-rose-500/10 border-rose-500/20"
                )}
                onClick={() => {
                  setPresetFilter(preset.id);
                  setPage(0);
                }}
              >
                <Icon className="h-3.5 w-3.5" />
                {preset.label}
              </Button>
            );
          })}
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-3">
          <div className="relative col-span-1 md:col-span-2 lg:col-span-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search actions, users..."
              className="pl-9 h-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="h-9 justify-start text-left font-normal">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {dateRange.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, "MMM dd")} - {format(dateRange.to, "MMM dd, yyyy")}
                    </>
                  ) : (
                    format(dateRange.from, "MMM dd, yyyy")
                  )
                ) : (
                  <span>Select dates</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                initialFocus
                mode="range"
                defaultMonth={dateRange.from}
                selected={{ from: dateRange.from, to: dateRange.to }}
                onSelect={(range: any) => range?.from && range?.to && setDateRange({ from: range.from, to: range.to })}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>

          <Select value={actionFilter} onValueChange={(v) => { setActionFilter(v); setPresetFilter('all'); setPage(0); }}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Action" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              <SelectItem value="VIEW">View</SelectItem>
              <SelectItem value="CREATE">Create</SelectItem>
              <SelectItem value="UPDATE">Update</SelectItem>
              <SelectItem value="DELETE">Delete</SelectItem>
              <SelectItem value="SIGN">Sign</SelectItem>
              <SelectItem value="DOWNLOAD">Download</SelectItem>
              <SelectItem value="LOGIN">Login</SelectItem>
              <SelectItem value="LOGOUT">Logout</SelectItem>
            </SelectContent>
          </Select>

          <Select value={resourceFilter} onValueChange={(v) => { setResourceFilter(v); setPage(0); }}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Resource" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Resources</SelectItem>
              <SelectItem value="client">Client</SelectItem>
              <SelectItem value="service_record">Service Record</SelectItem>
              <SelectItem value="document">Document</SelectItem>
              <SelectItem value="message_thread">Message</SelectItem>
              <SelectItem value="invoice">Invoice</SelectItem>
              <SelectItem value="workspace">Workspace</SelectItem>
              <SelectItem value="team_member">Team</SelectItem>
            </SelectContent>
          </Select>

          <Select value={actorFilter} onValueChange={(v) => { setActorFilter(v); setPage(0); }}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Actor" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actors</SelectItem>
              {workspaceMembers.map(member => {
                // Use the resolved identity logic for the filter dropdown
                const resolved = getMemberDisplay(member.user_id);
                return (
                  <SelectItem key={member.user_id} value={member.user_id}>
                    {resolved.name}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        <div className="rounded-lg border bg-card/50 overflow-hidden">
          <TooltipProvider>
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent border-b">
                  <TableHead className="w-[180px] text-xs font-bold uppercase tracking-wider py-4">Timestamp</TableHead>
                  <TableHead className="text-xs font-bold uppercase tracking-wider">Actor</TableHead>
                  <TableHead className="text-xs font-bold uppercase tracking-wider">Action</TableHead>
                  <TableHead className="text-xs font-bold uppercase tracking-wider">Resource</TableHead>
                  <TableHead className="text-xs font-bold uppercase tracking-wider">ID</TableHead>
                  <TableHead className="text-xs font-bold uppercase tracking-wider text-right">Route</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-64 text-center">
                      <div className="flex flex-col items-center justify-center gap-3">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                        <span className="text-sm font-medium text-muted-foreground">Synchronizing audit data...</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredLogs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-64 text-center">
                      <div className="flex flex-col items-center justify-center gap-2">
                        <History className="h-10 w-10 text-muted/20" />
                        <p className="text-muted-foreground font-medium">No audit records found for this period.</p>
                        <Button variant="link" size="sm" onClick={() => {
                          setPresetFilter('all');
                          setActionFilter('all');
                          setResourceFilter('all');
                          setActorFilter('all');
                          setSearchTerm('');
                          setDateRange({ from: subDays(new Date(), 30), to: new Date() });
                        }}>
                          Clear all filters
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredLogs.map((log) => {
                    const meta = typeof log.metadata === 'string' ? JSON.parse(log.metadata) : log.metadata;
                    const member = getMemberDisplay(log.actor_user_id);
                    return (
                      <TableRow 
                        key={log.id} 
                        className="hover:bg-muted/30 transition-colors cursor-pointer group border-b last:border-0"
                        onClick={() => setSelectedLog(log)}
                      >
                        <TableCell className="py-4">
                          <div className="flex flex-col">
                            <span className="text-sm font-medium whitespace-nowrap">
                              {format(new Date(log.created_at), 'MMM d, yyyy')}
                            </span>
                            <span className="text-[10px] text-muted-foreground font-mono">
                              {format(new Date(log.created_at), 'HH:mm:ss O')}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <div className="flex items-center gap-1.5">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <span className="text-sm font-semibold">{member.name}</span>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p className="text-xs font-mono">ID: {log.actor_user_id}</p>
                                </TooltipContent>
                              </Tooltip>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" 
                                onClick={(e) => { e.stopPropagation(); copyToClipboard(log.actor_user_id, 'User ID'); }}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                            {member.email && <span className="text-[10px] text-muted-foreground">{member.email}</span>}
                          </div>
                        </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={cn("text-[10px] uppercase font-bold px-2 py-0", getActionColor(log.action))}>
                          {log.action}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs font-medium text-muted-foreground uppercase tracking-tight">
                          {log.entity_type.replace('_', ' ')}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-mono text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded">
                            {log.entity_id ? log.entity_id.slice(0, 12) : '—'}
                          </span>
                          {log.entity_id && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" 
                              onClick={(e) => { e.stopPropagation(); copyToClipboard(log.entity_id, 'Resource ID'); }}
                            >
                              <Copy className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="text-[10px] text-muted-foreground truncate max-w-[150px] inline-block font-mono" title={meta?.route}>
                          {meta?.route || '—'}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TooltipProvider>
      </div>

        <div className="flex items-center justify-between pt-2">
          <div className="text-xs text-muted-foreground">
            Showing <span className="font-medium text-foreground">{filteredLogs.length}</span> of <span className="font-medium text-foreground">{totalCount}</span> secure records
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0 || loading}
                className="h-8 w-8 p-0"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="bg-muted px-3 h-8 flex items-center rounded-md border">
                <span className="text-xs font-bold uppercase tracking-wider">Page {page + 1}</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => p + 1)}
                disabled={(page + 1) * pageSize >= totalCount || loading}
                className="h-8 w-8 p-0"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </CardContent>

      {/* Log Investigation Drawer */}
      <Sheet open={!!selectedLog} onOpenChange={(open) => !open && setSelectedLog(null)}>
        <SheetContent className="sm:max-w-md md:max-w-lg border-l bg-card p-0">
          {selectedLog && (
            <div className="flex flex-col h-full">
              <SheetHeader className="p-6 border-b bg-muted/30">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className={cn("uppercase font-bold", getActionColor(selectedLog.action))}>
                    {selectedLog.action}
                  </Badge>
                  <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setSelectedLog(null)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <SheetTitle className="text-xl font-bold">Log Investigation</SheetTitle>
                <SheetDescription className="text-xs font-mono">
                  Record ID: {selectedLog.id}
                </SheetDescription>
              </SheetHeader>
              
              <ScrollArea className="flex-1">
                <div className="p-6 space-y-8">
                  <section className="space-y-4">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                      <LogIn className="h-3 w-3" />
                      Actor Details
                    </h4>
                    <div className="grid grid-cols-1 gap-4 p-4 rounded-lg bg-muted/20 border">
                      <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Display Name</p>
                        <p className="text-sm font-semibold">{getMemberDisplay(selectedLog.actor_user_id).name}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Email Address</p>
                        <p className="text-sm font-medium">{getMemberDisplay(selectedLog.actor_user_id).email || '—'}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">User ID</p>
                        <div className="flex items-center gap-2">
                          <code className="text-xs font-mono bg-background p-1.5 rounded border block w-full truncate">
                            {selectedLog.actor_user_id}
                          </code>
                          <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={() => copyToClipboard(selectedLog.actor_user_id, 'User ID')}>
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                      <Filter className="h-3 w-3" />
                      Resource Information
                    </h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1 p-3 rounded-lg bg-muted/20 border">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Resource Type</p>
                        <p className="text-sm font-bold uppercase">{selectedLog.entity_type.replace('_', ' ')}</p>
                      </div>
                      <div className="space-y-1 p-3 rounded-lg bg-muted/20 border">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Resource ID</p>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-mono truncate">{selectedLog.entity_id || '—'}</span>
                          {selectedLog.entity_id && (
                            <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => copyToClipboard(selectedLog.entity_id, 'Resource ID')}>
                              <Copy className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </section>

                  <section className="space-y-4">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                      <Info className="h-3 w-3" />
                      Technical Metadata
                    </h4>
                    <div className="space-y-3 p-4 rounded-lg bg-muted/20 border">
                      <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Timestamp</p>
                        <p className="text-xs font-medium">{format(new Date(selectedLog.created_at), 'PPPPpppp')}</p>
                      </div>
                      <Separator className="opacity-50" />
                      <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Route / URL</p>
                        <code className="text-[11px] font-mono break-all bg-background p-2 rounded block border">
                          {(typeof selectedLog.metadata === 'string' ? JSON.parse(selectedLog.metadata) : selectedLog.metadata)?.route || '—'}
                        </code>
                      </div>
                      <Separator className="opacity-50" />
                      <div className="space-y-1">
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">User Agent</p>
                        <p className="text-[11px] font-mono leading-relaxed text-muted-foreground bg-background p-2 rounded border">
                          {(typeof selectedLog.metadata === 'string' ? JSON.parse(selectedLog.metadata) : selectedLog.metadata)?.userAgent || '—'}
                        </p>
                      </div>
                    </div>
                  </section>
                </div>
              </ScrollArea>
              
              <div className="p-6 border-t bg-muted/30 grid grid-cols-2 gap-3">
                <Button variant="outline" size="sm" className="h-10 text-xs font-bold uppercase tracking-wider" onClick={() => {
                  const summary = `Audit Event: ${selectedLog.action} on ${selectedLog.entity_type}\nActor: ${getMemberDisplay(selectedLog.actor_user_id).name}\nTimestamp: ${format(new Date(selectedLog.created_at), 'yyyy-MM-dd HH:mm:ss')}`;
                  copyToClipboard(summary, 'Summary');
                }}>
                  Copy Summary
                </Button>
                <Button variant="outline" size="sm" className="h-10 text-xs font-bold uppercase tracking-wider" onClick={() => {
                  const meta = typeof selectedLog.metadata === 'string' ? JSON.parse(selectedLog.metadata) : selectedLog.metadata;
                  const json = JSON.stringify({
                    id: selectedLog.id,
                    timestamp: selectedLog.created_at,
                    action: selectedLog.action,
                    actor: getMemberDisplay(selectedLog.actor_user_id),
                    resource: { type: selectedLog.entity_type, id: selectedLog.entity_id },
                    metadata: meta
                  }, null, 2);
                  copyToClipboard(json, 'JSON');
                }}>
                  Copy JSON
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </Card>
  );
};

