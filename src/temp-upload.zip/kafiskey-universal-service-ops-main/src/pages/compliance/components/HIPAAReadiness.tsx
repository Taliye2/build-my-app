import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ShieldCheck, 
  ShieldAlert, 
  CheckCircle2, 
  Download, 
  ExternalLink, 
  ListChecks, 
  Building2, 
  Info,
  History,
  Lock,
  UserCheck,
  ChevronDown,
  AlertCircle,
  FileText,
  Shield
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const HIPAAReadiness: React.FC = () => {
  const { activeWorkspace, hasAdvancedReporting, isTrialActive } = useWorkspace();
  const [exportLoading, setExportLoading] = useState(false);

  const canReviewAudit = hasAdvancedReporting || isTrialActive;

  const readinessChecklist = [
    { id: 'audit', label: 'Audit Logging Controls', status: 'Available', description: 'Configurable tracking of PHI-related actions to support organizational recordkeeping.' },
    { id: 'signed_urls', label: 'Secure Signed URLs', status: 'Available', description: 'Technical controls for time-limited, cryptographically signed document links.' },
    { id: 'auto_logoff', label: 'Session Timeout Policies', status: 'Configurable', description: 'Administrative controls to terminate sessions after periods of inactivity.' },
    { id: 'notifications', label: 'Notification Safeguards', status: 'Available', description: 'System controls to ensure notifications do not contain PHI or clinical content.' },
    { id: 'acknowledgment', label: 'HIPAA Acknowledgment', status: 'Enabled', description: 'Configurable user acknowledgment of privacy practices for workspace members.' },
  ];

  const exportEvidence = async () => {
    if (!activeWorkspace) return;
    setExportLoading(true);
    
    try {
      // Fetch HIPAA Acknowledgments for evidence
      const { data, error } = await supabase
        .from('hipaa_acknowledgments')
        .select('user_id, acknowledged_at')
        .eq('workspace_id', activeWorkspace.id);

      if (error) throw error;

      if (!data || data.length === 0) {
        toast.info('No acknowledgment records found to export.');
        return;
      }

      const headers = ['User ID', 'Workspace ID', 'Acknowledged At'];
      const rows = data.map(record => [
        record.user_id,
        activeWorkspace.id,
        format(new Date(record.acknowledged_at), 'yyyy-MM-dd HH:mm:ss')
      ]);

      const csvContent = [
        headers.join(','),
        ...rows.map(row => row.map(val => `"${String(val).replace(/"/g, '""')}"`).join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `hipaa_acknowledgments_${format(new Date(), 'yyyyMMdd')}.csv`);
      link.click();
      toast.success('Evidence exported successfully');
    } catch (error: any) {
      console.error('Error exporting evidence:', error);
      toast.error('Failed to export evidence: ' + error.message);
    } finally {
      setExportLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* 1. HIPAA Overview */}
      <section className="space-y-4">
        <div className="bg-primary/5 border border-primary/10 rounded-xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none">
            <Shield className="h-32 w-32" />
          </div>
          <div className="relative z-10 space-y-2">
            <h2 className="text-2xl font-bold tracking-tight text-primary">HIPAA Overview</h2>
            <p className="text-muted-foreground leading-relaxed max-w-3xl">
              Kafiskey provides the technical safeguards and infrastructure necessary for organizations to maintain HIPAA compliance. 
              Compliance is optional, configurable, and built upon a shared responsibility model between the platform and your organization.
            </p>
          </div>
        </div>
      </section>

      {/* 2. HIPAA Responsibility Summary */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 px-1">
          <ShieldAlert className="h-5 w-5 text-amber-500" />
          <h3 className="font-semibold text-lg">Shared Responsibility Model</h3>
        </div>
        <Card className="shadow-sm border-amber-100 bg-amber-50/30">
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Compliance is a partnership. Kafiskey provides the **Technical Safeguards** (encryption, access controls, audit logs), 
              while your organization remains responsible for **Administrative Safeguards** (staff training, internal policies, risk assessments). 
              Kafiskey's tools are designed to support your organization's regulatory obligations as a Covered Entity.
            </p>
          </CardContent>
        </Card>
      </section>

      {/* 3. HIPAA Safeguards Summary */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 px-1">
          <CheckCircle2 className="h-5 w-5 text-primary" />
          <h3 className="font-semibold text-lg">System Safeguards Status</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-lg border bg-background flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
              <Lock className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm font-bold">Data Security</p>
              <p className="text-[11px] text-muted-foreground">Encryption at rest & transit</p>
            </div>
          </div>
          <div className="p-4 rounded-lg border bg-background flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
              <History className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm font-bold">Auditability</p>
              <p className="text-[11px] text-muted-foreground">Comprehensive access logs</p>
            </div>
          </div>
          <div className="p-4 rounded-lg border bg-background flex items-start gap-3">
            <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
              <UserCheck className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm font-bold">Access Controls</p>
              <p className="text-[11px] text-muted-foreground">Role-based isolation</p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Configuration & Guidance (Accordion for Dense Sections) */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 px-1">
          <ListChecks className="h-5 w-5 text-primary" />
          <h3 className="font-semibold text-lg">Detailed Configuration & Guidance</h3>
        </div>
        
        <Accordion type="single" collapsible className="w-full space-y-4">
          <AccordionItem value="safeguards-matrix" className="border rounded-lg px-4 bg-background">
            <AccordionTrigger className="hover:no-underline">
              <div className="flex flex-col items-start text-left">
                <span className="font-bold">Technical Safeguards Matrix</span>
                <span className="text-xs text-muted-foreground font-normal">View status of built-in compliance features and technical controls.</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pt-2 pb-4">
              <div className="divide-y border rounded-md overflow-hidden">
                {readinessChecklist.map((item) => (
                  <div key={item.id} className="flex items-start gap-4 p-3 hover:bg-muted/30 transition-colors">
                    <CheckCircle2 className="h-4 w-4 text-emerald-500 mt-1 shrink-0" />
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold">{item.label}</span>
                        <Badge variant="success" className="text-[9px] h-3.5 px-1 uppercase">{item.status}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="baa-tracker" className="border rounded-lg px-4 bg-background">
            <AccordionTrigger className="hover:no-underline">
              <div className="flex flex-col items-start text-left">
                <span className="font-bold">Vendor BAA Tracker</span>
                <span className="text-xs text-muted-foreground font-normal">Review active Business Associate Agreements with our key infrastructure partners.</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pt-2 pb-4 space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <VendorStatus name="Blink Infrastructure" role="Cloud Hosting" baa={true} />
                <VendorStatus name="Supabase" role="Storage & DB" baa={true} />
                <VendorStatus name="Resend" role="Email Services" baa={false} note="No PHI transmitted" />
                <VendorStatus name="Stripe" role="Billing" baa={false} note="Financial only" />
              </div>
              <div className="p-3 bg-muted/30 rounded-md text-[11px] text-muted-foreground italic">
                Organizations are responsible for maintaining BAAs with all relevant vendors. Kafiskey provides BAAs for platform services upon request.
              </div>
              <Button variant="link" size="sm" className="h-auto p-0 text-xs gap-1" asChild>
                <a href="https://www.hhs.gov/hipaa/for-professionals/privacy/guidance/business-associates/index.html" target="_blank" rel="noreferrer">
                  View HHS BAA Guidance <ExternalLink className="h-3 w-3" />
                </a>
              </Button>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="policy-basics" className="border rounded-lg px-4 bg-background">
            <AccordionTrigger className="hover:no-underline">
              <div className="flex flex-col items-start text-left">
                <span className="font-bold">HIPAA Policy Basics</span>
                <span className="text-xs text-muted-foreground font-normal">Core principles for organizational PHI handling and platform configuration.</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pt-2 pb-4 prose prose-sm max-w-none text-muted-foreground">
              <p>
                Kafiskey provides tools and controls that allow organizations to configure their platform for PHI handling.
                Compliance is enabled through organizational policy and administrative configuration. 
              </p>
              <p className="text-xs">
                For detailed operational advice on handling Protected Health Information (PHI) within the platform, 
                including role-based access and data isolation, please refer to the <Link to="?tab=guidelines" className="text-primary font-bold hover:underline">General Guidelines</Link> section.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="incident-response" className="border rounded-lg px-4 bg-background">
            <AccordionTrigger className="hover:no-underline">
              <div className="flex flex-col items-start text-left">
                <span className="font-bold">Incident & Breach Response</span>
                <span className="text-xs text-muted-foreground font-normal">High-level protocols for suspected unauthorized access or disclosures.</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pt-2 pb-4">
              <div className="space-y-4">
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="p-3 border rounded-md bg-muted/10">
                    <p className="font-bold text-xs mb-1">1. Report</p>
                    <p className="text-[10px] text-muted-foreground">Immediately notify your Compliance Officer of any suspected disclosures.</p>
                  </div>
                  <div className="p-3 border rounded-md bg-muted/10">
                    <p className="font-bold text-xs mb-1">2. Assess</p>
                    <p className="text-[10px] text-muted-foreground">Perform risk assessment based on the four HIPAA compromise factors.</p>
                  </div>
                  <div className="p-3 border rounded-md bg-muted/10">
                    <p className="font-bold text-xs mb-1">3. Notify</p>
                    <p className="text-[10px] text-muted-foreground">Breach determination and regulatory reporting remain the Covered Entity's responsibility.</p>
                  </div>
                </div>
                <div className="bg-destructive/5 border border-destructive/20 p-4 rounded-lg">
                  <p className="text-sm font-bold text-destructive flex items-center gap-2 mb-2">
                    <AlertCircle className="h-4 w-4" />
                    Security Incident?
                  </p>
                  <p className="text-xs text-muted-foreground mb-4">
                    If you suspect a data breach, follow your organization's Incident Response Plan immediately.
                  </p>
                  <Button variant="destructive" size="sm" className="w-full sm:w-auto text-xs gap-2" asChild>
                    <a href="mailto:absame@lazimkey.com">
                      Report Security Incident <ExternalLink className="h-3 w-3" />
                    </a>
                  </Button>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </section>

      {/* 5. Evidence, Logs, and Documentation */}
      <section className="space-y-4 pb-12">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            <h3 className="font-semibold text-lg">Operational Evidence</h3>
          </div>
          <Button variant="outline" size="sm" onClick={exportEvidence} disabled={exportLoading}>
            {exportLoading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2" />
            ) : (
              <Download className="h-4 w-4 mr-2" />
            )}
            Export Evidence
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="shadow-sm">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                Acknowledgment Logs
              </CardTitle>
              <CardDescription className="text-xs">Records of HIPAA policy acknowledgments.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
                Export a detailed CSV of all workspace members who have acknowledged your organization's privacy practices.
              </p>
              <Button variant="outline" size="sm" className="w-full text-xs" onClick={exportEvidence}>
                Download CSV Evidence
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-sm relative group">
            {!canReviewAudit && (
              <div className="absolute inset-0 bg-background/60 backdrop-blur-[1px] z-10 flex flex-col items-center justify-center rounded-lg opacity-0 group-hover:opacity-100 transition-opacity p-4 text-center">
                <p className="text-[10px] font-bold mb-2">Advanced audit logging requires a Scale plan</p>
                <Button size="sm" variant="outline" className="h-8 text-xs" asChild>
                  <Link to="/billing/plan">View Plans</Link>
                </Button>
              </div>
            )}
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-bold flex items-center gap-2">
                <History className="h-4 w-4 text-primary" />
                Audit Log Review
              </CardTitle>
              <CardDescription className="text-xs">PHI access and modification records.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
                Access comprehensive logs of all administrative and PHI-related actions within the workspace for audit review.
              </p>
              <Button variant="secondary" size="sm" className="w-full text-xs" asChild disabled={!canReviewAudit}>
                <Link to="?tab=audit">View Audit Logs</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

const VendorStatus = ({ name, role, baa, note }: { name: string; role: string; baa: boolean; note?: string }) => (
  <div className="flex items-center justify-between p-3 rounded-lg border bg-muted/20">
    <div className="space-y-0.5">
      <p className="text-xs font-bold">{name}</p>
      <p className="text-[10px] text-muted-foreground">{role}</p>
      {note && <p className="text-[9px] text-amber-600 font-medium italic mt-1">{note}</p>}
    </div>
    <div className="flex items-center gap-2">
      {baa ? (
        <Badge variant="success" className="text-[9px] px-1 h-4">BAA ACTIVE</Badge>
      ) : (
        <Badge variant="outline" className="text-[9px] px-1 h-4">N/A</Badge>
      )}
    </div>
  </div>
);
