import React, { useState, useEffect } from 'react';
import { format, differenceInDays, isPast } from 'date-fns';
import { 
  ShieldCheck, 
  Search, 
  Clock, 
  CheckCircle2, 
  FileText,
  Building2,
  UserSquare2,
  Contact2,
  AlertTriangle,
  Eye,
  ArrowUpRight,
  Info,
  ExternalLink,
  ShieldAlert,
  ListChecks,
  Lock
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { getSignedUrl } from '@/lib/supabase';
import { logAudit } from '@/lib/audit';
import { useAuth } from '@/contexts/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AuditLogViewer } from './components/AuditLogViewer';
import { HIPAAReadiness } from './components/HIPAAReadiness';
import { TrialPreviewBanner } from '@/components/TrialPreviewBanner';

interface ComplianceDoc extends any {
  entity_name?: string;
  entity_type_label?: string;
  days_left?: number;
  compliance_status?: 'expired' | 'expiring-soon' | 'valid' | 'no-expiration';
}

export const CompliancePage: React.FC = () => {
  const { user } = useAuth();
  const { activeWorkspace, activeMember, hasAdvancedReporting, isTrialActive } = useWorkspace();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const activeTab = searchParams.get('tab') || 'tracking';
  
  const isAdmin = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN';

  // In trial, we allow audit log access for evaluation
  const canAccessAudit = hasAdvancedReporting || isTrialActive;

  const [documents, setDocuments] = useState<ComplianceDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [entityTypeFilter, setEntityTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [expirationFilter, setExpirationFilter] = useState('all');

  useEffect(() => {
    if (activeWorkspace && activeTab === 'tracking') {
      fetchDocuments();
    }
  }, [activeWorkspace, activeTab]);

  const fetchDocuments = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('documents')
        .select(`
          *,
          client:clients(first_name, last_name, preferred_name),
          staff:staff_profiles(full_name),
          contact:contacts(first_name, last_name)
        `)
        .eq('workspace_id', activeWorkspace?.id)
        .order('expiration_date', { ascending: true, nullsFirst: false });

      if (error) throw error;

      const today = new Date();
      const processedDocs = (data || []).map(doc => {
        let entityName = 'Unknown';
        let entityTypeLabel = 'Unknown';
        let profilePath = '/';

        if (doc.client) {
          entityName = `${doc.client.first_name} ${doc.client.last_name}`;
          entityTypeLabel = 'Client';
          profilePath = `/clients/${doc.client_id}`;
        } else if (doc.staff) {
          entityName = doc.staff.full_name || 'Staff Member';
          entityTypeLabel = 'Provider';
          profilePath = `/providers/${doc.staff_id}`;
        } else if (doc.contact) {
          entityName = `${doc.contact.first_name} ${doc.contact.last_name}`;
          entityTypeLabel = 'Contact';
          profilePath = `/contacts/${doc.contact_id}`;
        }

        const expiry = doc.expiration_date ? new Date(doc.expiration_date) : null;
        let complianceStatus: ComplianceDoc['compliance_status'] = 'no-expiration';
        let daysLeft = undefined;

        if (expiry) {
          daysLeft = differenceInDays(expiry, today);
          if (isPast(expiry)) {
            complianceStatus = 'expired';
          } else if (daysLeft <= 30) {
            complianceStatus = 'expiring-soon';
          } else {
            complianceStatus = 'valid';
          }
        }

        return {
          ...doc,
          entity_name: entityName,
          entity_type_label: entityTypeLabel,
          profile_path: profilePath,
          days_left: daysLeft,
          compliance_status: complianceStatus
        };
      });

      setDocuments(processedDocs);
    } catch (error: any) {
      console.error('Error fetching compliance documents:', error);
      toast.error('Error fetching compliance documents: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const getStats = () => {
    const expired = documents.filter(d => d.compliance_status === 'expired').length;
    const expiring30 = documents.filter(d => d.days_left !== undefined && d.days_left >= 0 && d.days_left <= 30).length;
    const expiring60 = documents.filter(d => d.days_left !== undefined && d.days_left > 30 && d.days_left <= 60).length;
    const noExpiration = documents.filter(d => d.compliance_status === 'no-expiration').length;

    return { expired, expiring30, expiring60, noExpiration };
  };

  const stats = getStats();

  const filteredDocs = documents.filter(doc => {
    const matchesSearch = 
      doc.file_name.toLowerCase().includes(search.toLowerCase()) || 
      doc.entity_name?.toLowerCase().includes(search.toLowerCase());
    
    const matchesEntityType = entityTypeFilter === 'all' || doc.entity_type_label?.toLowerCase() === entityTypeFilter.toLowerCase();
    const matchesStatus = statusFilter === 'all' || doc.compliance_status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || doc.category === categoryFilter;
    
    let matchesExpiration = true;
    if (expirationFilter !== 'all') {
      const window = parseInt(expirationFilter);
      matchesExpiration = doc.days_left !== undefined && doc.days_left >= 0 && doc.days_left <= window;
    }

    return matchesSearch && matchesEntityType && matchesStatus && matchesCategory && matchesExpiration;
  });

  const handleViewDocument = async (doc: any) => {
    if (!activeWorkspace || !user) return;

    try {
      const signedUrl = await getSignedUrl('client-documents', doc.storage_path);
      logAudit(activeWorkspace.id, user.id, 'DOWNLOAD', 'document', doc.id, { method: 'signed_url', source: 'compliance_page' });
      window.open(signedUrl, '_blank', 'noopener,noreferrer');
    } catch (error: any) {
      toast.error('Error generating secure link: ' + error.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold tracking-tight">Compliance & HIPAA</h1>
          <p className="text-muted-foreground">Manage organizational compliance and HIPAA guidelines.</p>
        </div>
        {isAdmin && (
          <Button 
            variant="outline" 
            className="gap-2 self-start sm:self-center"
            onClick={() => navigate('/settings/compliance')}
          >
            <Lock className="h-4 w-4" />
            HIPAA Configuration
          </Button>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={(v) => setSearchParams({ tab: v })} className="w-full">
        <TabsList className="flex flex-wrap h-auto p-1 bg-muted/50">
          <TabsTrigger value="tracking">Compliance Tracking</TabsTrigger>
          <TabsTrigger value="readiness">HIPAA Readiness</TabsTrigger>
          <TabsTrigger value="guidelines">General Guidelines</TabsTrigger>
          {isAdmin && (
            <TabsTrigger value="audit" disabled={!canAccessAudit}>
              Audit Logs {!canAccessAudit && <Lock className="h-3 w-3 ml-2 opacity-50" />}
              {isTrialActive && <Badge variant="secondary" className="h-4 px-1 ml-2 text-[10px] font-bold bg-amber-100 text-amber-800 border-amber-200 uppercase">Trial</Badge>}
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="tracking" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-l-4 border-l-destructive shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider">Expired</CardTitle>
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.expired}</div>
                <p className="text-[10px] text-muted-foreground mt-1 uppercase font-bold">Immediate Action</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-amber-500 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider">Due 30 Days</CardTitle>
                <Clock className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.expiring30}</div>
                <p className="text-[10px] text-muted-foreground mt-1 uppercase font-bold">Renewal Soon</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-primary shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider">Due 60 Days</CardTitle>
                <Clock className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.expiring60}</div>
                <p className="text-[10px] text-muted-foreground mt-1 uppercase font-bold">Planned Review</p>
              </CardContent>
            </Card>
            <Card className="border-l-4 border-l-muted shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium uppercase tracking-wider">Indefinite</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.noExpiration}</div>
                <p className="text-[10px] text-muted-foreground mt-1 uppercase font-bold">No Expiry Date</p>
              </CardContent>
            </Card>
          </div>

          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg">Document Compliance Matrix</CardTitle>
              <CardDescription>Unified view of all critical compliance documentation.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="Search by name or document title..." 
                    className="pl-10"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <div className="flex flex-wrap gap-2">
                  <Select value={entityTypeFilter} onValueChange={setEntityTypeFilter}>
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="client">Client</SelectItem>
                      <SelectItem value="provider">Provider</SelectItem>
                      <SelectItem value="contact">Contact</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[130px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="valid">Valid</SelectItem>
                      <SelectItem value="expiring-soon">Soon</SelectItem>
                      <SelectItem value="expired">Expired</SelectItem>
                      <SelectItem value="no-expiration">None</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader className="bg-muted/50">
                    <TableRow>
                      <TableHead>Status</TableHead>
                      <TableHead>Entity</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Expiry</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      <TableRow>
                        <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">Loading...</TableCell>
                      </TableRow>
                    ) : filteredDocs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">No records found.</TableCell>
                      </TableRow>
                    ) : (
                      filteredDocs.map((doc) => (
                        <TableRow key={doc.id}>
                          <TableCell>
                            {doc.compliance_status === 'expired' ? (
                              <Badge variant="destructive">Expired</Badge>
                            ) : doc.compliance_status === 'expiring-soon' ? (
                              <Badge variant="warning">Soon</Badge>
                            ) : doc.compliance_status === 'valid' ? (
                              <Badge variant="success">Valid</Badge>
                            ) : (
                              <Badge variant="outline">N/A</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col">
                              <span className="font-medium text-sm">{doc.entity_name}</span>
                              <span className="text-[10px] text-muted-foreground uppercase font-bold">{doc.entity_type_label}</span>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate font-medium text-sm">{doc.file_name}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="text-[10px] font-bold uppercase">{doc.category}</Badge>
                          </TableCell>
                          <TableCell className="text-xs">
                            {doc.expiration_date ? format(new Date(doc.expiration_date), 'MMM d, yyyy') : '—'}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button variant="ghost" size="icon" onClick={() => handleViewDocument(doc)}>
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" asChild>
                                <Link to={doc.profile_path}><ArrowUpRight className="h-4 w-4" /></Link>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guidelines" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ListChecks className="h-5 w-5 text-primary" />
                    PHI Handling Guidelines
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="p-4 rounded-lg border bg-muted/30">
                      <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                        <ShieldAlert className="h-4 w-4 text-destructive" />
                        Avoid PHI in Email
                      </h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Do not include patient names, dates of birth, or clinical details in standard email body text. Standard email is not encrypted by default.
                      </p>
                    </div>
                    <div className="p-4 rounded-lg border bg-muted/30">
                      <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                        <ShieldCheck className="h-4 w-4 text-success" />
                        Use Secure Messaging
                      </h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Use the built-in messaging module for all communication involving sensitive data, as it is protected by workspace-level security.
                      </p>
                    </div>
                    <div className="p-4 rounded-lg border bg-muted/30">
                      <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                        <Info className="h-4 w-4 text-primary" />
                        Role-Based Access Control
                      </h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Kafiskey provides configurable Role-Based Access Control (RBAC). Administrators are responsible for assigning roles that provide only the minimum necessary access for staff.
                      </p>
                    </div>
                    <div className="p-4 rounded-lg border bg-muted/30">
                      <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
                        <Building2 className="h-4 w-4 text-primary" />
                        Workspace Isolation Tools
                      </h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        Data is isolated at the workspace level using technical controls like Supabase Row-Level Security (RLS), allowing organizations to control cross-tenant exposure.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-primary/5 dark:bg-primary/10 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-sm">Additional Compliance Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-muted-foreground mb-4 leading-relaxed">
                    Kafiskey's security team is available to assist with technical configuration questions or to provide platform documentation for your compliance audits.
                  </p>
                  <Button variant="outline" size="sm" className="w-full sm:w-auto gap-2" asChild>
                    <a href="mailto:absame@lazimkey.com">
                      Contact Security Team <ExternalLink className="h-3 w-3" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm uppercase font-bold tracking-tight">Resource Links</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <p className="text-[10px] font-bold uppercase text-muted-foreground flex items-center gap-2">
                        <Info className="h-3 w-3" />
                        External Guidance
                      </p>
                      <div className="flex flex-col gap-2">
                        <div className="flex flex-col gap-1">
                          <Button variant="link" size="sm" className="h-auto p-0 justify-start text-xs gap-2" asChild>
                            <a href="https://www.hhs.gov/hipaa/for-professionals/security/index.html" target="_blank" rel="noreferrer">
                              View HHS Security Rule <ExternalLink className="h-3 w-3" />
                            </a>
                          </Button>
                          <p className="text-[10px] text-muted-foreground italic">
                            If unavailable, visit hhs.gov and search for HIPAA Security Rule.
                          </p>
                        </div>
                        <div className="flex flex-col gap-1">
                          <Button variant="link" size="sm" className="h-auto p-0 justify-start text-xs gap-2" asChild>
                            <a href="https://www.hhs.gov/hipaa/for-professionals/privacy/index.html" target="_blank" rel="noreferrer">
                              View HHS Privacy Rule <ExternalLink className="h-3 w-3" />
                            </a>
                          </Button>
                          <p className="text-[10px] text-muted-foreground italic">
                            If unavailable, visit hhs.gov and search for HIPAA Privacy Rule.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="readiness" className="mt-6">
          <HIPAAReadiness />
        </TabsContent>

        {isAdmin && (
          <TabsContent value="audit" className="mt-6 space-y-6">
            <TrialPreviewBanner featureName="Administrative Audit Logs" />
            <AuditLogViewer />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};
