import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { MessageSquare, FileText, ShieldCheck, History, User, Clock, ArrowRight, Mail } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface TimelineTabProps {
  entityId: string;
  entityType: 'client' | 'provider' | 'contact';
}

export const TimelineTab: React.FC<TimelineTabProps> = ({ entityId, entityType }) => {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTimeline();
  }, [entityId]);

  const fetchTimeline = async () => {
    setLoading(true);
    try {
      // 1. Fetch notes
      const notesQuery = supabase.from('client_notes').select('*');
      
      if (entityType === 'client') {
        notesQuery.eq('client_id', entityId);
      } else if (entityType === 'provider') {
        notesQuery.eq('staff_id', entityId);
      } else if (entityType === 'contact') {
        notesQuery.eq('contact_id', entityId);
      }
      
      const { data: notes } = await notesQuery;

      // Fetch author emails for notes
      const authorIds = [...new Set((notes || []).map(n => n.author_id).filter(Boolean))];
      let authorMap: Record<string, string> = {};
      
      if (authorIds.length > 0) {
        const { data: members } = await supabase
          .from('workspace_members')
          .select('user_id, full_name')
          .in('user_id', authorIds);
        
        if (members) {
          authorMap = members.reduce((acc, m) => {
            acc[m.user_id] = m.full_name || '';
            return acc;
          }, {} as Record<string, string>);
        }
      }

      // 2. Fetch documents
      const docsQuery = supabase.from('documents').select('*');
      
      if (entityType === 'client') {
        docsQuery.eq('client_id', entityId);
      } else if (entityType === 'provider') {
        docsQuery.eq('staff_id', entityId);
      } else if (entityType === 'contact') {
        docsQuery.eq('contact_id', entityId);
      }
      
      const { data: docs } = await docsQuery;

      // 3. Fetch audit logs
      const { data: logs } = await supabase
        .from('audit_logs')
        .select('*')
        .eq('entity_id', entityId)
        .eq('entity_type', entityType);

      // 4. Fetch emails sent
      const { data: emails } = await supabase
        .from('emails_sent')
        .select('*')
        .eq('client_id', entityId);

      // Aggregate
      const aggregated = [
        ...(notes || []).map(n => ({
          id: n.id,
          type: 'note',
          date: n.created_at,
          title: n.title,
          description: `Note added by ${authorMap[n.author_id] || 'Unknown'}`,
          icon: MessageSquare,
          color: 'text-blue-500',
          bgColor: 'bg-blue-500/10'
        })),
        ...(docs || []).map(d => ({
          id: d.id,
          type: 'document',
          date: d.created_at,
          title: d.file_name,
          description: `Document uploaded (${d.category})`,
          icon: FileText,
          color: 'text-emerald-500',
          bgColor: 'bg-emerald-500/10'
        })),
        ...(logs || []).map(l => ({
          id: l.id,
          type: 'audit',
          date: l.created_at,
          title: l.action.replace(/_/g, ' '),
          description: l.metadata?.description || `System action performed`,
          icon: ShieldCheck,
          color: 'text-amber-500',
          bgColor: 'bg-amber-500/10'
        })),
        ...(emails || []).map(e => ({
          id: e.id,
          type: 'email',
          date: e.sent_at,
          title: `Email: ${e.subject}`,
          description: `Sent to ${e.recipient} (Status: ${e.status})`,
          icon: Mail,
          color: 'text-purple-500',
          bgColor: 'bg-purple-500/10'
        }))
      ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

      setEvents(aggregated);
    } catch (error) {
      console.error('Error fetching timeline:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div className="py-8 text-center text-muted-foreground">Generating timeline...</div>;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <History className="h-5 w-5 text-primary" />
          Case Activity Timeline
        </h3>
        <Badge variant="outline">{events.length} Events</Badge>
      </div>

      <div className="relative pl-8 space-y-8 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-0.5 before:bg-muted">
        {events.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground italic pl-0">No activity recorded yet.</div>
        ) : (
          events.map((event) => (
            <div key={`${event.type}-${event.id}`} className="relative group">
              <div className={`absolute -left-[31px] top-0 p-1.5 rounded-full border bg-background shadow-sm transition-transform group-hover:scale-110 z-10 ${event.color} ${event.bgColor}`}>
                <event.icon className="h-4 w-4" />
              </div>
              
              <div className="space-y-1.5">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider tabular-nums">
                    {format(new Date(event.date), 'MMM d, yyyy • h:mm a')}
                  </span>
                  <Badge variant="secondary" className="text-[10px] uppercase font-bold px-1.5 py-0">
                    {event.type}
                  </Badge>
                </div>
                
                <Card className="border-muted hover:border-primary/20 transition-colors">
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-sm mb-1">{event.title}</h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">{event.description}</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};