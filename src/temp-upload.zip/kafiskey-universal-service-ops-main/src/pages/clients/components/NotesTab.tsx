import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { MessageSquare, Paperclip, Plus, Send, MoreHorizontal, User, Clock, FileText, Download } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

interface NotesTabProps {
  entityId: string;
  entityType: 'client' | 'provider' | 'contact';
  isAddNoteOpen: boolean;
  onAddNoteClose: () => void;
  onAddNoteOpen?: () => void;
  onNoteAdded: () => void;
}

export const NotesTab: React.FC<NotesTabProps> = ({ 
  entityId, 
  entityType,
  isAddNoteOpen, 
  onAddNoteClose,
  onAddNoteOpen,
  onNoteAdded
}) => {
  const { activeWorkspace } = useWorkspace();
  const [notes, setNotes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Form state
  const [noteTitle, setNoteTitle] = useState('');
  const [noteType, setNoteType] = useState('Follow-up');
  const [noteContent, setNoteContent] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [saving, setSaving] = useState(false);

  // Addendum state
  const [isAddendumOpen, setIsAddendumOpen] = useState(false);
  const [selectedNote, setSelectedNote] = useState<any>(null);
  const [addendumContent, setAddendumContent] = useState('');

  useEffect(() => {
    fetchNotes();
  }, [entityId]);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      // Fetch notes with attachments
      const query = supabase
        .from('client_notes') // We'll use this for both for now, assuming it has entity_id or similar
        .select(`
          *,
          attachments:client_note_attachments(*)
        `);

      if (entityType === 'client') {
        query.eq('client_id', entityId);
      } else if (entityType === 'provider') {
        query.eq('staff_id', entityId);
      } else if (entityType === 'contact') {
        query.eq('contact_id', entityId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      
      // Fetch author emails for all unique author_ids
      const authorIds = [...new Set((data || []).map(n => n.author_id).filter(Boolean))];
      let authorMap: Record<string, string> = {};
      
      if (authorIds.length > 0) {
        const { data: members } = await supabase
          .from('workspace_members')
          .select('user_id, full_name')
          .in('user_id', authorIds);
        
        if (members) {
          authorMap = members.reduce((acc, m) => {
            acc[m.user_id] = m.full_name || '';
            return acc;
          }, {} as Record<string, string>);
        }
      }
      
      // Attach author info to notes
      const notesWithAuthors = (data || []).map(note => ({
        ...note,
        author: authorMap[note.author_id] ? { name: authorMap[note.author_id] } : null
      }));
      
      setNotes(notesWithAuthors);
    } catch (error: any) {
      toast.error('Error fetching notes: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setAttachments(Array.from(e.target.files));
    }
  };

  const handleSaveNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !entityId || !noteContent) return;

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // 1. Create the note
      const noteData: any = {
        workspace_id: activeWorkspace.id,
        author_id: user.id,
        title: noteTitle || `${noteType} Note`,
        note_type: noteType,
        content: noteContent
      };

      if (entityType === 'client') {
        noteData.client_id = entityId;
      } else if (entityType === 'provider') {
        noteData.staff_id = entityId;
      } else if (entityType === 'contact') {
        noteData.contact_id = entityId;
      }

      const { data: note, error: noteError } = await supabase
        .from('client_notes')
        .insert(noteData)
        .select()
        .single();

      if (noteError) throw noteError;

      // 2. Upload attachments if any
      if (attachments.length > 0) {
        for (const file of attachments) {
          const fileExt = file.name.split('.').pop();
          const fileName = `${Math.random()}.${fileExt}`;
          const filePath = `notes/${entityType}/${entityId}/${note.id}/${fileName}`;

          const { error: uploadError } = await supabase.storage
            .from('client-documents')
            .upload(filePath, file);

          if (uploadError) throw uploadError;

          const { data: { publicUrl } } = supabase.storage
            .from('client-documents')
            .getPublicUrl(filePath);

          const attachmentData: any = {
            workspace_id: activeWorkspace.id,
            note_id: note.id,
            file_name: file.name,
            storage_path: filePath,
            mime_type: file.type,
            size: file.size,
            public_url: publicUrl,
            uploaded_by: user.id
          };

          if (entityType === 'client') {
            attachmentData.client_id = entityId;
          } else if (entityType === 'provider') {
            attachmentData.staff_id = entityId;
          } else if (entityType === 'contact') {
            attachmentData.contact_id = entityId;
          }

          await supabase.from('client_note_attachments').insert(attachmentData);
        }
      }

      // 3. Log to audit
      await supabase.from('audit_logs').insert({
        workspace_id: activeWorkspace.id,
        actor_user_id: user.id,
        action: 'NOTE_ADDED',
        entity_type: entityType,
        entity_id: entityId,
        metadata: { title: noteTitle, type: noteType }
      });

      toast.success('Note added successfully');
      resetForm();
      onAddNoteClose();
      fetchNotes();
      onNoteAdded();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleAddAddendum = async () => {
    if (!activeWorkspace || !selectedNote || !addendumContent) return;

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const addendumData: any = {
        workspace_id: activeWorkspace.id,
        author_id: user.id,
        title: `Addendum to: ${selectedNote.title}`,
        note_type: 'Addendum',
        content: addendumContent,
        parent_note_id: selectedNote.id
      };

      if (entityType === 'client') {
        addendumData.client_id = entityId;
      } else if (entityType === 'provider') {
        addendumData.staff_id = entityId;
      } else if (entityType === 'contact') {
        addendumData.contact_id = entityId;
      }

      const { error } = await supabase.from('client_notes').insert(addendumData);

      if (error) throw error;

      toast.success('Addendum added');
      setIsAddendumOpen(false);
      setAddendumContent('');
      fetchNotes();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setNoteTitle('');
    setNoteType('Follow-up');
    setNoteContent('');
    setAttachments([]);
  };

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading notes...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <MessageSquare className="h-5 w-5 text-primary" />
            Clinical Notes & Activity
          </h3>
          <Badge variant="outline">{notes.length} Records</Badge>
        </div>
        {onAddNoteOpen && (
          <Button onClick={onAddNoteOpen} size="sm" className="gap-2">
            <Plus className="h-4 w-4" />
            Add Note
          </Button>
        )}
      </div>

      <div className="space-y-4">
        {notes.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-12 text-center">
              <MessageSquare className="h-12 w-12 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No clinical notes recorded for this client.</p>
              <Button variant="outline" className="mt-4" onClick={() => onAddNoteClose()}>
                Create First Note
              </Button>
            </CardContent>
          </Card>
        ) : (
          notes.filter(n => !n.parent_note_id).map((note) => (
            <Card key={note.id} className="overflow-hidden border-l-4 border-l-primary shadow-sm hover:shadow-md transition-shadow">
              <CardHeader className="pb-3 bg-muted/20">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="text-[10px] uppercase font-bold tracking-wider">
                        {note.note_type}
                      </Badge>
                      <CardTitle className="text-base">{note.title}</CardTitle>
                    </div>
                    <CardDescription className="flex items-center gap-2 text-xs">
                      <User className="h-3 w-3" /> {note.author?.name || 'Unknown Author'}
                      <span>&bull;</span>
                      <Clock className="h-3 w-3" /> {format(new Date(note.created_at), 'MMM d, yyyy h:mm a')}
                    </CardDescription>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => {
                        setSelectedNote(note);
                        setIsAddendumOpen(true);
                      }}>
                        Add Addendum
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="pt-4 space-y-4">
                <div className="text-sm leading-relaxed whitespace-pre-wrap text-foreground/90">
                  {note.content}
                </div>

                {note.attachments && note.attachments.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-2">
                    {note.attachments.map((att: any) => (
                      <a
                        key={att.id}
                        href={att.public_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 p-2 rounded-md bg-muted hover:bg-muted/80 text-xs font-medium transition-colors border"
                      >
                        <FileText className="h-3.5 w-3.5 text-primary" />
                        <span className="truncate max-w-[150px]">{att.file_name}</span>
                        <Download className="h-3 w-3 ml-1 opacity-50" />
                      </a>
                    ))}
                  </div>
                )}

                {/* Render Addendums */}
                {notes.filter(n => n.parent_note_id === note.id).map(addendum => (
                  <div key={addendum.id} className="mt-4 pl-4 border-l-2 border-primary/30 py-2 bg-primary/5 dark:bg-primary/10 rounded-r-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant="outline" className="text-[9px] uppercase font-bold">Addendum</Badge>
                      <span className="text-[10px] text-muted-foreground">{format(new Date(addendum.created_at), 'MMM d, yyyy h:mm a')}</span>
                    </div>
                    <p className="text-xs italic text-foreground/80">{addendum.content}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Add Note Dialog */}
      <Dialog open={isAddNoteOpen} onOpenChange={onAddNoteClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Add Clinical Note</DialogTitle>
            <DialogDescription>Record a new interaction or observation for this client.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Note Type</Label>
                <Select value={noteType} onValueChange={setNoteType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Intake">Intake</SelectItem>
                    <SelectItem value="Follow-up">Follow-up</SelectItem>
                    <SelectItem value="Phone Call">Phone Call</SelectItem>
                    <SelectItem value="Visit Summary">Visit Summary</SelectItem>
                    <SelectItem value="Escalation">Escalation</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Note Title (Optional)</Label>
                <Input 
                  placeholder="e.g. Monthly Progress Review"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Narrative</Label>
              <Textarea 
                placeholder="Describe the interaction, observations, and outcomes..."
                className="min-h-[200px]"
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                spellCheck={true}
                autoCorrect="on"
                autoCapitalize="sentences"
              />
            </div>
            <div className="space-y-2">
              <Label>Attachments</Label>
              <div className="flex items-center gap-2">
                <Input 
                  type="file" 
                  multiple 
                  className="cursor-pointer" 
                  onChange={handleFileChange}
                />
              </div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Max 5 files. Support: PDF, JPG, PNG.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={onAddNoteClose}>Cancel</Button>
            <Button onClick={handleSaveNote} disabled={saving || !noteContent}>
              {saving ? 'Saving...' : 'Save Note'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Addendum Dialog */}
      <Dialog open={isAddendumOpen} onOpenChange={setIsAddendumOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Addendum</DialogTitle>
            <DialogDescription>Provide additional context to the original note.</DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {selectedNote && (
              <div className="p-3 bg-muted rounded-md text-xs border">
                <p className="font-bold mb-1">Original Note:</p>
                <p className="truncate opacity-70">{selectedNote.content}</p>
              </div>
            )}
            <div className="space-y-2">
              <Label>Addendum Content</Label>
              <Textarea 
                placeholder="Enter addendum details..."
                value={addendumContent}
                onChange={(e) => setAddendumContent(e.target.value)}
                spellCheck={true}
                autoCorrect="on"
                autoCapitalize="sentences"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddendumOpen(false)}>Cancel</Button>
            <Button onClick={handleAddAddendum} disabled={saving || !addendumContent}>
              {saving ? 'Saving...' : 'Save Addendum'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
