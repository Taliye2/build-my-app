import React from 'react';
import { format } from 'date-fns';
import { ChevronLeft, Plus, MoreVertical, Edit2, Mail, Printer } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface ClientHeaderProps {
  client: any;
  onEditProfile: () => void;
  onAddDocument: () => void;
  onSendEmail: () => void;
  onStatusChange: (status: string) => void;
  onPrint: () => void;
}

export const ClientHeader: React.FC<ClientHeaderProps> = ({
  client,
  onEditProfile,
  onAddDocument,
  onSendEmail,
  onStatusChange,
  onPrint,
}) => {
  const statusColors: Record<string, "success" | "warning" | "secondary" | "destructive"> = {
    'ACTIVE': 'success',
    'PENDING': 'warning',
    'ON_HOLD': 'secondary',
    'CLOSED': 'destructive'
  };

  return (
    <div className="flex flex-col md:flex-row md:items-center gap-4 border-b pb-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild className="shrink-0">
          <Link to="/clients">
            <ChevronLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h2 className="text-3xl font-bold tracking-tight">
              {client.first_name} {client.last_name}
            </h2>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="p-0 h-auto hover:bg-transparent">
                  <Badge variant={statusColors[client.status] || 'outline'} className="capitalize cursor-pointer hover:opacity-80">
                    {client.status?.replace('_', ' ')}
                  </Badge>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                <DropdownMenuItem onClick={() => onStatusChange('ACTIVE')}>Active</DropdownMenuItem>
                <DropdownMenuItem onClick={() => onStatusChange('PENDING')}>Pending</DropdownMenuItem>
                <DropdownMenuItem onClick={() => onStatusChange('ON_HOLD')}>On Hold</DropdownMenuItem>
                <DropdownMenuItem onClick={() => onStatusChange('CLOSED')}>Closed</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <div className="flex items-center gap-3 text-muted-foreground mt-1 text-sm">
            <span className="font-medium">Case: {client.case_number || 'PENDING'}</span>
            <span>&bull;</span>
            <span>Joined {format(new Date(client.date_joined || client.created_at), 'MMM d, yyyy')}</span>
          </div>
          {client.tags && client.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {client.tags.map((tag: string) => (
                <Badge key={tag} variant="outline" className="bg-primary/5 dark:bg-primary/10 text-primary dark:text-primary-glow border-primary/20 text-[10px] font-bold uppercase tracking-wider">
                  {tag}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2 md:ml-auto">
        <Button variant="outline" className="gap-2" onClick={onPrint}>
          <Printer className="h-4 w-4" />
          <span className="hidden sm:inline">Print Profile</span>
        </Button>
        <Button variant="outline" className="gap-2" onClick={onSendEmail}>
          <Mail className="h-4 w-4" />
          <span className="hidden sm:inline">Send Email</span>
        </Button>
        <Button variant="outline" className="gap-2" onClick={onEditProfile}>
          <Edit2 className="h-4 w-4" />
          <span className="hidden sm:inline">Edit Profile</span>
        </Button>
        <Button className="gap-2" onClick={onAddDocument}>
          <Plus className="h-4 w-4" />
          <span>Add Document</span>
        </Button>
      </div>
    </div>
  );
};
