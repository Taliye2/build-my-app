import React from 'react';
import { format, parseISO } from 'date-fns';
import { User, Calendar, ShieldCheck, Mail, Phone, MapPin, Globe, UserPlus, Key } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

interface ClientOverviewProps {
  client: any;
}

export const ClientOverview: React.FC<ClientOverviewProps> = ({ client }) => {
  const InfoItem = ({ icon: Icon, label, value, subValue }: any) => (
    <div className="flex items-start gap-3">
      <div className="mt-1 p-1.5 bg-primary/5 dark:bg-primary/10 rounded border border-primary/10">
        <Icon className="h-3.5 w-3.5 text-primary" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight mb-0.5">{label}</p>
        <p className="text-sm font-semibold truncate">{value || <span className="text-muted-foreground font-normal italic text-[10px]">Not Provided</span>}</p>
        {subValue && <p className="text-xs text-muted-foreground">{subValue}</p>}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <Card className="border-primary/10 shadow-sm overflow-hidden bg-white dark:bg-card">
        <CardHeader className="pb-3 border-b bg-muted/30 dark:bg-slate-900/50">
          <CardTitle className="text-sm font-bold uppercase tracking-wider text-foreground">Client Overview</CardTitle>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="space-y-5">
            <InfoItem icon={User} label="Legal Name" value={client.preferred_name ? `${client.first_name} ${client.last_name} (${client.preferred_name})` : `${client.first_name} ${client.last_name}`} />
            <InfoItem icon={Calendar} label="Date of Birth" value={client.dob ? format(parseISO(client.dob), 'MMMM d, yyyy') : null} />
            <InfoItem icon={ShieldCheck} label="Case Identifier" value={client.case_number} />
            <InfoItem icon={UserPlus} label="Joined Date" value={format(new Date(client.date_joined || client.created_at), 'MMMM d, yyyy')} />
          </div>
          
          <Separator />
          
          <div className="space-y-5">
            <InfoItem icon={Mail} label="Email Contact" value={client.email} />
            <InfoItem icon={Phone} label="Primary Phone" value={client.phone} />
            <InfoItem 
              icon={MapPin} 
              label="Residential Address" 
              value={client.street_address ? `${client.street_address}${client.city ? `, ${client.city}` : ''}${client.state ? ` ${client.state}` : ''}${client.zip_code ? ` ${client.zip_code}` : ''}` : client.address} 
            />
            {client.mailing_same_as_physical === false && (
              <InfoItem 
                icon={MapPin} 
                label="Mailing Address" 
                value={`${client.mailing_street_address}${client.mailing_city ? `, ${client.mailing_city}` : ''}${client.mailing_state ? ` ${client.mailing_state}` : ''}${client.mailing_zip_code ? ` ${client.mailing_zip_code}` : ''}`} 
              />
            )}
          </div>

          <Separator />

          <div className="space-y-5">
            <div className="grid grid-cols-2 gap-4">
              <InfoItem icon={Globe} label="Language" value={client.language_preference || 'English'} />
              <InfoItem icon={ShieldCheck} label="Contact Method" value={client.preferred_contact_method || 'Any'} />
            </div>
          </div>

          {(client.saved_username || client.saved_password) && (
            <>
              <Separator />
              <div className="space-y-5">
                <div className="flex items-center gap-2 mb-2">
                  <Key className="h-4 w-4 text-primary" />
                  <span className="text-xs font-bold uppercase tracking-wider text-primary">Stored Portal Credentials</span>
                </div>
                <div className="grid grid-cols-2 gap-4 bg-muted/30 p-3 rounded-lg border border-border/50">
                  <InfoItem icon={User} label="Saved Username" value={client.saved_username} />
                  <InfoItem icon={Key} label="Saved Password" value={client.saved_password ? "••••••••" : null} subValue={client.saved_password ? "(Confidential info stored for reference)" : null} />
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {(client.emergency_contact_name || client.emergency_contact_phone) && (
        <Card className="border-destructive/10 overflow-hidden bg-white dark:bg-card">
          <CardHeader className="pb-3 border-b bg-destructive/5 dark:bg-destructive/10">
            <CardTitle className="text-sm font-bold uppercase tracking-wider text-destructive flex items-center gap-2">
              <ShieldCheck className="h-4 w-4" />
              Emergency Contact
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <div>
              <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight">Full Name</p>
              <p className="text-sm font-semibold">{client.emergency_contact_name || '—'}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-tight">Contact Phone</p>
              <p className="text-sm font-semibold">{client.emergency_contact_phone || '—'}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {!client.email && !client.phone && !client.address && (
        <Badge variant="warning" className="w-full justify-center py-1.5 text-[10px] uppercase tracking-wider font-bold">
          Missing critical contact info
        </Badge>
      )}
    </div>
  );
};