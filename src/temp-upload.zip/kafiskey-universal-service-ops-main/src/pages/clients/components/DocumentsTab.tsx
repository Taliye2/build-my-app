import React, { useState, useEffect } from 'react';
import { format, isPast, addDays, isFuture } from 'date-fns';
import { FileText, Plus, Search, Filter, Download, History, Trash2, ShieldCheck, AlertTriangle, CheckCircle2, MoreVertical, RotateCcw, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { logAudit } from '@/lib/audit';
import { getSignedUrl } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface DocumentsTabProps {
  entityId: string;
  entityType: 'client' | 'provider' | 'contact';
  isAddDocOpen: boolean;
  onAddDocClose: () => void;
  onDocAdded: () => void;
}

export const DocumentsTab: React.FC<DocumentsTabProps> = ({
  entityId,
  entityType,
  isAddDocOpen,
  onAddDocClose,
  onDocAdded
}) => {
  const { user } = useAuth();
  const { activeWorkspace } = useWorkspace();
  const [documents, setDocuments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // New Document state
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState('Other');
  const [docEffectiveDate, setDocEffectiveDate] = useState('');
  const [docExpirationDate, setDocExpirationDate] = useState('');
  const [docFile, setDocFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  // Version history state
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<any>(null);
  const [versions, setVersions] = useState<any[]>([]);

  // Replace state
  const [isReplaceOpen, setIsReplaceOpen] = useState(false);
  const [replaceFile, setReplaceFile] = useState<File | null>(null);

  useEffect(() => {
    fetchDocuments();
  }, [entityId]);

  const fetchDocuments = async () => {
    setLoading(true);
    try {
      const query = supabase
        .from('documents')
        .select('*');

      if (entityType === 'client') {
        query.eq('client_id', entityId);
      } else if (entityType === 'provider') {
        query.eq('staff_id', entityId);
      } else if (entityType === 'contact') {
        query.eq('contact_id', entityId);
      }

      const { data, error } = await query.order('created_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error: any) {
      toast.error('Error fetching documents: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUploadDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || !entityId || !docFile) return;

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const fileExt = docFile.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `documents/${entityType}/${entityId}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('client-documents')
        .upload(filePath, docFile);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('client-documents')
        .getPublicUrl(filePath);

      const docData: any = {
        workspace_id: activeWorkspace.id,
        file_name: docTitle || docFile.name,
        storage_path: filePath,
        mime_type: docFile.type,
        size: docFile.size,
        uploaded_by: user.id,
        category: docCategory,
        effective_date: docEffectiveDate || null,
        expiration_date: docExpirationDate || null,
        public_url: publicUrl,
        status: 'active'
      };

      if (entityType === 'client') {
        docData.client_id = entityId;
      } else if (entityType === 'provider') {
        docData.staff_id = entityId;
      } else if (entityType === 'contact') {
        docData.contact_id = entityId;
      }

      const { error: dbError } = await supabase.from('documents').insert(docData);

      if (dbError) throw dbError;

      toast.success('Document uploaded successfully');
      resetForm();
      onAddDocClose();
      fetchDocuments();
      onDocAdded();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleReplaceDoc = async () => {
    if (!selectedDoc || !replaceFile || !activeWorkspace) return;

    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // 1. Store current version in client_document_versions
      await supabase.from('client_document_versions').insert({
        document_id: selectedDoc.id,
        file_name: selectedDoc.file_name,
        storage_path: selectedDoc.storage_path,
        mime_type: selectedDoc.mime_type,
        size: selectedDoc.size,
        public_url: selectedDoc.public_url,
        uploaded_by: selectedDoc.uploaded_by
      });

      // 2. Upload new file
      const fileExt = replaceFile.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `documents/${entityType}/${entityId}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('client-documents')
        .upload(filePath, replaceFile);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('client-documents')
        .getPublicUrl(filePath);

      // 3. Update main document record
      const { error: updateError } = await supabase
        .from('documents')
        .update({
          file_name: replaceFile.name,
          storage_path: filePath,
          mime_type: replaceFile.type,
          size: replaceFile.size,
          public_url: publicUrl,
          uploaded_by: user.id,
          created_at: new Date().toISOString()
        })
        .eq('id', selectedDoc.id);

      if (updateError) throw updateError;

      toast.success('Document replaced successfully');
      setIsReplaceOpen(false);
      setReplaceFile(null);
      fetchDocuments();
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setSaving(false);
    }
  };

  const fetchVersions = async (doc: any) => {
    setSelectedDoc(doc);
    try {
      const { data, error } = await supabase
        .from('client_document_versions')
        .select('*')
        .eq('document_id', doc.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVersions(data || []);
      setIsHistoryOpen(true);
    } catch (error: any) {
      toast.error('Error fetching versions: ' + error.message);
    }
  };

  const resetForm = () => {
    setDocTitle('');
    setDocCategory('Other');
    setDocEffectiveDate('');
    setDocExpirationDate('');
    setDocFile(null);
  };

  const getDocStatus = (doc: any) => {
    if (!doc.expiration_date) return 'active';
    const expiry = new Date(doc.expiration_date);
    if (isPast(expiry)) return 'expired';
    if (isFuture(expiry) && isPast(addDays(expiry, -30))) return 'expiring-soon';
    return 'active';
  };

  const filteredDocs = documents.filter(doc => {
    const matchesSearch = doc.file_name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || doc.category === categoryFilter;
    const matchesStatus = statusFilter === 'all' || getDocStatus(doc) === statusFilter;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleViewDocument = async (doc: any) => {
    if (!activeWorkspace || !user) return;

    try {
      const signedUrl = await getSignedUrl('client-documents', doc.storage_path);
      
      // Log the view/download event
      logAudit(activeWorkspace.id, user.id, 'DOWNLOAD', 'document', doc.id, { method: 'signed_url' });
      
      window.open(signedUrl, '_blank', 'noopener,noreferrer');
    } catch (error: any) {
      toast.error('Error generating secure link: ' + error.message);
    }
  };

  const StatusBadge = ({ status }: { status: string }) => {
    switch (status) {
      case 'expired':
        return <Badge variant="destructive" className="gap-1"><AlertTriangle className="h-3 w-3" /> Expired</Badge>;
      case 'expiring-soon':
        return <Badge variant="warning" className="gap-1"><Clock className="h-3 w-3" /> Expiring Soon</Badge>;
      default:
        return <Badge variant="success" className="gap-1"><CheckCircle2 className="h-3 w-3" /> Active</Badge>;
    }
  };

  if (loading) return <div className="p-8 text-center text-muted-foreground">Loading documents...</div>;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search documents..." 
            className="pl-10"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="ID">ID</SelectItem>
              <SelectItem value="Consent">Consent</SelectItem>
              <SelectItem value="Eligibility">Eligibility</SelectItem>
              <SelectItem value="Medical">Medical</SelectItem>
              <SelectItem value="School">School</SelectItem>
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="expiring-soon">Expiring Soon</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="border rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead>Document Name</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Dates</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredDocs.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                  No documents found matching the filters.
                </TableCell>
              </TableRow>
            ) : (
              filteredDocs.map((doc) => (
                <TableRow key={doc.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/5 dark:bg-primary/10 rounded border border-primary/10">
                        <FileText className="h-4 w-4 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <button 
                          onClick={() => handleViewDocument(doc)}
                          className="font-medium text-sm truncate max-w-[200px] hover:text-primary hover:underline transition-colors block text-left bg-transparent border-none p-0 cursor-pointer"
                        >
                          {doc.file_name}
                        </button>
                        <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-tight">
                          {(doc.size / 1024).toFixed(1)} KB &bull; {format(new Date(doc.created_at), 'MMM d, yyyy')}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-[10px] font-bold uppercase tracking-wider">{doc.category}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-0.5">
                      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-tighter">Effective</p>
                      <p className="text-xs">{doc.effective_date ? format(new Date(doc.effective_date), 'MMM d, yyyy') : '—'}</p>
                      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-tighter mt-1">Expires</p>
                      <p className="text-xs font-medium">{doc.expiration_date ? format(new Date(doc.expiration_date), 'MMM d, yyyy') : 'Never'}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <StatusBadge status={getDocStatus(doc)} />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" onClick={() => handleViewDocument(doc)} className="h-8 w-8">
                        <Download className="h-4 w-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => {
                            setSelectedDoc(doc);
                            setIsReplaceOpen(true);
                          }}>
                            <RotateCcw className="h-4 w-4 mr-2" /> Replace
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => fetchVersions(doc)}>
                            <History className="h-4 w-4 mr-2" /> History
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add Document Dialog */}
      <Dialog open={isAddDocOpen} onOpenChange={onAddDocClose}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Document</DialogTitle>
            <DialogDescription>Add a new compliance or clinical document to the client profile.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Document Title</Label>
              <Input 
                placeholder="e.g. Health Assessment 2024"
                value={docTitle}
                onChange={(e) => setDocTitle(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={docCategory} onValueChange={setDocCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ID">ID / License</SelectItem>
                    <SelectItem value="Consent">Consent Form</SelectItem>
                    <SelectItem value="Eligibility">Eligibility</SelectItem>
                    <SelectItem value="Medical">Medical Record</SelectItem>
                    <SelectItem value="School">School Record</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>File Upload</Label>
                <Input type="file" onChange={(e) => setDocFile(e.target.files?.[0] || null)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Effective Date</Label>
                <Input type="date" value={docEffectiveDate} onChange={(e) => setDocEffectiveDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Expiration Date</Label>
                <Input type="date" value={docExpirationDate} onChange={(e) => setDocExpirationDate(e.target.value)} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={onAddDocClose}>Cancel</Button>
            <Button onClick={handleUploadDoc} disabled={saving || !docFile}>
              {saving ? 'Uploading...' : 'Upload Document'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Replace Document Dialog */}
      <Dialog open={isReplaceOpen} onOpenChange={setIsReplaceOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Replace Document</DialogTitle>
            <DialogDescription>The current version will be moved to history. Only the latest version is shown in the main list.</DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {selectedDoc && (
              <div className="p-3 bg-muted rounded-md border text-xs">
                <p className="font-bold">Current: {selectedDoc.file_name}</p>
                <p className="opacity-70">Category: {selectedDoc.category}</p>
              </div>
            )}
            <div className="space-y-2">
              <Label>New File</Label>
              <Input type="file" onChange={(e) => setReplaceFile(e.target.files?.[0] || null)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsReplaceOpen(false)}>Cancel</Button>
            <Button onClick={handleReplaceDoc} disabled={saving || !replaceFile}>
              {saving ? 'Replacing...' : 'Confirm Replace'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Version History Dialog */}
      <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Document History</DialogTitle>
            <DialogDescription>Previous versions of this document.</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {versions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground italic">No previous versions found.</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>File Name</TableHead>
                    <TableHead>Uploaded On</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {versions.map((v) => (
                    <TableRow key={v.id}>
                      <TableCell className="text-sm">{v.file_name}</TableCell>
                      <TableCell className="text-sm">{format(new Date(v.created_at), 'MMM d, yyyy h:mm a')}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" asChild>
                          <a href={v.public_url} target="_blank" rel="noopener noreferrer">
                            <Download className="h-4 w-4" />
                          </a>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsHistoryOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
