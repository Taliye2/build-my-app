import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileText, CheckCircle, Clock, Printer } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { Link } from 'react-router-dom';

interface ServiceRecordsClientTabProps {
  clientId: string;
}

export const ServiceRecordsClientTab: React.FC<ServiceRecordsClientTabProps> = ({ clientId }) => {
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRecords = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('service_events')
        .select('*, service_templates(*), service_records(*)')
        .eq('client_id', clientId)
        .order('date', { ascending: false });

      if (!error && data) {
        setRecords(data);
      }
      setLoading(false);
    };

    fetchRecords();
  }, [clientId]);

  if (loading) return <div className="py-8 text-center text-muted-foreground">Loading service records...</div>;

  return (
    <div className="space-y-4">
      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Service</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {records.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="h-24 text-center text-muted-foreground italic">
                  No service records found for this client.
                </TableCell>
              </TableRow>
            ) : (
              records.map((event) => {
                const hasRecord = event.service_records && event.service_records.length > 0;
                const record = hasRecord ? event.service_records[0] : null;
                const isSigned = record?.signed_at != null;

                return (
                  <TableRow key={event.id}>
                    <TableCell className="text-sm font-medium">
                      {format(parseISO(event.date), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-sm">
                      <div className="flex flex-col">
                        <span>{event.service_templates?.name}</span>
                        <span className="text-[10px] text-muted-foreground">{event.start_time} - {event.end_time}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {isSigned ? (
                        <Badge variant="success" className="gap-1">
                          <CheckCircle className="h-3 w-3" /> Signed
                        </Badge>
                      ) : hasRecord ? (
                        <Badge variant="warning">Draft</Badge>
                      ) : (
                        <Badge variant="secondary">Missing</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link to={`/documentation/edit/${event.id}`}>
                            {hasRecord ? 'Edit' : 'Create'} Note
                          </Link>
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
