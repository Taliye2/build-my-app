import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { ClientHeader } from './components/ClientHeader';
import { ClientOverview } from './components/ClientOverview';
import { NotesTab } from './components/NotesTab';
import { DocumentsTab } from './components/DocumentsTab';
import { ServiceRecordsClientTab } from './components/ServiceRecordsClientTab';
import { InvoicesClientTab } from './components/InvoicesClientTab';
import { TimelineTab } from './components/TimelineTab';
import { EditProfileDialog } from './components/EditProfileDialog';
import { ComposeEmailDialog } from '@/components/ComposeEmailDialog';
import { MessageSquare, FileText, History, ClipboardList, Receipt } from 'lucide-react';
import { Spinner } from '@/components/ui/spinner';
import { logAudit } from '@/lib/audit';

export const ClientProfilePage: React.FC = () => {
  const { clientId } = useParams<{ clientId: string }>();
  const { activeWorkspace } = useWorkspace();
  const [client, setClient] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any | null>(null); // State to hold user object
  
  // Modal states
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddNoteOpen, setIsAddNoteOpen] = useState(false);
  const [isAddDocOpen, setIsAddDocOpen] = useState(false);
  const [isComposeEmailOpen, setIsComposeEmailOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchClient();
    const initialize = async () => {
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      setUser(currentUser);
      if (currentUser && clientId && activeWorkspace) {
        logAudit(activeWorkspace.id, currentUser.id, 'VIEW', 'client', clientId);
      }
    };
    initialize();
  }, [clientId, activeWorkspace]);

  const fetchUser = async () => {
    try {
      const { data: { user: fetchedUser } } = await supabase.auth.getUser();
      setUser(fetchedUser);
    } catch (error: any) {
      toast.error('Error fetching user: ' + error.message);
    }
  };

  const fetchClient = async () => {
    if (!clientId || !activeWorkspace) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('clients')
        .select('*')
        .eq('id', clientId)
        .eq('workspace_id', activeWorkspace.id)
        .single();

      if (error) throw error;
      setClient(data);
    } catch (error: any) {
      toast.error('Error fetching client details: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (newStatus: string) => {
    if (!activeWorkspace || !clientId || !client) return;

    try {
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      if (!currentUser) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('clients')
        .update({ status: newStatus })
        .eq('id', clientId);

      if (error) throw error;

      await supabase.from('audit_logs').insert({
        workspace_id: activeWorkspace.id,
        actor_user_id: currentUser.id,
        action: 'STATUS_CHANGE',
        entity_type: 'client',
        entity_id: clientId,
        metadata: {
          old_status: client.status,
          new_status: newStatus,
          description: `Status changed from ${client.status} to ${newStatus}`
        }
      });

      setClient({ ...client, status: newStatus });
      toast.success(`Status updated to ${newStatus}`);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const handlePrint = () => {
    if (activeWorkspace && user && clientId) {
      logAudit(activeWorkspace.id, user.id, 'DOWNLOAD', 'client_profile', clientId, { method: 'print' });
    }
    window.print();
  };

  if (loading) {
    return (
      <div className="flex h-[400px] items-center justify-center">
        <Spinner className="h-8 w-8 text-primary" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-muted-foreground">Client profile not found</h2>
      </div>
    );
  }

  return (
    <div className="max-w-[1600px] mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-20">
      <ClientHeader 
        client={client}
        onEditProfile={() => setIsEditModalOpen(true)}
        onAddDocument={() => {
          setActiveTab('documents');
          setIsAddDocOpen(true);
        }}
        onSendEmail={() => setIsComposeEmailOpen(true)}
        onStatusChange={handleStatusChange}
        onPrint={handlePrint}
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Client Overview */}
        <aside className="lg:col-span-4 xl:col-span-3 space-y-6 lg:sticky lg:top-8">
          <ClientOverview client={client} />
        </aside>

        {/* Right Column: Main Content Tabs */}
        <main className="lg:col-span-8 xl:col-span-9">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent space-x-8 mb-6 overflow-x-auto scrollbar-hide">
              <TabsTrigger 
                value="overview" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <ClipboardList className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger 
                value="records" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <FileText className="h-4 w-4" />
                Service Records
              </TabsTrigger>
              <TabsTrigger 
                value="invoices" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <Receipt className="h-4 w-4" />
                Invoices
              </TabsTrigger>
              <TabsTrigger 
                value="notes" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <MessageSquare className="h-4 w-4" />
                Case Notes
              </TabsTrigger>
              <TabsTrigger 
                value="documents" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <FileText className="h-4 w-4" />
                Documents
              </TabsTrigger>
              <TabsTrigger 
                value="timeline" 
                className="px-0 py-3 rounded-none border-b-2 border-transparent data-[state=active]:border-brand-blue data-[state=active]:bg-transparent data-[state=active]:shadow-none gap-2 font-bold data-[state=active]:text-brand-blue"
              >
                <History className="h-4 w-4" />
                History
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <TimelineTab entityId={client.id} entityType="client" />
            </TabsContent>

            <TabsContent value="records" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <ServiceRecordsClientTab clientId={client.id} />
            </TabsContent>

            <TabsContent value="invoices" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <InvoicesClientTab clientId={client.id} />
            </TabsContent>

            <TabsContent value="notes" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <NotesTab 
                entityId={client.id} 
                entityType="client"
                isAddNoteOpen={isAddNoteOpen}
                onAddNoteClose={() => setIsAddNoteOpen(false)}
                onAddNoteOpen={() => setIsAddNoteOpen(true)}
                onNoteAdded={() => {}} // Could trigger a reload of timeline if needed
              />
            </TabsContent>

            <TabsContent value="documents" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <DocumentsTab 
                entityId={client.id}
                entityType="client"
                isAddDocOpen={isAddDocOpen}
                onAddDocClose={() => setIsAddDocOpen(false)}
                onDocAdded={() => {}}
              />
            </TabsContent>

            <TabsContent value="timeline" className="mt-0 focus-visible:outline-none focus-visible:ring-0">
              <TimelineTab entityId={client.id} entityType="client" />
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <EditProfileDialog 
        isOpen={isEditModalOpen}
        onOpenChange={setIsEditModalOpen}
        client={client}
        onSuccess={fetchClient}
      />

      <ComposeEmailDialog
        open={isComposeEmailOpen}
        onOpenChange={setIsComposeEmailOpen}
        defaultRecipient={client.email}
        clientName={`${client.first_name} ${client.last_name}`}
        clientId={client.id}
      />
    </div>
  );
};
