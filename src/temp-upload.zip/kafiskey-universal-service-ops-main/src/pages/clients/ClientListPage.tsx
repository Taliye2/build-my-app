import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, MoreHorizontal, User, UserPlus, Power, PowerOff, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { Empty } from '@/components/ui/empty';
import { logAudit } from '@/lib/audit';
import { useAuth } from '@/contexts/AuthContext';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { AddressFields } from '@/components/AddressFields';
import { LoginCredentialsFields } from '@/components/LoginCredentialsFields';
import { Separator } from '@/components/ui/separator';

const createClientSchema = z.object({
  first_name: z.string().min(1, 'First name is required'),
  last_name: z.string().min(1, 'Last name is required'),
  email: z.string().email('Invalid email address').optional().or(z.literal('')),
  phone: z.string().optional(),
  case_number: z.string().optional(),
  dob: z.string().optional(),
  street_address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip_code: z.string().optional(),
  mailing_same_as_physical: z.boolean().default(true),
  mailing_street_address: z.string().optional(),
  mailing_city: z.string().optional(),
  mailing_state: z.string().optional(),
  mailing_zip_code: z.string().optional(),
  saved_username: z.string().optional(),
  saved_password: z.string().optional(),
});

type CreateClientFormValues = z.infer<typeof createClientSchema>;

export interface Client {
  id: string;
  first_name: string;
  last_name: string;
  preferred_name: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  dob: string | null;
  status: 'ACTIVE' | 'PENDING' | 'ON_HOLD' | 'CLOSED' | 'INACTIVE';
  case_number: string | null;
  preferred_contact_method: string | null;
  language_preference: string | null;
  emergency_contact_name: string | null;
  emergency_contact_phone: string | null;
  date_joined: string;
  created_at: string;
  tags: string[] | null;
}

export const ClientListPage: React.FC = () => {
  const { user } = useAuth();
  const { activeWorkspace, activeMember, canAddClient, planLimits, clientCount } = useWorkspace();
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const form = useForm<CreateClientFormValues>({
    resolver: zodResolver(createClientSchema),
    defaultValues: {
      first_name: '',
      last_name: '',
      email: '',
      phone: '',
      case_number: '',
      dob: '',
      street_address: '',
      city: '',
      state: '',
      zip_code: '',
      mailing_same_as_physical: true,
      mailing_street_address: '',
      mailing_city: '',
      mailing_state: '',
      mailing_zip_code: '',
      saved_username: '',
      saved_password: '',
    },
  });

  const canManageStatus = activeMember && ['OWNER', 'ADMIN', 'MANAGER'].includes(activeMember.role);

  const fetchClients = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    // Use 'clients' table
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .eq('workspace_id', activeWorkspace.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Error fetching clients');
    } else {
      setClients(data);
    }
    setLoading(false);
  };

  const handleCreateClient = async (values: CreateClientFormValues) => {
    if (!activeWorkspace) return;

    if (!canAddClient) {
      toast.error('Client limit reached for your current plan. Please upgrade to add more clients.');
      return;
    }

    try {
      const payload: any = {
        ...values,
        workspace_id: activeWorkspace.id,
        status: 'PENDING',
        date_joined: new Date().toISOString().split('T')[0],
        email: values.email || null,
        phone: values.phone || null,
        case_number: values.case_number || null,
        dob: values.dob || null,
      };

      const { data, error } = await supabase.from('clients').insert(payload).select().single();

      if (error) {
        toast.error(error.message);
      } else {
        // Audit Log
        if (user) {
          logAudit(activeWorkspace.id, user.id, 'CLIENT_CREATE', 'client', data.id, { name: `${values.first_name} ${values.last_name}` });
        }

        toast.success('Client created successfully');
        setIsDialogOpen(false);
        fetchClients();
        // Reset form
        form.reset();
      }
    } catch (err: any) {
      toast.error(err.message || 'Error creating client');
    }
  };

  const handleToggleStatus = async (client: Client) => {
    const isCurrentlyActive = client.status === 'ACTIVE';
    const newStatus = isCurrentlyActive ? 'INACTIVE' : 'ACTIVE';
    const actionName = isCurrentlyActive ? 'deactivate' : 'activate';
    
    if (!window.confirm(`Are you sure you want to ${actionName} this client?`)) {
      return;
    }

    const { error } = await supabase
      .from('clients')
      .update({ status: newStatus })
      .eq('id', client.id);

    if (error) {
      toast.error(`Error ${actionName}ing client: ${error.message}`);
    } else {
      // Audit Log
      if (user && activeWorkspace) {
        logAudit(activeWorkspace.id, user.id, 'CLIENT_STATUS_CHANGE', 'client', client.id, { old_status: client.status, new_status: newStatus });
      }

      toast.success(`Client ${actionName}d successfully`);
      // Update local state immediately for optimistic UI
      setClients(prev => prev.map(c => c.id === client.id ? { ...c, status: newStatus as any } : c));
    }
  };

  const filteredClients = clients.filter(c => 
    `${c.first_name} ${c.last_name}`.toLowerCase().includes(search.toLowerCase()) ||
    c.email?.toLowerCase().includes(search.toLowerCase()) ||
    c.tags?.some(t => t.toLowerCase().includes(search.toLowerCase()))
  );

  useEffect(() => {
    fetchClients();
  }, [activeWorkspace]);

  return (
    <div className="space-y-4 animate-fade-in">
      {!canAddClient && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
              <User className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-sm font-bold text-amber-900">Plan Limit Reached</p>
              <p className="text-xs text-amber-700">Your current plan is limited to {planLimits.maxClients} active clients. Upgrade to Growth or Scale for unlimited clients.</p>
            </div>
          </div>
          <Button size="sm" variant="outline" className="border-amber-300 hover:bg-amber-100" asChild>
            <Link to="/billing/plan">Upgrade Plan</Link>
          </Button>
        </div>
      )}

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-1 h-8 bg-brand-gradient rounded-full" />
          <h2 className="text-2xl font-bold tracking-tight bg-brand-gradient bg-clip-text text-transparent">Clients</h2>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative w-72">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search clients..."
              className="pl-8 focus-brand-ring"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button disabled={!canAddClient} variant="brand">
                <Plus className="mr-2 h-4 w-4" />
                Add Client
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Client</DialogTitle>
                <DialogDescription>
                  Enter the client's information to get started. Login credentials and mailing address are optional.
                </DialogDescription>
              </DialogHeader>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleCreateClient)} className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="first_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input {...field} required />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="last_name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input {...field} required />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <LoginCredentialsFields form={form} />

                  <div className="space-y-4 pt-4">
                    <div className="flex items-center gap-4">
                      <Separator className="flex-1" />
                      <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Contact & Location</span>
                      <Separator className="flex-1" />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address (Optional)</FormLabel>
                            <FormControl>
                              <Input type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number (Optional)</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <AddressFields form={form} />
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <FormField
                      control={form.control}
                      name="case_number"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Case Number</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="e.g. CN-12345" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="dob"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date of Birth</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                    <Button type="submit" variant="brand">Create Client</Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
        </Dialog>
        </div>
        </div>

      <div className="rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Tags</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">Loading clients...</TableCell>
              </TableRow>
            ) : filteredClients.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-auto py-12">
                  <Empty 
                    icon={UserPlus}
                    title="No clients found"
                    description="Clients are the foundation of service delivery. Add a client to begin scheduling services and documentation."
                    action={
                      <Button onClick={() => setIsDialogOpen(true)} disabled={!canAddClient}>
                        <Plus className="mr-2 h-4 w-4" />
                        Add First Client
                      </Button>
                    }
                  />
                </TableCell>
              </TableRow>
            ) : (
              filteredClients.map((client) => (
                <TableRow key={client.id}>
                  <TableCell className="font-medium">
                    <Link to={`/clients/${client.id}`} className="flex items-center gap-2 hover:underline text-brand-blue font-bold">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-blue/10 text-brand-blue">
                        <User className="h-4 w-4" />
                      </div>
                      {client.first_name} {client.last_name}
                    </Link>
                  </TableCell>
                  <TableCell>
                    <Badge variant={
                      client.status === 'ACTIVE' ? 'success' : 
                      client.status === 'PENDING' ? 'outline' :
                      client.status === 'ON_HOLD' ? 'secondary' :
                      (client.status === 'CLOSED' || client.status === 'INACTIVE') ? 'destructive' : 'secondary'
                    } className="capitalize">
                      {client.status === 'ACTIVE' ? 'Active' : 
                       client.status === 'PENDING' ? 'Pending' : 
                       client.status === 'ON_HOLD' ? 'On Hold' : 
                       client.status === 'CLOSED' ? 'Closed' :
                       client.status === 'INACTIVE' ? 'Inactive' : client.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1">
                      {client.tags?.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-[10px] px-1 py-0 h-4">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell>{client.email || '-'}</TableCell>
                  <TableCell>{client.phone || '-'}</TableCell>
                  <TableCell>{new Date(client.created_at).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild>
                          <Link to={`/clients/${client.id}`}>
                            <ExternalLink className="mr-2 h-4 w-4" />
                            View Profile
                          </Link>
                        </DropdownMenuItem>
                        {canManageStatus && (
                          <DropdownMenuItem 
                            onClick={() => handleToggleStatus(client)}
                            className={client.status === 'ACTIVE' ? "text-destructive focus:text-destructive" : "text-emerald-600 focus:text-emerald-600 dark:text-emerald-400 dark:focus:text-emerald-400"}
                          >
                            {client.status === 'ACTIVE' ? (
                              <>
                                <PowerOff className="mr-2 h-4 w-4" />
                                Deactivate Client
                              </>
                            ) : (
                              <>
                                <Power className="mr-2 h-4 w-4" />
                                Activate Client
                              </>
                            )}
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};
