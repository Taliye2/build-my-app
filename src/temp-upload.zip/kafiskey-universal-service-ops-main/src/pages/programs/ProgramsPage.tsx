import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/contexts/WorkspaceContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Layers, Calendar, User, CheckCircle2, Circle, Clock, MoreVertical, Trash2, Edit2, ExternalLink, Loader2, Check, ChevronsUpDown, X, ChevronDown, ChevronRight, UserPlus, Milestone, ShieldCheck, ShieldAlert, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { Empty } from '@/components/ui/empty';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { logAudit } from '@/lib/audit';

export type FacilitatorRole = 'LEAD' | 'CO_FACILITATOR' | 'CASE_MANAGER';

export interface Program {
  id: string;
  workspace_id: string;
  name: string;
  description: string | null;
  created_at: string;
  facilitators?: (ProgramFacilitator & { member?: any })[];
  milestones?: ProgramMilestone[];
  enrollments?: (ProgramEnrollment & { clients?: { first_name: string; last_name: string } })[];
}

export interface ProgramFacilitator {
  id: string;
  workspace_id: string;
  program_id: string;
  user_id: string;
  role: FacilitatorRole;
  created_at: string;
}

export interface ProgramMilestone {
  id: string;
  workspace_id: string;
  program_id: string;
  title: string;
  created_at: string;
}

export interface ProgramEnrollment {
  id: string;
  workspace_id: string;
  client_id: string;
  program_id: string;
  name: string;
  start_date: string;
  end_date: string | null;
  status: 'ACTIVE' | 'COMPLETED' | 'ON_HOLD' | 'CANCELLED';
  created_at: string;
  milestones: any[]; // Individual client progress
}

interface ManageProgramDialogProps {
  program: Program;
  onSuccess: () => void;
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
}

const ManageProgramDialog: React.FC<ManageProgramDialogProps> = ({ program, onSuccess, isOpen, onOpenChange }) => {
  const { activeWorkspace } = useWorkspace();
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState(program.name);
  const [description, setDescription] = useState(program.description || '');
  const [milestones, setMilestones] = useState<Partial<ProgramMilestone>[]>(program.milestones || []);
  const [newMilestone, setNewMilestone] = useState('');
  const [teamMembers, setTeamMembers] = useState<any[]>([]);
  const [facilitators, setFacilitators] = useState<Partial<ProgramFacilitator>[]>(program.facilitators || []);

  useEffect(() => {
    if (isOpen) {
      fetchTeamMembers();
      setName(program.name);
      setDescription(program.description || '');
      setMilestones(program.milestones || []);
      setFacilitators(program.facilitators || []);
    }
  }, [isOpen, program]);

  const fetchTeamMembers = async () => {
    if (!activeWorkspace) return;
    const { data } = await supabase
      .from('workspace_members')
      .select('user_id, role, status, full_name')
      .eq('workspace_id', activeWorkspace.id)
      .eq('status', 'active');
    
    if (data) {
      setTeamMembers(data.map(m => ({
        user_id: m.user_id,
        display_name: m.full_name || 'Unknown'
      })));
    }
  };

  const handleUpdate = async () => {
    setLoading(true);
    try {
      // 1. Update Program
      const { error: progError } = await supabase
        .from('programs')
        .update({ name, description })
        .eq('id', program.id);
      
      if (progError) throw progError;

      // 2. Sync Milestones (Simple clear and re-insert for MVP)
      const { error: delMError } = await supabase
        .from('program_milestones')
        .delete()
        .eq('program_id', program.id);
      
      if (delMError) throw delMError;

      if (milestones.length > 0) {
        const { error: insMError } = await supabase
          .from('program_milestones')
          .insert(milestones.map(m => ({
            workspace_id: activeWorkspace?.id,
            program_id: program.id,
            title: m.title
          })));
        if (insMError) throw insMError;
      }

      // 3. Sync Facilitators
      const { error: delFError } = await supabase
        .from('program_facilitators')
        .delete()
        .eq('program_id', program.id);
      
      if (delFError) throw delFError;

      if (facilitators.length > 0) {
        const { error: insFError } = await supabase
          .from('program_facilitators')
          .insert(facilitators.map(f => ({
            workspace_id: activeWorkspace?.id,
            program_id: program.id,
            user_id: f.user_id,
            role: f.role
          })));
        if (insFError) throw insFError;
      }
      
      toast.success('Program details updated');
      onSuccess();
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const addMilestone = () => {
    if (!newMilestone.trim()) return;
    setMilestones([...milestones, { title: newMilestone.trim() }]);
    setNewMilestone('');
  };

  const removeMilestone = (index: number) => {
    setMilestones(milestones.filter((_, i) => i !== index));
  };

  const addFacilitator = (user_id: string) => {
    if (facilitators.some(f => f.user_id === user_id)) return;
    setFacilitators([...facilitators, { user_id, role: 'CO_FACILITATOR' }]);
  };

  const removeFacilitator = (user_id: string) => {
    setFacilitators(facilitators.filter(f => f.user_id !== user_id));
  };

  const updateFacilitatorRole = (user_id: string, role: FacilitatorRole) => {
    setFacilitators(facilitators.map(f => f.user_id === user_id ? { ...f, role } : f));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Manage Program</DialogTitle>
          <DialogDescription>Update program details, facilitators, and milestones.</DialogDescription>
        </DialogHeader>
        <div className="space-y-8 py-4">
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
              <Layers className="h-4 w-4" />
              General Information
            </h4>
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-2">
                <Label>Program Name</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Program objectives and overview..." />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
              <UserPlus className="h-4 w-4" />
              Assigned Facilitators
            </h4>
            <div className="flex gap-2">
              <Select onValueChange={(val) => addFacilitator(val)}>
                <SelectTrigger>
                  <SelectValue placeholder="Add facilitator..." />
                </SelectTrigger>
                <SelectContent>
                  {teamMembers.map(m => (
                    <SelectItem key={m.user_id} value={m.user_id}>{m.display_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              {facilitators.map((f, i) => {
                const member = teamMembers.find(m => m.user_id === f.user_id);
                const displayName = member?.display_name || (f as any).member?.full_name || 'Unknown';
                return (
                  <div key={i} className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-full">
                        <User className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{displayName}</span>
                        <Select value={f.role} onValueChange={(val: FacilitatorRole) => updateFacilitatorRole(f.user_id!, val)}>
                          <SelectTrigger className="h-7 text-[10px] w-32 mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="LEAD">Program Lead</SelectItem>
                            <SelectItem value="CO_FACILITATOR">Co-Facilitator</SelectItem>
                            <SelectItem value="CASE_MANAGER">Case Manager</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => removeFacilitator(f.user_id!)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-2">
              <Milestone className="h-4 w-4" />
              Program Milestones
            </h4>
            <p className="text-xs text-muted-foreground">These milestones are automatically tracked for all enrolled clients.</p>
            <div className="flex gap-2">
              <Input 
                placeholder="e.g. Initial Assessment" 
                value={newMilestone} 
                onChange={(e) => setNewMilestone(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && addMilestone()}
              />
              <Button type="button" size="icon" onClick={addMilestone}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-2">
              {milestones.map((m, i) => (
                <div key={i} className="flex items-center justify-between p-3 border rounded-lg bg-muted/30">
                  <span className="text-sm font-medium">{m.title}</span>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive" onClick={() => removeMilestone(i)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleUpdate} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const ProgramsPage: React.FC = () => {
  const { activeWorkspace, activeMember } = useWorkspace();
  const [programs, setPrograms] = useState<Program[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);
  const [isManageOpen, setIsManageOpen] = useState(false);
  const [isClientPopoverOpen, setIsClientPopoverOpen] = useState(false);
  const [expandedPrograms, setExpandedPrograms] = useState<Set<string>>(new Set());
  const [workspaceMembers, setWorkspaceMembers] = useState<any[]>([]);

  // Deletion state
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleteBlockedOpen, setIsDeleteBlockedOpen] = useState(false);
  const [programToDelete, setProgramToDelete] = useState<Program | null>(null);

  // Form state
  const [selectedClientIds, setSelectedClientIds] = useState<string[]>([]);
  const [targetProgramId, setTargetProgramId] = useState<string>('');
  const [newProgramName, setNewProgramName] = useState('');
  const [startDate, setStartDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [endDate, setEndDate] = useState('');

  const fetchPrograms = async () => {
    if (!activeWorkspace) return;
    setLoading(true);
    try {
      // 1. Fetch workspace members for mapping names
      const { data: members } = await supabase
        .from('workspace_members')
        .select('user_id, full_name')
        .eq('workspace_id', activeWorkspace.id);
      
      setWorkspaceMembers(members || []);

      // 2. Fetch Programs
      const { data: progs, error: progError } = await supabase
        .from('programs')
        .select(`
          *,
          facilitators:program_facilitators(*),
          milestones:program_milestones(*),
          enrollments:program_instances(*, clients(first_name, last_name))
        `)
        .eq('workspace_id', activeWorkspace.id)
        .order('created_at', { ascending: false });

      if (progError) throw progError;

      // Map member info to facilitators
      const mappedProgs = (progs || []).map(p => ({
        ...p,
        facilitators: (p.facilitators || []).map((f: any) => ({
          ...f,
          member: members?.find(m => m.user_id === f.user_id)
        }))
      }));

      setPrograms(mappedProgs);
    } catch (error: any) {
      toast.error('Error fetching programs: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchClients = async () => {
    if (!activeWorkspace) return;
    const { data } = await supabase
      .from('clients')
      .select('id, first_name, last_name')
      .eq('workspace_id', activeWorkspace.id)
      .eq('status', 'ACTIVE');
    
    if (data) setClients(data);
  };

  useEffect(() => {
    fetchPrograms();
    fetchClients();
  }, [activeWorkspace]);

  const toggleProgram = (id: string) => {
    setExpandedPrograms(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleCreateEnrollment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeWorkspace || selectedClientIds.length === 0) return;

    setLoading(true);
    try {
      let programId = targetProgramId;

      // 1. Create program if new
      if (targetProgramId === 'new') {
        const { data: newProg, error: progError } = await supabase
          .from('programs')
          .insert({
            workspace_id: activeWorkspace.id,
            name: newProgramName
          })
          .select()
          .single();
        
        if (progError) throw progError;
        programId = newProg.id;
      }

      const selectedProgramObj = programs.find(p => p.id === programId);
      const programName = selectedProgramObj?.name || newProgramName;

      // 2. Create enrollments
      const records = selectedClientIds.map(clientId => ({
        workspace_id: activeWorkspace.id,
        client_id: clientId,
        program_id: programId,
        name: programName,
        start_date: startDate,
        end_date: endDate || null,
        status: 'ACTIVE',
        milestones: selectedProgramObj?.milestones?.map(m => ({ title: m.title, completed: false })) || []
      }));

      const { error } = await supabase.from('program_instances').insert(records);

      if (error) throw error;

      toast.success(`${selectedClientIds.length} client(s) enrolled in program`);
      setIsDialogOpen(false);
      fetchPrograms();
      // Reset
      setSelectedClientIds([]);
      setTargetProgramId('');
      setNewProgramName('');
      setStartDate(format(new Date(), 'yyyy-MM-dd'));
      setEndDate('');
    } catch (error: any) {
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateEnrollmentStatus = async (enrollmentId: string, status: string) => {
    const { error } = await supabase
      .from('program_instances')
      .update({ status })
      .eq('id', enrollmentId);

    if (error) {
      toast.error('Failed to update status');
    } else {
      toast.success('Enrollment updated');
      fetchPrograms();
    }
  };

  const handleToggleMilestone = async (enrollment: ProgramEnrollment, milestoneIndex: number) => {
    const updatedMilestones = [...enrollment.milestones];
    updatedMilestones[milestoneIndex].completed = !updatedMilestones[milestoneIndex].completed;
    updatedMilestones[milestoneIndex].completedAt = updatedMilestones[milestoneIndex].completed ? new Date().toISOString() : null;

    const { error } = await supabase
      .from('program_instances')
      .update({ milestones: updatedMilestones })
      .eq('id', enrollment.id);

    if (error) {
      toast.error('Failed to update milestone');
    } else {
      fetchPrograms();
    }
  };

  const isOwnerOrAdmin = activeMember?.role === 'OWNER' || activeMember?.role === 'ADMIN';

  const handleDeleteProgram = async () => {
    if (!programToDelete || !activeWorkspace) return;

    const enrollmentCount = programToDelete.enrollments?.length || 0;
    const facilitatorCount = programToDelete.facilitators?.length || 0;
    const milestoneCount = programToDelete.milestones?.length || 0;

    if (enrollmentCount > 0 || facilitatorCount > 0 || milestoneCount > 0) {
      setIsDeleteDialogOpen(false);
      setIsDeleteBlockedOpen(true);
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('programs')
        .delete()
        .eq('id', programToDelete.id);

      if (error) throw error;

      await logAudit(
        activeWorkspace.id,
        activeMember?.user_id,
        'PROGRAM_DELETED',
        'programs',
        programToDelete.id,
        { status: 'success', name: programToDelete.name }
      );

      toast.success('Program deleted');
      fetchPrograms();
      setIsDeleteDialogOpen(false);
      setProgramToDelete(null);
    } catch (error: any) {
      toast.error('Error deleting program: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredPrograms = programs.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.enrollments?.some(e => `${e.clients?.first_name} ${e.clients?.last_name}`.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-3xl font-bold tracking-tight">Program Management</h2>
          <p className="text-muted-foreground">Orchestrate multi-week programs, facilitators, and client progress.</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-brand-gradient border-none shadow-elegant">
              <Plus className="mr-2 h-4 w-4" />
              Enroll Clients
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-xl">
            <DialogHeader>
              <DialogTitle>Program Enrollment</DialogTitle>
              <DialogDescription>
                Enroll clients into an existing program or create a new one.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateEnrollment} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label>Select Client(s)</Label>
                <Popover open={isClientPopoverOpen} onOpenChange={setIsClientPopoverOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={isClientPopoverOpen}
                      className="w-full justify-between font-normal"
                    >
                      <span className="truncate">
                        {selectedClientIds.length > 0
                          ? `${selectedClientIds.length} client(s) selected`
                          : "Choose clients..."}
                      </span>
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[400px] p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search clients..." />
                      <CommandList>
                        <CommandEmpty>No client found.</CommandEmpty>
                        <CommandGroup>
                          <div className="max-h-[300px] overflow-y-auto">
                            {clients.map((client) => {
                              const isSelected = selectedClientIds.includes(client.id);
                              return (
                                <CommandItem
                                  key={client.id}
                                  onSelect={() => {
                                    setSelectedClientIds(prev => 
                                      isSelected
                                        ? prev.filter(id => id !== client.id)
                                        : [...prev, client.id]
                                    );
                                  }}
                                  className="flex items-center gap-2 cursor-pointer"
                                >
                                  <div className={cn(
                                    "flex h-4 w-4 items-center justify-center rounded-sm border border-primary",
                                    isSelected
                                      ? "bg-primary text-primary-foreground"
                                      : "opacity-50 [&_svg]:invisible"
                                  )}>
                                    <Check className={cn("h-4 w-4")} />
                                  </div>
                                  <span>{client.first_name} {client.last_name}</span>
                                </CommandItem>
                              );
                            })}
                          </div>
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label>Select Program</Label>
                <Select value={targetProgramId} onValueChange={setTargetProgramId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose program..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">+ Create New Program</SelectItem>
                    {programs.map(p => (
                      <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {targetProgramId === 'new' && (
                <div className="space-y-2 animate-in slide-in-from-top-2">
                  <Label>New Program Name</Label>
                  <Input 
                    value={newProgramName} 
                    onChange={(e) => setNewProgramName(e.target.value)} 
                    placeholder="e.g. Wellness Workshop"
                    required
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label>End Date (Optional)</Label>
                  <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={loading || selectedClientIds.length === 0 || !targetProgramId}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Confirm Enrollment
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search programs or clients..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {loading && programs.length === 0 ? (
        <div className="flex h-64 items-center justify-center border rounded-lg bg-card/50">
          <Clock className="h-8 w-8 animate-spin text-primary/40" />
        </div>
      ) : filteredPrograms.length === 0 ? (
        <Empty 
          icon={Layers}
          title="No programs found"
          description="Create your first program and enroll clients to start tracking progress."
          action={
            <Button onClick={() => setIsDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Get Started
            </Button>
          }
        />
      ) : (
        <div className="space-y-4">
          {filteredPrograms.map((program) => (
            <div key={program.id} className="border rounded-xl overflow-hidden bg-card hover:border-primary/40 transition-smooth shadow-sm">
              <div 
                className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer hover:bg-muted/30"
                onClick={() => toggleProgram(program.id)}
              >
                <div className="flex items-center gap-4">
                  <div className="bg-primary/10 p-2.5 rounded-lg text-primary">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold">{program.name}</h3>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {program.enrollments?.length || 0} Enrolled
                      </span>
                      <span className="flex items-center gap-1">
                        <ShieldCheck className="h-3 w-3" />
                        {program.facilitators?.length || 0} Facilitators
                      </span>
                      <span className="flex items-center gap-1">
                        <Milestone className="h-3 w-3" />
                        {program.milestones?.length || 0} Milestones
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex -space-x-2 mr-2">
                    {program.facilitators?.slice(0, 3).map((f, i) => {
                      const displayName = f.member?.full_name || 'U';
                      return (
                        <div key={i} className="h-8 w-8 rounded-full bg-muted border-2 border-background flex items-center justify-center text-[10px] font-bold" title={displayName}>
                          {displayName.charAt(0)}
                        </div>
                      );
                    })}
                    {(program.facilitators?.length || 0) > 3 && (
                      <div className="h-8 w-8 rounded-full bg-muted border-2 border-background flex items-center justify-center text-[10px] font-bold">
                        +{(program.facilitators?.length || 0) - 3}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="h-8 gap-2"
                      onClick={() => {
                        setSelectedProgram(program);
                        setIsManageOpen(true);
                      }}
                    >
                      <Edit2 className="h-4 w-4" />
                      Manage
                    </Button>

                    {isOwnerOrAdmin && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem 
                            className="text-destructive focus:text-destructive cursor-pointer"
                            onClick={() => {
                              setProgramToDelete(program);
                              setIsDeleteDialogOpen(true);
                            }}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete Program
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                  
                  {expandedPrograms.has(program.id) ? <ChevronDown className="h-5 w-5 text-muted-foreground" /> : <ChevronRight className="h-5 w-5 text-muted-foreground" />}
                </div>
              </div>

              {expandedPrograms.has(program.id) && (
                <div className="border-t bg-muted/10 p-4 space-y-6 animate-in slide-in-from-top-4 duration-300">
                  <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                    {/* Enrollments / Clients */}
                    <div className="xl:col-span-2 space-y-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-bold uppercase tracking-wider text-foreground/80 flex items-center gap-2">
                          <User className="h-4 w-4 text-primary" />
                          Enrolled Clients
                        </h4>
                      </div>
                      
                      <div className="border rounded-lg bg-card overflow-hidden">
                        <Table>
                          <TableHeader>
                            <TableRow className="bg-muted/50">
                              <TableHead>Client</TableHead>
                              <TableHead>Dates</TableHead>
                              <TableHead>Progress</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {program.enrollments?.map((enrollment) => (
                              <TableRow key={enrollment.id}>
                                <TableCell>
                                  <Link to={`/clients/${enrollment.client_id}`} className="font-medium hover:underline flex items-center gap-2">
                                    <Avatar className="h-7 w-7">
                                      <AvatarFallback className="text-[10px]">{enrollment.clients?.first_name?.charAt(0)}{enrollment.clients?.last_name?.charAt(0)}</AvatarFallback>
                                    </Avatar>
                                    {enrollment.clients?.first_name} {enrollment.clients?.last_name}
                                  </Link>
                                </TableCell>
                                <TableCell>
                                  <div className="text-xs space-y-0.5">
                                    <div className="flex items-center gap-1.5 text-muted-foreground">
                                      <Calendar className="h-3 w-3" />
                                      {format(new Date(enrollment.start_date), 'MMM d, yyyy')}
                                    </div>
                                    {enrollment.end_date && (
                                      <div className="flex items-center gap-1.5 text-muted-foreground">
                                        <Clock className="h-3 w-3" />
                                        {format(new Date(enrollment.end_date), 'MMM d, yyyy')}
                                      </div>
                                    )}
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="space-y-2 max-w-[150px]">
                                    <div className="flex justify-between text-[10px] font-bold">
                                      <span>Milestones</span>
                                      <span>{enrollment.milestones?.filter(m => m.completed).length || 0} / {enrollment.milestones?.length || 0}</span>
                                    </div>
                                    <Progress value={((enrollment.milestones?.filter(m => m.completed).length || 0) / (enrollment.milestones?.length || 1)) * 100} className="h-1.5" />
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <Select 
                                    value={enrollment.status} 
                                    onValueChange={(val) => handleUpdateEnrollmentStatus(enrollment.id, val)}
                                  >
                                    <SelectTrigger className="h-7 text-[10px] w-24">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="ACTIVE">Active</SelectItem>
                                      <SelectItem value="COMPLETED">Completed</SelectItem>
                                      <SelectItem value="ON_HOLD">On Hold</SelectItem>
                                      <SelectItem value="CANCELLED">Cancelled</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </TableCell>
                                <TableCell className="text-right">
                                  <Popover>
                                    <PopoverTrigger asChild>
                                      <Button variant="ghost" size="icon" className="h-8 w-8">
                                        <MoreVertical className="h-4 w-4" />
                                      </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-48 p-0" align="end">
                                      <div className="p-2 space-y-1">
                                        <h5 className="px-2 py-1.5 text-xs font-bold uppercase tracking-wider text-muted-foreground border-b mb-1">Milestones</h5>
                                        {enrollment.milestones?.map((m, idx) => (
                                          <div key={idx} className="flex items-center gap-2 px-2 py-1.5 hover:bg-muted rounded-md cursor-pointer transition-colors" onClick={() => handleToggleMilestone(enrollment, idx)}>
                                            <Checkbox checked={m.completed} readOnly />
                                            <span className={cn("text-xs", m.completed && "line-through text-muted-foreground")}>{m.title}</span>
                                          </div>
                                        ))}
                                        {(!enrollment.milestones || enrollment.milestones.length === 0) && (
                                          <p className="px-2 py-3 text-xs text-center text-muted-foreground italic">No milestones</p>
                                        )}
                                      </div>
                                    </PopoverContent>
                                  </Popover>
                                </TableCell>
                              </TableRow>
                            ))}
                            {(!program.enrollments || program.enrollments.length === 0) && (
                              <TableRow>
                                <TableCell colSpan={5} className="h-24 text-center text-muted-foreground italic">
                                  No clients enrolled in this program yet.
                                </TableCell>
                              </TableRow>
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </div>

                    {/* Facilitators & Details */}
                    <div className="space-y-6">
                      <div className="space-y-3">
                        <h4 className="text-sm font-bold uppercase tracking-wider text-foreground/80 flex items-center gap-2">
                          <ShieldCheck className="h-4 w-4 text-primary" />
                          Facilitators
                        </h4>
                        <div className="space-y-2">
                          {program.facilitators?.map((f, i) => {
                            const displayName = f.member?.full_name || 'Unknown';
                            return (
                              <div key={i} className="flex items-center gap-3 p-3 border rounded-lg bg-card shadow-sm">
                                <Avatar className="h-8 w-8 border">
                                  <AvatarFallback className="text-[10px]">{displayName.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="text-sm font-bold">{displayName}</p>
                                  <p className="text-[10px] font-bold text-primary uppercase tracking-tighter">{f.role.replace('_', ' ')}</p>
                                </div>
                              </div>
                            );
                          })}
                          {(!program.facilitators || program.facilitators.length === 0) && (
                            <p className="text-xs text-muted-foreground italic border-2 border-dashed rounded-lg p-4 text-center">
                              No facilitators assigned.
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="text-sm font-bold uppercase tracking-wider text-foreground/80 flex items-center gap-2">
                          <Milestone className="h-4 w-4 text-primary" />
                          Program Milestones
                        </h4>
                        <div className="space-y-1.5">
                          {program.milestones?.map((m, i) => (
                            <div key={i} className="flex items-center gap-2 text-xs p-2.5 border rounded-lg bg-card">
                              <CheckCircle2 className="h-3.5 w-3.5 text-primary" />
                              {m.title}
                            </div>
                          ))}
                          {(!program.milestones || program.milestones.length === 0) && (
                            <p className="text-xs text-muted-foreground italic border-2 border-dashed rounded-lg p-4 text-center">
                              No milestones defined.
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {selectedProgram && (
        <ManageProgramDialog
          program={selectedProgram}
          isOpen={isManageOpen}
          onOpenChange={setIsManageOpen}
          onSuccess={fetchPrograms}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete program?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <span className="font-bold text-foreground">"{programToDelete?.name}"</span>? 
              This action is permanent and cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={handleDeleteProgram}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Blocked Dialog */}
      <AlertDialog open={isDeleteBlockedOpen} onOpenChange={setIsDeleteBlockedOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Can't delete this program</AlertDialogTitle>
            <AlertDialogDescription>
              This program has enrolled clients, facilitators, or milestones. 
              Please remove them first before deleting the program.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-4 space-y-3">
            <div className="flex items-center justify-between text-sm p-3 border rounded-lg bg-muted/30">
              <span className="flex items-center gap-2">
                <User className="h-4 w-4 text-primary" />
                Enrolled Clients
              </span>
              <span className="font-bold">{programToDelete?.enrollments?.length || 0}</span>
            </div>
            <div className="flex items-center justify-between text-sm p-3 border rounded-lg bg-muted/30">
              <span className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-primary" />
                Facilitators
              </span>
              <span className="font-bold">{programToDelete?.facilitators?.length || 0}</span>
            </div>
            <div className="flex items-center justify-between text-sm p-3 border rounded-lg bg-muted/30">
              <span className="flex items-center gap-2">
                <Milestone className="h-4 w-4 text-primary" />
                Milestones
              </span>
              <span className="font-bold">{programToDelete?.milestones?.length || 0}</span>
            </div>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>Close</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              if (programToDelete) {
                toggleProgram(programToDelete.id);
                setSelectedProgram(programToDelete);
                setIsManageOpen(true);
              }
            }}>
              Go to Manage
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
