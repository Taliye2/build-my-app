import { blink } from './blink';

export interface EmailOptions {
  to: string | string[];
  subject: string;
  html: string;
  workspaceId: string;
  senderIdentity?: 'transactional' | 'campaign';
  campaignId?: string;
  sequenceId?: string;
  userId?: string;
}

export interface EmailResult {
  success: boolean;
  data?: {
    id: string;
  };
  testMode?: boolean;
  warning?: string;
  error?: string;
  action_required?: {
    step1: string;
    step2: string;
    step3: string;
    step4: string;
    note: string;
  };
}

export async function sendEmail(options: EmailOptions): Promise<EmailResult> {
  try {
    const res = await blink.functions.invoke('send-email', {
      body: options,
    }) as any;

    if (res.error) {
      // Handle potential detailed error for domain verification issues or missing fields
      const errorData = res.data as any;
      if (errorData?.action_required) {
        return {
          success: false,
          error: errorData.error || res.error.message || 'Failed to send email',
          action_required: errorData.action_required,
        };
      }
      
      const errorMsg = errorData?.details 
        ? `${errorData.error}: ${errorData.details}` 
        : (errorData?.error || errorData?.message || res.error.message || 'Gateway request failed');

      return {
        success: false,
        error: errorMsg,
      };
    }

    const data = res.data as any;

    // Return full response including testMode and warning if present
    return {
      success: true,
      data: data?.data,
      testMode: data?.testMode,
      warning: data?.warning,
    };
  } catch (error: any) {
    console.error('Error sending email:', error);
    return {
      success: false,
      error: error.message || 'An unexpected error occurred while sending email',
    };
  }
}
