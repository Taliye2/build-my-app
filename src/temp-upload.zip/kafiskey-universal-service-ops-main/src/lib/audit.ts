import { supabase } from './supabase';
import { blink } from './blink';

/**
 * Logs an audit event to the database via Edge Function.
 * Strictly avoids logging any PHI (Protected Health Information).
 */
export async function logAudit(
  workspaceId: string,
  actorUserId: string | null | undefined,
  action: string,
  entityType: string,
  entityId?: string,
  metadata: any = {}
) {
  // Non-blocking call - silently fail if audit logging doesn't work
  (async () => {
    try {
      let finalActorId = actorUserId;
      let finalWorkspaceId = workspaceId;

      // If actor ID is not provided, try to get it from the current session
      if (!finalActorId || finalActorId === '') {
        try {
          const { data: { session } } = await supabase.auth.getSession();
          finalActorId = session?.user?.id;
        } catch (e) {
          // Continue without actor ID
        }
      }

      // If workspaceId is not provided, try to get it from localStorage or member status
      if (!finalWorkspaceId || finalWorkspaceId === '') {
        const storedId = localStorage.getItem('activeWorkspaceId');
        if (storedId) {
          finalWorkspaceId = storedId;
        } else if (finalActorId) {
          try {
            const { data: members } = await supabase
              .from('workspace_members')
              .select('workspace_id')
              .eq('user_id', finalActorId)
              .eq('status', 'active')
              .limit(1);
            
            if (members && members.length > 0) {
              finalWorkspaceId = members[0].workspace_id;
            }
          } catch (e) {
            // Continue without workspace ID
          }
        }
      }

      const isUuid = (id: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id);
      
      if (!finalWorkspaceId || !isUuid(finalWorkspaceId)) {
        // Silently skip if we don't have a valid workspace ID
        return;
      }

      // Call Edge Function for secure logging - best effort, no error thrown
      try {
        await blink.functions.invoke('log-audit-event', {
          body: {
            workspaceId: finalWorkspaceId,
            action,
            entityType,
            entityId,
            metadata
          }
        });
      } catch (invokeErr) {
        // Silently fail - audit logging should not break the app
        // In production, this could be sent to a separate error tracking service
      }
    } catch (err) {
      // Top-level catch - silently ignore
    }
  })();
}
