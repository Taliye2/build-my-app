import bcrypt from 'bcryptjs';

/**
 * Hashes a plaintext password using bcryptjs.
 * @param password The plaintext password to hash
 * @returns The hashed password
 */
export const hashPassword = async (password: string): Promise<string> => {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
};

/**
 * Validates a password against a hash.
 * @param password Plaintext password
 * @param hash Hashed password
 * @returns boolean
 */
export const comparePassword = async (password: string, hash: string): Promise<boolean> => {
  return bcrypt.compare(password, hash);
};
