import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { blink } from './blink';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Create client even with empty strings - will fail gracefully on actual API calls
// This prevents the app from crashing during initial load
export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseAnonKey);

// Helper to check if Supabase is properly configured
export const isSupabaseConfigured = (): boolean => {
  return Boolean(supabaseUrl && supabaseAnonKey);
};

/**
 * Generates a short-lived signed URL for a file via Edge Function for better authorization.
 * @param bucket The storage bucket name
 * @param path The path to the file within the bucket
 * @param expiresIn Time in seconds until the link expires (default 300s / 5m)
 */
export const getSignedUrl = async (bucket: string, path: string, expiresIn: number = 300) => {
  try {
    const response = await blink.functions.invoke('generate-signed-url', {
      body: { bucket, path, expiresIn }
    });

    const { data, error } = response as any;

    if (error) throw error;
    if (data?.error) throw new Error(data.error);

    return data.signedUrl;
  } catch (error) {
    console.error('Error creating signed URL via function:', error);
    
    // Fallback to client-side if function fails, but log warning
    // In production, you might want to force the function path
    const { data, error: storageError } = await supabase.storage
      .from(bucket)
      .createSignedUrl(path, expiresIn);

    if (storageError) throw storageError;
    return data.signedUrl;
  }
};