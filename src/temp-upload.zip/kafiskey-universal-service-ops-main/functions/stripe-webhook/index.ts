import { createClient } from "npm:@supabase/supabase-js";
import Stripe from "npm:stripe@^14.0.0";

export async function handleSubscriptionChange(supabase: any, event: Stripe.Event, workspaceId: string) {
  const data = event.data.object as any;
  let status: string | undefined;
  let subId: string | undefined;
  let customerId: string | undefined;
  let priceId: string | undefined;
  let planKey: string | undefined;
  let trialEndsAt: Date | null = null;
  let currentPeriodEnd: Date | null = null;
  let cancelAtPeriodEnd: boolean | undefined;

  // Extract common fields based on event type
  if (event.type.startsWith("customer.subscription.")) {
    status = data.status;
    subId = data.id;
    customerId = data.customer;
    priceId = data.items.data[0]?.price.id;
    planKey = data.metadata?.plan_key;
    trialEndsAt = data.trial_end ? new Date(data.trial_end * 1000) : null;
    currentPeriodEnd = data.current_period_end ? new Date(data.current_period_end * 1000) : null;
    cancelAtPeriodEnd = data.cancel_at_period_end;
  } else if (event.type === "checkout.session.completed") {
    const isOneTime = data.mode === 'payment';
    status = data.payment_status === "paid" || data.status === "complete" ? (isOneTime ? "active" : "trialing") : "incomplete";
    if (data.subscription) {
      subId = data.subscription as string;
    }
    customerId = data.customer;
    planKey = data.metadata?.plan_key;

    // Handle one-time payment (Launchpad)
    if (isOneTime && planKey === 'launchpad' && status === 'active') {
      await supabase.from("workspaces").update({ 
        is_launchpad: true,
        plan_key: 'scale', // Launchpad includes 3 months of Scale
        plan_status: 'active',
        access_state: 'ACTIVE_PAID',
        // Set trial end to 3 months from now
        trial_ends_at: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString()
      }).eq("id", workspaceId);
      
      console.log(`Workspace ${workspaceId} upgraded to Launchpad`);
      return; // Exit early as we don't have a subId to update 'subscriptions' table
    }
  } else if (event.type === "invoice.payment_succeeded") {
    status = "active";
    subId = data.subscription as string;
    customerId = data.customer;
  } else if (event.type === "invoice.payment_failed") {
    status = "past_due";
    subId = data.subscription as string;
    customerId = data.customer;
  }

  if (subId) {
    // Update subscriptions table
    const updateData: any = {
      workspace_id: workspaceId,
      stripe_subscription_id: subId,
      stripe_customer_id: customerId,
      updated_at: new Date().toISOString(),
    };

    if (status) updateData.status = status;
    if (priceId) updateData.stripe_price_id = priceId;
    if (planKey) updateData.plan_key = planKey;
    if (trialEndsAt) updateData.trial_ends_at = trialEndsAt.toISOString();
    if (currentPeriodEnd) updateData.current_period_end = currentPeriodEnd.toISOString();
    if (cancelAtPeriodEnd !== undefined) updateData.cancel_at_period_end = cancelAtPeriodEnd;

    const { error: subError } = await supabase
      .from("subscriptions")
      .upsert(updateData, { onConflict: "workspace_id" });

    if (subError) console.error("Error updating subscription record:", subError);

    // Also update workspace table for quick access
    const wsUpdate: any = {};
    if (status) wsUpdate.plan_status = status;
    if (planKey) wsUpdate.plan_key = planKey;
    if (customerId) wsUpdate.stripe_customer_id = customerId;
    if (subId) wsUpdate.stripe_subscription_id = subId;
    if (trialEndsAt) wsUpdate.trial_ends_at = trialEndsAt.toISOString();
    
    // Set access_state to ACTIVE_PAID on successful payment or active subscription
    if (status === 'active' || status === 'trialing') {
      wsUpdate.access_state = 'ACTIVE_PAID';
    } else if (status === 'canceled' || status === 'unpaid') {
      wsUpdate.access_state = 'TRIAL_EXPIRED_LOCKED';
    }

    if (Object.keys(wsUpdate).length > 0) {
      await supabase.from("workspaces").update(wsUpdate).eq("id", workspaceId);
    }
  }
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
  const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!stripeSecretKey || !webhookSecret || !supabaseUrl || !supabaseServiceRoleKey) {
    console.error("Missing configuration");
    return new Response("Configuration error", { status: 500 });
  }

  const stripe = new Stripe(stripeSecretKey);
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

  const signature = req.headers.get("stripe-signature");
  if (!signature) {
    return new Response("Missing signature", { status: 400 });
  }

  let event: Stripe.Event;

  try {
    const body = await req.text();
    // Use constructEventAsync for Deno compatibility
    event = await stripe.webhooks.constructEventAsync(body, signature, webhookSecret);
  } catch (err) {
    console.error(`Webhook signature verification failed: ${err.message}`);
    return new Response(`Webhook Error: ${err.message}`, { status: 400 });
  }

  console.log(`Processing event: ${event.type} [${event.id}]`);

  // Check for idempotency
  const { data: existingEvent } = await supabase
    .from("billing_events")
    .select("id")
    .eq("stripe_event_id", event.id)
    .maybeSingle();

  if (existingEvent) {
    console.log(`Event ${event.id} already processed`);
    return new Response(JSON.stringify({ received: true, already_processed: true }), { status: 200 });
  }

  try {
    const data = event.data.object as any;
    let workspaceId = data.metadata?.workspace_id;

    // Handle session completed to get workspaceId from metadata if not in sub metadata
    if (event.type === "checkout.session.completed") {
      workspaceId = data.metadata?.workspace_id;
    } else if (data.subscription) {
      // For subscription events, try to get workspaceId from subscription metadata
      const subscription = await stripe.subscriptions.retrieve(data.subscription as string);
      workspaceId = subscription.metadata?.workspace_id;
    } else if (data.object === "subscription") {
      workspaceId = data.metadata?.workspace_id;
    }

    // Record the event
    await supabase.from("billing_events").insert({
      workspace_id: workspaceId || null,
      stripe_event_id: event.id,
      event_type: event.type,
      payload_json: event,
    });

    if (!workspaceId) {
      console.warn(`No workspace_id found for event ${event.id} (${event.type})`);
      // If we can't find workspaceId but have customer, try to find workspace by customer_id
      if (data.customer) {
        const { data: ws } = await supabase
          .from("workspaces")
          .select("id")
          .eq("stripe_customer_id", data.customer)
          .maybeSingle();
        workspaceId = ws?.id;
      }
    }

    if (workspaceId) {
      await handleSubscriptionChange(supabase, event, workspaceId);
    }

    return new Response(JSON.stringify({ received: true }), { status: 200 });
  } catch (err) {
    console.error(`Error processing webhook event: ${err.message}`);
    return new Response(`Webhook handler error: ${err.message}`, { status: 500 });
  }
}

Deno.serve(handler);