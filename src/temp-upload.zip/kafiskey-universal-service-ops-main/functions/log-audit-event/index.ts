import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      return new Response(JSON.stringify({ error: "Missing config" }), { status: 500, headers: corsHeaders });
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);
    const supabasePublic = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY") || "");

    const { workspaceId, action, entityType, entityId, metadata } = await req.json();

    if (!workspaceId || !action || !entityType) {
      return new Response(JSON.stringify({ error: "Missing parameters" }), { status: 400, headers: corsHeaders });
    }

    // 1. Try to get user from Authorization header (Blink SDK passes it)
    let userId: string | null = null;
    const authHeader = req.headers.get("Authorization");
    
    if (authHeader) {
      try {
        const token = authHeader.replace("Bearer ", "");
        const { data: { user }, error: authError } = await supabasePublic.auth.getUser(token);
        if (!authError && user) {
          userId = user.id;
        }
      } catch (e) {
        // Continue without user ID - audit logging should be best-effort
        console.warn("Failed to authenticate user from token:", e);
      }
    }

    // 2. If we have a userId, validate workspace membership (optional auth enforcement)
    if (userId) {
      const { data: member, error: memberError } = await supabaseAdmin
        .from('workspace_members')
        .select('id')
        .eq('workspace_id', workspaceId)
        .eq('user_id', userId)
        .eq('status', 'active')
        .single();

      if (memberError || !member) {
        // Log but don't reject - workspace is the security boundary
        console.warn(`User ${userId} not in workspace ${workspaceId}, proceeding with audit log`);
      }
    }

    // 3. Clean metadata (prevent PHI logging)
    const whitelist = ['status', 'role', 'method', 'reason', 'type', 'category', 'errorCode'];
    const safeMetadata: any = {
      userAgent: req.headers.get("user-agent"),
      timestamp: new Date().toISOString()
    };

    if (metadata && typeof metadata === 'object') {
      Object.keys(metadata).forEach(key => {
        if (whitelist.includes(key)) {
          safeMetadata[key] = metadata[key];
        }
      });
    }

    // 4. Insert log (best-effort - use NULL for userId if not authenticated)
    const { error: insertError } = await supabaseAdmin.from('audit_logs').insert({
      workspace_id: workspaceId,
      actor_user_id: userId || null,
      action: action.toUpperCase(),
      entity_type: entityType,
      entity_id: entityId,
      metadata: JSON.stringify(safeMetadata)
    });

    if (insertError) throw insertError;

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);
