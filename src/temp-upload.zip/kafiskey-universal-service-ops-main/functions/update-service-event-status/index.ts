import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      return new Response(JSON.stringify({ error: "Missing config" }), { status: 500, headers: corsHeaders });
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);

    // 1. Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), { status: 401, headers: corsHeaders });
    }

    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(authHeader.replace("Bearer ", ""));
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: corsHeaders });
    }

    const { eventId, workspaceId, newStatus, rejectionReason } = await req.json();

    if (!eventId || !workspaceId || !newStatus) {
      return new Response(JSON.stringify({ error: "Missing parameters" }), { status: 400, headers: corsHeaders });
    }

    // 2. Validate workspace membership and role
    const { data: member, error: memberError } = await supabaseAdmin
      .from('workspace_members')
      .select('role')
      .eq('workspace_id', workspaceId)
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single();

    if (memberError || !member) {
      return new Response(JSON.stringify({ error: "Forbidden: Not a member of this workspace" }), { status: 403, headers: corsHeaders });
    }

    // 3. Define permission rules for status transitions
    const isManager = ['OWNER', 'ADMIN', 'MANAGER'].includes(member.role);
    
    // Fetch current event state
    const { data: event, error: eventError } = await supabaseAdmin
      .from('service_events')
      .select('status, staff_user_id')
      .eq('id', eventId)
      .eq('workspace_id', workspaceId)
      .single();

    if (eventError || !event) {
      return new Response(JSON.stringify({ error: "Event not found" }), { status: 404, headers: corsHeaders });
    }

    // Validation logic
    if (newStatus === 'APPROVED' || newStatus === 'REJECTED') {
      if (!isManager) {
        return new Response(JSON.stringify({ error: "Forbidden: Only managers can approve or reject events" }), { status: 403, headers: corsHeaders });
      }
    }

    if (newStatus === 'COMPLETED' || newStatus === 'SUBMITTED') {
      // Allow the person who performed the service or a manager
      if (event.staff_user_id !== user.id && !isManager) {
        return new Response(JSON.stringify({ error: "Forbidden: You cannot submit this event" }), { status: 403, headers: corsHeaders });
      }
    }

    // 4. Perform the update
    const updateData: any = { status: newStatus };
    if (newStatus === 'APPROVED') {
      updateData.approved_by = user.id;
      updateData.approved_at = new Date().toISOString();
    } else if (newStatus === 'REJECTED') {
      updateData.rejection_reason = rejectionReason;
    } else if (newStatus === 'SUBMITTED') {
      updateData.submitted_at = new Date().toISOString();
    }

    const { error: updateError } = await supabaseAdmin
      .from('service_events')
      .update(updateData)
      .eq('id', eventId)
      .eq('workspace_id', workspaceId);

    if (updateError) {
      throw updateError;
    }

    // 5. Log Audit Event
    await supabaseAdmin.from('audit_logs').insert({
      workspace_id: workspaceId,
      actor_user_id: user.id,
      action: `SERVICE_EVENT_${newStatus}`,
      entity_type: 'service_event',
      entity_id: eventId,
      metadata: JSON.stringify({ oldStatus: event.status, newStatus, reason: rejectionReason })
    });

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);
