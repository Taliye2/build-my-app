import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      console.error("[public-workspace] Missing Supabase environment variables");
      return new Response(
        JSON.stringify({ error: "Missing config" }), 
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);

    // Try to get slug from body first, then fallback to URL query for backwards compatibility if needed
    let slug = "";
    if (req.method === "POST") {
      try {
        const body = await req.json();
        slug = body.slug;
      } catch (e) {
        console.warn("[public-workspace] Could not parse JSON body");
      }
    }

    if (!slug) {
      const url = new URL(req.url);
      slug = url.searchParams.get("slug") || "";
    }

    console.log(`[public-workspace] Resolving slug: "${slug}"`);

    if (!slug) {
      return new Response(
        JSON.stringify({ error: "missing_slug" }), 
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Query workspace by slug
    const { data: workspace, error: wsError } = await supabaseAdmin
      .from("workspaces")
      .select("id, name, slug, is_check_in_enabled")
      .eq("slug", slug)
      .single();

    if (wsError || !workspace) {
      console.log(`[public-workspace] Workspace not found for slug: ${slug}`);
      return new Response(
        JSON.stringify({ error: "workspace_not_found", slug }), 
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[public-workspace] Found workspace: ${workspace.id} (${workspace.name})`);

    if (!workspace.is_check_in_enabled) {
      console.log(`[public-workspace] Check-in disabled for workspace: ${workspace.id}`);
      return new Response(
        JSON.stringify({ 
          error: "check_in_disabled",
          workspace_id: workspace.id,
          name: workspace.name,
          slug: workspace.slug,
          is_check_in_enabled: false
        }), 
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ 
        workspace_id: workspace.id,
        name: workspace.name,
        slug: workspace.slug,
        is_check_in_enabled: workspace.is_check_in_enabled
      }), 
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("[public-workspace] Internal error:", error);
    return new Response(
      JSON.stringify({ error: "internal_error", message: error.message }), 
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
}

Deno.serve(handler);