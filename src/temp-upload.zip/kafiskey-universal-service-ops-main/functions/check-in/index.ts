import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      console.error("[check-in] Missing Supabase environment variables");
      return new Response(
        JSON.stringify({ error: "Missing config" }), 
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);

    const body = await req.json();
    const { workspaceSlug, firstName, lastName, phone, locationTag, honeypot, submissionTime } = body;

    console.log(`[check-in] Incoming request for slug: ${workspaceSlug}, name: ${firstName} ${lastName}`);

    // 1. Bot Protection: Honeypot
    if (honeypot) {
      console.warn("[check-in] Honeypot filled, rejecting bot");
      return new Response(JSON.stringify({ error: "Bot detected" }), { status: 400, headers: corsHeaders });
    }

    // 2. Bot Protection: Too fast submission
    const now = Date.now();
    if (submissionTime && now - submissionTime < 1000) {
      console.warn("[check-in] Submission too fast, rejecting bot");
      return new Response(JSON.stringify({ error: "Bot detected" }), { status: 400, headers: corsHeaders });
    }

    // 3. Validation
    if (!workspaceSlug || !firstName || !lastName || !phone) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), { status: 400, headers: corsHeaders });
    }

    // Phone format sanity check (basic)
    const phoneDigits = phone.replace(/[^0-9]/g, '');
    if (phoneDigits.length < 10 || phoneDigits.length > 15) {
      return new Response(JSON.stringify({ error: "Invalid phone number format" }), { status: 400, headers: corsHeaders });
    }

    // 4. Resolve workspaceSlug to workspaceId
    const { data: workspace, error: wsError } = await supabaseAdmin
      .from('workspaces')
      .select('id, name, is_check_in_enabled')
      .eq('slug', workspaceSlug)
      .single();

    if (wsError || !workspace) {
      console.log(`[check-in] Workspace not found for slug: ${workspaceSlug}`);
      return new Response(JSON.stringify({ error: "Workspace not found" }), { status: 404, headers: corsHeaders });
    }

    if (!workspace.is_check_in_enabled) {
      console.log(`[check-in] Check-in disabled for workspace: ${workspace.id}`);
      return new Response(JSON.stringify({ error: "Check-in feature is not enabled for this workspace" }), { status: 403, headers: corsHeaders });
    }

    // 5. Rate limiting / Duplicate prevention (5 minutes)
    const fiveMinutesAgo = new Date(now - 5 * 60 * 1000).toISOString();
    const { data: existing, error: checkError } = await supabaseAdmin
        .from('queue_entries')
        .select('id')
        .eq('workspace_id', workspace.id)
        .eq('phone', phone)
        .eq('status', 'waiting')
        .gt('created_at', fiveMinutesAgo)
        .limit(1);

    if (existing && existing.length > 0) {
        console.log(`[check-in] Duplicate check-in detected for phone: ${phone}`);
        return new Response(JSON.stringify({ success: true, alreadyCheckedIn: true }), { 
            status: 200, 
            headers: { ...corsHeaders, "Content-Type": "application/json" } 
        });
    }

    // 6. Insert queue entry
    const { error: insertError } = await supabaseAdmin.from('queue_entries').insert({
      workspace_id: workspace.id,
      first_name: firstName,
      last_name: lastName,
      phone: phone,
      location_tag: locationTag || null,
      source: 'walk-in-qr'
    });

    if (insertError) {
      console.error("[check-in] Insert error:", insertError);
      throw insertError;
    }

    // 7. Audit Log
    try {
      await supabaseAdmin.from('audit_logs').insert({
        workspace_id: workspace.id,
        actor_user_id: null,
        action: 'QR_CHECK_IN',
        entity_type: 'QUEUE_ENTRY',
        metadata: JSON.stringify({
          firstName,
          lastName,
          phone: phone.substring(phone.length - 4),
          source: 'walk-in-qr',
          locationTag,
          ip: req.headers.get("x-real-ip") || req.headers.get("x-forwarded-for") || "unknown"
        })
      });
    } catch (auditError) {
      console.error("[check-in] Audit log error (non-fatal):", auditError);
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("[check-in] Internal error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);
