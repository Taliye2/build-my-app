import { createClient } from "npm:@supabase/supabase-js";
import { handleSubscriptionChange } from "../shared/webhook-handlers.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!supabaseUrl || !supabaseServiceRoleKey) {
    console.error("Missing configuration");
    return new Response("Configuration error", { status: 500 });
  }

  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

  try {
    const { eventId, provider } = await req.json();

    if (!eventId || !provider) {
      return new Response("Missing eventId or provider", { status: 400 });
    }

    if (provider === "stripe") {
      const { data: eventLog, error: fetchError } = await supabase
        .from("billing_events")
        .select("*")
        .eq("id", eventId)
        .single();

      if (fetchError || !eventLog) {
        return new Response("Event not found", { status: 404 });
      }

      const event = eventLog.payload_json;
      const workspaceId = eventLog.workspace_id;

      if (workspaceId) {
        await handleSubscriptionChange(supabase, event, workspaceId);
        return new Response(JSON.stringify({ success: true, reprocessed: true }), { status: 200 });
      } else {
        return new Response("No workspace_id associated with this event", { status: 400 });
      }
    } else if (provider === "resend") {
      // Reprocess Resend logic (e.g. update campaign logs)
      const { data: eventLog, error: fetchError } = await supabase
        .from("email_events")
        .select("*")
        .eq("id", eventId)
        .single();

      if (fetchError || !eventLog) {
        return new Response("Event not found", { status: 404 });
      }

      const { event_type: type, resend_id: emailId } = eventLog;
      
      const statusMap: Record<string, string> = {
        'email.sent': 'sent',
        'email.delivered': 'delivered',
        'email.delivery_delayed': 'delayed',
        'email.complained': 'complained',
        'email.bounced': 'bounced',
        'email.opened': 'opened',
        'email.clicked': 'clicked',
      };

      const status = statusMap[type];
      if (status && emailId) {
        await supabase
          .from('campaign_logs')
          .update({ status, updated_at: new Date().toISOString() })
          .eq('resend_id', emailId);
          
        return new Response(JSON.stringify({ success: true, reprocessed: true }), { status: 200 });
      }
      
      return new Response("Event not re-processable", { status: 400 });
    }

    return new Response("Unsupported provider", { status: 400 });
  } catch (err) {
    console.error(`Error re-processing webhook: ${err.message}`);
    return new Response(`Error: ${err.message}`, { status: 500 });
  }
}

Deno.serve(handler);
