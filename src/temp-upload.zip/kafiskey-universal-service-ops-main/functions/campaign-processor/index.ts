import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { action, campaignId } = await req.json()

    if (action === 'launch-campaign') {
      if (!campaignId) {
        return new Response(JSON.stringify({ error: 'campaignId is required' }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        })
      }

      // 1. Fetch Campaign
      const { data: campaign, error: campError } = await supabaseClient
        .from('system_campaigns')
        .select('*')
        .eq('id', campaignId)
        .single()

      if (campError || !campaign) {
        return new Response(JSON.stringify({ error: 'Campaign not found' }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 404,
        })
      }

      // 2. Determine Target Workspaces
      let query = supabaseClient.from('workspaces').select('id, name')
      
      if (campaign.target_audience === 'TRIALING') {
        query = query.eq('subscription_status', 'trialing')
      } else if (campaign.target_audience === 'ACTIVE') {
        query = query.eq('subscription_status', 'active')
      } else if (campaign.target_audience === 'EXPIRED') {
        query = query.eq('subscription_status', 'expired')
      }

      const { data: workspaces, error: wsError } = await query
      if (wsError) throw wsError

      // 3. Update status to sending
      await supabaseClient
        .from('system_campaigns')
        .update({ status: 'sending' })
        .eq('id', campaignId)

      const results = []
      let sentCount = 0

      for (const ws of workspaces) {
        // Fetch primary admin for the workspace
        const { data: members, error: memError } = await supabaseClient
          .from('workspace_members')
          .select('user_id')
          .eq('workspace_id', ws.id)
          .eq('role', 'OWNER')
          .limit(1)

        if (memError || !members || members.length === 0) continue

        const ownerId = members[0].user_id

        // Get owner email from auth.users (requires service role)
        // Note: In Supabase edge functions, we can't directly select from auth.users easily without a RPC or using the admin API
        // For now, let's assume we have a staff_profiles or users table that mirrored emails, or we use a custom function
        // Actually, we can use supabaseClient.auth.admin.getUserById(ownerId)
        const { data: { user }, error: userError } = await supabaseClient.auth.admin.getUserById(ownerId)
        
        if (userError || !user || !user.email) continue

        // 4. Send Email
        const personalizedHtml = campaign.content_html
          .replace(/\{\{organization_name\}\}/g, ws.name)
          .replace(/\{\{trial_days_left\}\}/g, '3') // Placeholder or calculated

        // Call our own send-email function or use Resend directly
        const res = await fetch(`${Deno.env.get('SUPABASE_URL')}/functions/v1/send-email`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')}`,
          },
          body: JSON.stringify({
            to: user.email,
            subject: campaign.subject,
            html: personalizedHtml,
            workspaceId: ws.id,
            campaignId: campaignId,
            senderIdentity: 'campaign'
          }),
        })

        if (res.ok) {
          const resData = await res.json()
          sentCount++
          
          // Log it
          await supabaseClient.from('system_campaign_logs').insert({
            campaign_id: campaignId,
            workspace_id: ws.id,
            recipient_email: user.email,
            status: 'sent',
            resend_id: resData.data?.id
          })
        }
      }

      // 5. Finalize stats
      await supabaseClient
        .from('system_campaigns')
        .update({ 
          status: 'completed',
          stats: { ...campaign.stats, sent: sentCount }
        })
        .eq('id', campaignId)

      return new Response(JSON.stringify({ success: true, sent: sentCount }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      })
    }

    if (action === 'check-trials') {
      // Find workspaces with trials ending in 3 days or already expired
      const { data: workspaces, error } = await supabaseClient
        .from('workspaces')
        .select('*')
        .eq('subscription_status', 'trialing')

      if (error) throw error

      const now = new Date()
      const notifications = []

      for (const ws of workspaces) {
        const startDate = new Date(ws.trial_start_date || ws.created_at)
        const diffTime = now.getTime() - startDate.getTime()
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24))
        const daysLeft = 30 - diffDays

        if (daysLeft === 3) {
          // Trigger 3-Day Warning
          notifications.push({
            workspaceId: ws.id,
            type: 'Trial_End_3_Days',
            message: 'Sending 3-day trial warning email'
          })
          
          // In a real app, you'd send an email here via Resend
          console.log(`[Campaign] Sending 3-day warning to ${ws.name}`)
        } else if (daysLeft <= 0) {
          // Trigger Expired
          notifications.push({
            workspaceId: ws.id,
            type: 'Trial_Expired',
            message: 'Updating workspace to expired and sending notification'
          })

          await supabaseClient
            .from('workspaces')
            .update({ subscription_status: 'expired', access_state: 'TRIAL_EXPIRED_LOCKED' })
            .eq('id', ws.id)

          console.log(`[Campaign] Workspace ${ws.name} expired`)
        }
      }

      return new Response(JSON.stringify({ success: true, processed: notifications.length, notifications }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      })
    }

    return new Response(JSON.stringify({ error: 'Invalid action' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    })

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400,
    })
  }
})