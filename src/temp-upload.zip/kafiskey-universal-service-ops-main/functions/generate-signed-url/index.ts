import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      return new Response(JSON.stringify({ error: "Missing config" }), { status: 500, headers: corsHeaders });
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);

    // 1. Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), { status: 401, headers: corsHeaders });
    }

    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(authHeader.replace("Bearer ", ""));
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: corsHeaders });
    }

    const { bucket, path, expiresIn = 300 } = await req.json();

    if (!bucket || !path) {
      return new Response(JSON.stringify({ error: "Missing parameters" }), { status: 400, headers: corsHeaders });
    }

    // 2. Validate Authorization
    // Extract workspaceId from path (assuming folder-based isolation: workspaceId/file)
    const pathParts = path.split('/');
    const potentialWorkspaceId = pathParts[0];

    // Check if it's a UUID
    const isUuid = (id: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id);
    
    if (!isUuid(potentialWorkspaceId)) {
      return new Response(JSON.stringify({ error: "Invalid path format" }), { status: 400, headers: corsHeaders });
    }

    // Check workspace membership
    const { data: member, error: memberError } = await supabaseAdmin
      .from('workspace_members')
      .select('id')
      .eq('workspace_id', potentialWorkspaceId)
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single();

    if (memberError || !member) {
      return new Response(JSON.stringify({ error: "Forbidden: You do not have access to this resource" }), { status: 403, headers: corsHeaders });
    }

    // 3. Generate Signed URL using Service Role
    const { data, error } = await supabaseAdmin.storage
      .from(bucket)
      .createSignedUrl(path, expiresIn);

    if (error) throw error;

    // 4. Log Access (Audit)
    await supabaseAdmin.from('audit_logs').insert({
      workspace_id: potentialWorkspaceId,
      actor_user_id: user.id,
      action: 'SIGNED_URL_GENERATED',
      entity_type: 'document',
      metadata: JSON.stringify({ bucket, path, expiresIn })
    });

    return new Response(JSON.stringify({ signedUrl: data.signedUrl }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);
