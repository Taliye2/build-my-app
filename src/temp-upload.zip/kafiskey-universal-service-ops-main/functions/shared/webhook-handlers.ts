import Stripe from "npm:stripe@^14.0.0";

export async function handleSubscriptionChange(supabase: any, event: Stripe.Event, workspaceId: string) {
  const data = event.data.object as any;
  let status: string | undefined;
  let subId: string | undefined;
  let customerId: string | undefined;
  let priceId: string | undefined;
  let planKey: string | undefined;
  let trialEndsAt: Date | null = null;
  let currentPeriodEnd: Date | null = null;
  let cancelAtPeriodEnd: boolean | undefined;

  // Extract common fields based on event type
  if (event.type.startsWith("customer.subscription.")) {
    status = data.status;
    subId = data.id;
    customerId = data.customer;
    priceId = data.items.data[0]?.price.id;
    planKey = data.metadata?.plan_key;
    trialEndsAt = data.trial_end ? new Date(data.trial_end * 1000) : null;
    currentPeriodEnd = data.current_period_end ? new Date(data.current_period_end * 1000) : null;
    cancelAtPeriodEnd = data.cancel_at_period_end;
  } else if (event.type === "checkout.session.completed") {
    const isOneTime = data.mode === 'payment';
    status = data.payment_status === "paid" || data.status === "complete" ? (isOneTime ? "active" : "trialing") : "incomplete";
    if (data.subscription) {
      subId = data.subscription as string;
    }
    customerId = data.customer;
    planKey = data.metadata?.plan_key;

    // Handle one-time payment (Launchpad)
    if (isOneTime && planKey === 'launchpad' && status === 'active') {
      await supabase.from("workspaces").update({ 
        is_launchpad: true,
        plan_key: 'scale', // Launchpad includes 3 months of Scale
        plan_status: 'active',
        access_state: 'ACTIVE_PAID',
        // Set trial end to 3 months from now
        trial_ends_at: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString()
      }).eq("id", workspaceId);
      
      console.log(`Workspace ${workspaceId} upgraded to Launchpad`);
      return; // Exit early as we don't have a subId to update 'subscriptions' table
    }
  } else if (event.type === "invoice.payment_succeeded") {
    status = "active";
    subId = data.subscription as string;
    customerId = data.customer;
  } else if (event.type === "invoice.payment_failed") {
    status = "past_due";
    subId = data.subscription as string;
    customerId = data.customer;
  }

  if (subId) {
    // Update subscriptions table
    const updateData: any = {
      workspace_id: workspaceId,
      stripe_subscription_id: subId,
      stripe_customer_id: customerId,
      updated_at: new Date().toISOString(),
    };

    if (status) updateData.status = status;
    if (priceId) updateData.stripe_price_id = priceId;
    if (planKey) updateData.plan_key = planKey;
    if (trialEndsAt) updateData.trial_ends_at = trialEndsAt.toISOString();
    if (currentPeriodEnd) updateData.current_period_end = currentPeriodEnd.toISOString();
    if (cancelAtPeriodEnd !== undefined) updateData.cancel_at_period_end = cancelAtPeriodEnd;

    const { error: subError } = await supabase
      .from("subscriptions")
      .upsert(updateData, { onConflict: "workspace_id" });

    if (subError) console.error("Error updating subscription record:", subError);

    // Also update workspace table for quick access
    const wsUpdate: any = {};
    if (status) wsUpdate.plan_status = status;
    if (planKey) wsUpdate.plan_key = planKey;
    if (customerId) wsUpdate.stripe_customer_id = customerId;
    if (subId) wsUpdate.stripe_subscription_id = subId;
    if (trialEndsAt) wsUpdate.trial_ends_at = trialEndsAt.toISOString();
    
    // Set access_state to ACTIVE_PAID on successful payment or active subscription
    if (status === 'active' || status === 'trialing') {
      wsUpdate.access_state = 'ACTIVE_PAID';
    } else if (status === 'canceled' || status === 'unpaid') {
      wsUpdate.access_state = 'TRIAL_EXPIRED_LOCKED';
    }

    if (Object.keys(wsUpdate).length > 0) {
      await supabase.from("workspaces").update(wsUpdate).eq("id", workspaceId);
    }
  }
}
