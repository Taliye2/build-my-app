import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  const url = new URL(req.url);
  let action = url.searchParams.get("action");
  let workspaceId = url.searchParams.get("workspaceId");

  // Also try to get from body if it's a POST request
  if (req.method === "POST") {
    try {
      const body = await req.json();
      action = action || body.action;
      workspaceId = workspaceId || body.workspaceId;
    } catch (e) {
      // Ignore if body is not JSON
    }
  }

  try {
    const clientId = Deno.env.get("QUICKBOOKS_CLIENT_ID");
    const clientSecret = Deno.env.get("QUICKBOOKS_CLIENT_SECRET");
    const redirectUri = Deno.env.get("QUICKBOOKS_REDIRECT_URI");
    const mode = Deno.env.get("QUICKBOOKS_MODE") || "sandbox";

    if (action === "authorize") {
      if (!workspaceId) throw new Error("workspaceId is required");

      const authUrl = new URL(
        mode === "sandbox"
          ? "https://appcenter.intuit.com/connect/oauth2"
          : "https://appcenter.intuit.com/connect/oauth2"
      );
      authUrl.searchParams.set("client_id", clientId!);
      authUrl.searchParams.set("response_type", "code");
      authUrl.searchParams.set("scope", "com.intuit.quickbooks.accounting");
      authUrl.searchParams.set("redirect_uri", redirectUri!);
      authUrl.searchParams.set("state", workspaceId); // Pass workspaceId in state

      return new Response(JSON.stringify({ url: authUrl.toString() }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "callback") {
      const code = url.searchParams.get("code");
      const realmId = url.searchParams.get("realmId");
      const state = url.searchParams.get("state"); // This is our workspaceId

      if (!code || !realmId || !state) {
        throw new Error("Missing code, realmId, or state");
      }

      const tokenResponse = await fetch("https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Authorization": `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
        },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code: code,
          redirect_uri: redirectUri!,
        }),
      });

      const tokens = await tokenResponse.json();
      if (tokens.error) throw new Error(tokens.error_description || tokens.error);

      // Initialize Supabase client
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      const expiresAt = new Date(Date.now() + tokens.expires_in * 1000).toISOString();
      const refreshExpiresAt = new Date(Date.now() + tokens.x_refresh_token_expires_in * 1000).toISOString();

      // Upsert connection
      const { error: upsertError } = await supabase
        .from('quickbooks_connections')
        .upsert({
          workspace_id: state,
          realm_id: realmId,
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          expires_at: expiresAt,
          refresh_token_expires_at: refreshExpiresAt,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'workspace_id'
        });

      if (upsertError) throw upsertError;

      // Redirect back to the app
      const appUrl = Deno.env.get("APP_URL") || "https://kafiskey.com";
      return Response.redirect(`${appUrl}/settings/integrations?connected=1`);
    }

    if (action === "disconnect") {
      if (!workspaceId) throw new Error("workspaceId is required");

      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      // Delete connection
      const { error: deleteError } = await supabase
        .from('quickbooks_connections')
        .delete()
        .eq('workspace_id', workspaceId);

      if (deleteError) throw deleteError;

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "status") {
      if (!workspaceId) throw new Error("workspaceId is required");

      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      const { data, error } = await supabase
        .from('quickbooks_connections')
        .select('realm_id, updated_at')
        .eq('workspace_id', workspaceId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      return new Response(JSON.stringify({ connected: !!data, connection: data }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: any) {
    console.error("QuickBooks OAuth error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);