import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!supabaseUrl || !supabaseServiceRoleKey) {
    console.error("Missing configuration");
    return new Response("Configuration error", { status: 500 });
  }

  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

  try {
    const payload = await req.json();
    const { type, created_at, data } = payload;
    const emailId = data?.email_id || data?.id;

    console.log(`Processing Resend event: ${type} [${emailId}]`);

    // Record the event
    await supabase.from("email_events").insert({
      resend_id: emailId,
      event_type: type,
      payload_json: payload,
      created_at: created_at || new Date().toISOString(),
    });

    // Update campaign logs if it's a campaign email
    if (emailId) {
      const statusMap: Record<string, string> = {
        'email.sent': 'sent',
        'email.delivered': 'delivered',
        'email.delivery_delayed': 'delayed',
        'email.complained': 'complained',
        'email.bounced': 'bounced',
        'email.opened': 'opened',
        'email.clicked': 'clicked',
      };

      const status = statusMap[type];
      if (status) {
        // 1. Update Workspace Campaigns (campaign_logs)
        await supabase
          .from('campaign_logs')
          .update({ status, updated_at: new Date().toISOString() })
          .eq('resend_id', emailId);

        // 2. Update System Campaigns (system_campaign_logs)
        const { data: systemLog, error: sysLogError } = await supabase
          .from('system_campaign_logs')
          .select('campaign_id')
          .eq('resend_id', emailId)
          .maybeSingle();

        if (systemLog) {
          const updates: any = { status };
          if (type === 'email.opened') updates.opened_at = new Date().toISOString();
          if (type === 'email.clicked') updates.clicked_at = new Date().toISOString();

          await supabase
            .from('system_campaign_logs')
            .update(updates)
            .eq('resend_id', emailId);

          // Update stats in system_campaigns
          if (type === 'email.opened' || type === 'email.clicked') {
            const field = type === 'email.opened' ? 'opens' : 'clicks';
            // Use jsonb_set or similar to increment if we were in Postgres
            // Since we're in JS, we'll fetch and update
            const { data: campaign } = await supabase
              .from('system_campaigns')
              .select('stats')
              .eq('id', systemLog.campaign_id)
              .single();

            if (campaign) {
              const newStats = { ...campaign.stats };
              newStats[field] = (newStats[field] || 0) + 1;
              await supabase
                .from('system_campaigns')
                .update({ stats: newStats })
                .eq('id', systemLog.campaign_id);
            }
          }
        }
          
        // Log to audit logs for important events
        if (['email.bounced', 'email.complained'].includes(type)) {
          // Find the workspace_id from campaign_logs
          const { data: log } = await supabase
            .from('campaign_logs')
            .select('workspace_id, user_id, email')
            .eq('resend_id', emailId)
            .maybeSingle();
            
          if (log) {
            await supabase.from('audit_logs').insert({
              workspace_id: log.workspace_id,
              action: type === 'email.bounced' ? 'email_bounced' : 'email_complained',
              entity_type: 'email',
              entity_id: emailId,
              metadata: { email: log.email, user_id: log.user_id }
            });
          }
        }
      }
    }

    return new Response(JSON.stringify({ received: true }), { 
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  } catch (err) {
    console.error(`Error processing Resend webhook: ${err.message}`);
    return new Response(`Webhook handler error: ${err.message}`, { 
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
}

Deno.serve(handler);