import { createClient } from "npm:@supabase/supabase-js";
import Stripe from "npm:stripe@^14.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, x-workspace-id, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const stripeSecretKey = Deno.env.get("STRIPE_SECRET_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const appUrl = Deno.env.get("APP_URL") || "https://kafiskey-saas-app-3r3oth6a.sites.blink.new";

    if (!stripeSecretKey || !supabaseUrl || !supabaseServiceRoleKey) {
      return new Response(
        JSON.stringify({ error: "Missing configuration" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const stripe = new Stripe(stripeSecretKey);
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

    const { workspaceId, planKey, userEmail, priceId: priceIdFromRequest, mode: modeFromRequest } = await req.json();

    if (!workspaceId || (!planKey && !priceIdFromRequest)) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Map plan keys to price IDs
    const priceMap: Record<string, string | undefined> = {
      small: Deno.env.get("STRIPE_PRICE_SMALL"),
      medium: Deno.env.get("STRIPE_PRICE_MEDIUM"),
      large: Deno.env.get("STRIPE_PRICE_LARGE"),
      launchpad: Deno.env.get("STRIPE_PRICE_LAUNCHPAD"),
    };

    const priceId = priceIdFromRequest || priceMap[planKey];
    const mode = modeFromRequest || (planKey === 'launchpad' ? 'payment' : 'subscription');

    if (!priceId || priceId.includes('.') || !priceId.startsWith('price_')) {
      return new Response(
        JSON.stringify({ error: `Invalid plan key or missing price ID for ${planKey}. Please ensure STRIPE_PRICE_${planKey.toUpperCase()} is set to a valid Stripe Price ID (e.g., price_...). Received: ${priceId}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check if workspace already has a customer ID
    const { data: workspace } = await supabase
      .from("workspaces")
      .select("stripe_customer_id, name")
      .eq("id", workspaceId)
      .single();

    let customerId = workspace?.stripe_customer_id;

    if (!customerId && userEmail) {
      // Create a new customer if none exists
      const customer = await stripe.customers.create({
        email: userEmail,
        name: workspace?.name || "Workspace",
        metadata: { workspace_id: workspaceId },
      });
      customerId = customer.id;

      // Update workspace with customer ID
      await supabase
        .from("workspaces")
        .update({ stripe_customer_id: customerId })
        .eq("id", workspaceId);
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : userEmail,
      line_items: [{ price: priceId, quantity: 1 }],
      mode: mode,
      payment_method_collection: "always",
      subscription_data: mode === 'subscription' ? {
        metadata: { workspace_id: workspaceId, plan_key: planKey },
      } : undefined,
      success_url: `${appUrl}/dashboard?session_id={CHECKOUT_SESSION_ID}${planKey === 'launchpad' ? '&launchpad=true' : ''}`,
      cancel_url: `${appUrl}/billing/plan`,
      metadata: { workspace_id: workspaceId, plan_key: planKey },
    });

    return new Response(JSON.stringify({ url: session.url }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);