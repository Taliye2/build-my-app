import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      return new Response(JSON.stringify({ error: "Missing config" }), { status: 500, headers: corsHeaders });
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey);

    // 1. Authenticate user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), { status: 401, headers: corsHeaders });
    }

    const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(authHeader.replace("Bearer ", ""));
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: corsHeaders });
    }

    const { workspaceId, clientId, billingItemIds, startDate, endDate } = await req.json();

    if (!workspaceId || !clientId || (!billingItemIds?.length && (!startDate || !endDate))) {
      return new Response(JSON.stringify({ error: "Missing parameters" }), { status: 400, headers: corsHeaders });
    }

    // 2. Validate workspace membership and plan status
    const { data: workspace, error: wsError } = await supabaseAdmin
      .from('workspaces')
      .select('plan_status, access_state, trial_ends_at')
      .eq('id', workspaceId)
      .single();

    if (wsError || !workspace) {
      return new Response(JSON.stringify({ error: "Workspace not found" }), { status: 404, headers: corsHeaders });
    }

    // Check plan gating (Server-side enforcement)
    const isPaid = workspace.plan_status === 'active' || workspace.access_state === 'ACTIVE_PAID';
    const isTrialActive = (workspace.plan_status === 'trialing' || workspace.plan_status === 'trial' || workspace.access_state === 'TRIAL_ACTIVE') && 
                         (workspace.trial_ends_at ? new Date(workspace.trial_ends_at) > new Date() : true);
    
    if (!isPaid && !isTrialActive) {
      return new Response(JSON.stringify({ error: "Access Denied: Active plan or trial required to generate invoices" }), { status: 403, headers: corsHeaders });
    }

    // Validate user role
    const { data: member, error: memberError } = await supabaseAdmin
      .from('workspace_members')
      .select('role')
      .eq('workspace_id', workspaceId)
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single();

    if (memberError || !member || !['OWNER', 'ADMIN', 'MANAGER'].includes(member.role)) {
      return new Response(JSON.stringify({ error: "Forbidden: Manager role required" }), { status: 403, headers: corsHeaders });
    }

    // 3. Fetch Billing Items
    let query = supabaseAdmin
      .from('billing_items')
      .select('*, service_templates(name)')
      .eq('workspace_id', workspaceId)
      .eq('client_id', clientId)
      .in('billing_status', ['Unbilled', 'Partially Paid', 'unbilled', 'partially paid', 'partial paid', 'partial_paid']);

    if (billingItemIds?.length) {
      query = query.in('id', billingItemIds);
    } else {
      query = query.gte('service_date', startDate).lte('service_date', endDate);
    }

    const { data: items, error: itemsError } = await query;

    if (itemsError || !items?.length) {
      return new Response(JSON.stringify({ error: "No billable items found" }), { status: 400, headers: corsHeaders });
    }

    // 4. Calculate subtotal and generate invoice
    const subtotal = items.reduce((sum, item) => sum + Number(item.line_total), 0);
    const invoiceNumber = `INV-${Date.now().toString().slice(-6)}`;

    const { data: invoice, error: invError } = await supabaseAdmin
      .from('invoices')
      .insert({
        workspace_id: workspaceId,
        client_id: clientId,
        invoice_number: invoiceNumber,
        period_start: startDate || items[0].service_date,
        period_end: endDate || items[items.length - 1].service_date,
        subtotal,
        status: 'Draft'
      })
      .select()
      .single();

    if (invError || !invoice) throw invError;

    // 5. Create Invoice Lines
    const lines = items.map(item => ({
      workspace_id: workspaceId,
      invoice_id: invoice.id,
      description: item.service_templates?.name || 'Service',
      qty: item.quantity,
      rate: item.rate_amount,
      line_total: item.line_total
    }));

    const { error: linesError } = await supabaseAdmin.from('invoice_lines').insert(lines);
    if (linesError) throw linesError;

    // 6. Update Billing Items
    const { error: updateError } = await supabaseAdmin
      .from('billing_items')
      .update({ billing_status: 'Invoiced', invoice_id: invoice.id })
      .in('id', items.map(i => i.id));
    
    if (updateError) throw updateError;

    // 7. Log Audit Event
    await supabaseAdmin.from('audit_logs').insert({
      workspace_id: workspaceId,
      actor_user_id: user.id,
      action: 'INVOICE_CREATED',
      entity_type: 'invoice',
      entity_id: invoice.id,
      metadata: JSON.stringify({ invoice_number: invoiceNumber, subtotal, client_id: clientId })
    });

    return new Response(JSON.stringify({ success: true, invoiceId: invoice.id }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);
