import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, content-type",
};

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const { workspaceId, payrollItems, period } = await req.json();

    if (!workspaceId || !payrollItems) {
      return new Response(JSON.stringify({ error: "Missing required data" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    const mode = Deno.env.get("QUICKBOOKS_MODE") || "sandbox";
    const qbBaseUrl = mode === "sandbox" 
      ? "https://sandbox-quickbooks.api.intuit.com" 
      : "https://quickbooks.api.intuit.com";

    // 1. Get QuickBooks Connection
    const { data: qb, error: qbError } = await supabase
      .from('quickbooks_connections')
      .select('*')
      .eq('workspace_id', workspaceId)
      .single();

    if (qbError || !qb) {
      return new Response(JSON.stringify({ error: "QuickBooks not connected" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 2. Refresh Token if needed
    const now = new Date();
    const expiresAt = new Date(qb.expires_at);
    if (now >= expiresAt) {
      console.log("Refreshing QuickBooks token...");
      const clientId = Deno.env.get("QUICKBOOKS_CLIENT_ID");
      const clientSecret = Deno.env.get("QUICKBOOKS_CLIENT_SECRET");

      const tokenResponse = await fetch("https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Authorization": `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
        },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          refresh_token: qb.refresh_token,
        }),
      });

      const tokens = await tokenResponse.json();
      if (tokens.error) throw new Error(`Refresh failed: ${tokens.error_description || tokens.error}`);

      const newExpiresAt = new Date(Date.now() + tokens.expires_in * 1000).toISOString();
      const newRefreshExpiresAt = new Date(Date.now() + tokens.x_refresh_token_expires_in * 1000).toISOString();

      const { error: updateError } = await supabase
        .from('quickbooks_connections')
        .update({
          access_token: tokens.access_token,
          refresh_token: tokens.refresh_token,
          expires_at: newExpiresAt,
          refresh_token_expires_at: newRefreshExpiresAt,
          updated_at: new Date().toISOString()
        })
        .eq('workspace_id', workspaceId);

      if (updateError) throw updateError;

      qb.access_token = tokens.access_token;
    }

    // 3. Sync to QuickBooks (Create Journal Entry)
    const totalAmount = payrollItems.reduce((acc: number, item: any) => acc + item.total_amount, 0);
    
    // Fetch Accounts
    const accountsResponse = await fetch(`${qbBaseUrl}/v3/company/${qb.realm_id}/query?query=select * from Account where AccountType='Expense' or AccountType='Bank'`, {
      headers: {
        "Authorization": `Bearer ${qb.access_token}`,
        "Accept": "application/json",
      },
    });
    
    const accountsData = await accountsResponse.json();
    const accounts = accountsData.QueryResponse?.Account || [];
    
    const expenseAccount = accounts.find((a: any) => a.Name.toLowerCase().includes("payroll")) || accounts.find((a: any) => a.AccountType === "Expense");
    const bankAccount = accounts.find((a: any) => a.AccountType === "Bank");
    
    if (!expenseAccount || !bankAccount) {
      throw new Error("Could not find suitable accounts in QuickBooks (Expense and Bank required)");
    }

    const journalEntry = {
      Line: [
        {
          Description: `Payroll for period ${period}`,
          Amount: totalAmount,
          DetailType: "JournalEntryLineDetail",
          JournalEntryLineDetail: {
            PostingType: "Debit",
            AccountRef: {
              value: expenseAccount.Id,
              name: expenseAccount.Name,
            }
          }
        },
        {
          Description: `Payroll for period ${period}`,
          Amount: totalAmount,
          DetailType: "JournalEntryLineDetail",
          JournalEntryLineDetail: {
            PostingType: "Credit",
            AccountRef: {
              value: bankAccount.Id,
              name: bankAccount.Name,
            }
          }
        }
      ]
    };

    const qbResponse = await fetch(`${qbBaseUrl}/v3/company/${qb.realm_id}/journalentry`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${qb.access_token}`,
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify(journalEntry),
    });

    const qbResult = await qbResponse.json();
    if (qbResult.Fault) {
      throw new Error(qbResult.Fault.Error[0].Message);
    }

    return new Response(JSON.stringify({ success: true, journalEntryId: qbResult.JournalEntry.Id }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("QuickBooks sync error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);