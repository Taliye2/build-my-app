import { createClient } from "npm:@supabase/supabase-js";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, x-workspace-id, content-type",
};

// Centralized email configuration from environment variables
const RESEND_FROM_EMAIL = Deno.env.get("RESEND_FROM_EMAIL") || "invites@kafiskey.com";
const RESEND_FROM_NAME = Deno.env.get("RESEND_FROM_NAME") || "Kafiskey";
const REQUIRED_DOMAIN = "kafiskey.com";

// Resend's testing email for accounts without verified domains
const RESEND_TESTING_EMAIL = "onboarding@resend.dev";
const RESEND_TESTING_NAME = "Kafiskey (Test Mode)";

// Validate the from email uses the verified domain
function validateFromEmail(email: string): boolean {
  return email.toLowerCase().endsWith(`@${REQUIRED_DOMAIN}`);
}

// Mask email for logging (show first 2 chars + domain)
function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!domain) return '***@***';
  return `${local.slice(0, 2)}***@${domain}`;
}

// Check if error is a domain verification error
function isDomainVerificationError(errorMessage: string): boolean {
  return errorMessage.includes('testing emails to your own email') || 
         errorMessage.includes('verify a domain') ||
         errorMessage.includes('onboarding@resend.dev');
}

async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  // Handle GET request for testing email configuration
  if (req.method === "GET") {
    const url = new URL(req.url);
    const action = url.searchParams.get("action");
    
    if (action === "test") {
      const testEmail = url.searchParams.get("email");
      const globalResendApiKey = Deno.env.get("RESEND_API_KEY");
      
      if (!globalResendApiKey) {
        return new Response(
          JSON.stringify({ error: "RESEND_API_KEY not configured" }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      if (!testEmail) {
        return new Response(
          JSON.stringify({ 
            error: "Missing email parameter",
            usage: "GET ?action=test&email=yourtest@gmail.com",
            config: {
              fromEmail: RESEND_FROM_EMAIL,
              fromName: RESEND_FROM_NAME,
              verifiedDomain: REQUIRED_DOMAIN,
              isValid: validateFromEmail(RESEND_FROM_EMAIL)
            }
          }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      if (!validateFromEmail(RESEND_FROM_EMAIL)) {
        return new Response(
          JSON.stringify({ 
            error: `RESEND_FROM_EMAIL must use @${REQUIRED_DOMAIN} domain`,
            currentValue: RESEND_FROM_EMAIL
          }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      // Send a test email
      try {
        const res = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${globalResendApiKey}`,
          },
          body: JSON.stringify({
            from: `${RESEND_FROM_NAME} <${RESEND_FROM_EMAIL}>`,
            to: testEmail,
            subject: "Kafiskey Email Test - Configuration Verified",
            html: `
              <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #0D9488;">✅ Email Configuration Verified</h2>
                <p>This test email confirms that your Resend configuration is working correctly.</p>
                <ul style="background: #f4f4f5; padding: 16px; border-radius: 8px;">
                  <li><strong>From Name:</strong> ${RESEND_FROM_NAME}</li>
                  <li><strong>From Email:</strong> ${RESEND_FROM_EMAIL}</li>
                  <li><strong>Verified Domain:</strong> ${REQUIRED_DOMAIN}</li>
                  <li><strong>Sent At:</strong> ${new Date().toISOString()}</li>
                </ul>
                <hr style="border: none; border-top: 1px solid #eee; margin: 32px 0;" />
                <p style="color: #999; font-size: 12px;">&copy; ${new Date().getFullYear()} Kafiskey Universal Service Ops</p>
              </div>
            `,
          }),
        });
        
        let resData;
        try {
          const text = await res.text();
          resData = text ? JSON.parse(text) : {};
        } catch (e) {
          resData = { message: "Invalid response from Resend API" };
        }
        
        if (!res.ok) {
          console.error(`[EMAIL_TEST_FAILED] To: ${maskEmail(testEmail)} | Error: ${resData.message || 'Unknown'}`);
          return new Response(
            JSON.stringify({ success: false, error: resData.message || "Resend API error" }),
            { status: res.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        console.log(`[EMAIL_TEST_SUCCESS] To: ${maskEmail(testEmail)} | ID: ${resData.id}`);
        return new Response(
          JSON.stringify({ 
            success: true, 
            message: `Test email sent to ${maskEmail(testEmail)}`,
            emailId: resData.id,
            config: {
              fromEmail: RESEND_FROM_EMAIL,
              fromName: RESEND_FROM_NAME
            }
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      } catch (error) {
        console.error(`[EMAIL_TEST_ERROR] ${error.message}`);
        return new Response(
          JSON.stringify({ success: false, error: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }
    
    // Return config status for GET without action
    return new Response(
      JSON.stringify({
        status: "ok",
        config: {
          fromEmail: RESEND_FROM_EMAIL,
          fromName: RESEND_FROM_NAME,
          verifiedDomain: REQUIRED_DOMAIN,
          isValidConfig: validateFromEmail(RESEND_FROM_EMAIL)
        },
        testEndpoint: "GET ?action=test&email=yourtest@gmail.com"
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const globalResendApiKey = Deno.env.get("RESEND_API_KEY");

    // Startup validation: ensure RESEND_FROM_EMAIL uses verified domain
    if (!validateFromEmail(RESEND_FROM_EMAIL)) {
      console.error(`[EMAIL_CONFIG_ERROR] RESEND_FROM_EMAIL "${RESEND_FROM_EMAIL}" does not use verified domain @${REQUIRED_DOMAIN}`);
      return new Response(
        JSON.stringify({ error: `Email sender must use @${REQUIRED_DOMAIN} domain. Current: ${RESEND_FROM_EMAIL}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!supabaseUrl || !supabaseServiceRoleKey) {
      return new Response(
        JSON.stringify({ error: "Missing configuration" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);
    const body = await req.json();
    const { 
      to, 
      subject, 
      html, 
      workspaceId, 
      senderIdentity = 'transactional',
      campaignId,
      campaignName,
      sequenceId,
      userId,
      useTestMode = false, // New option to force test mode
    } = body;

    if (!to || !subject || !html || !workspaceId) {
      const missing = [];
      if (!to) missing.push("to");
      if (!subject) missing.push("subject");
      if (!html) missing.push("html");
      if (!workspaceId) missing.push("workspaceId");
      
      return new Response(
        JSON.stringify({ 
          error: "Missing required fields", 
          details: `Missing: ${missing.join(", ")}`,
          received: Object.keys(body)
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch workspace settings for API key and sender identity
    const { data: workspace, error: wsError } = await supabase
      .from('workspaces')
      .select('resend_api_key, email_sender_name, email_sender_address, email_reply_to, is_email_verified')
      .eq('id', workspaceId)
      .single();

    if (wsError || !workspace) {
      return new Response(
        JSON.stringify({ error: "Workspace not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate if the workspace API key looks like a real Resend key (starts with re_)
    const workspaceKey = workspace.resend_api_key;
    const isWorkspaceKeyValid = workspaceKey && workspaceKey.trim().startsWith('re_');
    
    // Use workspace key if valid, otherwise fallback to global key
    const resendApiKey = isWorkspaceKeyValid ? workspaceKey : globalResendApiKey;
    
    if (!isWorkspaceKeyValid && workspaceKey) {
      console.warn(`[EMAIL_API_KEY_WARNING] Workspace ${workspaceId} has an invalid API key format. Falling back to global key.`);
    }
    
    // Determine which from address and name to use
    let fromName = workspace.email_sender_name || RESEND_FROM_NAME;
    let fromAddress = RESEND_FROM_EMAIL;
    let replyTo = workspace.email_reply_to || workspace.email_sender_address;

    // If they have their own API key and it's verified (or we allow it), we could use their sender address
    // But per instructions: "Default mode: emails still send through Kafiskey infrastructure, but Reply-To = workspace email and visible “From Name” is workspace name."
    if (isWorkspaceKeyValid && workspace.email_sender_address && workspace.is_email_verified) {
      fromAddress = workspace.email_sender_address;
    }

    if (useTestMode) {
      fromName = RESEND_TESTING_NAME;
      fromAddress = RESEND_TESTING_EMAIL;
    }

    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: "Resend API key not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // First attempt with configured domain
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify({
        from: `${fromName} <${fromAddress}>`,
        to,
        subject,
        html,
        reply_to: replyTo,
      }),
    });

    let resData;
    try {
      const text = await res.text();
      resData = text ? JSON.parse(text) : {};
    } catch (e) {
      resData = { message: "Invalid response from Resend API" };
    }
    const recipientMasked = typeof to === 'string' ? maskEmail(to) : to.map(maskEmail).join(', ');

    let retryRes, retryData; // Declare retry variables here

    // Check if this is a domain verification error and we haven't already tried test mode
    if (!res.ok && isDomainVerificationError(resData.message || '') && !useTestMode) {
      console.warn(`[EMAIL_DOMAIN_NOT_VERIFIED] Attempting fallback with Resend test email`);
      
      // Retry with Resend's testing email
      retryRes = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${resendApiKey}`,
        },
        body: JSON.stringify({
          from: `${RESEND_TESTING_NAME} <${RESEND_TESTING_EMAIL}>`,
          to,
          subject: `[TEST MODE] ${subject}`,
          reply_to: replyTo,
          html: `
            <div style="background: #fef3c7; border: 1px solid #f59e0b; padding: 12px; margin-bottom: 16px; border-radius: 8px;">
              <strong>⚠️ Test Mode:</strong> This email was sent using Resend's test sender. 
              To use your custom domain (${REQUIRED_DOMAIN}), please verify it at 
              <a href="https://resend.com/domains">resend.com/domains</a>.
            </div>
            ${html}
          `,
        }),
      });

      try {
        const text = await retryRes.text();
        retryData = text ? JSON.parse(text) : {};
      } catch (e) {
        retryData = { message: "Invalid response from Resend API (retry)" };
      }

      if (retryRes.ok) {
        console.log(`[EMAIL_SENT_TEST_MODE] Recipient: ${recipientMasked} | Subject: "${subject}" | ID: ${retryData.id}`);
        
        if (campaignId && userId) {
          await supabase.from('campaign_logs').insert({
            campaign_id: campaignId,
            sequence_id: sequenceId,
            workspace_id: workspaceId,
            user_id: userId,
            email: typeof to === 'string' ? to : to[0],
            status: 'sent',
            resend_id: retryData.id,
          });
        }

        return new Response(JSON.stringify({ 
          success: true, 
          data: retryData,
          testMode: true,
          warning: `Email sent using test mode. To use ${REQUIRED_DOMAIN}, verify your domain at https://resend.com/domains`
        }), {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Both attempts failed - provide detailed guidance
      console.error(`[EMAIL_SEND_FAILED] Both primary and test mode failed. Primary error: ${resData.message}`);
      return new Response(
        JSON.stringify({ 
          error: "Email sending failed - domain not verified",
          details: resData.message,
          action_required: {
            step1: "Go to https://resend.com/domains",
            step2: `Add and verify the domain: ${REQUIRED_DOMAIN}`,
            step3: "Add the DNS records provided by Resend to your domain",
            step4: "Wait for verification (usually 5-30 minutes)",
            note: "Once verified, emails will be sent from your custom domain."
          }
        }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (res.ok && campaignId && userId) {
      await supabase.from('campaign_logs').insert({
        campaign_id: campaignId,
        sequence_id: sequenceId,
        workspace_id: workspaceId,
        user_id: userId,
        email: typeof to === 'string' ? to : to[0],
        status: 'sent',
        resend_id: resData.id,
      });
    }

    // Use the effective response for logging (either primary or retry)
    const effectiveRes = (typeof retryRes !== 'undefined') ? retryRes : res;
    const effectiveData = (typeof retryData !== 'undefined') ? retryData : resData;

    // Always log to emails_sent for activity tracking
    try {
      await supabase.from('emails_sent').insert({
        workspace_id: workspaceId,
        recipient: typeof to === 'string' ? to : (Array.isArray(to) ? to[0] : to),
        subject: subject,
        template_name: campaignName ? `Campaign: ${campaignName}` : (senderIdentity === 'campaign' ? 'Campaign Email' : 'Transactional Email'),
        sender_email: fromAddress,
        status: effectiveRes.ok ? 'sent' : 'failed',
        sent_at: effectiveRes.ok ? new Date().toISOString() : null,
        error_message: effectiveRes.ok ? null : (effectiveData.message || 'Unknown error')
      });
    } catch (logError) {
      console.error(`[LOG_ERROR] Failed to log to emails_sent: ${logError.message}`);
    }

    if (!res.ok) {
      // Enhanced runtime logging for email failures
      console.error(`[EMAIL_SEND_FAILED] Recipient: ${recipientMasked} | Subject: "${subject}" | From: ${fromAddress} | Error: ${resData.message || 'Unknown error'} | Status: ${res.status}`);
      return new Response(
        JSON.stringify({ error: resData.message || "Failed to send email" }),
        { status: res.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`[EMAIL_SENT] Recipient: ${recipientMasked} | Subject: "${subject}" | From: ${fromAddress} | ID: ${resData.id}`);
    return new Response(JSON.stringify({ success: true, data: resData }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error(`[EMAIL_ERROR] ${error.message}`);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
}

Deno.serve(handler);